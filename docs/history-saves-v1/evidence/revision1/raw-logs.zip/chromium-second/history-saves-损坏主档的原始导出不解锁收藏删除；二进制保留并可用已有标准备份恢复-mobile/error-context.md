# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: history-saves.spec.ts >> 损坏主档的原始导出不解锁收藏删除；二进制保留并可用已有标准备份恢复
- Location: e2e/history-saves.spec.ts:98:1

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 0
Received:    -1
```

# Page snapshot

```yaml
- main "游戏首页与存档馆" [ref=f2e4]:
  - generic [ref=f2e5]:
    - generic [aria-hidden] [ref=f2e6]: 黑
    - generic [ref=f2e7]:
      - text: 黑金王朝
      - generic [ref=f2e8]: HEIJINWANGCHAO
    - button "设置" [ref=f2e9] [cursor=pointer]
    - generic [ref=f2e10]: V1.0 Beta
  - generic [ref=f2e11]:
    - paragraph [ref=f2e12]: MODERN CITY / OPEN WORLD
    - heading "黑金王朝" [level=1] [ref=f2e13]
    - paragraph [ref=f2e14]: 起点有冲突，人生不预设结局。
  - status "终点 未知，时刻 08:13，已选择" [ref=f2e15]:
    - generic [ref=f2e16]:
      - text: 终点
      - generic [ref=f2e17]: DEST
    - generic [ref=f2e18]:
      - generic [ref=f2e19]: 未
      - generic [ref=f2e20]: 知
    - generic [ref=f2e22]:
      - generic [ref=f2e23]: "0"
      - generic [ref=f2e24]: "8"
      - generic [ref=f2e25]: ":"
      - generic [ref=f2e26]: "1"
      - generic [ref=f2e27]: "3"
    - generic [ref=f2e28]: 已选择
  - generic [ref=f2e29]:
    - generic [ref=f2e30]: 车票 02
    - generic [ref=f2e31]: 本地保存 · 无需账号
    - button "导入备份" [ref=f2e32] [cursor=pointer]: ⤓ 导入备份
    - button "刷新列表" [ref=f2e33] [cursor=pointer]
  - region "车票栏，左右方向键切换" [ref=f2e34]:
    - article "其他人生，保存于 2026/11/17 08:13，已选择" [ref=f2e36]:
      - generic [ref=f2e37]:
        - generic [ref=f2e38]: ARCHIVE 01
        - generic [ref=f2e40]:
          - generic [ref=f2e41]:
            - generic [ref=f2e42]:
              - generic [ref=f2e43]: FROM
              - generic [ref=f2e44]: 其他人生
            - generic [aria-hidden] [ref=f2e45]: 单程
            - generic [ref=f2e47]: TO
          - generic [ref=f2e49]:
            - generic [ref=f2e50]:
              - term [ref=f2e51]: 保存日期
              - definition [ref=f2e52]: 2026/11/17
            - generic [ref=f2e53]:
              - term [ref=f2e54]: 时刻
              - definition [ref=f2e55]: 08:13
            - generic [ref=f2e56]:
              - generic [aria-hidden]:
                - text: 已检票
                - generic: SELECTED
          - paragraph [ref=f2e57]: 从未备份
      - generic [ref=f2e76]:
        - text: 继续游戏
        - generic [ref=f2e77]: ↓ 按住票根往下撕
    - article "无法读取的存档：测试存档，保存于 2026/11/17 08:13" [ref=f2e80]:
      - generic [ref=f2e81]:
        - generic [ref=f2e82]:
          - generic [ref=f2e83]: 未知
          - generic [ref=f2e84]: UNREADABLE
          - generic [ref=f2e85]: ARCHIVE 02
        - generic [ref=f2e86]:
          - generic [ref=f2e88]:
            - generic [ref=f2e89]: FROM
            - generic [ref=f2e90]: 测试存档
          - paragraph [ref=f2e91]: 存档记录 ID：save-a
          - paragraph [ref=f2e92]: 当前版本无法读取这条记录。其他存档不受影响；可先导出主存档原始数据。原始数据导出不包含手动历史收藏。有关联收藏时禁止删除，请保留本机数据并联系维护者恢复。
        - generic [aria-hidden]: 无法读取
      - generic [ref=f2e93]: 保存时间无法读取
    - article "空白车票：开启新的人生" [ref=f2e97]:
      - generic [ref=f2e98]:
        - generic [ref=f2e99]:
          - generic [ref=f2e100]: 空白车票
          - generic [ref=f2e101]: NEW LIFE
          - generic [ref=f2e102]: NEW
        - generic [ref=f2e103]:
          - generic [ref=f2e104]:
            - generic [ref=f2e105]:
              - generic [ref=f2e106]: FROM
              - generic [ref=f2e107]: ？
            - generic [aria-hidden] [ref=f2e108]: 单程
            - generic [ref=f2e110]:
              - generic [ref=f2e111]: TO
              - generic [ref=f2e112]: ？
          - generic [ref=f2e113]:
            - generic [ref=f2e114]:
              - term [ref=f2e115]: 城市
              - definition [ref=f2e116]
            - generic [ref=f2e118]:
              - term [ref=f2e119]: 职业
              - definition [ref=f2e120]
            - generic [ref=f2e122]:
              - term [ref=f2e123]: 存档
              - definition [ref=f2e124]: —
          - paragraph [ref=f2e125]: 四座城市 · 自由职业 · 开放人生
      - generic [ref=f2e127]:
        - text: 开启新的人生
        - generic [ref=f2e128]: ↓ 按住票根往下撕
  - navigation "车票页码" [ref=f2e130]:
    - button "第 1 张" [ref=f2e131] [cursor=pointer]
    - button "第 2 张" [ref=f2e132] [cursor=pointer]
    - button "第 3 张，空白车票" [ref=f2e133] [cursor=pointer]
  - generic [ref=f2e134]:
    - button "继续游戏" [ref=f2e135] [cursor=pointer]:
      - text: 继续游戏
      - generic [aria-hidden] [ref=f2e136]: →
    - generic [ref=f2e137]:
      - button "历史存档" [ref=f2e138] [cursor=pointer]
      - button "导出备份" [ref=f2e139] [cursor=pointer]
      - button "删除" [ref=f2e140] [cursor=pointer]
  - generic [ref=f2e141]:
    - group "游玩信息" [ref=f2e142]:
      - button "游玩须知与免责声明" [ref=f2e143] [cursor=pointer]
      - button "王朝公告" [ref=f2e144] [cursor=pointer]
    - paragraph [ref=f2e145]: 四座城市 · 自由职业 · 开放人生三阶段生成 · 原子结算 · 连续回合
```

# Test source

```ts
  28  |     config.routes.story = { channelId: channel.id, modelId: 'story' };
  29  |     for (const stage of ['variables', 'world', 'memory']) config.routes[stage] = { mode: 'independent', channelId: channel.id, modelId: stage };
  30  |     saveAiConfig(localStorage, config); new CredentialVault(sessionStorage, localStorage).set(channel.id, 'synthetic-history-key');
  31  |   }, turns);
  32  |   await page.reload();
  33  | }
  34  | async function read(page: Page) {
  35  |   return page.evaluate(async () => {
  36  |     const p = '/src/services/storage/saveRepository.ts', { SaveRepository } = await import(p), repo = await SaveRepository.open();
  37  |     try { return { ...await repo.loadGame('save-a'), raw: await repo.exportRaw('save-a'), history: await repo.history.list('save-a'), undo: await repo.undoStatus('save-a') }; }
  38  |     finally { repo.close(); }
  39  |   });
  40  | }
  41  | async function open(page: Page) {
  42  |   if ((page.viewportSize()?.width ?? 1440) > 900) {
  43  |     await expect(page.locator('.home-experience')).toBeVisible();
  44  |     const button = page.getByRole('button', { name: '存档馆', exact: true });
  45  |     if (await button.isVisible()) await button.click();
  46  |   }
  47  |   await page.getByRole('button', { name: '历史存档', exact: true }).click();
  48  |   await expect(page.getByRole('dialog', { name: '历史存档', exact: true })).toBeVisible();
  49  |   await expect(page.getByText('正在读取历史元数据…')).toHaveCount(0);
  50  | }
  51  | async function mock(page: Page) {
  52  |   const calls: string[] = [], control = { failStory: false };
  53  |   await page.route('https://history.mock.invalid/**', async route => {
  54  |     const stage = String(route.request().postDataJSON().model); calls.push(stage);
  55  |     const state = (await read(page)).state;
  56  |     const text = stage === 'story' ? control.failStory ? '<正文>不完整' : '<thinking>继续当前选择。</thinking><正文>【旁白】主角来到公园，沿着小路慢慢散步。</正文><短期记忆>在公园散步。</短期记忆><变量规划>[]</变量规划>'
  57  |       : stage === 'variables' ? `<thinking>记录时间。</thinking><说明>时间经过。</说明><命令>\nset worldClock = "${new Date(Date.parse(state.worldClock) + 60000).toISOString()}"\n</命令>`
  58  |         : JSON.stringify({ worldCommands: [], taskCommands: [], eventCommands: [], visibleHooks: [], unresolved: [] });
  59  |     await route.fulfill({ contentType: stage === 'story' ? 'text/event-stream' : 'application/json', body: stage === 'story'
  60  |       ? `data: ${JSON.stringify({ choices: [{ delta: { content: text } }] })}\n\ndata: ${JSON.stringify({ choices: [{ delta: {}, finish_reason: 'stop' }] })}\n\ndata: [DONE]\n\n`
  61  |       : JSON.stringify({ choices: [{ message: { content: text }, finish_reason: 'stop' }] }) });
  62  |   });
  63  |   return { calls, control };
  64  | }
  65  | async function choose(page: Page, turn: number) {
  66  |   await page.getByRole('button', { name: `预览第 ${turn} 回合`, exact: true }).click();
  67  |   await expect(page.getByText(`只读历史 · 第 ${turn} 回合结束。`, { exact: false })).toBeVisible();
  68  | }
  69  | async function confirm(page: Page) {
  70  |   await page.getByLabel('从此历史节点开始的行动').fill('改去公园走走');
  71  |   await page.getByRole('button', { name: '发送新行动（先确认覆盖）', exact: true }).click();
  72  |   await page.getByRole('button', { name: '确认覆盖并继续', exact: true }).click();
  73  | }
  74  | 
  75  | // Include every store and binary byte: JSON.stringify(ArrayBuffer) alone would hide data loss.
  76  | async function recoverySnapshot(page: Page) {
  77  |   return page.evaluate(async () => {
  78  |     const p = '/src/services/storage/idb.ts', { request, transaction } = await import(p);
  79  |     const db: IDBDatabase = await request(indexedDB.open('heijinwangchao'));
  80  |     function binary(value: unknown): unknown {
  81  |       if (value instanceof ArrayBuffer) return { arrayBuffer: Array.from(new Uint8Array(value)) };
  82  |       if (Array.isArray(value)) return value.map(binary);
  83  |       if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, part]) => [key, binary(part)]));
  84  |       return value;
  85  |     }
  86  |     try {
  87  |       return await transaction(db, Array.from(db.objectStoreNames), 'readonly', async (tx: IDBTransaction) => {
  88  |         const result: Record<string, { keys: IDBValidKey[]; values: unknown[] }> = {};
  89  |         for (const name of Array.from(db.objectStoreNames)) result[name] = {
  90  |           keys: await request(tx.objectStore(name).getAllKeys()), values: binary(await request(tx.objectStore(name).getAll())) as unknown[],
  91  |         };
  92  |         return result;
  93  |       });
  94  |     } finally { db.close(); }
  95  |   });
  96  | }
  97  | 
  98  | test('损坏主档的原始导出不解锁收藏删除；二进制保留并可用已有标准备份恢复', async ({ page }, info) => {
  99  |   await seed(page, 2); const server = await mock(page); await open(page);
  100 |   await page.getByRole('button', { name: '保存当前正式节点' }).click();
  101 |   await page.getByLabel('历史收藏名称').fill('不可丢失的收藏');
  102 |   await page.getByRole('button', { name: '保存收藏', exact: true }).click();
  103 |   await expect(page.locator('.history-node-list')).toContainText('不可丢失的收藏');
  104 |   const original = await read(page);
  105 |   expect(original.history.nodes.find((n: { kind: string }) => n.kind === 'manual')).toBeTruthy();
  106 |   const savedDownload = page.waitForEvent('download'); await page.getByRole('button', { name: '导出节点备份' }).click();
  107 |   const backupPath = (await (await savedDownload).path())!;
  108 |   await page.getByRole('button', { name: '关闭资料界面' }).click();
  109 |   const savedId = await page.evaluate(async () => {
  110 |     const rp = '/src/services/storage/saveRepository.ts', ip = '/src/services/storage/idb.ts';
  111 |     const { SaveRepository } = await import(rp), { request, transaction } = await import(ip), repo = await SaveRepository.open();
  112 |     try {
  113 |       const state = await repo.load('save-a'), other = { ...state, saveId: 'save-b', title: '其他人生' };
  114 |       await repo.importBackup({ state: other }, (await repo.compareBackup({ state: other })).confirmation);
  115 |       await repo.history.create('save-b', '另一份收藏');
  116 |       const node = (await repo.history.list('save-a')).nodes.find((n: { kind: string }) => n.kind === 'manual');
  117 |       const db: IDBDatabase = await request(indexedDB.open('heijinwangchao'));
  118 |       try { await transaction(db, ['saves'], 'readwrite', async (tx: IDBTransaction) => {
  119 |         await request(tx.objectStore('saves').put({ ...state, schemaVersion: 999 }));
  120 |       }); } finally { db.close(); }
  121 |       return node.id;
  122 |     } finally { repo.close(); }
  123 |   });
  124 |   await page.reload();
  125 |   if (info.project.name === 'desktop') await page.getByRole('button', { name: '存档馆', exact: true }).click();
  126 |   else {
  127 |     const index = await page.locator('.mh-ticket-wrap').evaluateAll(items => items.findIndex(item => item.textContent?.includes('存档记录 ID：save-a')));
> 128 |     expect(index).toBeGreaterThanOrEqual(0);
      |                   ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  129 |     await page.getByRole('navigation', { name: '车票页码' }).getByRole('button').nth(index).click();
  130 |   }
  131 |   const card = info.project.name === 'desktop' ? page.locator('.save-card.bad') : page.locator('.mh-ticket-wrap[aria-current=true]');
  132 |   await expect(card).toContainText('原始数据导出不包含手动历史收藏');
  133 |   const before = await recoverySnapshot(page);
  134 |   const payload = before.historyPayloads.values.find((row: { saveId?: string }) => row.saveId === 'save-a');
  135 |   expect(payload.payload.encoding).toBe('gzip'); expect(payload.payload.data.arrayBuffer.length).toBeGreaterThan(0);
  136 |   const pending = page.waitForEvent('download'); await page.getByRole('button', { name: '导出原始数据', exact: true }).click();
  137 |   const raw = JSON.parse(await readFile((await (await pending).path())!, 'utf8'));
  138 |   expect(raw.version).toBe(1); expect(raw.records.saves[0].value.schemaVersion).toBe(999);
  139 |   expect(raw.records).not.toHaveProperty('historyPayloads');
  140 |   await expect(page.getByRole('status').filter({ hasText: '已发起主存档原始数据下载' })).toContainText('不含手动历史收藏');
  141 |   await page.screenshot({ path: info.outputPath('unreadable-export-warning.png') });
  142 |   expect(await recoverySnapshot(page)).toEqual(before);
  143 |   await page.getByRole('button', { name: '删除存档', exact: true }).click();
  144 |   const dialog = page.getByRole('dialog', { name: '删除这份存档？', exact: true });
  145 |   await expect(dialog).toContainText('有关联收藏时禁止删除');
  146 |   await dialog.getByRole('button', { name: '确认删除', exact: true }).click();
  147 |   await expect(dialog.getByRole('alert')).toContainText('已阻止删除');
  148 |   await expect(dialog.getByRole('alert')).toContainText('本次未删除任何数据');
  149 |   expect(await recoverySnapshot(page)).toEqual(before); expect(server.calls).toEqual([]);
  150 |   await page.screenshot({ path: info.outputPath('unreadable-delete-protected.png') });
  151 |   await dialog.getByRole('button', { name: '取消', exact: true }).click();
  152 |   await page.reload(); expect(await recoverySnapshot(page)).toEqual(before);
  153 |   // A verified backup saved BEFORE damage can repair the main record using the existing import flow.
  154 |   // The raw rescue JSON above is deliberately NOT represented as an importable collection backup.
  155 |   await page.getByRole('button', { name: '导入备份', exact: true }).click();
  156 |   const importer = page.locator('dialog.backup-import-dialog');
  157 |   await importer.locator('input[type=file]').setInputFiles(backupPath);
  158 |   await expect(importer).toContainText('本机记录无法读取');
  159 |   await importer.getByRole('button', { name: '覆盖并导入', exact: true }).click();
  160 |   await expect(importer).toContainText('已导入');
  161 |   await importer.getByRole('button', { name: '关闭', exact: true }).click();
  162 |   const after = await recoverySnapshot(page);
  163 |   expect(after.historyMetadata).toEqual(before.historyMetadata); expect(after.historyPayloads).toEqual(before.historyPayloads);
  164 |   for (const store of ['saves', 'drafts', 'turnReceipts', 'turnUndo', 'saveControls']) {
  165 |     const rows = (data: typeof before) => data[store].values.filter((row: { saveId?: string }) => row.saveId === 'save-b');
  166 |     expect(rows(after)).toEqual(rows(before));
  167 |   }
  168 |   const restored = await page.evaluate(async id => {
  169 |     const p = '/src/services/storage/saveRepository.ts', { SaveRepository } = await import(p), repo = await SaveRepository.open();
  170 |     try { const preview = await repo.history.preview('save-a', { kind: 'manual', id }); repo.history.release(preview.confirmation); return preview.state; }
  171 |     finally { repo.close(); }
  172 |   }, savedId);
  173 |   expect(restored).toEqual(original.state); expect(server.calls).toEqual([]);
  174 |   await page.screenshot({ path: info.outputPath('unreadable-recovered.png') });
  175 | });
  176 | 
  177 | test('自动五节点只读预览、取消覆盖、旧链不变、日夜与窄屏截图', async ({ page }, info) => {
  178 |   await seed(page); const server = await mock(page), before = await read(page); await open(page);
  179 |   await expect(page.locator('.history-node-list > li')).toHaveCount(5);
  180 |   await page.screenshot({ path: info.outputPath('automatic-night.png') });
  181 |   await choose(page, 2); await page.getByLabel('历史阅读内容').selectOption('人物档案');
  182 |   await expect(page.locator('.history-world')).toContainText(before.state.protagonist.name);
  183 |   await page.getByLabel('历史阅读内容').selectOption('正文');
  184 |   await page.getByLabel('从此历史节点开始的行动').fill('取消的选择');
  185 |   await page.getByRole('button', { name: '发送新行动（先确认覆盖）' }).click();
  186 |   await expect(page.getByLabel('覆盖时间线确认')).toContainText('第 3～7 回合');
  187 |   await page.screenshot({ path: info.outputPath('overwrite-warning.png') });
  188 |   await page.getByRole('button', { name: '取消，保留原进度' }).click();
  189 |   expect(await read(page)).toEqual(before); expect(server.calls).toEqual([]);
  190 |   await page.evaluate(() => { document.documentElement.dataset.appearance = 'day'; });
  191 |   await page.setViewportSize(info.project.name === 'mobile' ? { width: 375, height: 667 } : { width: 901, height: 600 });
  192 |   const contrast = await settingsTextContrast(page.locator('dialog.history-saves'));
  193 |   expect(contrast.rows.length).toBeGreaterThan(0);
  194 |   expect(contrast.failures).toEqual([]);
  195 |   expect(contrast.controlFailures).toEqual([]);
  196 |   await writeFile(info.outputPath('day-contrast.json'), JSON.stringify(contrast, null, 2));
  197 |   await page.screenshot({ path: info.outputPath('preview-day-narrow.png') });
  198 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  199 |   await page.getByRole('button', { name: '关闭资料界面' }).click(); await open(page);
  200 |   expect(await read(page)).toEqual(before); expect(server.calls).toEqual([]);
  201 | });
  202 | 
  203 | test('手动收藏命名重开改名删除，完整状态导出，确认后单次三阶段且连续推进两回合', async ({ page }, info) => {
  204 |   await seed(page); const server = await mock(page); await open(page);
  205 |   await page.getByRole('button', { name: '保存当前正式节点' }).click();
  206 |   await page.getByLabel('历史收藏名称').fill('重要谈判前'); await page.getByRole('button', { name: '保存收藏', exact: true }).click();
  207 |   await expect(page.locator('.history-node-list')).toContainText('重要谈判前');
  208 |   const saved = await read(page); expect(saved.history.nodes.filter((n: { kind: string }) => n.kind === 'manual')).toHaveLength(1);
  209 |   await page.reload(); await open(page); await page.getByRole('button', { name: '手动收藏', exact: true }).click();
  210 |   await page.getByRole('button', { name: '重命名', exact: true }).click(); await page.getByLabel('历史收藏名称').fill('谈判前收藏');
  211 |   await page.getByRole('button', { name: '保存名称', exact: true }).click(); await expect(page.locator('.history-node-list')).toContainText('谈判前收藏');
  212 |   const downloaded = page.waitForEvent('download'); await page.getByRole('button', { name: '导出节点备份' }).click();
  213 |   expect((await downloaded).suggestedFilename()).toContain('.heijin.json');
  214 |   await page.getByRole('button', { name: '自动历史', exact: true }).click(); await choose(page, 2); await confirm(page);
  215 |   await expect(page.locator('.game-layout')).toBeVisible(); await expect.poll(async () => (await read(page)).state.turnNumber).toBe(3);
  216 |   expect(server.calls).toEqual(['story', 'variables', 'world']); expect((await read(page)).undo.available).toBe(1);
  217 |   await page.getByLabel('你的行动', { exact: true }).fill('继续去公园散步'); await page.getByRole('button', { name: '发送', exact: true }).click();
  218 |   await expect.poll(async () => (await read(page)).state.turnNumber).toBe(4);
  219 |   expect(server.calls).toEqual(['story', 'variables', 'world', 'story', 'variables', 'world']);
  220 |   const fresh = await read(page); expect(fresh.undo.available).toBe(2); expect(fresh.raw.records.turnReceipts).toHaveLength(2);
  221 |   expect(fresh.history.nodes.find((n: { kind: string }) => n.kind === 'manual').oldTimeline).toBe(true);
  222 |   await page.reload(); expect((await read(page)).state).toEqual(fresh.state); expect(server.calls).toHaveLength(6);
  223 |   await page.goto('/'); await open(page); await page.getByRole('button', { name: '手动收藏', exact: true }).click();
  224 |   await expect(page.locator('.history-node-list')).toContainText('旧时间线收藏'); await page.screenshot({ path: info.outputPath('old-timeline-collection.png') });
  225 |   await page.getByRole('button', { name: '删除收藏', exact: true }).click(); await page.getByRole('button', { name: '保留收藏', exact: true }).click();
  226 |   expect((await read(page)).history.nodes.filter((n: { kind: string }) => n.kind === 'manual')).toHaveLength(1);
  227 |   await page.getByRole('button', { name: '删除收藏', exact: true }).click(); await page.getByRole('button', { name: '确认删除收藏', exact: true }).click();
  228 |   await expect(page.getByText('尚未保存手动收藏。')).toBeVisible(); expect((await read(page)).state).toEqual(fresh.state);
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: history-saves.spec.ts >> 损坏主档的原始导出不解锁收藏删除；二进制保留并可用已有标准备份恢复
- Location: e2e/history-saves.spec.ts:98:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.click: Test timeout of 60000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '导入备份', exact: true })

```

# Page snapshot

```yaml
- main [ref=f3e4]:
  - region "游戏首页" [ref=f3e5]:
    - generic [ref=f3e7]:
      - text: SHANGHAI · 31°14′N
      - generic [ref=f3e8]: 外滩 · 霓虹 · 江风
    - generic [aria-hidden] [ref=f3e9]: 上海
    - generic [ref=f3e10]:
      - generic [ref=f3e11]:
        - generic [aria-hidden] [ref=f3e12]: 黑
        - generic [ref=f3e13]:
          - text: 黑金王朝
          - generic [ref=f3e14]: HEIJINWANGCHAO
      - button "存档馆" [ref=f3e15] [cursor=pointer]
      - button "设置" [ref=f3e16] [cursor=pointer]
      - generic [ref=f3e17]: V1.0 Beta
    - generic [ref=f3e18]:
      - paragraph [ref=f3e19]: MODERN CITY / OPEN WORLD
      - heading "黑金王朝" [level=1] [ref=f3e20]
      - paragraph [ref=f3e21]: 起点有冲突，人生不预设结局。
      - paragraph [ref=f3e22]: 一款 AI 驱动的现代都市开放世界文字角色扮演游戏。在熟悉的城市里，写下属于你的人生。
      - generic [ref=f3e23]:
        - button "开始新游戏" [ref=f3e24] [cursor=pointer]:
          - text: 开始新游戏
          - generic [aria-hidden] [ref=f3e25]: ↗
        - button "继续游戏 其他人生 · 保存于 2026/11/17 08:13" [ref=f3e26] [cursor=pointer]:
          - generic [ref=f3e27]: 继续游戏
          - generic [ref=f3e28]: 其他人生 · 保存于 2026/11/17 08:13
          - generic [aria-hidden] [ref=f3e29]: →
        - button "存档馆02" [ref=f3e30] [cursor=pointer]
      - group "游玩信息" [ref=f3e31]:
        - button "游玩须知与免责声明" [ref=f3e32] [cursor=pointer]
        - button "王朝公告" [ref=f3e33] [cursor=pointer]
    - generic [ref=f3e34]:
      - generic [ref=f3e35]:
        - generic [ref=f3e36]: 四座城市 · 自由职业 · 开放人生
        - generic [ref=f3e37]: 三阶段生成 · 原子结算 · 连续回合
      - navigation "封面城市" [ref=f3e38]:
        - button "重庆" [ref=f3e39] [cursor=pointer]
        - button "上海" [pressed] [ref=f3e40] [cursor=pointer]
        - button "哈尔滨" [ref=f3e41] [cursor=pointer]
        - button "广州" [ref=f3e42] [cursor=pointer]
```

# Test source

```ts
  55  |     const state = (await read(page)).state;
  56  |     const text = stage === 'story' ? control.failStory ? '<正文>不完整' : '<thinking>继续当前选择。</thinking><正文>【旁白】主角来到公园，沿着小路慢慢散步。</正文><短期记忆>在公园散步。</短期记忆><变量规划>[]</变量规划>'
  57  |       : stage === 'variables' ? `<thinking>记录时间。</thinking><说明>时间经过。</说明><命令>\nset worldClock = "${new Date(Date.parse(state.worldClock) + 60000).toISOString()}"\n</命令>`
  58  |         : JSON.stringify({ worldCommands: [], taskCommands: [], eventCommands: [], visibleHooks: [], unresolved: [] });
  59  |     await route.fulfill({ contentType: stage === 'story' ? 'text/event-stream' : 'application/json', body: stage === 'story'
  60  |       ? `data: ${JSON.stringify({ choices: [{ delta: { content: text } }] })}\n\ndata: ${JSON.stringify({ choices: [{ delta: {}, finish_reason: 'stop' }] })}\n\ndata: [DONE]\n\n`
  61  |       : JSON.stringify({ choices: [{ message: { content: text }, finish_reason: 'stop' }] }) });
  62  |   });
  63  |   return { calls, control };
  64  | }
  65  | async function choose(page: Page, turn: number) {
  66  |   await page.getByRole('button', { name: `预览第 ${turn} 回合`, exact: true }).click();
  67  |   await expect(page.getByText(`只读历史 · 第 ${turn} 回合结束。`, { exact: false })).toBeVisible();
  68  | }
  69  | async function confirm(page: Page) {
  70  |   await page.getByLabel('从此历史节点开始的行动').fill('改去公园走走');
  71  |   await page.getByRole('button', { name: '发送新行动（先确认覆盖）', exact: true }).click();
  72  |   await page.getByRole('button', { name: '确认覆盖并继续', exact: true }).click();
  73  | }
  74  | 
  75  | // Include every store and binary byte: JSON.stringify(ArrayBuffer) alone would hide data loss.
  76  | async function recoverySnapshot(page: Page) {
  77  |   return page.evaluate(async () => {
  78  |     const p = '/src/services/storage/idb.ts', { request, transaction } = await import(p);
  79  |     const db: IDBDatabase = await request(indexedDB.open('heijinwangchao'));
  80  |     function binary(value: unknown): unknown {
  81  |       if (value instanceof ArrayBuffer) return { arrayBuffer: Array.from(new Uint8Array(value)) };
  82  |       if (Array.isArray(value)) return value.map(binary);
  83  |       if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, part]) => [key, binary(part)]));
  84  |       return value;
  85  |     }
  86  |     try {
  87  |       return await transaction(db, Array.from(db.objectStoreNames), 'readonly', async (tx: IDBTransaction) => {
  88  |         const result: Record<string, { keys: IDBValidKey[]; values: unknown[] }> = {};
  89  |         for (const name of Array.from(db.objectStoreNames)) result[name] = {
  90  |           keys: await request(tx.objectStore(name).getAllKeys()), values: binary(await request(tx.objectStore(name).getAll())) as unknown[],
  91  |         };
  92  |         return result;
  93  |       });
  94  |     } finally { db.close(); }
  95  |   });
  96  | }
  97  | 
  98  | test('损坏主档的原始导出不解锁收藏删除；二进制保留并可用已有标准备份恢复', async ({ page }, info) => {
  99  |   await seed(page, 2); const server = await mock(page); await open(page);
  100 |   await page.getByRole('button', { name: '保存当前正式节点' }).click();
  101 |   await page.getByLabel('历史收藏名称').fill('不可丢失的收藏');
  102 |   await page.getByRole('button', { name: '保存收藏', exact: true }).click();
  103 |   await expect(page.locator('.history-node-list')).toContainText('不可丢失的收藏');
  104 |   const original = await read(page);
  105 |   expect(original.history.nodes.find((n: { kind: string }) => n.kind === 'manual')).toBeTruthy();
  106 |   const savedDownload = page.waitForEvent('download'); await page.getByRole('button', { name: '导出节点备份' }).click();
  107 |   const backupPath = (await (await savedDownload).path())!;
  108 |   await page.getByRole('button', { name: '关闭资料界面' }).click();
  109 |   const savedId = await page.evaluate(async () => {
  110 |     const rp = '/src/services/storage/saveRepository.ts', ip = '/src/services/storage/idb.ts';
  111 |     const { SaveRepository } = await import(rp), { request, transaction } = await import(ip), repo = await SaveRepository.open();
  112 |     try {
  113 |       const state = await repo.load('save-a'), other = { ...state, saveId: 'save-b', title: '其他人生' };
  114 |       await repo.importBackup({ state: other }, (await repo.compareBackup({ state: other })).confirmation);
  115 |       await repo.history.create('save-b', '另一份收藏');
  116 |       const node = (await repo.history.list('save-a')).nodes.find((n: { kind: string }) => n.kind === 'manual');
  117 |       const db: IDBDatabase = await request(indexedDB.open('heijinwangchao'));
  118 |       try { await transaction(db, ['saves'], 'readwrite', async (tx: IDBTransaction) => {
  119 |         await request(tx.objectStore('saves').put({ ...state, schemaVersion: 999 }));
  120 |       }); } finally { db.close(); }
  121 |       return node.id;
  122 |     } finally { repo.close(); }
  123 |   });
  124 |   await page.reload();
  125 |   if (info.project.name === 'desktop') await page.getByRole('button', { name: '存档馆', exact: true }).click();
  126 |   else {
  127 |     const index = await page.locator('.mh-ticket-wrap').evaluateAll(items => items.findIndex(item => item.textContent?.includes('存档记录 ID：save-a')));
  128 |     expect(index).toBeGreaterThanOrEqual(0);
  129 |     await page.getByRole('navigation', { name: '车票页码' }).getByRole('button').nth(index).click();
  130 |   }
  131 |   const card = info.project.name === 'desktop' ? page.locator('.save-card.bad') : page.locator('.mh-ticket-wrap[aria-current=true]');
  132 |   await expect(card).toContainText('原始数据导出不包含手动历史收藏');
  133 |   const before = await recoverySnapshot(page);
  134 |   const payload = before.historyPayloads.values.find((row: { saveId?: string }) => row.saveId === 'save-a');
  135 |   expect(payload.payload.encoding).toBe('gzip'); expect(payload.payload.data.arrayBuffer.length).toBeGreaterThan(0);
  136 |   const pending = page.waitForEvent('download'); await page.getByRole('button', { name: '导出原始数据', exact: true }).click();
  137 |   const raw = JSON.parse(await readFile((await (await pending).path())!, 'utf8'));
  138 |   expect(raw.version).toBe(1); expect(raw.records.saves[0].value.schemaVersion).toBe(999);
  139 |   expect(raw.records).not.toHaveProperty('historyPayloads');
  140 |   await expect(page.getByRole('status').filter({ hasText: '已发起主存档原始数据下载' })).toContainText('不含手动历史收藏');
  141 |   await page.screenshot({ path: info.outputPath('unreadable-export-warning.png') });
  142 |   expect(await recoverySnapshot(page)).toEqual(before);
  143 |   await page.getByRole('button', { name: '删除存档', exact: true }).click();
  144 |   const dialog = page.getByRole('dialog', { name: '删除这份存档？', exact: true });
  145 |   await expect(dialog).toContainText('有关联收藏时禁止删除');
  146 |   await dialog.getByRole('button', { name: '确认删除', exact: true }).click();
  147 |   await expect(dialog.getByRole('alert')).toContainText('已阻止删除');
  148 |   await expect(dialog.getByRole('alert')).toContainText('本次未删除任何数据');
  149 |   expect(await recoverySnapshot(page)).toEqual(before); expect(server.calls).toEqual([]);
  150 |   await page.screenshot({ path: info.outputPath('unreadable-delete-protected.png') });
  151 |   await dialog.getByRole('button', { name: '取消', exact: true }).click();
  152 |   await page.reload(); expect(await recoverySnapshot(page)).toEqual(before);
  153 |   // A verified backup saved BEFORE damage can repair the main record using the existing import flow.
  154 |   // The raw rescue JSON above is deliberately NOT represented as an importable collection backup.
> 155 |   await page.getByRole('button', { name: '导入备份', exact: true }).click();
      |                                                                 ^ Error: locator.click: Test timeout of 60000ms exceeded.
  156 |   const importer = page.locator('dialog.backup-import-dialog');
  157 |   await importer.locator('input[type=file]').setInputFiles(backupPath);
  158 |   await expect(importer).toContainText('本机记录无法读取');
  159 |   await importer.getByRole('button', { name: '覆盖并导入', exact: true }).click();
  160 |   await expect(importer).toContainText('已导入');
  161 |   await importer.getByRole('button', { name: '关闭', exact: true }).click();
  162 |   const after = await recoverySnapshot(page);
  163 |   expect(after.historyMetadata).toEqual(before.historyMetadata); expect(after.historyPayloads).toEqual(before.historyPayloads);
  164 |   for (const store of ['saves', 'drafts', 'turnReceipts', 'turnUndo', 'saveControls']) {
  165 |     const rows = (data: typeof before) => data[store].values.filter((row: { saveId?: string }) => row.saveId === 'save-b');
  166 |     expect(rows(after)).toEqual(rows(before));
  167 |   }
  168 |   const restored = await page.evaluate(async id => {
  169 |     const p = '/src/services/storage/saveRepository.ts', { SaveRepository } = await import(p), repo = await SaveRepository.open();
  170 |     try { const preview = await repo.history.preview('save-a', { kind: 'manual', id }); repo.history.release(preview.confirmation); return preview.state; }
  171 |     finally { repo.close(); }
  172 |   }, savedId);
  173 |   expect(restored).toEqual(original.state); expect(server.calls).toEqual([]);
  174 |   await page.screenshot({ path: info.outputPath('unreadable-recovered.png') });
  175 | });
  176 | 
  177 | test('自动五节点只读预览、取消覆盖、旧链不变、日夜与窄屏截图', async ({ page }, info) => {
  178 |   await seed(page); const server = await mock(page), before = await read(page); await open(page);
  179 |   await expect(page.locator('.history-node-list > li')).toHaveCount(5);
  180 |   await page.screenshot({ path: info.outputPath('automatic-night.png') });
  181 |   await choose(page, 2); await page.getByLabel('历史阅读内容').selectOption('人物档案');
  182 |   await expect(page.locator('.history-world')).toContainText(before.state.protagonist.name);
  183 |   await page.getByLabel('历史阅读内容').selectOption('正文');
  184 |   await page.getByLabel('从此历史节点开始的行动').fill('取消的选择');
  185 |   await page.getByRole('button', { name: '发送新行动（先确认覆盖）' }).click();
  186 |   await expect(page.getByLabel('覆盖时间线确认')).toContainText('第 3～7 回合');
  187 |   await page.screenshot({ path: info.outputPath('overwrite-warning.png') });
  188 |   await page.getByRole('button', { name: '取消，保留原进度' }).click();
  189 |   expect(await read(page)).toEqual(before); expect(server.calls).toEqual([]);
  190 |   await page.evaluate(() => { document.documentElement.dataset.appearance = 'day'; });
  191 |   await page.setViewportSize(info.project.name === 'mobile' ? { width: 375, height: 667 } : { width: 901, height: 600 });
  192 |   const contrast = await settingsTextContrast(page.locator('dialog.history-saves'));
  193 |   expect(contrast.rows.length).toBeGreaterThan(0);
  194 |   expect(contrast.failures).toEqual([]);
  195 |   expect(contrast.controlFailures).toEqual([]);
  196 |   await writeFile(info.outputPath('day-contrast.json'), JSON.stringify(contrast, null, 2));
  197 |   await page.screenshot({ path: info.outputPath('preview-day-narrow.png') });
  198 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  199 |   await page.getByRole('button', { name: '关闭资料界面' }).click(); await open(page);
  200 |   expect(await read(page)).toEqual(before); expect(server.calls).toEqual([]);
  201 | });
  202 | 
  203 | test('手动收藏命名重开改名删除，完整状态导出，确认后单次三阶段且连续推进两回合', async ({ page }, info) => {
  204 |   await seed(page); const server = await mock(page); await open(page);
  205 |   await page.getByRole('button', { name: '保存当前正式节点' }).click();
  206 |   await page.getByLabel('历史收藏名称').fill('重要谈判前'); await page.getByRole('button', { name: '保存收藏', exact: true }).click();
  207 |   await expect(page.locator('.history-node-list')).toContainText('重要谈判前');
  208 |   const saved = await read(page); expect(saved.history.nodes.filter((n: { kind: string }) => n.kind === 'manual')).toHaveLength(1);
  209 |   await page.reload(); await open(page); await page.getByRole('button', { name: '手动收藏', exact: true }).click();
  210 |   await page.getByRole('button', { name: '重命名', exact: true }).click(); await page.getByLabel('历史收藏名称').fill('谈判前收藏');
  211 |   await page.getByRole('button', { name: '保存名称', exact: true }).click(); await expect(page.locator('.history-node-list')).toContainText('谈判前收藏');
  212 |   const downloaded = page.waitForEvent('download'); await page.getByRole('button', { name: '导出节点备份' }).click();
  213 |   expect((await downloaded).suggestedFilename()).toContain('.heijin.json');
  214 |   await page.getByRole('button', { name: '自动历史', exact: true }).click(); await choose(page, 2); await confirm(page);
  215 |   await expect(page.locator('.game-layout')).toBeVisible(); await expect.poll(async () => (await read(page)).state.turnNumber).toBe(3);
  216 |   expect(server.calls).toEqual(['story', 'variables', 'world']); expect((await read(page)).undo.available).toBe(1);
  217 |   await page.getByLabel('你的行动', { exact: true }).fill('继续去公园散步'); await page.getByRole('button', { name: '发送', exact: true }).click();
  218 |   await expect.poll(async () => (await read(page)).state.turnNumber).toBe(4);
  219 |   expect(server.calls).toEqual(['story', 'variables', 'world', 'story', 'variables', 'world']);
  220 |   const fresh = await read(page); expect(fresh.undo.available).toBe(2); expect(fresh.raw.records.turnReceipts).toHaveLength(2);
  221 |   expect(fresh.history.nodes.find((n: { kind: string }) => n.kind === 'manual').oldTimeline).toBe(true);
  222 |   await page.reload(); expect((await read(page)).state).toEqual(fresh.state); expect(server.calls).toHaveLength(6);
  223 |   await page.goto('/'); await open(page); await page.getByRole('button', { name: '手动收藏', exact: true }).click();
  224 |   await expect(page.locator('.history-node-list')).toContainText('旧时间线收藏'); await page.screenshot({ path: info.outputPath('old-timeline-collection.png') });
  225 |   await page.getByRole('button', { name: '删除收藏', exact: true }).click(); await page.getByRole('button', { name: '保留收藏', exact: true }).click();
  226 |   expect((await read(page)).history.nodes.filter((n: { kind: string }) => n.kind === 'manual')).toHaveLength(1);
  227 |   await page.getByRole('button', { name: '删除收藏', exact: true }).click(); await page.getByRole('button', { name: '确认删除收藏', exact: true }).click();
  228 |   await expect(page.getByText('尚未保存手动收藏。')).toBeVisible(); expect((await read(page)).state).toEqual(fresh.state);
  229 | });
  230 | 
  231 | test('确认后正文失败保留历史基线及输入；刷新不自动请求，主动恢复后正式结算', async ({ page }, info) => {
  232 |   await seed(page); const server = await mock(page); server.control.failStory = true;
  233 |   await open(page); await choose(page, 2); await confirm(page);
  234 |   await expect.poll(async () => (await read(page)).draft?.stageStatus.story).toBe('failed');
  235 |   const failure = await read(page); expect(failure.state.turnNumber).toBe(2); expect(failure.undo.available).toBe(0); expect(failure.draft.userInput).toBe('改去公园走走');
  236 |   expect(server.calls).toEqual(['story']); await page.reload(); await expect(page.locator('.game-layout')).toBeVisible();
  237 |   expect((await read(page)).raw).toEqual(failure.raw); expect(server.calls).toEqual(['story']);
  238 |   await page.screenshot({ path: info.outputPath('restored-failure.png') });
  239 |   server.control.failStory = false;
  240 |   await page.getByLabel('你的行动', { exact: true }).fill('重新在公园散步'); await page.getByRole('button', { name: '发送', exact: true }).click();
  241 |   await expect.poll(async () => (await read(page)).state.turnNumber).toBe(3);
  242 |   expect(server.calls).toEqual(['story', 'story', 'variables', 'world']);
  243 | });
  244 | 
  245 | test('已合并主干的纯小说设置在历史回溯后仍只请求正文并正式结算一次', async ({ page }) => {
  246 |   await seed(page);
  247 |   await page.evaluate(async () => {
  248 |     const path = '/src/ui/settings/model.ts', { settingsKey } = await import(path);
  249 |     const settings = JSON.parse(localStorage.getItem(settingsKey)!);
  250 |     settings.runtime.useVariableStage = false; settings.runtime.useWorldStage = false;
  251 |     localStorage.setItem(settingsKey, JSON.stringify(settings));
  252 |   });
  253 |   await page.reload(); const server = await mock(page); await open(page); await choose(page, 2);
  254 |   const expectedClock = await page.evaluate(async () => {
  255 |     const path = '/src/services/storage/saveRepository.ts', { SaveRepository } = await import(path), repo = await SaveRepository.open();
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: history-saves.spec.ts >> 损坏主档的原始导出不解锁收藏删除；二进制保留并可用已有标准备份恢复
- Location: e2e/history-saves.spec.ts:98:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.setInputFiles: Test timeout of 60000ms exceeded.
Call log:
  - waiting for locator('dialog.backup-import-dialog').locator('input[type=file]')

```

# Page snapshot

```yaml
- main "游戏首页与存档馆" [ref=f3e4]:
  - generic [ref=f3e5]:
    - generic [aria-hidden] [ref=f3e6]: 黑
    - generic [ref=f3e7]:
      - text: 黑金王朝
      - generic [ref=f3e8]: HEIJINWANGCHAO
    - button "设置" [ref=f3e9] [cursor=pointer]
    - generic [ref=f3e10]: V1.0 Beta
  - generic [ref=f3e11]:
    - paragraph [ref=f3e12]: MODERN CITY / OPEN WORLD
    - heading "黑金王朝" [level=1] [ref=f3e13]
    - paragraph [ref=f3e14]: 起点有冲突，人生不预设结局。
  - status "终点 未知，时刻 08:15，已选择" [ref=f3e15]:
    - generic [ref=f3e16]:
      - text: 终点
      - generic [ref=f3e17]: DEST
    - generic [ref=f3e18]:
      - generic [ref=f3e19]: 未
      - generic [ref=f3e20]: 知
    - generic [ref=f3e22]:
      - generic [ref=f3e23]: "0"
      - generic [ref=f3e24]: "8"
      - generic [ref=f3e25]: ":"
      - generic [ref=f3e26]: "1"
      - generic [ref=f3e27]: "5"
    - generic [ref=f3e28]: 已选择
  - generic [ref=f3e29]:
    - generic [ref=f3e30]: 车票 02
    - generic [ref=f3e31]: 本地保存 · 无需账号
    - button "导入备份" [active] [ref=f3e32] [cursor=pointer]: ⤓ 导入备份
    - button "刷新列表" [ref=f3e33] [cursor=pointer]
  - region "车票栏，左右方向键切换" [ref=f3e34]:
    - article "其他人生，保存于 2026/11/17 08:15，已选择" [ref=f3e36]:
      - generic [ref=f3e37]:
        - generic [ref=f3e38]: ARCHIVE 01
        - generic [ref=f3e40]:
          - generic [ref=f3e41]:
            - generic [ref=f3e42]:
              - generic [ref=f3e43]: FROM
              - generic [ref=f3e44]: 其他人生
            - generic [aria-hidden] [ref=f3e45]: 单程
            - generic [ref=f3e47]: TO
          - generic [ref=f3e49]:
            - generic [ref=f3e50]:
              - term [ref=f3e51]: 保存日期
              - definition [ref=f3e52]: 2026/11/17
            - generic [ref=f3e53]:
              - term [ref=f3e54]: 时刻
              - definition [ref=f3e55]: 08:15
            - generic [ref=f3e56]:
              - generic [aria-hidden]:
                - text: 已检票
                - generic: SELECTED
          - paragraph [ref=f3e57]: 从未备份
      - generic [ref=f3e76]:
        - text: 继续游戏
        - generic [ref=f3e77]: ↓ 按住票根往下撕
    - article "无法读取的存档：测试存档，保存于 2026/11/17 08:15" [ref=f3e80]:
      - generic [ref=f3e81]:
        - generic [ref=f3e82]:
          - generic [ref=f3e83]: 未知
          - generic [ref=f3e84]: UNREADABLE
          - generic [ref=f3e85]: ARCHIVE 02
        - generic [ref=f3e86]:
          - generic [ref=f3e88]:
            - generic [ref=f3e89]: FROM
            - generic [ref=f3e90]: 测试存档
          - paragraph [ref=f3e91]: 存档记录 ID：save-a
          - paragraph [ref=f3e92]: 当前版本无法读取这条记录。其他存档不受影响；可先导出主存档原始数据。原始数据导出不包含手动历史收藏。有关联收藏时禁止删除，请保留本机数据并联系维护者恢复。
        - generic [aria-hidden]: 无法读取
      - generic [ref=f3e93]: 保存时间无法读取
    - article "空白车票：开启新的人生" [ref=f3e97]:
      - generic [ref=f3e98]:
        - generic [ref=f3e99]:
          - generic [ref=f3e100]: 空白车票
          - generic [ref=f3e101]: NEW LIFE
          - generic [ref=f3e102]: NEW
        - generic [ref=f3e103]:
          - generic [ref=f3e104]:
            - generic [ref=f3e105]:
              - generic [ref=f3e106]: FROM
              - generic [ref=f3e107]: ？
            - generic [aria-hidden] [ref=f3e108]: 单程
            - generic [ref=f3e110]:
              - generic [ref=f3e111]: TO
              - generic [ref=f3e112]: ？
          - generic [ref=f3e113]:
            - generic [ref=f3e114]:
              - term [ref=f3e115]: 城市
              - definition [ref=f3e116]
            - generic [ref=f3e118]:
              - term [ref=f3e119]: 职业
              - definition [ref=f3e120]
            - generic [ref=f3e122]:
              - term [ref=f3e123]: 存档
              - definition [ref=f3e124]: —
          - paragraph [ref=f3e125]: 四座城市 · 自由职业 · 开放人生
      - generic [ref=f3e127]:
        - text: 开启新的人生
        - generic [ref=f3e128]: ↓ 按住票根往下撕
  - navigation "车票页码" [ref=f3e130]:
    - button "第 1 张" [ref=f3e131] [cursor=pointer]
    - button "第 2 张" [ref=f3e132] [cursor=pointer]
    - button "第 3 张，空白车票" [ref=f3e133] [cursor=pointer]
  - generic [ref=f3e134]:
    - button "继续游戏" [ref=f3e135] [cursor=pointer]:
      - text: 继续游戏
      - generic [aria-hidden] [ref=f3e136]: →
    - generic [ref=f3e137]:
      - button "历史存档" [ref=f3e138] [cursor=pointer]
      - button "导出备份" [ref=f3e139] [cursor=pointer]
      - button "删除" [ref=f3e140] [cursor=pointer]
  - generic [ref=f3e141]:
    - group "游玩信息" [ref=f3e142]:
      - button "游玩须知与免责声明" [ref=f3e143] [cursor=pointer]
      - button "王朝公告" [ref=f3e144] [cursor=pointer]
    - paragraph [ref=f3e145]: 四座城市 · 自由职业 · 开放人生三阶段生成 · 原子结算 · 连续回合
```

# Test source

```ts
  61  |       : JSON.stringify({ choices: [{ message: { content: text }, finish_reason: 'stop' }] }) });
  62  |   });
  63  |   return { calls, control };
  64  | }
  65  | async function choose(page: Page, turn: number) {
  66  |   await page.getByRole('button', { name: `预览第 ${turn} 回合`, exact: true }).click();
  67  |   await expect(page.getByText(`只读历史 · 第 ${turn} 回合结束。`, { exact: false })).toBeVisible();
  68  | }
  69  | async function confirm(page: Page) {
  70  |   await page.getByLabel('从此历史节点开始的行动').fill('改去公园走走');
  71  |   await page.getByRole('button', { name: '发送新行动（先确认覆盖）', exact: true }).click();
  72  |   await page.getByRole('button', { name: '确认覆盖并继续', exact: true }).click();
  73  | }
  74  | 
  75  | // Include every store and binary byte: JSON.stringify(ArrayBuffer) alone would hide data loss.
  76  | async function recoverySnapshot(page: Page) {
  77  |   return page.evaluate(async () => {
  78  |     const p = '/src/services/storage/idb.ts', { request, transaction } = await import(p);
  79  |     const db: IDBDatabase = await request(indexedDB.open('heijinwangchao'));
  80  |     function binary(value: unknown): unknown {
  81  |       if (value instanceof ArrayBuffer) return { arrayBuffer: Array.from(new Uint8Array(value)) };
  82  |       if (Array.isArray(value)) return value.map(binary);
  83  |       if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, part]) => [key, binary(part)]));
  84  |       return value;
  85  |     }
  86  |     try {
  87  |       return await transaction(db, Array.from(db.objectStoreNames), 'readonly', async (tx: IDBTransaction) => {
  88  |         const result: Record<string, { keys: IDBValidKey[]; values: unknown[] }> = {};
  89  |         for (const name of Array.from(db.objectStoreNames)) result[name] = {
  90  |           keys: await request(tx.objectStore(name).getAllKeys()), values: binary(await request(tx.objectStore(name).getAll())) as unknown[],
  91  |         };
  92  |         return result;
  93  |       });
  94  |     } finally { db.close(); }
  95  |   });
  96  | }
  97  | 
  98  | test('损坏主档的原始导出不解锁收藏删除；二进制保留并可用已有标准备份恢复', async ({ page }, info) => {
  99  |   await seed(page, 2); const server = await mock(page), posts: string[] = [];
  100 |   page.on('request', request => { if (request.method() === 'POST') posts.push(request.url()); });
  101 |   await open(page);
  102 |   await page.getByRole('button', { name: '保存当前正式节点' }).click();
  103 |   await page.getByLabel('历史收藏名称').fill('不可丢失的收藏');
  104 |   await page.getByRole('button', { name: '保存收藏', exact: true }).click();
  105 |   await expect(page.locator('.history-node-list')).toContainText('不可丢失的收藏');
  106 |   const original = await read(page);
  107 |   expect(original.history.nodes.find((n: { kind: string }) => n.kind === 'manual')).toBeTruthy();
  108 |   const savedDownload = page.waitForEvent('download'); await page.getByRole('button', { name: '导出节点备份' }).click();
  109 |   const backupPath = (await (await savedDownload).path())!;
  110 |   await page.getByRole('button', { name: '关闭资料界面' }).click();
  111 |   const savedId = await page.evaluate(async () => {
  112 |     const rp = '/src/services/storage/saveRepository.ts', ip = '/src/services/storage/idb.ts';
  113 |     const { SaveRepository } = await import(rp), { request, transaction } = await import(ip), repo = await SaveRepository.open();
  114 |     try {
  115 |       const state = await repo.load('save-a'), other = { ...state, saveId: 'save-b', title: '其他人生' };
  116 |       await repo.importBackup({ state: other }, (await repo.compareBackup({ state: other })).confirmation);
  117 |       await repo.history.create('save-b', '另一份收藏');
  118 |       const node = (await repo.history.list('save-a')).nodes.find((n: { kind: string }) => n.kind === 'manual');
  119 |       const db: IDBDatabase = await request(indexedDB.open('heijinwangchao'));
  120 |       try { await transaction(db, ['saves'], 'readwrite', async (tx: IDBTransaction) => {
  121 |         await request(tx.objectStore('saves').put({ ...state, schemaVersion: 999 }));
  122 |       }); } finally { db.close(); }
  123 |       return node.id;
  124 |     } finally { repo.close(); }
  125 |   });
  126 |   await page.reload();
  127 |   if (info.project.name === 'desktop') await page.getByRole('button', { name: '存档馆', exact: true }).click();
  128 |   else {
  129 |     await expect(page.locator('.mh-ticket.bad')).toContainText('存档记录 ID：save-a');
  130 |     const index = await page.locator('.mh-ticket-wrap').evaluateAll(items => items.findIndex(item => item.textContent?.includes('存档记录 ID：save-a')));
  131 |     expect(index).toBeGreaterThanOrEqual(0);
  132 |     await page.getByRole('navigation', { name: '车票页码' }).getByRole('button').nth(index).click();
  133 |   }
  134 |   const card = info.project.name === 'desktop' ? page.locator('.save-card.bad') : page.locator('.mh-ticket-wrap[aria-current=true]');
  135 |   await expect(card).toContainText('原始数据导出不包含手动历史收藏');
  136 |   const before = await recoverySnapshot(page);
  137 |   const payload = before.historyPayloads.values.find((row: { saveId?: string }) => row.saveId === 'save-a');
  138 |   expect(payload.payload.encoding).toBe('gzip'); expect(payload.payload.data.arrayBuffer.length).toBeGreaterThan(0);
  139 |   const pending = page.waitForEvent('download'); await page.getByRole('button', { name: '导出原始数据', exact: true }).click();
  140 |   const raw = JSON.parse(await readFile((await (await pending).path())!, 'utf8'));
  141 |   expect(raw.version).toBe(1); expect(raw.records.saves[0].value.schemaVersion).toBe(999);
  142 |   expect(raw.records).not.toHaveProperty('historyPayloads');
  143 |   await expect(page.getByRole('status').filter({ hasText: '已发起主存档原始数据下载' })).toContainText('不含手动历史收藏');
  144 |   await page.screenshot({ path: info.outputPath('unreadable-export-warning.png') });
  145 |   expect(await recoverySnapshot(page)).toEqual(before);
  146 |   await page.getByRole('button', { name: '删除存档', exact: true }).click();
  147 |   const dialog = page.getByRole('dialog', { name: '删除这份存档？', exact: true });
  148 |   await expect(dialog).toContainText('有关联收藏时禁止删除');
  149 |   await dialog.getByRole('button', { name: '确认删除', exact: true }).click();
  150 |   await expect(dialog.getByRole('alert')).toContainText('已阻止删除');
  151 |   await expect(dialog.getByRole('alert')).toContainText('本次未删除任何数据');
  152 |   expect(await recoverySnapshot(page)).toEqual(before); expect(server.calls).toEqual([]);
  153 |   await page.screenshot({ path: info.outputPath('unreadable-delete-protected.png') });
  154 |   await dialog.getByRole('button', { name: '取消', exact: true }).click();
  155 |   await page.reload(); expect(await recoverySnapshot(page)).toEqual(before);
  156 |   // A verified backup saved BEFORE damage can repair the main record using the existing import flow.
  157 |   // The raw rescue JSON above is deliberately NOT represented as an importable collection backup.
  158 |   if (info.project.name === 'desktop') await page.getByRole('button', { name: '存档馆', exact: true }).click();
  159 |   await page.getByRole('button', { name: '导入备份', exact: true }).click();
  160 |   const importer = page.locator('dialog.backup-import-dialog');
> 161 |   await importer.locator('input[type=file]').setInputFiles(backupPath);
      |   ^ Error: locator.setInputFiles: Test timeout of 60000ms exceeded.
  162 |   await expect(importer.getByRole('heading', { name: '覆盖本机存档？', exact: true })).toBeVisible();
  163 |   await expect(importer).toContainText('无法读取');
  164 |   await importer.getByRole('button', { name: '覆盖并导入', exact: true }).click();
  165 |   await expect(importer).toHaveCount(0);
  166 |   await expect(page.getByRole('status').filter({ hasText: '已导入「测试存档」' })).toBeVisible();
  167 |   const after = await recoverySnapshot(page);
  168 |   expect(after.historyMetadata).toEqual(before.historyMetadata); expect(after.historyPayloads).toEqual(before.historyPayloads);
  169 |   for (const store of ['saves', 'drafts', 'turnReceipts', 'turnUndo', 'saveControls']) {
  170 |     const rows = (data: typeof before) => data[store].values.filter((row: { saveId?: string }) => row.saveId === 'save-b');
  171 |     expect(rows(after)).toEqual(rows(before));
  172 |   }
  173 |   const restored = await page.evaluate(async id => {
  174 |     const p = '/src/services/storage/saveRepository.ts', { SaveRepository } = await import(p), repo = await SaveRepository.open();
  175 |     try { const preview = await repo.history.preview('save-a', { kind: 'manual', id }); repo.history.release(preview.confirmation); return preview.state; }
  176 |     finally { repo.close(); }
  177 |   }, savedId);
  178 |   expect(restored).toEqual(original.state); expect(server.calls).toEqual([]); expect(posts).toEqual([]);
  179 |   await page.screenshot({ path: info.outputPath('unreadable-recovered.png') });
  180 | });
  181 | 
  182 | test('自动五节点只读预览、取消覆盖、旧链不变、日夜与窄屏截图', async ({ page }, info) => {
  183 |   await seed(page); const server = await mock(page), before = await read(page); await open(page);
  184 |   await expect(page.locator('.history-node-list > li')).toHaveCount(5);
  185 |   await page.screenshot({ path: info.outputPath('automatic-night.png') });
  186 |   await choose(page, 2); await page.getByLabel('历史阅读内容').selectOption('人物档案');
  187 |   await expect(page.locator('.history-world')).toContainText(before.state.protagonist.name);
  188 |   await page.getByLabel('历史阅读内容').selectOption('正文');
  189 |   await page.getByLabel('从此历史节点开始的行动').fill('取消的选择');
  190 |   await page.getByRole('button', { name: '发送新行动（先确认覆盖）' }).click();
  191 |   await expect(page.getByLabel('覆盖时间线确认')).toContainText('第 3～7 回合');
  192 |   await page.screenshot({ path: info.outputPath('overwrite-warning.png') });
  193 |   await page.getByRole('button', { name: '取消，保留原进度' }).click();
  194 |   expect(await read(page)).toEqual(before); expect(server.calls).toEqual([]);
  195 |   await page.evaluate(() => { document.documentElement.dataset.appearance = 'day'; });
  196 |   await page.setViewportSize(info.project.name === 'mobile' ? { width: 375, height: 667 } : { width: 901, height: 600 });
  197 |   const contrast = await settingsTextContrast(page.locator('dialog.history-saves'));
  198 |   expect(contrast.rows.length).toBeGreaterThan(0);
  199 |   expect(contrast.failures).toEqual([]);
  200 |   expect(contrast.controlFailures).toEqual([]);
  201 |   await writeFile(info.outputPath('day-contrast.json'), JSON.stringify(contrast, null, 2));
  202 |   await page.screenshot({ path: info.outputPath('preview-day-narrow.png') });
  203 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  204 |   await page.getByRole('button', { name: '关闭资料界面' }).click(); await open(page);
  205 |   expect(await read(page)).toEqual(before); expect(server.calls).toEqual([]);
  206 | });
  207 | 
  208 | test('手动收藏命名重开改名删除，完整状态导出，确认后单次三阶段且连续推进两回合', async ({ page }, info) => {
  209 |   await seed(page); const server = await mock(page); await open(page);
  210 |   await page.getByRole('button', { name: '保存当前正式节点' }).click();
  211 |   await page.getByLabel('历史收藏名称').fill('重要谈判前'); await page.getByRole('button', { name: '保存收藏', exact: true }).click();
  212 |   await expect(page.locator('.history-node-list')).toContainText('重要谈判前');
  213 |   const saved = await read(page); expect(saved.history.nodes.filter((n: { kind: string }) => n.kind === 'manual')).toHaveLength(1);
  214 |   await page.reload(); await open(page); await page.getByRole('button', { name: '手动收藏', exact: true }).click();
  215 |   await page.getByRole('button', { name: '重命名', exact: true }).click(); await page.getByLabel('历史收藏名称').fill('谈判前收藏');
  216 |   await page.getByRole('button', { name: '保存名称', exact: true }).click(); await expect(page.locator('.history-node-list')).toContainText('谈判前收藏');
  217 |   const downloaded = page.waitForEvent('download'); await page.getByRole('button', { name: '导出节点备份' }).click();
  218 |   expect((await downloaded).suggestedFilename()).toContain('.heijin.json');
  219 |   await page.getByRole('button', { name: '自动历史', exact: true }).click(); await choose(page, 2); await confirm(page);
  220 |   await expect(page.locator('.game-layout')).toBeVisible(); await expect.poll(async () => (await read(page)).state.turnNumber).toBe(3);
  221 |   expect(server.calls).toEqual(['story', 'variables', 'world']); expect((await read(page)).undo.available).toBe(1);
  222 |   await page.getByLabel('你的行动', { exact: true }).fill('继续去公园散步'); await page.getByRole('button', { name: '发送', exact: true }).click();
  223 |   await expect.poll(async () => (await read(page)).state.turnNumber).toBe(4);
  224 |   expect(server.calls).toEqual(['story', 'variables', 'world', 'story', 'variables', 'world']);
  225 |   const fresh = await read(page); expect(fresh.undo.available).toBe(2); expect(fresh.raw.records.turnReceipts).toHaveLength(2);
  226 |   expect(fresh.history.nodes.find((n: { kind: string }) => n.kind === 'manual').oldTimeline).toBe(true);
  227 |   await page.reload(); expect((await read(page)).state).toEqual(fresh.state); expect(server.calls).toHaveLength(6);
  228 |   await page.goto('/'); await open(page); await page.getByRole('button', { name: '手动收藏', exact: true }).click();
  229 |   await expect(page.locator('.history-node-list')).toContainText('旧时间线收藏'); await page.screenshot({ path: info.outputPath('old-timeline-collection.png') });
  230 |   await page.getByRole('button', { name: '删除收藏', exact: true }).click(); await page.getByRole('button', { name: '保留收藏', exact: true }).click();
  231 |   expect((await read(page)).history.nodes.filter((n: { kind: string }) => n.kind === 'manual')).toHaveLength(1);
  232 |   await page.getByRole('button', { name: '删除收藏', exact: true }).click(); await page.getByRole('button', { name: '确认删除收藏', exact: true }).click();
  233 |   await expect(page.getByText('尚未保存手动收藏。')).toBeVisible(); expect((await read(page)).state).toEqual(fresh.state);
  234 | });
  235 | 
  236 | test('确认后正文失败保留历史基线及输入；刷新不自动请求，主动恢复后正式结算', async ({ page }, info) => {
  237 |   await seed(page); const server = await mock(page); server.control.failStory = true;
  238 |   await open(page); await choose(page, 2); await confirm(page);
  239 |   await expect.poll(async () => (await read(page)).draft?.stageStatus.story).toBe('failed');
  240 |   const failure = await read(page); expect(failure.state.turnNumber).toBe(2); expect(failure.undo.available).toBe(0); expect(failure.draft.userInput).toBe('改去公园走走');
  241 |   expect(server.calls).toEqual(['story']); await page.reload(); await expect(page.locator('.game-layout')).toBeVisible();
  242 |   expect((await read(page)).raw).toEqual(failure.raw); expect(server.calls).toEqual(['story']);
  243 |   await page.screenshot({ path: info.outputPath('restored-failure.png') });
  244 |   server.control.failStory = false;
  245 |   await page.getByLabel('你的行动', { exact: true }).fill('重新在公园散步'); await page.getByRole('button', { name: '发送', exact: true }).click();
  246 |   await expect.poll(async () => (await read(page)).state.turnNumber).toBe(3);
  247 |   expect(server.calls).toEqual(['story', 'story', 'variables', 'world']);
  248 | });
  249 | 
  250 | test('已合并主干的纯小说设置在历史回溯后仍只请求正文并正式结算一次', async ({ page }) => {
  251 |   await seed(page);
  252 |   await page.evaluate(async () => {
  253 |     const path = '/src/ui/settings/model.ts', { settingsKey } = await import(path);
  254 |     const settings = JSON.parse(localStorage.getItem(settingsKey)!);
  255 |     settings.runtime.useVariableStage = false; settings.runtime.useWorldStage = false;
  256 |     localStorage.setItem(settingsKey, JSON.stringify(settings));
  257 |   });
  258 |   await page.reload(); const server = await mock(page); await open(page); await choose(page, 2);
  259 |   const expectedClock = await page.evaluate(async () => {
  260 |     const path = '/src/services/storage/saveRepository.ts', { SaveRepository } = await import(path), repo = await SaveRepository.open();
  261 |     try {
```
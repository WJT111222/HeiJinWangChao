# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: history-saves.spec.ts >> 手动收藏命名重开改名删除，完整状态导出，确认后单次三阶段且连续推进两回合
- Location: e2e/history-saves.spec.ts:97:1

# Error details

```
Test timeout of 60000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=f4e3]:
  - main [ref=f4e4]:
    - region "已有存档" [ref=f4e5]:
      - generic [ref=f4e6]:
        - button "封面" [ref=f4e7] [cursor=pointer]:
          - generic [aria-hidden] [ref=f4e8]: ←
          - text: 封面
        - generic [ref=f4e9]:
          - generic [aria-hidden] [ref=f4e10]: 黑
          - generic [ref=f4e11]:
            - text: 黑金王朝
            - generic [ref=f4e12]: YOUR STORIES
        - button "导入备份" [ref=f4e13] [cursor=pointer]: ⤓ 导入备份
        - button "导出全部" [ref=f4e14] [cursor=pointer]
        - button "刷新列表" [ref=f4e15] [cursor=pointer]
      - generic [ref=f4e16]:
        - generic [ref=f4e18]:
          - paragraph [ref=f4e19]: YOUR STORIES
          - heading "已有存档 01" [level=2] [ref=f4e20]
          - paragraph [ref=f4e21]: 每份存档都是一段独立的人生，保存在当前浏览器。
        - generic [ref=f4e22]:
          - article [ref=f4e23]:
            - generic [ref=f4e24]: NEW
            - button [ref=f4e26] [cursor=pointer]:
              - generic [ref=f4e27]:
                - generic [aria-hidden] [ref=f4e28]: ＋
                - heading "开启新的人生" [level=3] [ref=f4e29]
                - paragraph [ref=f4e30]: 四座城市 · 自由职业 · 开放人生
          - article [ref=f4e31]:
            - generic [ref=f4e32]: ARCHIVE 01
            - generic [ref=f4e35]:
              - generic [ref=f4e36]: 已选择
              - generic [ref=f4e360]:
                - heading "测试存档" [level=3] [ref=f4e361]
                - paragraph [ref=f4e362]: 保存于 2026/11/17 06:10
                - paragraph [ref=f4e363]: 从未备份
                - generic [ref=f4e364]:
                  - button "读取存档 ↗" [ref=f4e365] [cursor=pointer]
                  - button "历史存档" [ref=f4e366] [cursor=pointer]
                  - button "导出备份" [ref=f4e367] [cursor=pointer]
                  - button "删除" [ref=f4e368] [cursor=pointer]
      - generic [ref=f4e369]:
        - text: 本地保存 · 无需账号 · 备份文件不含 AI 密钥与设置
        - button "打开设置 ↗" [ref=f4e370] [cursor=pointer]
  - dialog [ref=f4e371]:
    - banner [ref=f4e372]:
      - generic [ref=f4e373]:
        - paragraph [ref=f4e374]: HEIJIN / ARCHIVE
        - heading "历史存档" [level=2] [ref=f4e375]
      - button "关闭资料界面" [ref=f4e376] [cursor=pointer]: 关闭 ×
    - generic [ref=f4e377]:
      - note [ref=f4e378]: 自动历史复用最近五个撤回恢复点（64 MiB 预算）。手动收藏独立保留，只保存已经正式结算的世界。
      - status [ref=f4e379]: 已删除所选收藏。
      - generic [ref=f4e380]:
        - button "自动历史" [ref=f4e381] [cursor=pointer]
        - button "手动收藏" [pressed] [ref=f4e382] [cursor=pointer]
        - button "保存当前正式节点" [ref=f4e383] [cursor=pointer]
        - button "刷新历史列表" [ref=f4e384] [cursor=pointer]
      - paragraph [ref=f4e385]: 手动收藏记录体积：0 B（编码载荷及元数据，不含数据库内部开销）。普通整档备份不含历史收藏，请单独导出重要节点。
      - paragraph [ref=f4e386]: 浏览器估算：已使用约 88.0 KiB / 配额约 10240.09 MiB，不是精确剩余空间。
      - paragraph [ref=f4e387]: 尚未保存手动收藏。
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: history-saves.spec.ts >> 手动收藏命名重开改名删除，完整状态导出，确认后单次三阶段且连续推进两回合
- Location: e2e/history-saves.spec.ts:90:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.click: Test timeout of 60000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '历史存档', exact: true })

```

# Page snapshot

```yaml
- main [ref=f1e2]:
  - generic "城市与当前场景" [ref=f1e3]:
    - generic [ref=f1e4]:
      - generic [aria-hidden] [ref=f1e5]: 黑
      - generic [ref=f1e6]:
        - heading "城市长夜" [level=1] [ref=f1e7]
        - generic "A CITY. A TURNING POINT." [ref=f1e8]
    - generic [ref=f1e9]:
      - generic "重庆" [ref=f1e10]: 当前地点
      - generic "2026/10/18 星期日 08:07" [ref=f1e13]:
        - time [ref=f1e14]: 08:07
        - generic [ref=f1e15]:
          - generic [ref=f1e16]: 2026/10/18 星期日
          - generic [ref=f1e17]: 早晨
      - generic [ref=f1e18]:
        - button "查看天气详情" [ref=f1e19] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e20]: 晴
          - generic [ref=f1e21]: 天气
          - generic [ref=f1e22]: 天气待确认
        - button "查看环境详情" [ref=f1e23] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e24]: 境
          - generic [ref=f1e25]: 环境
          - generic [ref=f1e26]: 环境待确认
  - complementary "主角信息" [ref=f1e27]:
    - generic [ref=f1e28]:
      - generic [aria-hidden] [ref=f1e29]: 林
      - generic [ref=f1e30]:
        - heading "林舟" [level=2] [ref=f1e31]
        - paragraph [ref=f1e32]: 30 岁 · 男 · 教师
    - paragraph [ref=f1e33]: 资金
    - generic [ref=f1e34]:
      - generic [ref=f1e35]:
        - generic [ref=f1e36]: 现金
        - strong [ref=f1e37]: 100.00 元
      - generic [ref=f1e38]:
        - generic [ref=f1e39]: 线上资金
        - strong [ref=f1e40]: 200.00 元
    - paragraph [ref=f1e41]: 状态
    - generic [ref=f1e42]:
      - generic "健康" [ref=f1e43]:
        - generic [ref=f1e44]: 身体
        - text: 健康
      - generic "平静" [ref=f1e45]:
        - generic [ref=f1e46]: 情绪
        - text: 平静
    - region "当前穿戴与装备" [ref=f1e47]:
      - paragraph [ref=f1e48]: 当前穿戴与装备
      - generic [ref=f1e49]:
        - generic [ref=f1e50]:
          - term [ref=f1e51]: 上衣
          - definition [ref=f1e52]: 无
        - generic [ref=f1e53]:
          - term [ref=f1e54]: 下装
          - definition [ref=f1e55]: 无
        - generic [ref=f1e56]:
          - term [ref=f1e57]: 鞋子
          - definition [ref=f1e58]: 无
        - generic [ref=f1e59]:
          - term [ref=f1e60]: 饰品
          - definition [ref=f1e61]: 无
        - generic [ref=f1e62]:
          - term [ref=f1e63]: 主武器
          - definition [ref=f1e64]: 无
        - generic [ref=f1e65]:
          - term [ref=f1e66]: 副武器
          - definition [ref=f1e67]: 无
        - generic [ref=f1e68]:
          - term [ref=f1e69]: 载具
          - definition [ref=f1e70]: 无
    - generic [ref=f1e71]:
      - button "人物档案" [ref=f1e72] [cursor=pointer]
      - button "经济与资产" [ref=f1e73] [cursor=pointer]
  - region "剧情与行动" [ref=f1e74]:
    - generic "正文阅读区域" [ref=f1e75]:
      - generic [ref=f1e76]:
        - generic [ref=f1e77]: THE STORY
        - generic [ref=f1e78]: 已结算历史
      - article [ref=f1e79]:
        - generic [ref=f1e80]:
          - heading "第 1 回合" [level=2] [ref=f1e81]
          - generic [aria-hidden] [ref=f1e82]: 第一回
          - generic [aria-hidden] [ref=f1e83]: 十月十八日 · 星期日 · 八时整 · 重庆
        - paragraph [ref=f1e85]: 经过十分钟，主角完成用餐。主角已经用现金支付30元吃饭。
      - article [ref=f1e86]:
        - generic [ref=f1e87]:
          - heading "第 2 回合" [level=2] [ref=f1e88]
          - generic [aria-hidden] [ref=f1e89]: 第二回
          - generic [aria-hidden] [ref=f1e90]: 十月十八日 · 星期日 · 八时一分 · 重庆
        - paragraph [ref=f1e92]: 经过十分钟，主角完成用餐。主角已经用现金支付30元吃饭。
      - article [ref=f1e93]:
        - generic [ref=f1e94]:
          - heading "第 3 回合" [level=2] [ref=f1e95]
          - generic [aria-hidden] [ref=f1e96]: 第三回
          - generic [aria-hidden] [ref=f1e97]: 十月十八日 · 星期日 · 八时二分 · 重庆
        - paragraph [ref=f1e99]: 经过十分钟，主角完成用餐。主角已经用现金支付30元吃饭。
      - article [ref=f1e100]:
        - generic [ref=f1e101]:
          - heading "第 4 回合" [level=2] [ref=f1e102]
          - generic [aria-hidden] [ref=f1e103]: 第四回
          - generic [aria-hidden] [ref=f1e104]: 十月十八日 · 星期日 · 八时三分 · 重庆
        - paragraph [ref=f1e106]: 经过十分钟，主角完成用餐。主角已经用现金支付30元吃饭。
      - article [ref=f1e107]:
        - generic [ref=f1e108]:
          - heading "第 5 回合" [level=2] [ref=f1e109]
          - generic [aria-hidden] [ref=f1e110]: 第五回
          - generic [aria-hidden] [ref=f1e111]: 十月十八日 · 星期日 · 八时四分 · 重庆
        - paragraph [ref=f1e113]: 经过十分钟，主角完成用餐。主角已经用现金支付30元吃饭。
      - article [ref=f1e114]:
        - generic [ref=f1e115]:
          - heading "第 6 回合" [level=2] [ref=f1e116]
          - generic [aria-hidden] [ref=f1e117]: 第六回
          - generic [aria-hidden] [ref=f1e118]: 十月十八日 · 星期日 · 八时五分 · 重庆
        - paragraph [ref=f1e120]: 经过十分钟，主角完成用餐。主角已经用现金支付30元吃饭。
      - article [ref=f1e121]:
        - generic [ref=f1e122]:
          - heading "第 7 回合" [level=2] [ref=f1e123]
          - generic [aria-hidden] [ref=f1e124]: 第七回
          - generic [aria-hidden] [ref=f1e125]: 十月十八日 · 星期日 · 八时六分 · 重庆
        - paragraph [ref=f1e127]: 经过十分钟，主角完成用餐。主角已经用现金支付30元吃饭。
        - button "本回合变化 2 项" [ref=f1e129] [cursor=pointer]:
          - generic [ref=f1e130]: 本回合变化
          - generic [ref=f1e131]: 2 项
          - generic [aria-hidden] [ref=f1e135]: ▼
    - generic [ref=f1e136]:
      - region "三阶段工作流" [ref=f1e138]:
        - generic [ref=f1e140]:
          - status [ref=f1e141]: 三阶段 · 本回合已结算 · 等待行动
          - generic [ref=f1e142]:
            - button "01 正文 · 已结算" [ref=f1e143] [cursor=pointer]:
              - generic [ref=f1e145]:
                - generic [ref=f1e146]: "01"
                - text: 正文
                - emphasis [ref=f1e147]: · 已结算
            - button "02 变量 · 已结算" [ref=f1e148] [cursor=pointer]:
              - generic [ref=f1e150]:
                - generic [ref=f1e151]: "02"
                - text: 变量
                - emphasis [ref=f1e152]: · 已结算
            - button "03 动态世界 · 已结算" [ref=f1e153] [cursor=pointer]:
              - generic [ref=f1e155]:
                - generic [ref=f1e156]: "03"
                - text: 动态世界
                - emphasis [ref=f1e157]: · 已结算
          - button "详情" [ref=f1e158] [cursor=pointer]
      - generic [ref=f1e159]:
        - generic [ref=f1e161]:
          - button "撤回（5）" [ref=f1e162] [cursor=pointer]
          - button "本回合已完成" [disabled] [ref=f1e163]
        - generic [ref=f1e164]: 你的行动
        - textbox "你的行动" [ref=f1e165]:
          - /placeholder: 填写你的行动；发送后生成三阶段并自动结算
        - generic [ref=f1e166]:
          - button "发送" [disabled] [ref=f1e167]
          - generic [ref=f1e168]: Ctrl + Enter
  - complementary "世界资料" [ref=f1e169]:
    - heading "世界资料" [level=2] [ref=f1e170]
    - navigation "世界资料分类" [ref=f1e171]:
      - button "NPC" [ref=f1e172] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e173]: 人
      - button "势力组织" [ref=f1e175] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e176]: 势
      - button "地图" [ref=f1e178] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e179]: 图
      - button "物品栏" [ref=f1e181] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e182]: 物
      - button "世界事件" [ref=f1e184] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e185]: 事
      - button "历史时间轴" [ref=f1e187] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e188]: 史
      - button "记忆" [ref=f1e190] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e191]: 忆
    - navigation "系统操作" [ref=f1e193]:
      - button "设置" [ref=f1e194] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e195]: 设
      - button "返回首页" [ref=f1e197] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e198]: 归
```

# Test source

```ts
  1   | import { expect, test } from './helpers/test';
  2   | import type { Page } from '@playwright/test';
  3   | 
  4   | async function seed(page: Page, turns = 7) {
  5   |   await page.goto('/');
  6   |   await page.evaluate(async turns => {
  7   |     const paths = ['/src/services/storage/saveRepository.ts', '/src/tests/fixtures/world.ts', '/src/tests/fixtures/turn.ts',
  8   |       '/src/ui/settings/model.ts', '/src/services/ai/configuration.ts', '/src/services/ai/credentials.ts'];
  9   |     const [{ SaveRepository }, { worldState }, { completeDraft, elapsedVariables, submission }, { defaultSettings, settingsKey },
  10  |       { defaultAiConfig, newChannel, saveAiConfig }, { CredentialVault }] = await Promise.all(paths.map(p => import(p)));
  11  |     const repo = await SaveRepository.open();
  12  |     try {
  13  |       await repo.create(worldState());
  14  |       for (let i = 1; i <= turns; i++) {
  15  |         const game = await repo.loadGame('save-a'); if (game.draft) await repo.bindTurnAction(game.draft, `合成行动${i}`, true, true);
  16  |         await repo.commitTurn(submission(await completeDraft(repo, { variables: await elapsedVariables(repo, '正常经过时间', 60) }), ''));
  17  |       }
  18  |     } finally { repo.close(); }
  19  |     const settings = defaultSettings(); settings.prompts.minNarrativeChars = 5; settings.prompts.actionOptions = false;
  20  |     for (const setting of Object.values(settings.memory.summaries) as { automatic: boolean }[]) setting.automatic = false;
  21  |     localStorage.setItem(settingsKey, JSON.stringify(settings));
  22  |     const config = defaultAiConfig(), channel = newChannel(); channel.baseUrl = 'https://history.mock.invalid/v1'; config.channels = [channel];
  23  |     config.routes.story = { channelId: channel.id, modelId: 'story' };
  24  |     for (const stage of ['variables', 'world', 'memory']) config.routes[stage] = { mode: 'independent', channelId: channel.id, modelId: stage };
  25  |     saveAiConfig(localStorage, config); new CredentialVault(sessionStorage, localStorage).set(channel.id, 'synthetic-history-key');
  26  |   }, turns);
  27  |   await page.reload();
  28  | }
  29  | async function read(page: Page) {
  30  |   return page.evaluate(async () => {
  31  |     const p = '/src/services/storage/saveRepository.ts', { SaveRepository } = await import(p), repo = await SaveRepository.open();
  32  |     try { return { ...await repo.loadGame('save-a'), raw: await repo.exportRaw('save-a'), history: await repo.history.list('save-a'), undo: await repo.undoStatus('save-a') }; }
  33  |     finally { repo.close(); }
  34  |   });
  35  | }
  36  | async function open(page: Page) {
  37  |   if ((page.viewportSize()?.width ?? 1440) > 900) {
  38  |     const button = page.getByRole('button', { name: /继续游戏/ });
  39  |     if (await button.count()) await button.first().click();
  40  |   }
> 41  |   await page.getByRole('button', { name: '历史存档', exact: true }).click();
      |                                                                 ^ Error: locator.click: Test timeout of 60000ms exceeded.
  42  |   await expect(page.getByRole('dialog', { name: '历史存档', exact: true })).toBeVisible();
  43  |   await expect(page.getByText('正在读取历史元数据…')).toHaveCount(0);
  44  | }
  45  | async function mock(page: Page) {
  46  |   const calls: string[] = [], control = { failStory: false };
  47  |   await page.route('https://history.mock.invalid/**', async route => {
  48  |     const stage = String(route.request().postDataJSON().model); calls.push(stage);
  49  |     const state = (await read(page)).state;
  50  |     const text = stage === 'story' ? control.failStory ? '<正文>不完整' : '<thinking>继续当前选择。</thinking><正文>【旁白】主角来到公园，沿着小路慢慢散步。</正文><短期记忆>在公园散步。</短期记忆><变量规划>[]</变量规划>'
  51  |       : stage === 'variables' ? `<thinking>记录时间。</thinking><说明>时间经过。</说明><命令>\nset worldClock = "${new Date(Date.parse(state.worldClock) + 60000).toISOString()}"\n</命令>`
  52  |         : JSON.stringify({ worldCommands: [], taskCommands: [], eventCommands: [], visibleHooks: [], unresolved: [] });
  53  |     await route.fulfill({ contentType: stage === 'story' ? 'text/event-stream' : 'application/json', body: stage === 'story'
  54  |       ? `data: ${JSON.stringify({ choices: [{ delta: { content: text } }] })}\n\ndata: ${JSON.stringify({ choices: [{ delta: {}, finish_reason: 'stop' }] })}\n\ndata: [DONE]\n\n`
  55  |       : JSON.stringify({ choices: [{ message: { content: text }, finish_reason: 'stop' }] }) });
  56  |   });
  57  |   return { calls, control };
  58  | }
  59  | async function choose(page: Page, turn: number) {
  60  |   await page.getByRole('button', { name: `预览第 ${turn} 回合`, exact: true }).click();
  61  |   await expect(page.getByText(`只读历史 · 第 ${turn} 回合结束。`, { exact: false })).toBeVisible();
  62  | }
  63  | async function confirm(page: Page) {
  64  |   await page.getByLabel('从此历史节点开始的行动').fill('改去公园走走');
  65  |   await page.getByRole('button', { name: '发送新行动（先确认覆盖）', exact: true }).click();
  66  |   await page.getByRole('button', { name: '确认覆盖并继续', exact: true }).click();
  67  | }
  68  | 
  69  | test('自动五节点只读预览、取消覆盖、旧链不变、日夜与窄屏截图', async ({ page }, info) => {
  70  |   await seed(page); const server = await mock(page), before = await read(page); await open(page);
  71  |   await expect(page.locator('.history-node-list > li')).toHaveCount(5);
  72  |   await page.screenshot({ path: info.outputPath('automatic-night.png') });
  73  |   await choose(page, 2); await page.getByLabel('历史阅读内容').selectOption('人物档案');
  74  |   await expect(page.locator('.history-world')).toContainText(before.state.protagonist.name);
  75  |   await page.getByLabel('历史阅读内容').selectOption('正文');
  76  |   await page.getByLabel('从此历史节点开始的行动').fill('取消的选择');
  77  |   await page.getByRole('button', { name: '发送新行动（先确认覆盖）' }).click();
  78  |   await expect(page.getByLabel('覆盖时间线确认')).toContainText('第 3～7 回合');
  79  |   await page.screenshot({ path: info.outputPath('overwrite-warning.png') });
  80  |   await page.getByRole('button', { name: '取消，保留原进度' }).click();
  81  |   expect(await read(page)).toEqual(before); expect(server.calls).toEqual([]);
  82  |   await page.evaluate(() => { document.documentElement.dataset.appearance = 'day'; });
  83  |   await page.setViewportSize(info.project.name === 'mobile' ? { width: 375, height: 667 } : { width: 901, height: 600 });
  84  |   await page.screenshot({ path: info.outputPath('preview-day-narrow.png') });
  85  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  86  |   await page.getByRole('button', { name: '关闭资料界面' }).click(); await open(page);
  87  |   expect(await read(page)).toEqual(before); expect(server.calls).toEqual([]);
  88  | });
  89  | 
  90  | test('手动收藏命名重开改名删除，完整状态导出，确认后单次三阶段且连续推进两回合', async ({ page }, info) => {
  91  |   await seed(page); const server = await mock(page); await open(page);
  92  |   await page.getByRole('button', { name: '保存当前正式节点' }).click();
  93  |   await page.getByLabel('历史收藏名称').fill('重要谈判前'); await page.getByRole('button', { name: '保存收藏', exact: true }).click();
  94  |   await expect(page.locator('.history-node-list')).toContainText('重要谈判前');
  95  |   const saved = await read(page); expect(saved.history.nodes.filter((n: { kind: string }) => n.kind === 'manual')).toHaveLength(1);
  96  |   await page.reload(); await open(page); await page.getByRole('button', { name: '手动收藏', exact: true }).click();
  97  |   await page.getByRole('button', { name: '重命名', exact: true }).click(); await page.getByLabel('历史收藏名称').fill('谈判前收藏');
  98  |   await page.getByRole('button', { name: '保存名称', exact: true }).click(); await expect(page.locator('.history-node-list')).toContainText('谈判前收藏');
  99  |   const downloaded = page.waitForEvent('download'); await page.getByRole('button', { name: '导出节点备份' }).click();
  100 |   expect((await downloaded).suggestedFilename()).toContain('.heijin.json');
  101 |   await page.getByRole('button', { name: '自动历史', exact: true }).click(); await choose(page, 2); await confirm(page);
  102 |   await expect(page.locator('.game-layout')).toBeVisible(); await expect.poll(async () => (await read(page)).state.turnNumber).toBe(3);
  103 |   expect(server.calls).toEqual(['story', 'variables', 'world']); expect((await read(page)).undo.available).toBe(1);
  104 |   await page.getByLabel('你的行动', { exact: true }).fill('继续去公园散步'); await page.getByRole('button', { name: '发送', exact: true }).click();
  105 |   await expect.poll(async () => (await read(page)).state.turnNumber).toBe(4);
  106 |   expect(server.calls).toEqual(['story', 'variables', 'world', 'story', 'variables', 'world']);
  107 |   const fresh = await read(page); expect(fresh.undo.available).toBe(2); expect(fresh.raw.records.turnReceipts).toHaveLength(2);
  108 |   expect(fresh.history.nodes.find((n: { kind: string }) => n.kind === 'manual').oldTimeline).toBe(true);
  109 |   await page.reload(); expect((await read(page)).state).toEqual(fresh.state); expect(server.calls).toHaveLength(6);
  110 |   await page.goto('/'); await open(page); await page.getByRole('button', { name: '手动收藏', exact: true }).click();
  111 |   await expect(page.locator('.history-node-list')).toContainText('旧时间线收藏'); await page.screenshot({ path: info.outputPath('old-timeline-collection.png') });
  112 |   await page.getByRole('button', { name: '删除收藏', exact: true }).click(); await page.getByRole('button', { name: '保留收藏', exact: true }).click();
  113 |   expect((await read(page)).history.nodes.filter((n: { kind: string }) => n.kind === 'manual')).toHaveLength(1);
  114 |   await page.getByRole('button', { name: '删除收藏', exact: true }).click(); await page.getByRole('button', { name: '确认删除收藏', exact: true }).click();
  115 |   await expect(page.getByText('尚未保存手动收藏。')).toBeVisible(); expect((await read(page)).state).toEqual(fresh.state);
  116 | });
  117 | 
  118 | test('确认后正文失败保留历史基线及输入；刷新不自动请求，主动恢复后正式结算', async ({ page }, info) => {
  119 |   await seed(page); const server = await mock(page); server.control.failStory = true;
  120 |   await open(page); await choose(page, 2); await confirm(page);
  121 |   await expect.poll(async () => (await read(page)).draft?.stageStatus.story).toBe('failed');
  122 |   const failure = await read(page); expect(failure.state.turnNumber).toBe(2); expect(failure.undo.available).toBe(0); expect(failure.draft.userInput).toBe('改去公园走走');
  123 |   expect(server.calls).toEqual(['story']); await page.reload(); await expect(page.locator('.game-layout')).toBeVisible();
  124 |   expect((await read(page)).raw).toEqual(failure.raw); expect(server.calls).toEqual(['story']);
  125 |   await page.screenshot({ path: info.outputPath('restored-failure.png') });
  126 |   server.control.failStory = false;
  127 |   await page.getByLabel('你的行动', { exact: true }).fill('重新在公园散步'); await page.getByRole('button', { name: '发送', exact: true }).click();
  128 |   await expect.poll(async () => (await read(page)).state.turnNumber).toBe(3);
  129 |   expect(server.calls).toEqual(['story', 'story', 'variables', 'world']);
  130 | });
  131 | 
  132 | test('跨标签正在生成和无 Web Locks 保守拒绝覆盖，零额外请求', async ({ page, context }) => {
  133 |   await seed(page); const server = await mock(page); await open(page); await choose(page, 2);
  134 |   const other = await context.newPage(); await other.goto('/');
  135 |   await other.evaluate(() => { void navigator.locks.request('heijin.turn:save-a', () => new Promise<void>(resolve => { (window as unknown as { releaseHistoryLock: () => void }).releaseHistoryLock = resolve; })); });
  136 |   await expect.poll(() => other.evaluate(() => Boolean((window as unknown as { releaseHistoryLock?: () => void }).releaseHistoryLock))).toBe(true);
  137 |   const before = await read(page); await confirm(page); await expect(page.getByRole('alert')).toContainText('其他标签');
  138 |   expect(await read(page)).toEqual(before); expect(server.calls).toEqual([]);
  139 |   await other.evaluate(() => (window as unknown as { releaseHistoryLock: () => void }).releaseHistoryLock()); await other.close();
  140 |   await choose(page, 2); await page.evaluate(() => { Object.defineProperty(navigator, 'locks', { value: undefined, configurable: true }); });
  141 |   await confirm(page); await expect(page.getByRole('alert')).toContainText('跨标签互斥');
```
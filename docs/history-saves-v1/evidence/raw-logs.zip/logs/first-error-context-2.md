# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: history-saves.spec.ts >> 确认后正文失败保留历史基线及输入；刷新不自动请求，主动恢复后正式结算
- Location: e2e/history-saves.spec.ts:118:1

# Error details

```
Error: locator.click: Test ended.
Call log:
  - waiting for getByRole('button', { name: '历史存档', exact: true })

```

# Test source

```ts
  1   | import { expect, test } from './helpers/test';
  2   | import type { Page } from '@playwright/test';
  3   | 
  4   | async function seed(page: Page, turns = 7) {
  5   |   await page.goto('/');
  6   |   await page.evaluate(async turns => {
  7   |     const paths = ['/src/services/storage/saveRepository.ts', '/src/tests/fixtures/world.ts', '/src/tests/fixtures/turn.ts',
  8   |       '/src/ui/settings/model.ts', '/src/services/ai/configuration.ts', '/src/services/ai/credentials.ts'];
  9   |     const [{ SaveRepository }, { worldState }, { completeDraft, elapsedVariables, submission }, { defaultSettings, settingsKey },
  10  |       { defaultAiConfig, newChannel, saveAiConfig }, { CredentialVault }] = await Promise.all(paths.map(p => import(p)));
  11  |     const repo = await SaveRepository.open();
  12  |     try {
  13  |       await repo.create(worldState());
  14  |       for (let i = 1; i <= turns; i++) {
  15  |         const game = await repo.loadGame('save-a'); if (game.draft) await repo.bindTurnAction(game.draft, `合成行动${i}`, true, true);
  16  |         await repo.commitTurn(submission(await completeDraft(repo, { variables: await elapsedVariables(repo, '正常经过时间', 60) }), ''));
  17  |       }
  18  |     } finally { repo.close(); }
  19  |     const settings = defaultSettings(); settings.prompts.minNarrativeChars = 5; settings.prompts.actionOptions = false;
  20  |     for (const setting of Object.values(settings.memory.summaries) as { automatic: boolean }[]) setting.automatic = false;
  21  |     localStorage.setItem(settingsKey, JSON.stringify(settings));
  22  |     const config = defaultAiConfig(), channel = newChannel(); channel.baseUrl = 'https://history.mock.invalid/v1'; config.channels = [channel];
  23  |     config.routes.story = { channelId: channel.id, modelId: 'story' };
  24  |     for (const stage of ['variables', 'world', 'memory']) config.routes[stage] = { mode: 'independent', channelId: channel.id, modelId: stage };
  25  |     saveAiConfig(localStorage, config); new CredentialVault(sessionStorage, localStorage).set(channel.id, 'synthetic-history-key');
  26  |   }, turns);
  27  |   await page.reload();
  28  | }
  29  | async function read(page: Page) {
  30  |   return page.evaluate(async () => {
  31  |     const p = '/src/services/storage/saveRepository.ts', { SaveRepository } = await import(p), repo = await SaveRepository.open();
  32  |     try { return { ...await repo.loadGame('save-a'), raw: await repo.exportRaw('save-a'), history: await repo.history.list('save-a'), undo: await repo.undoStatus('save-a') }; }
  33  |     finally { repo.close(); }
  34  |   });
  35  | }
  36  | async function open(page: Page) {
  37  |   if ((page.viewportSize()?.width ?? 1440) > 900) {
  38  |     const button = page.getByRole('button', { name: /继续游戏/ });
  39  |     if (await button.count()) await button.first().click();
  40  |   }
> 41  |   await page.getByRole('button', { name: '历史存档', exact: true }).click();
      |                                                                 ^ Error: locator.click: Test ended.
  42  |   await expect(page.getByRole('dialog', { name: '历史存档', exact: true })).toBeVisible();
  43  |   await expect(page.getByText('正在读取历史元数据…')).toHaveCount(0);
  44  | }
  45  | async function mock(page: Page) {
  46  |   const calls: string[] = [], control = { failStory: false };
  47  |   await page.route('https://history.mock.invalid/**', async route => {
  48  |     const stage = String(route.request().postDataJSON().model); calls.push(stage);
  49  |     const state = (await read(page)).state;
  50  |     const text = stage === 'story' ? control.failStory ? '<正文>不完整' : '<thinking>继续当前选择。</thinking><正文>【旁白】主角来到公园，沿着小路慢慢散步。</正文><短期记忆>在公园散步。</短期记忆><变量规划>[]</变量规划>'
  51  |       : stage === 'variables' ? `<thinking>记录时间。</thinking><说明>时间经过。</说明><命令>\nset worldClock = "${new Date(Date.parse(state.worldClock) + 60000).toISOString()}"\n</命令>`
  52  |         : JSON.stringify({ worldCommands: [], taskCommands: [], eventCommands: [], visibleHooks: [], unresolved: [] });
  53  |     await route.fulfill({ contentType: stage === 'story' ? 'text/event-stream' : 'application/json', body: stage === 'story'
  54  |       ? `data: ${JSON.stringify({ choices: [{ delta: { content: text } }] })}\n\ndata: ${JSON.stringify({ choices: [{ delta: {}, finish_reason: 'stop' }] })}\n\ndata: [DONE]\n\n`
  55  |       : JSON.stringify({ choices: [{ message: { content: text }, finish_reason: 'stop' }] }) });
  56  |   });
  57  |   return { calls, control };
  58  | }
  59  | async function choose(page: Page, turn: number) {
  60  |   await page.getByRole('button', { name: `预览第 ${turn} 回合`, exact: true }).click();
  61  |   await expect(page.getByText(`只读历史 · 第 ${turn} 回合结束。`, { exact: false })).toBeVisible();
  62  | }
  63  | async function confirm(page: Page) {
  64  |   await page.getByLabel('从此历史节点开始的行动').fill('改去公园走走');
  65  |   await page.getByRole('button', { name: '发送新行动（先确认覆盖）', exact: true }).click();
  66  |   await page.getByRole('button', { name: '确认覆盖并继续', exact: true }).click();
  67  | }
  68  | 
  69  | test('自动五节点只读预览、取消覆盖、旧链不变、日夜与窄屏截图', async ({ page }, info) => {
  70  |   await seed(page); const server = await mock(page), before = await read(page); await open(page);
  71  |   await expect(page.locator('.history-node-list > li')).toHaveCount(5);
  72  |   await page.screenshot({ path: info.outputPath('automatic-night.png') });
  73  |   await choose(page, 2); await page.getByLabel('历史阅读内容').selectOption('人物档案');
  74  |   await expect(page.locator('.history-world')).toContainText(before.state.protagonist.name);
  75  |   await page.getByLabel('历史阅读内容').selectOption('正文');
  76  |   await page.getByLabel('从此历史节点开始的行动').fill('取消的选择');
  77  |   await page.getByRole('button', { name: '发送新行动（先确认覆盖）' }).click();
  78  |   await expect(page.getByLabel('覆盖时间线确认')).toContainText('第 3～7 回合');
  79  |   await page.screenshot({ path: info.outputPath('overwrite-warning.png') });
  80  |   await page.getByRole('button', { name: '取消，保留原进度' }).click();
  81  |   expect(await read(page)).toEqual(before); expect(server.calls).toEqual([]);
  82  |   await page.evaluate(() => { document.documentElement.dataset.appearance = 'day'; });
  83  |   await page.setViewportSize(info.project.name === 'mobile' ? { width: 375, height: 667 } : { width: 901, height: 600 });
  84  |   await page.screenshot({ path: info.outputPath('preview-day-narrow.png') });
  85  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  86  |   await page.getByRole('button', { name: '关闭资料界面' }).click(); await open(page);
  87  |   expect(await read(page)).toEqual(before); expect(server.calls).toEqual([]);
  88  | });
  89  | 
  90  | test('手动收藏命名重开改名删除，完整状态导出，确认后单次三阶段且连续推进两回合', async ({ page }, info) => {
  91  |   await seed(page); const server = await mock(page); await open(page);
  92  |   await page.getByRole('button', { name: '保存当前正式节点' }).click();
  93  |   await page.getByLabel('历史收藏名称').fill('重要谈判前'); await page.getByRole('button', { name: '保存收藏', exact: true }).click();
  94  |   await expect(page.locator('.history-node-list')).toContainText('重要谈判前');
  95  |   const saved = await read(page); expect(saved.history.nodes.filter((n: { kind: string }) => n.kind === 'manual')).toHaveLength(1);
  96  |   await page.reload(); await open(page); await page.getByRole('button', { name: '手动收藏', exact: true }).click();
  97  |   await page.getByRole('button', { name: '重命名', exact: true }).click(); await page.getByLabel('历史收藏名称').fill('谈判前收藏');
  98  |   await page.getByRole('button', { name: '保存名称', exact: true }).click(); await expect(page.locator('.history-node-list')).toContainText('谈判前收藏');
  99  |   const downloaded = page.waitForEvent('download'); await page.getByRole('button', { name: '导出节点备份' }).click();
  100 |   expect((await downloaded).suggestedFilename()).toContain('.heijin.json');
  101 |   await page.getByRole('button', { name: '自动历史', exact: true }).click(); await choose(page, 2); await confirm(page);
  102 |   await expect(page.locator('.game-layout')).toBeVisible(); await expect.poll(async () => (await read(page)).state.turnNumber).toBe(3);
  103 |   expect(server.calls).toEqual(['story', 'variables', 'world']); expect((await read(page)).undo.available).toBe(1);
  104 |   await page.getByLabel('你的行动', { exact: true }).fill('继续去公园散步'); await page.getByRole('button', { name: '发送', exact: true }).click();
  105 |   await expect.poll(async () => (await read(page)).state.turnNumber).toBe(4);
  106 |   expect(server.calls).toEqual(['story', 'variables', 'world', 'story', 'variables', 'world']);
  107 |   const fresh = await read(page); expect(fresh.undo.available).toBe(2); expect(fresh.raw.records.turnReceipts).toHaveLength(2);
  108 |   expect(fresh.history.nodes.find((n: { kind: string }) => n.kind === 'manual').oldTimeline).toBe(true);
  109 |   await page.reload(); expect((await read(page)).state).toEqual(fresh.state); expect(server.calls).toHaveLength(6);
  110 |   await page.goto('/'); await open(page); await page.getByRole('button', { name: '手动收藏', exact: true }).click();
  111 |   await expect(page.locator('.history-node-list')).toContainText('旧时间线收藏'); await page.screenshot({ path: info.outputPath('old-timeline-collection.png') });
  112 |   await page.getByRole('button', { name: '删除收藏', exact: true }).click(); await page.getByRole('button', { name: '保留收藏', exact: true }).click();
  113 |   expect((await read(page)).history.nodes.filter((n: { kind: string }) => n.kind === 'manual')).toHaveLength(1);
  114 |   await page.getByRole('button', { name: '删除收藏', exact: true }).click(); await page.getByRole('button', { name: '确认删除收藏', exact: true }).click();
  115 |   await expect(page.getByText('尚未保存手动收藏。')).toBeVisible(); expect((await read(page)).state).toEqual(fresh.state);
  116 | });
  117 | 
  118 | test('确认后正文失败保留历史基线及输入；刷新不自动请求，主动恢复后正式结算', async ({ page }, info) => {
  119 |   await seed(page); const server = await mock(page); server.control.failStory = true;
  120 |   await open(page); await choose(page, 2); await confirm(page);
  121 |   await expect.poll(async () => (await read(page)).draft?.stageStatus.story).toBe('failed');
  122 |   const failure = await read(page); expect(failure.state.turnNumber).toBe(2); expect(failure.undo.available).toBe(0); expect(failure.draft.userInput).toBe('改去公园走走');
  123 |   expect(server.calls).toEqual(['story']); await page.reload(); await expect(page.locator('.game-layout')).toBeVisible();
  124 |   expect((await read(page)).raw).toEqual(failure.raw); expect(server.calls).toEqual(['story']);
  125 |   await page.screenshot({ path: info.outputPath('restored-failure.png') });
  126 |   server.control.failStory = false;
  127 |   await page.getByLabel('你的行动', { exact: true }).fill('重新在公园散步'); await page.getByRole('button', { name: '发送', exact: true }).click();
  128 |   await expect.poll(async () => (await read(page)).state.turnNumber).toBe(3);
  129 |   expect(server.calls).toEqual(['story', 'story', 'variables', 'world']);
  130 | });
  131 | 
  132 | test('跨标签正在生成和无 Web Locks 保守拒绝覆盖，零额外请求', async ({ page, context }) => {
  133 |   await seed(page); const server = await mock(page); await open(page); await choose(page, 2);
  134 |   const other = await context.newPage(); await other.goto('/');
  135 |   await other.evaluate(() => { void navigator.locks.request('heijin.turn:save-a', () => new Promise<void>(resolve => { (window as unknown as { releaseHistoryLock: () => void }).releaseHistoryLock = resolve; })); });
  136 |   await expect.poll(() => other.evaluate(() => Boolean((window as unknown as { releaseHistoryLock?: () => void }).releaseHistoryLock))).toBe(true);
  137 |   const before = await read(page); await confirm(page); await expect(page.getByRole('alert')).toContainText('其他标签');
  138 |   expect(await read(page)).toEqual(before); expect(server.calls).toEqual([]);
  139 |   await other.evaluate(() => (window as unknown as { releaseHistoryLock: () => void }).releaseHistoryLock()); await other.close();
  140 |   await choose(page, 2); await page.evaluate(() => { Object.defineProperty(navigator, 'locks', { value: undefined, configurable: true }); });
  141 |   await confirm(page); await expect(page.getByRole('alert')).toContainText('跨标签互斥');
```
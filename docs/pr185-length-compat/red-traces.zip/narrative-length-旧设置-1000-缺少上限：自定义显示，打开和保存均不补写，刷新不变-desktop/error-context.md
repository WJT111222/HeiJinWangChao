# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: narrative-length.spec.ts >> 旧设置 1000 缺少上限：自定义显示，打开和保存均不补写，刷新不变
- Location: e2e/narrative-length.spec.ts:88:3

# Error details

```
Error: expect(locator).toBeChecked() failed

Locator:  getByRole('dialog', { name: '设置', exact: true }).getByRole('radiogroup', { name: '正文篇幅档位' }).getByRole('radio', { name: /^自定义/ })
Expected: checked
Received: unchecked
Timeout:  5000ms

Call log:
  - Expect "toBeChecked" getByRole('dialog', { name: '设置', exact: true }).getByRole('radiogroup', { name: '正文篇幅档位' }).getByRole('radio', { name: /^自定义/ }) with timeout 5000ms
  - waiting for getByRole('dialog', { name: '设置', exact: true }).getByRole('radiogroup', { name: '正文篇幅档位' }).getByRole('radio', { name: /^自定义/ })
    14 × locator resolved to <input type="radio" value="custom" name="length-tier"/>
       - unexpected value "unchecked"

```

```yaml
- radio "自定义 自己填写"
```

# Test source

```ts
  1   | import { expect, test } from './helpers/test';
  2   | import type { Page } from '@playwright/test';
  3   | 
  4   | /** 正文篇幅：低 / 中 / 高三档一键填好最低字数与建议上限；手动改数字或点「自定义」为自定义。 */
  5   | async function openPromptSettings(page: Page, seed?: Record<string, unknown>) {
  6   |   await page.route('**/*', (route) => {
  7   |     const url = new URL(route.request().url());
  8   |     return ['127.0.0.1', 'localhost'].includes(url.hostname) ? route.continue() : route.abort();
  9   |   });
  10  |   await page.goto('/');
  11  |   if (seed) {
  12  |     await page.evaluate(async (prompts) => {
  13  |       const path = '/src/ui/settings/model.ts', { defaultSettings, settingsKey } = await import(path);
  14  |       const settings = defaultSettings(); settings.prompts = { ...settings.prompts, ...prompts };
  15  |       if (!('maxNarrativeChars' in prompts)) delete settings.prompts.maxNarrativeChars;
  16  |       localStorage.setItem(settingsKey, JSON.stringify(settings));
  17  |     }, seed);
  18  |     await page.reload();
  19  |   }
  20  |   await page.getByRole('button', { name: '设置', exact: true }).first().click();
  21  |   const root = page.getByRole('dialog', { name: '设置', exact: true });
  22  |   const back = root.getByRole('button', { name: '返回设置', exact: true });
  23  |   if (await back.isVisible()) await back.click();
  24  |   await root.getByRole('button', { name: '提示词', exact: true }).click();
  25  |   return root;
  26  | }
  27  | async function stored(page: Page) {
  28  |   return page.evaluate(async () => {
  29  |     const path = '/src/ui/settings/model.ts', { SettingsSchema, settingsKey } = await import(path);
  30  |     const raw = localStorage.getItem(settingsKey);
  31  |     return raw === null ? null : SettingsSchema.parse(JSON.parse(raw)).prompts as { minNarrativeChars: number; maxNarrativeChars?: number };
  32  |   });
  33  | }
  34  | const tier = (root: ReturnType<Page['getByRole']>, name: string) => root.getByRole('radiogroup', { name: '正文篇幅档位' }).getByRole('radio', { name: new RegExp(`^${name}`) });
  35  | 
  36  | test('新玩家默认低档；选中档 / 高档后保存，刷新仍在；高档提示输出长度', async ({ page }, info) => {
  37  |   const root = await openPromptSettings(page);
  38  |   await expect(tier(root, '低')).toBeChecked();
  39  |   await expect(root.getByLabel('正文最低字数', { exact: true })).toHaveValue('1000');
  40  |   await expect(root.getByLabel('正文建议上限', { exact: true })).toHaveValue('2000');
  41  |   await root.getByRole('group', { name: '正文篇幅' }).screenshot({ path: `/tmp/length-${info.project.name}-low.png` });
  42  | 
  43  |   await tier(root, '中').check();
  44  |   await expect(root.getByLabel('正文最低字数', { exact: true })).toHaveValue('4000');
  45  |   await expect(root.getByLabel('正文建议上限', { exact: true })).toHaveValue('5000');
  46  |   await root.getByRole('button', { name: '保存本地设置', exact: true }).click();
  47  |   await page.reload();
  48  |   const mid = await openPromptSettings(page);
  49  |   await expect(tier(mid, '中')).toBeChecked();
  50  |   await tier(root, '高').check();
  51  |   await expect(root.getByLabel('正文最低字数', { exact: true })).toHaveValue('8000');
  52  |   await expect(root.getByLabel('正文建议上限', { exact: true })).toHaveValue('10000');
  53  |   await expect(root.getByRole('group', { name: '正文篇幅' })).toContainText('建议在「AI 连接」把最大输出调到 16k 以上');
  54  |   await root.getByRole('group', { name: '正文篇幅' }).screenshot({ path: `/tmp/length-${info.project.name}-high.png` });
  55  |   await root.getByRole('button', { name: '保存本地设置', exact: true }).click();
  56  |   await expect(root.getByRole('status')).toContainText('本地偏好已保存');
  57  |   expect(await stored(page)).toMatchObject({ minNarrativeChars: 8000, maxNarrativeChars: 10000 });
  58  | 
  59  |   await page.reload();
  60  |   const again = await openPromptSettings(page);
  61  |   await expect(tier(again, '高')).toBeChecked();
  62  | });
  63  | 
  64  | test('自定义：手动改数字即为自定义；上限低于最低时不能保存', async ({ page }, info) => {
  65  |   const root = await openPromptSettings(page);
  66  |   await root.getByLabel('正文最低字数', { exact: true }).fill('3000');
  67  |   await expect(tier(root, '自定义')).toBeChecked();
  68  |   await root.getByLabel('正文建议上限', { exact: true }).fill('2500');
  69  |   await expect(root.getByRole('group', { name: '正文篇幅' }).getByRole('alert')).toContainText('建议上限不能低于最低字数');
  70  |   await root.getByRole('group', { name: '正文篇幅' }).screenshot({ path: `/tmp/length-${info.project.name}-invalid.png` });
  71  |   await root.getByRole('button', { name: '保存本地设置', exact: true }).click();
  72  |   await expect(root.getByRole('status')).toContainText('正文建议上限不能低于最低字数');
  73  |   expect(await stored(page)).toBeNull();
  74  | 
  75  |   await root.getByLabel('正文建议上限', { exact: true }).fill('3600');
  76  |   await root.getByRole('button', { name: '保存本地设置', exact: true }).click();
  77  |   await expect(root.getByRole('status')).toContainText('本地偏好已保存');
  78  |   expect(await stored(page)).toMatchObject({ minNarrativeChars: 3000, maxNarrativeChars: 3600 });
  79  | 
  80  |   // 点「自定义」不改数字，只是把焦点放到最低字数上。
  81  |   await tier(root, '低').check();
  82  |   await tier(root, '自定义').check();
  83  |   await expect(root.getByLabel('正文最低字数', { exact: true })).toBeFocused();
  84  |   await expect(root.getByLabel('正文最低字数', { exact: true })).toHaveValue('1000');
  85  | });
  86  | 
  87  | for (const [min, max] of [[1000, 2000], [1500, 2000], [4000, 5000], [8000, 10000]]) {
  88  |   test(`旧设置 ${min} 缺少上限：自定义显示，打开和保存均不补写，刷新不变`, async ({ page }, info) => {
  89  |     const root = await openPromptSettings(page, { minNarrativeChars: min });
  90  |     const raw = () => page.evaluate(() => localStorage.getItem('heijin.settings.v1'));
  91  |     const before = await raw();
> 92  |     await expect(tier(root, '自定义')).toBeChecked();
      |                                     ^ Error: expect(locator).toBeChecked() failed
  93  |     await expect(root.getByLabel('正文最低字数', { exact: true })).toHaveValue(String(min));
  94  |     await expect(root.getByLabel('正文建议上限', { exact: true })).toHaveValue(String(max));
  95  |     expect(await raw()).toBe(before);
  96  |     expect(await stored(page)).not.toHaveProperty('maxNarrativeChars');
  97  |     await root.getByRole('group', { name: '正文篇幅' }).screenshot({ path: info.outputPath(`legacy-${min}.png`), animations: 'disabled' });
  98  |     await root.getByRole('button', { name: '保存本地设置', exact: true }).click();
  99  |     await expect(root.getByRole('status')).toContainText('本地偏好已保存');
  100 |     expect(await raw()).toBe(before);
  101 |     await root.getByRole('button', { name: '关闭资料界面', exact: true }).click();
  102 |     const reopened = await openPromptSettings(page);
  103 |     await expect(tier(reopened, '自定义')).toBeChecked();
  104 |     await page.reload();
  105 |     const again = await openPromptSettings(page);
  106 |     await expect(tier(again, '自定义')).toBeChecked();
  107 |     await expect(again.getByLabel('正文最低字数', { exact: true })).toHaveValue(String(min));
  108 |     await expect(again.getByLabel('正文建议上限', { exact: true })).toHaveValue(String(max));
  109 |     expect(await raw()).toBe(before);
  110 |   });
  111 | }
  112 | 
  113 | test('旧设置手动改最低字数时，固定当前推算上限', async ({ page }) => {
  114 |   const root = await openPromptSettings(page, { minNarrativeChars: 1500 });
  115 |   await root.getByLabel('正文最低字数', { exact: true }).fill('1800');
  116 |   await expect(tier(root, '自定义')).toBeChecked();
  117 |   await expect(root.getByLabel('正文建议上限', { exact: true })).toHaveValue('2000');
  118 |   await root.getByRole('button', { name: '保存本地设置', exact: true }).click();
  119 |   await expect(root.getByRole('status')).toContainText('本地偏好已保存');
  120 |   expect(await stored(page)).toMatchObject({ minNarrativeChars: 1800, maxNarrativeChars: 2000 });
  121 |   await page.reload();
  122 |   const again = await openPromptSettings(page);
  123 |   await expect(tier(again, '自定义')).toBeChecked();
  124 |   await expect(again.getByLabel('正文最低字数', { exact: true })).toHaveValue('1800');
  125 | });
  126 | 
  127 | test('旧设置主动选择低档后保存刷新，按显式预设恢复', async ({ page }) => {
  128 |   const root = await openPromptSettings(page, { minNarrativeChars: 1000 });
  129 |   await expect(tier(root, '自定义')).toBeChecked();
  130 |   await tier(root, '低').check();
  131 |   await root.getByRole('button', { name: '保存本地设置', exact: true }).click();
  132 |   await expect(root.getByRole('status')).toContainText('本地偏好已保存');
  133 |   expect(await stored(page)).toMatchObject({ minNarrativeChars: 1000, maxNarrativeChars: 2000 });
  134 |   await page.reload();
  135 |   const again = await openPromptSettings(page);
  136 |   await expect(tier(again, '低')).toBeChecked();
  137 | });
  138 | 
```
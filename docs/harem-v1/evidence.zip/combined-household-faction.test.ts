import {expect,it} from 'vitest';
import {organizationState} from './fixtures/organizations';
import {npc} from './fixtures/game';
import {joinFamily} from './fixtures/harem';
import {DomainCommandSchema,commitCommands} from '../domain/commands';
import {GameStateSchema} from '../domain/state';
it('两模块同一正式存档、同批提交，交替地位与调整组织职位互不改写',()=>{
 const state=organizationState();state.npc.a={...npc('a'),gender:'female',age:36};state.npc.b={...npc('b'),gender:'female',age:31};
 const h=(changes:unknown[],expectedRevision:number)=>DomainCommandSchema.parse({type:'ApplyHaremChanges',expectedRevision,changes,commandId:'house',evidence:'家庭已确认'});
 const f=(action:string,position:string)=>DomainCommandSchema.parse({type:'RecordOrgRelation',commandId:'faction',evidence:'组织任命',organizationId:'org-gang',relation:'正式成员',reason:'任命',faction:{action,position,...(action==='bind'?{bondText:'共同负责事务'}:{})}});
 const both=commitCommands(state,'both',state.revision,[h([joinFamily('a',100),joinFamily('b',92)],state.revision),f('bind','合伙人')]);
 const switched=commitCommands(both,'switch',both.revision,[h([{op:'score',npcId:'a',from:100,to:84,reason:'共同决定'},{op:'score',npcId:'b',from:92,to:100,reason:'共同决定'}],both.revision)]);
 expect(switched.protagonistFaction).toEqual(both.protagonistFaction);expect(switched.organizations).toEqual(both.organizations);
 const promoted=commitCommands(switched,'promote',switched.revision,[f('update','会长')]);
 expect(promoted.harem).toEqual(switched.harem);expect(GameStateSchema.parse(JSON.parse(JSON.stringify(promoted))).protagonistFaction?.position).toBe('会长');
});

import { createServer } from 'node:http';
import type { ServerResponse } from 'node:http';
import { test, expect } from './helpers/test';
import type { Locator, Page, TestInfo } from '@playwright/test';
import { paintedContrast } from './helpers/readabilityContrast';
import { cities, seedDayReading, setAppearance, repositoryValue } from './helpers/dayReadability';
import { openWorkflow, openWorkflowStage } from './helpers/gameLayout';

async function contrast(page: Page, target: Locator, info: TestInfo, name: string, threshold?: number) {
  const row = await paintedContrast(page, target);
  await info.attach(name, { contentType: 'application/json', body: JSON.stringify(row) });
  expect(row.ratio, `${name}: ${JSON.stringify(row)}`).toBeGreaterThanOrEqual(threshold ?? row.threshold);
  return row;
}
async function shot(page: Page, info: TestInfo, name: string) {
  await page.mouse.move(0, 0);
  await page.screenshot({ path: info.outputPath(`${name}.png`), animations: 'disabled' });
}
test.beforeEach(async ({ page }) => {
  await page.route('**/*', route => ['127.0.0.1', 'localhost'].includes(new URL(route.request().url()).hostname) ? route.continue() : route.abort());
});

for (const city of cities) test(`四城正文 ${city}：主角/NPC/旁白、当前/历史、日夜与系统`, async ({ page }, info) => {
  let posts = 0; page.on('request', req => { if (req.method() === 'POST') posts++; });
  await seedDayReading(page, city);
  const before = await repositoryValue(page), reader = page.getByTestId('story-reader');
  await expect(page.locator('.story-entry')).toHaveCount(2);
  for (const state of ['latest', 'past']) {
    const entry = page.locator(`.story-entry.${state}`).first();
    for (const [name, selector] of [['hero', '.story-dialogue-hero .story-bubble'], ['speaker', '.story-dialogue-hero .story-speaker'],
      ['npc', '.story-dialogue:not(.story-dialogue-hero) .story-bubble'], ['narration', '.story-narration']] as const)
      await contrast(page, entry.locator(selector).first(), info, `${city}-${state}-${name}`, 4.5);
  }
  await reader.evaluate(el => el.scrollTop = 0); await shot(page, info, `${city}-day-history`);
  await reader.evaluate(el => el.scrollTop = el.scrollHeight); await shot(page, info, `${city}-day-current`);
  await setAppearance(page, 'night'); await expect(page.locator('html')).toHaveAttribute('data-appearance', 'night');
  const night = await page.locator('.story-entry.latest .story-dialogue-hero .story-bubble').evaluate(el => getComputedStyle(el).color);
  expect(night).toBe('rgb(241, 230, 200)');
  await shot(page, info, `${city}-night`);
  await page.emulateMedia({ colorScheme: 'light' }); await setAppearance(page, 'system');
  await expect(page.locator('html')).toHaveAttribute('data-appearance', 'day');
  await contrast(page, page.locator('.story-entry.latest .story-dialogue-hero .story-bubble'), info, `${city}-system-light`, 4.5);
  await shot(page, info, `${city}-system-light`);
  await page.emulateMedia({ colorScheme: 'dark' }); await expect(page.locator('html')).toHaveAttribute('data-appearance', 'night');
  expect(await page.locator('.story-entry.latest .story-dialogue-hero .story-bubble').evaluate(el => getComputedStyle(el).color)).toBe(night);
  expect(await repositoryValue(page)).toEqual(before); expect(posts).toBe(0);
});

test('哈尔滨铭牌：不透明钢青、普通/历史/草稿，冰刻形状与缩放', async ({ page }, info) => {
  await seedDayReading(page, 'harbin');
  for (const state of ['latest', 'past']) {
    const entry = page.locator(`.story-entry.${state}`).first(), plate = entry.locator('.plate');
    expect(await plate.evaluate(el => getComputedStyle(el).backgroundColor)).not.toBe('rgba(0, 0, 0, 0)');
    expect(await plate.evaluate(el => getComputedStyle(el).borderTopLeftRadius)).not.toBe('0px');
    for (const part of ['p-num', 'p-cn', 'p-sub']) await contrast(page, entry.locator(`.${part}`), info, `harbin-${state}-${part}`);
    await plate.scrollIntoViewIfNeeded(); await shot(page, info, `harbin-${state}-plate`);
  }
});

for (const mode of ['pending', 'running', 'failed', 'complete'] as const) test(`工作流 ${mode}：深色浮层标题/正文/按钮、焦点、诊断、预览`, async ({ page }, info) => {
  let response: ServerResponse | undefined, calls = 0;
  const server = createServer(async (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*'); res.setHeader('Access-Control-Allow-Headers', 'content-type,authorization');
    if (req.method === 'OPTIONS') { res.writeHead(204).end(); return; }
    for await (const chunk of req) void chunk;
    calls++; response = res;
    if (mode === 'failed') { res.writeHead(401, { 'Content-Type': 'application/json' }).end('{"error":{"message":"Mock authorization failure"}}'); return; }
    res.writeHead(200, { 'Content-Type': 'text/event-stream' }); res.flushHeaders();
    res.write('data: ' + JSON.stringify({ choices: [{ delta: { content: '<thinking>实际Mock规划</thinking><正文>【旁白】晨光照在街道上。\n【沈砚】今天先看看街坊们有什么消息。\n' } }] }) + '\n\n');
  });
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve));
  const address = server.address(); if (!address || typeof address === 'string') throw new Error('missing Mock port');
  try {
    await seedDayReading(page, 'harbin', 'day', mode, `http://127.0.0.1:${address.port}/v1`);
    const before = await repositoryValue(page);
    if (mode === 'running' || mode === 'failed') {
      await openWorkflow(page); await page.locator('#workflow-pop .workflow-primary button').click();
      await expect.poll(() => calls).toBe(1);
      if (mode === 'running') {
        await expect(page.getByRole('article', { name: '流式正文预览', exact: true })).toBeVisible();
        await page.keyboard.press('Escape');
        const preview = page.getByRole('article', { name: '流式正文预览', exact: true });
        await preview.locator('.plate').scrollIntoViewIfNeeded();
        for (const part of ['p-num', 'p-cn', 'p-sub']) await contrast(page, preview.locator(`.${part}`), info, `harbin-preview-${part}`);
        await contrast(page, preview.locator('.story-dialogue-hero .story-bubble'), info, 'stream-hero', 4.5);
        await shot(page, info, 'harbin-live-preview');
      } else {
        await expect.poll(async () => (await repositoryValue(page)).draft?.failures.length).toBeGreaterThan(0);
        const diagnostics = page.getByRole('dialog', { name: '重试与变更详情', exact: true });
        if (await diagnostics.isVisible()) await page.keyboard.press('Escape');
      }
    }
    await openWorkflow(page);
    await contrast(page, page.locator('#workflow-pop .wf-hd h3'), info, `${mode}-workflow-heading`, 4.5);
    await contrast(page, page.locator('#workflow-pop .workflow-fee'), info, `${mode}-workflow-fee`, 4.5);
    const input = page.locator('.workflow-drawer-input');
    if (await input.isVisible()) { await contrast(page, input, info, `${mode}-input-button`, 4.5); await input.focus(); await expect(input).toBeFocused(); }
    const primary = page.locator('#workflow-pop .workflow-primary button');
    if (await primary.isVisible()) { await contrast(page, primary, info, `${mode}-primary`, 4.5); await primary.focus(); await expect(primary).toBeFocused(); }
    await shot(page, info, `workflow-${mode}`);
    await openWorkflowStage(page, 'variables');
    await contrast(page, page.locator('#workflow-pop .wf-dt-body'), info, `${mode}-workflow-body`, 4.5);
    // Disabled controls remain disabled; WCAG exempts inactive text. Capture actual styling without claiming AA.
    const action = page.locator('#workflow-pop .wf-dt-act button');
    if (await action.isVisible() && await action.isDisabled()) await info.attach('inactive-control', { body: JSON.stringify(await paintedContrast(page, action)), contentType: 'application/json' });
    if (mode === 'failed') { await contrast(page, page.locator('#workflow-pop .wf-banner-msg p').first(), info, 'workflow-error', 4.5); }
    if (mode === 'running') { await primary.click(); await expect.poll(() => response?.destroyed).toBe(true); }
    else { expect((await repositoryValue(page)).state).toEqual(before.state); }
    expect(calls).toBe(mode === 'running' || mode === 'failed' ? 1 : 0);
  } finally { server.closeAllConnections(); await new Promise<void>(resolve => server.close(() => resolve())); }
});

test('纸页隔离与外观保存：人物/世界/设置、未保存偏好、失败回退', async ({ page }, info) => {
  await seedDayReading(page, 'shanghai'); const before = await repositoryValue(page);
  const mobile = (page.viewportSize()?.width ?? 0) <= 900;
  if (mobile) { await page.getByRole('navigation', { name: '底部导航' }).getByRole('button', { name: '人物', exact: true }).click(); await page.getByRole('button', { name: '人物档案', exact: true }).click(); }
  else await page.locator('[data-archive-panel="人物档案"]').click();
  const profile = page.getByRole('dialog', { name: '人物档案', exact: true }); await expect(profile).toBeVisible();
  expect(await profile.evaluate(el => getComputedStyle(el).getPropertyValue('--text').trim().toLowerCase())).not.toBe('#ece7da');
  await shot(page, info, 'day-profile-paper'); await page.keyboard.press('Escape');
  if (mobile) { await page.getByRole('button', { name: '世界资料', exact: true }).click(); await page.getByRole('dialog', { name: '世界资料', exact: true }).getByRole('button', { name: 'NPC', exact: true }).click(); }
  else await page.locator('[data-archive-panel="NPC"]').click();
  await expect(page.getByRole('dialog', { name: 'NPC', exact: true })).toBeVisible(); await shot(page, info, 'day-world-paper'); await page.keyboard.press('Escape');
  await page.getByRole('button', { name: '设置', exact: true }).click(); const settings = page.getByRole('dialog', { name: '设置', exact: true });
  await settings.getByRole('button', { name: '运行', exact: true }).click(); await settings.getByLabel('请求超时（秒）', { exact: true }).fill('77');
  if (mobile) await settings.getByRole('button', { name: '返回设置', exact: true }).click();
  await settings.getByRole('button', { name: '外观', exact: true }).click(); await settings.getByRole('radio', { name: /夜间/ }).check();
  expect(await page.evaluate(() => JSON.parse(localStorage.getItem('heijin.settings.v1')!).runtime.timeoutSeconds)).toBe(120);
  if (mobile) await settings.getByRole('button', { name: '返回设置', exact: true }).click();
  await settings.getByRole('button', { name: '运行', exact: true }).click(); await expect(settings.getByLabel('请求超时（秒）', { exact: true })).toHaveValue('77');
  await settings.getByRole('button', { name: '保存本地设置', exact: true }).click();
  if (mobile) await settings.getByRole('button', { name: '返回设置', exact: true }).click();
  await settings.getByRole('button', { name: '外观', exact: true }).click(); await settings.getByRole('radio', { name: /日间/ }).check();
  await shot(page, info, 'day-appearance-settings');
  await page.evaluate(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function(key, value) { if (key === 'heijin.settings.v1') throw new DOMException('Mock storage rejection'); return original.call(this, key, value); }; });
  await settings.getByRole('radio', { name: /夜间/ }).click(); await expect(settings).toContainText('外观保存失败');
  await expect(page.locator('html')).toHaveAttribute('data-appearance', 'day'); expect(await repositoryValue(page)).toEqual(before);
});

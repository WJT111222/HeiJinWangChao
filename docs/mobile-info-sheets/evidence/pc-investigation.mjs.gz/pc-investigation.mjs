import { createRequire } from 'node:module';
import {readFileSync,writeFileSync} from 'node:fs';
const require=createRequire('/workspace/mobile-sheet-interaction/package.json'),{chromium,expect}=require('@playwright/test'),ts=require('typescript');
const source=readFileSync('/workspace/mobile-sheet-interaction/e2e/mobile-info-sheets.spec.ts','utf8');
const seed=new Function('expect',ts.transpileModule(source.slice(source.indexOf('async function seed'),source.indexOf('async function stored')),{compilerOptions:{target:ts.ScriptTarget.ESNext}}).outputText+';return seed;')(expect);
const browser=await chromium.launch({executablePath:'/usr/bin/chromium'}),rows=[];
for(const [i,port] of [54150,54152,54152].entries()){
 const ctx=await browser.newContext({baseURL:`http://127.0.0.1:${port}`,viewport:{width:1440,height:900},reducedMotion:'reduce'}),page=await ctx.newPage();await ctx.addInitScript(()=>{const d=new Date();localStorage.setItem('heijin.notices.hidden-on.v1',[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-'));});await page.route('https://**/*',r=>r.abort());await seed(page);await page.locator('[data-archive-panel="人物档案"]').click();await expect(page.getByRole('dialog',{name:'人物档案',exact:true})).toBeVisible();await page.mouse.move(0,0);await page.evaluate(()=>document.fonts.ready);await page.screenshot({animations:'disabled'});
 rows.push(await page.locator('.status-actions button').first().evaluate(el=>{const e=el,s=getComputedStyle(e);return{element:e.outerHTML,rect:e.getBoundingClientRect().toJSON(),parentRect:e.parentElement.getBoundingClientRect().toJSON(),parentScroll:e.parentElement.parentElement.scrollTop,focus:document.activeElement?.outerHTML,styles:Object.fromEntries([...s].map(k=>[k,s.getPropertyValue(k)]))};}));
 await page.screenshot({path:`/workspace/mobile-sheet-interaction-evidence/pc-${i}.png`,animations:'disabled'});await ctx.close();
}
await browser.close();writeFileSync('/workspace/mobile-sheet-interaction-evidence/pc-computed.json',JSON.stringify(rows,null,2));for(let i=1;i<rows.length;i++) console.log(i,JSON.stringify(Object.fromEntries(Object.keys(rows[0].styles).filter(k=>rows[0].styles[k]!==rows[i].styles[k]).map(k=>[k,[rows[0].styles[k],rows[i].styles[k]]]))),rows[0].rect,rows[i].rect,rows[0].parentScroll,rows[i].parentScroll);

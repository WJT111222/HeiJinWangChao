import { createRequire } from 'node:module';
import {readFileSync,writeFileSync} from 'node:fs';
const require=createRequire('/workspace/mobile-sheet-interaction/package.json'),{chromium,expect}=require('@playwright/test'),ts=require('typescript');
const source=readFileSync('/workspace/mobile-sheet-interaction/e2e/mobile-info-sheets.spec.ts','utf8');
const seed=new Function('expect',ts.transpileModule(source.slice(source.indexOf('async function seed'),source.indexOf('async function stored')),{compilerOptions:{target:ts.ScriptTarget.ESNext}}).outputText+';return seed;')(expect);
const browser=await chromium.launch({executablePath:'/usr/bin/chromium'}),rows=[];
for(const [label,port] of [['before',54152],['after',54150]]){
 const ctx=await browser.newContext({baseURL:`http://127.0.0.1:${port}`,viewport:{width:390,height:844},isMobile:true,hasTouch:true,reducedMotion:'reduce'}),page=await ctx.newPage();await ctx.addInitScript(()=>{const d=new Date();localStorage.setItem('heijin.notices.hidden-on.v1',[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-'));});await page.route('https://**/*',r=>r.abort());await seed(page);
 for(const entry of ['人物','世界资料']){
  await page.getByRole('navigation',{name:'底部导航'}).getByRole('button',{name:entry,exact:true}).click();const d=page.getByRole('dialog',{name:entry==='人物'?'此时此地':entry,exact:true});await expect(d).toBeVisible();
  await page.screenshot({path:`/workspace/mobile-sheet-interaction-evidence/matched-${label}-${entry}-initial.png`,animations:'disabled'});rows.push({label,entry,initial:await d.boundingBox()});
  if(label==='after'){await d.getByRole('button',{name:'展开面板',exact:true}).click();await page.screenshot({path:`/workspace/mobile-sheet-interaction-evidence/matched-${label}-${entry}-expanded.png`,animations:'disabled'});rows.push({label,entry,expanded:await d.boundingBox()});}
  await page.keyboard.press('Escape');
 }
 await ctx.close();
}
await browser.close();writeFileSync('/workspace/mobile-sheet-interaction-evidence/matched-bounds.json',JSON.stringify(rows,null,2));

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ai-settings.spec.ts >> 真实浏览器加载原文、校验哈希并组装六种模式，记录模块顺序
- Location: e2e/ai-settings.spec.ts:9:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

  Array [
-   "stages.opening.variables.text",
+   "stages.opening.variables",
  ]
```

# Page snapshot

```yaml
- main "游戏首页与存档馆" [ref=e4]:
  - generic [ref=e5]:
    - generic [aria-hidden] [ref=e6]: 黑
    - generic [ref=e7]:
      - text: 黑金王朝
      - generic [ref=e8]: HEIJINWANGCHAO
    - button "设置" [ref=e9] [cursor=pointer]
    - generic [ref=e10]: V1.0 Beta
  - generic [ref=e11]:
    - paragraph [ref=e12]: MODERN CITY / OPEN WORLD
    - heading "黑金王朝" [level=1] [ref=e13]
    - paragraph [ref=e14]: 起点有冲突，人生不预设结局。
  - status "终点 新人生，时刻 --:--，可购票" [ref=e15]:
    - generic [ref=e16]:
      - text: 终点
      - generic [ref=e17]: DEST
    - generic [ref=e18]:
      - generic [ref=e19]: 新
      - generic [ref=e20]: 人
      - generic [ref=e21]: 生
    - generic [ref=e22]:
      - generic [ref=e23]: "-"
      - generic [ref=e24]: "-"
      - generic [ref=e25]: ":"
      - generic [ref=e26]: "-"
      - generic [ref=e27]: "-"
    - generic [ref=e28]: 可购票
  - generic [ref=e29]:
    - generic [ref=e30]: 车票 00
    - generic [ref=e31]: 本地保存 · 无需账号
    - button "导入备份" [ref=e32] [cursor=pointer]: ⤓ 导入备份
    - button "刷新列表" [ref=e33] [cursor=pointer]
  - region "车票栏，左右方向键切换" [ref=e34]:
    - article "空白车票：开启新的人生" [ref=e36]:
      - generic [ref=e37]:
        - generic [ref=e38]:
          - generic [ref=e39]: 空白车票
          - generic [ref=e40]: NEW LIFE
          - generic [ref=e41]: NEW
        - generic [ref=e42]:
          - generic [ref=e43]:
            - generic [ref=e44]:
              - generic [ref=e45]: FROM
              - generic [ref=e46]: ？
            - generic [aria-hidden] [ref=e47]: 单程
            - generic [ref=e49]:
              - generic [ref=e50]: TO
              - generic [ref=e51]: ？
          - generic [ref=e52]:
            - generic [ref=e53]:
              - term [ref=e54]: 城市
              - definition [ref=e55]
            - generic [ref=e57]:
              - term [ref=e58]: 职业
              - definition [ref=e59]
            - generic [ref=e61]:
              - term [ref=e62]: 存档
              - definition [ref=e63]: —
          - paragraph [ref=e64]: 四座城市 · 自由职业 · 开放人生
      - generic [ref=e66]:
        - text: 开启新的人生
        - generic [ref=e67]: ↓ 按住票根往下撕
  - navigation "车票页码" [ref=e69]:
    - button "第 1 张，空白车票" [ref=e70] [cursor=pointer]
  - paragraph [ref=e71]: 还没有开始的人生。创建角色，留下第一份存档。
  - button "开始新游戏" [ref=e73] [cursor=pointer]:
    - text: 开始新游戏
    - generic [aria-hidden] [ref=e74]: ↗
  - generic [ref=e75]:
    - group "游玩信息" [ref=e76]:
      - button "游玩须知与免责声明" [ref=e77] [cursor=pointer]
      - button "王朝公告" [ref=e78] [cursor=pointer]
    - paragraph [ref=e79]: 四座城市 · 自由职业 · 开放人生三阶段生成 · 原子结算 · 连续回合
```

# Test source

```ts
  1   | import { expect, test } from './helpers/test';
  2   | import { addChannel, backToList, chooseText, follow, openAiSettings, openChannel, saveAi, stageModel, testReply } from './helpers/aiSettings';
  3   | import { writeFile } from 'node:fs/promises';
  4   | 
  5   | test.beforeEach(async ({ page }) => {
  6   |   await page.route(/^https:\/\/(?:api\.openai\.com|api\.anthropic\.com|api\.deepseek\.com|generativelanguage\.googleapis\.com)\//, (route) => route.fulfill({ json: { data: [], models: [] } }));
  7   | });
  8   | 
  9   | test('真实浏览器加载原文、校验哈希并组装六种模式，记录模块顺序', async ({ page }, testInfo) => {
  10  |   await page.goto('/');
  11  |   const examples = await page.evaluate(async () => {
  12  |     const composerPath = '/src/prompts/composer.ts';
  13  |     const gamePath = '/src/tests/fixtures/game.ts';
  14  |     const settingsPath = '/src/ui/settings/model.ts';
  15  |     const draftsPath = '/src/domain/drafts.ts';
  16  |     const { composePrompt } = await import(composerPath);
  17  |     const { game } = await import(gamePath);
  18  |     const { defaultSettings } = await import(settingsPath);
  19  |     const { createTurnDraft, rerollStory } = await import(draftsPath);
  20  |     const state = game();
  21  |     const examples: {
  22  |       stage: string;
  23  |       mode: string;
  24  |       modules: { id: string; role: string; order: number }[];
  25  |       roles: string[];
  26  |       variablePending?: boolean;
  27  |     }[] = [];
  28  |     for (const mode of ['opening', 'regular']) {
  29  |       const draft = rerollStory(
  30  |         createTurnDraft(state.saveId, state.revision, 'example-turn', mode, '查看附近环境'),
  31  |         {
  32  |           turnKind: mode,
  33  |           narrative: '【旁白】街道依然安静。',
  34  |           summary: '观察环境',
  35  |           variableGuide: [],
  36  |         },
  37  |       );
  38  |       for (const stage of ['story', 'variables', 'world']) {
  39  |         const prompt = await composePrompt({
  40  |           state,
  41  |           settings: defaultSettings(),
  42  |           mode,
  43  |           stage,
  44  |           draft,
  45  |           userInput: '查看附近环境',
  46  |           domains: ['protagonist', 'economy'],
  47  |         });
  48  |         examples.push({
  49  |           stage,
  50  |           mode,
  51  |           modules: prompt.modules.map((m: { id: string; role: string; order: number }) => ({
  52  |             id: m.id,
  53  |             role: m.role,
  54  |             order: m.order,
  55  |           })),
  56  |           roles: prompt.messages.map((m: { role: string }) => m.role),
  57  |           variablePending: prompt.context.variablePending,
  58  |         });
  59  |       }
  60  |     }
  61  |     return examples;
  62  |   });
  63  |   expect(examples).toHaveLength(6);
  64  |   for (const example of examples) {
  65  |     const ids = example.modules.map((module) => module.id);
> 66  |     expect(ids.filter((id) => id.startsWith('stages.'))).toEqual([
      |                                                          ^ Error: expect(received).toEqual(expected) // deep equality
  67  |       `stages.${example.mode}.${example.stage}${example.stage === 'variables' ? '.text' : ''}`,
  68  |     ]);
  69  |     expect(example.roles.at(-1)).toBe('user');
  70  |     if (example.stage === 'story') {
  71  |       expect(ids.slice(0, 3)).toEqual([
  72  |         'identity.fusheng',
  73  |         'worldbooks.heijin.worldview',
  74  |         'worldbooks.heijin.modern_underworld',
  75  |       ]);
  76  |       expect(ids.filter((id) => id === 'writing.nsfw')).toHaveLength(1);
  77  |       expect(ids.filter((id) => id === 'writing.intimacy_boundaries')).toHaveLength(1);
  78  |     } else expect(ids.some((id) => id.startsWith('writing.'))).toBe(false);
  79  |     if (example.stage === 'world') expect(example.variablePending).toBe(true);
  80  |   }
  81  |   const artifact = testInfo.outputPath('prompt-order.json');
  82  |   await writeFile(artifact, JSON.stringify(examples, null, 2));
  83  |   await testInfo.attach('prompt-order.json', { path: artifact, contentType: 'application/json' });
  84  | });
  85  | 
  86  | test('AI 多渠道：选服务商后自动获取模型、测试回复、阶段路由与密钥保存位置', async ({ page }) => {
  87  |   const errors: string[] = [];
  88  |   page.on('pageerror', (error) => errors.push(error.message));
  89  |   const requests: { url: string; method: string; headers: Record<string, string>; body: string }[] = [];
  90  |   await page.route('https://api.mock.invalid/**', async (route) => {
  91  |     const request = route.request();
  92  |     requests.push({ url: request.url(), method: request.method(), headers: request.headers(), body: request.postData() ?? '' });
  93  |     const native = request.url().includes('/gemini/') ? 'gemini' : request.url().includes('/anthropic/') ? 'anthropic' : 'openai';
  94  |     const result = request.method() === 'GET'
  95  |       ? native === 'gemini' ? { models: [{ name: 'models/mock-model' }] } : { data: [{ id: 'mock-model' }] }
  96  |       : native === 'gemini' ? { candidates: [{ content: { parts: [{ text: 'OK' }] }, finishReason: 'STOP' }] }
  97  |         : native === 'anthropic' ? { content: [{ type: 'text', text: 'OK' }], stop_reason: 'end_turn' }
  98  |           : { choices: [{ message: { content: 'OK' }, finish_reason: 'stop' }] };
  99  |     await route.fulfill({ json: result });
  100 |   });
  101 |   await page.goto('/');
  102 |   const settings = await openAiSettings(page);
  103 |   const channels = [
  104 |     { name: 'Mock openai', preset: 'OpenAI 兼容', url: 'https://api.mock.invalid/openai/v1' },
  105 |     { name: 'Mock gemini', preset: 'OpenAI 兼容', url: 'https://api.mock.invalid/gemini/v1', format: 'Gemini 格式' },
  106 |     { name: 'Mock anthropic', preset: 'OpenAI 兼容', url: 'https://api.mock.invalid/anthropic/v1', format: 'Claude 格式' },
  107 |     { name: 'Mock deepseek', preset: 'DeepSeek', url: 'https://api.mock.invalid/deepseek/v1' },
  108 |   ];
  109 |   for (const [index, channel] of channels.entries()) {
  110 |     await addChannel(settings, { ...channel, key: undefined });
  111 |     const password = settings.getByLabel('API 密钥', { exact: true });
  112 |     await expect(password).toHaveAttribute('type', 'password');
  113 |     // 未保存时也能填好密钥后直接获取模型、测试回复。
  114 |     await password.fill('browser-mock-credential');
  115 |     await expect(settings.getByRole('status').filter({ hasText: '连接正常' }).first()).toBeVisible();
  116 |     await expect.poll(() => requests.length).toBe(index * 2 + 1);
  117 |     await testReply(settings);
  118 |     await expect(settings.getByRole('status').filter({ hasText: '收到了回复' }).first()).toBeVisible();
  119 |     await expect.poll(() => requests.length).toBe(index * 2 + 2);
  120 |   }
  121 |   expect(requests.map((request) => `${request.method} ${request.url}`)).toEqual([
  122 |     'GET https://api.mock.invalid/openai/v1/models',
  123 |     'POST https://api.mock.invalid/openai/v1/chat/completions',
  124 |     'GET https://api.mock.invalid/gemini/v1/models',
  125 |     'POST https://api.mock.invalid/gemini/v1/models/mock-model:generateContent',
  126 |     'GET https://api.mock.invalid/anthropic/v1/models?limit=100',
  127 |     'POST https://api.mock.invalid/anthropic/v1/messages',
  128 |     'GET https://api.mock.invalid/deepseek/v1/models',
  129 |     'POST https://api.mock.invalid/deepseek/v1/chat/completions',
  130 |   ]);
  131 |   for (const [index, header] of [[1, 'authorization'], [3, 'x-goog-api-key'], [5, 'x-api-key'], [7, 'authorization']] as const) {
  132 |     expect(requests[index].headers[header]).toContain('browser-mock-credential');
  133 |     expect(requests[index].url).not.toContain('browser-mock-credential');
  134 |     expect(requests[index].body).not.toContain('browser-mock-credential');
  135 |   }
  136 |   // 正文用第一个渠道（从列表选），变量单独用 Gemini 渠道（手动填写），其余跟随正文。
  137 |   await stageModel(settings, '正文生成', 'Mock openai', 'mock-model', 'list');
  138 |   await stageModel(settings, '变量管理', 'Mock gemini', 'variable-override');
  139 |   await expect(settings.getByRole('group', { name: '动态世界模型来源', exact: true }).getByRole('button', { name: '跟随正文', exact: true })).toHaveAttribute('aria-pressed', 'true');
  140 |   // 第三个渠道关闭「记住密钥」，只在本次会话保留。
  141 |   await openChannel(settings, 'Mock anthropic');
  142 |   await settings.getByRole('switch', { name: '记住密钥' }).uncheck();
  143 |   await saveAi(settings);
  144 |   await page.keyboard.press('Escape');
  145 |   await page.reload();
  146 |   const again = await openAiSettings(page);
  147 |   await openChannel(again, 'Mock openai');
  148 |   await expect(again.getByLabel('API 密钥', { exact: true })).toHaveValue('browser-mock-credential');
  149 |   await backToList(again);
  150 |   await expect(again.getByRole('combobox', { name: '变量管理渠道', exact: true })).toContainText('Mock gemini');
  151 |   await expect(again.getByRole('combobox', { name: '变量管理模型', exact: true })).toHaveAttribute('value', 'variable-override');
  152 |   await expect(again.getByRole('combobox', { name: '正文生成模型', exact: true })).toHaveAttribute('value', 'mock-model');
  153 |   const stored = await page.evaluate(() => ({ local: Object.entries(localStorage), session: Object.entries(sessionStorage) }));
  154 |   const config = stored.local.find(([key]) => key === 'heijin.ai.v1')?.[1] ?? '';
  155 |   expect(config).not.toContain('browser-mock-credential');
  156 |   expect(stored.local.filter(([key, value]) => key.startsWith('heijin.credential.v1:') && value === 'browser-mock-credential')).toHaveLength(3);
  157 |   expect(stored.session.filter(([key, value]) => key.startsWith('heijin.credential.v1:') && value === 'browser-mock-credential')).toHaveLength(1);
  158 |   // 删除：取消不改动；确认后保存才生效；删除正文用的渠道会阻止保存，直到重新选好模型或放弃修改。
  159 |   await openChannel(again, 'Mock deepseek');
  160 |   await again.getByRole('button', { name: '删除渠道', exact: true }).click();
  161 |   await page.getByRole('button', { name: '取消', exact: true }).click();
  162 |   await backToList(again);
  163 |   await expect(again.getByRole('button', { name: /^编辑渠道：/ })).toHaveCount(4);
  164 |   await openChannel(again, 'Mock deepseek');
  165 |   await again.getByRole('button', { name: '删除渠道', exact: true }).click();
  166 |   await page.getByRole('button', { name: '确认删除渠道', exact: true }).click();
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ai-settings.spec.ts >> 连接授权错误不展示服务详情，网络错误不误报密钥，取消请求有效
- Location: e2e/ai-settings.spec.ts:191:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '新增渠道', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - main "游戏首页与存档馆" [ref=e4]:
    - generic [ref=e5]:
      - generic [aria-hidden] [ref=e6]: 黑
      - generic [ref=e7]:
        - text: 黑金王朝
        - generic [ref=e8]: HEIJINWANGCHAO
      - button "设置" [ref=e9] [cursor=pointer]
      - generic [ref=e10]: V1.0 Beta
    - generic [ref=e11]:
      - paragraph [ref=e12]: MODERN CITY / OPEN WORLD
      - heading "黑金王朝" [level=1] [ref=e13]
      - paragraph [ref=e14]: 起点有冲突，人生不预设结局。
    - status "终点 新人生，时刻 --:--，可购票" [ref=e15]:
      - generic [ref=e16]:
        - text: 终点
        - generic [ref=e17]: DEST
      - generic [ref=e18]:
        - generic [ref=e19]: 新
        - generic [ref=e20]: 人
        - generic [ref=e21]: 生
      - generic [ref=e22]:
        - generic [ref=e23]: "-"
        - generic [ref=e24]: "-"
        - generic [ref=e25]: ":"
        - generic [ref=e26]: "-"
        - generic [ref=e27]: "-"
      - generic [ref=e28]: 可购票
    - generic [ref=e29]:
      - generic [ref=e30]: 车票 00
      - generic [ref=e31]: 本地保存 · 无需账号
      - button "导入备份" [disabled] [ref=e32]: ⤓ 导入备份
      - button "刷新列表" [ref=e33] [cursor=pointer]
    - region "车票栏，左右方向键切换" [ref=e34]:
      - article "空白车票：开启新的人生" [ref=e36]:
        - generic [ref=e37]:
          - generic [ref=e38]:
            - generic [ref=e39]: 空白车票
            - generic [ref=e40]: NEW LIFE
            - generic [ref=e41]: NEW
          - generic [ref=e42]:
            - generic [ref=e43]:
              - generic [ref=e44]:
                - generic [ref=e45]: FROM
                - generic [ref=e46]: ？
              - generic [aria-hidden] [ref=e47]: 单程
              - generic [ref=e49]:
                - generic [ref=e50]: TO
                - generic [ref=e51]: ？
            - generic [ref=e52]:
              - generic [ref=e53]:
                - term [ref=e54]: 城市
                - definition [ref=e55]
              - generic [ref=e57]:
                - term [ref=e58]: 职业
                - definition [ref=e59]
              - generic [ref=e61]:
                - term [ref=e62]: 存档
                - definition [ref=e63]: —
            - paragraph [ref=e64]: 四座城市 · 自由职业 · 开放人生
        - generic [ref=e66]:
          - text: 开启新的人生
          - generic [ref=e67]: ↓ 按住票根往下撕
    - navigation "车票页码" [ref=e69]:
      - button "第 1 张，空白车票" [ref=e70] [cursor=pointer]
    - paragraph [ref=e71]: 还没有开始的人生。创建角色，留下第一份存档。
    - button "开始新游戏" [disabled] [ref=e73]:
      - text: 开始新游戏
      - generic [aria-hidden] [ref=e74]: ↗
    - generic [ref=e75]:
      - group "游玩信息" [ref=e76]:
        - button "游玩须知与免责声明" [ref=e77] [cursor=pointer]
        - button "王朝公告" [ref=e78] [cursor=pointer]
      - paragraph [ref=e79]: 四座城市 · 自由职业 · 开放人生三阶段生成 · 原子结算 · 连续回合
  - dialog [active] [ref=e80]:
    - banner [ref=e83]:
      - generic [aria-hidden] [ref=e84]: 设
      - generic [ref=e85]:
        - paragraph [aria-hidden] [ref=e86]: SYSTEM · 系统
        - heading "设置" [level=2] [ref=e87]
      - button "关闭资料界面" [ref=e88] [cursor=pointer]:
        - text: 关闭
        - generic [aria-hidden] [ref=e89]: ×
    - navigation "设置分类" [ref=e92]:
      - paragraph [ref=e93]: 本地偏好与 AI 渠道
      - button "AI 连接" [ref=e94] [cursor=pointer]:
        - generic [aria-hidden] [ref=e95]: 连
        - generic [ref=e96]:
          - strong [ref=e97]: AI 连接
          - generic [ref=e98]: 渠道、密钥与模型路由
        - generic [aria-hidden] [ref=e99]: ›
      - button "提示词" [ref=e100] [cursor=pointer]:
        - generic [aria-hidden] [ref=e101]: 词
        - generic [ref=e102]:
          - strong [ref=e103]: 提示词
          - generic [ref=e104]: 叙事人称、风格与开关
        - generic [aria-hidden] [ref=e105]: ›
      - button "记忆" [ref=e106] [cursor=pointer]:
        - generic [aria-hidden] [ref=e107]: 忆
        - generic [ref=e108]:
          - strong [ref=e109]: 记忆
          - generic [ref=e110]: 即时记忆与记忆总结
        - generic [aria-hidden] [ref=e111]: ›
      - button "运行" [ref=e112] [cursor=pointer]:
        - generic [aria-hidden] [ref=e113]: 运
        - generic [ref=e114]:
          - strong [ref=e115]: 运行
          - generic [ref=e116]: 阶段开关与超时
        - generic [aria-hidden] [ref=e117]: ›
      - button "提示词管理" [ref=e118] [cursor=pointer]:
        - generic [aria-hidden] [ref=e119]: 管
        - generic [ref=e120]:
          - strong [ref=e121]: 提示词管理
          - generic [ref=e122]: 查看与编辑提示词
        - generic [aria-hidden] [ref=e123]: ›
      - group "游玩信息" [ref=e124]:
        - button "游玩须知与免责声明" [ref=e125] [cursor=pointer]
        - button "王朝公告" [ref=e126] [cursor=pointer]
```

# Test source

```ts
  111 |           : native === 'anthropic'
  112 |             ? { content: [{ type: 'text', text: 'OK' }], stop_reason: 'end_turn' }
  113 |             : { choices: [{ message: { content: 'OK' }, finish_reason: 'stop' }] };
  114 |     await route.fulfill({ json: result });
  115 |   });
  116 |   await page.goto('/');
  117 |   await page.getByRole('button', { name: '设置', exact: true }).click();
  118 |   const ids: string[] = [];
  119 |   for (const protocol of ['openai', 'gemini', 'anthropic']) {
  120 |     await page.getByRole('button', { name: '新增渠道', exact: true }).click();
  121 |     await page.getByLabel('渠道名称', { exact: true }).fill(`Mock ${protocol}`);
  122 |     await choose(page, '协议', protocol);
  123 |     await page
  124 |       .getByLabel('API Base URL', { exact: true })
  125 |       .fill(`https://api.mock.invalid/${protocol}/v1`);
  126 |     const password = page.getByLabel('API 密钥', { exact: true });
  127 |     await expect(password).toHaveAttribute('type', 'password');
  128 |     await password.fill('browser-mock-credential');
  129 |     await page.getByRole('button', { name: '手动填写默认模型 ID', exact: true }).click();
  130 |     await page.getByLabel('默认模型 ID', { exact: true }).fill('mock-model');
  131 |     expect(requests).toHaveLength(ids.length * 2);
  132 |     await page.getByRole('button', { name: '保存 AI 配置', exact: true }).click();
  133 |     await expect(
  134 |       page.getByText('AI 配置已保存；模型列表会自动获取，尚未发起生成请求。', { exact: true }),
  135 |     ).toBeVisible();
  136 |     await expect(page.getByRole('group', { name: '默认模型选择', exact: true })).toContainText('当前接口返回 1 个模型。列表由服务端提供，可能不是该平台全部可用模型。');
  137 |     await optionCount(page, '默认模型', 2);
  138 |     await page.getByRole('button', { name: /测试连接（/ }).click();
  139 |     await expect(page.getByText(/连接测试成功，已收到模型文本响应/)).toBeVisible();
  140 |     ids.push(await page.getByRole('combobox', { name: '当前渠道', exact: true }).getAttribute('value') ?? '');
  141 |   }
  142 |   expect(requests).toHaveLength(6);
  143 |   expect(requests.map((request) => request.url)).toEqual([
  144 |     'https://api.mock.invalid/openai/v1/models',
  145 |     'https://api.mock.invalid/openai/v1/chat/completions',
  146 |     'https://api.mock.invalid/gemini/v1/models',
  147 |     'https://api.mock.invalid/gemini/v1/models/mock-model:generateContent',
  148 |     'https://api.mock.invalid/anthropic/v1/models?limit=100',
  149 |     'https://api.mock.invalid/anthropic/v1/messages',
  150 |   ]);
  151 |   for (const [index, header] of [
  152 |     [1, 'authorization'],
  153 |     [3, 'x-goog-api-key'],
  154 |     [5, 'x-api-key'],
  155 |   ] as const) {
  156 |     expect(requests[index].headers[header]).toContain('browser-mock-credential');
  157 |     expect(requests[index].url).not.toContain('browser-mock-credential');
  158 |     expect(requests[index].body).not.toContain('browser-mock-credential');
  159 |   }
  160 |   await page.getByLabel('变量管理跟随正文模型', { exact: true }).uncheck();
  161 |   await choose(page, '变量管理渠道', ids[1]);
  162 |   await page.getByRole('button', { name: '手动填写变量管理模型 ID', exact: true }).click();
  163 |   await page.getByLabel('变量管理模型 ID', { exact: true }).fill('variable-override');
  164 |   await expect(page.getByLabel('动态世界跟随正文模型', { exact: true })).toBeChecked();
  165 |   await page.getByRole('button', { name: '保存 AI 配置', exact: true }).click();
  166 |   await page.keyboard.press('Escape');
  167 |   await page.reload();
  168 |   await page.getByRole('button', { name: '设置', exact: true }).click();
  169 |   await expect(page.getByLabel('API 密钥', { exact: true })).toHaveValue('browser-mock-credential');
  170 |   await selected(page, '变量管理渠道', ids[1]);
  171 |   await expect(page.getByLabel('变量管理模型 ID', { exact: true })).toHaveValue(
  172 |     'variable-override',
  173 |   );
  174 |   const stored = await page.evaluate(() => ({
  175 |     local: JSON.stringify(localStorage),
  176 |     session: JSON.stringify(sessionStorage),
  177 |   }));
  178 |   expect(stored.local).not.toContain('browser-mock-credential');
  179 |   expect(stored.session).toContain('browser-mock-credential');
  180 |   await page.getByRole('button', { name: '删除渠道', exact: true }).click();
  181 |   await page.getByRole('button', { name: '取消删除', exact: true }).click();
  182 |   await optionCount(page, '当前渠道', 3);
  183 |   await page.getByRole('button', { name: '删除渠道', exact: true }).click();
  184 |   await page.getByRole('button', { name: '确认删除渠道', exact: true }).click();
  185 |   await optionCount(page, '当前渠道', 2);
  186 |   await selected(page, '正文生成渠道', '');
  187 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  188 |   expect(errors).toEqual([]);
  189 | });
  190 | 
  191 | test('连接授权错误不展示服务详情，网络错误不误报密钥，取消请求有效', async ({ page }) => {
  192 |   let mode = 'authorization';
  193 |   await page.route('https://api.mock.invalid/**', async (route) => {
  194 |     if (mode === 'authorization')
  195 |       await route.fulfill({
  196 |         status: 401,
  197 |         json: { error: 'browser-mock-credential secret service detail' },
  198 |       });
  199 |     else if (mode === 'network') await route.abort('failed');
  200 |     else
  201 |       await new Promise<void>((resolve) => {
  202 |         route
  203 |           .request()
  204 |           .response()
  205 |           .then(() => resolve())
  206 |           .catch(() => resolve());
  207 |       });
  208 |   });
  209 |   await page.goto('/');
  210 |   await page.getByRole('button', { name: '设置', exact: true }).click();
> 211 |   await page.getByRole('button', { name: '新增渠道', exact: true }).click();
      |                                                                 ^ Error: locator.click: Test timeout of 30000ms exceeded.
  212 |   await page.getByLabel('API Base URL', { exact: true }).fill('https://api.mock.invalid/v1');
  213 |   await page.getByRole('button', { name: '手动填写默认模型 ID', exact: true }).click();
  214 |   await page.getByLabel('默认模型 ID', { exact: true }).fill('mock-model');
  215 |   await page.getByLabel('API 密钥', { exact: true }).fill('browser-mock-credential');
  216 |   await page.getByRole('button', { name: '保存 AI 配置', exact: true }).click();
  217 |   await page.getByRole('button', { name: /测试连接（/ }).click();
  218 |   await expect(page.getByRole('status').filter({ hasText: '授权错误' }).last()).toBeVisible();
  219 |   await expect(page.getByRole('dialog')).not.toContainText('secret service detail');
  220 |   mode = 'network';
  221 |   await page.getByRole('button', { name: /测试连接（/ }).click();
  222 |   await expect(page.getByRole('status').filter({ hasText: 'CORS' })).toBeVisible();
  223 |   mode = 'hanging';
  224 |   await page.getByRole('button', { name: /测试连接（/ }).click();
  225 |   await page.getByRole('button', { name: '取消请求', exact: true }).click();
  226 |   await expect(page.getByRole('status').filter({ hasText: '取消' })).toBeVisible();
  227 |   await expect(page.getByRole('button', { name: /测试连接（/ })).toBeEnabled();
  228 | });
  229 | 
  230 | test('P6完善：输出档位映射、旧渠道值与渠道隔离，新渠道默认8K', async ({ page }) => {
  231 |   await page.goto('/');
  232 |   const ids = await page.evaluate(async () => {
  233 |     const path = '/src/services/ai/configuration.ts', vaultPath = '/src/services/ai/credentials.ts';
  234 |     const { defaultAiConfig, newChannel, saveAiConfig } = await import(path), { CredentialVault } = await import(vaultPath);
  235 |     const config = defaultAiConfig(), first = newChannel(), second = newChannel();
  236 |     first.name = '旧4K渠道'; first.parameters.maxOutputTokens = 4096;
  237 |     second.name = '旧自定义渠道'; second.parameters.maxOutputTokens = 32768; config.channels = [first, second];
  238 |     saveAiConfig(localStorage, config); const vault = new CredentialVault(sessionStorage, localStorage);
  239 |     config.channels.forEach((channel: { id: string }) => vault.set(channel.id, 'mock-budget-key'));
  240 |     return [first.id, second.id];
  241 |   });
  242 |   await page.reload(); await page.getByRole('button', { name: '设置', exact: true }).click();
  243 |   await page.getByRole('button', { name: 'AI 连接', exact: true }).click();
  244 |   await page.getByText('生成参数与模型兼容', { exact: true }).click();
  245 |   const selector = page.getByLabel('最大输出 Token 档位', { exact: true }); await expect(selector).toHaveAttribute('value', '4096');
  246 |   await choose(page, '最大输出 Token 档位', '16384'); await page.getByRole('button', { name: '保存 AI 配置', exact: true }).click();
  247 |   await choose(page, '当前渠道', ids[1]);
  248 |   await expect(selector).toHaveAttribute('value', 'custom'); await expect(page.getByLabel('自定义最大输出 Token')).toHaveValue('32768');
  249 |   const values = await page.evaluate(async () => { const path = '/src/services/ai/configuration.ts', { readAiConfig } = await import(path);
  250 |     return readAiConfig(localStorage).channels.map((channel: { parameters: { maxOutputTokens: number } }) => channel.parameters.maxOutputTokens); });
  251 |   expect(values).toEqual([16384, 32768]);
  252 |   await page.getByRole('button', { name: '新增渠道', exact: true }).click(); await expect(selector).toHaveAttribute('value', '8192');
  253 |   await page.getByLabel('API 密钥', { exact: true }).fill('new-mock-key'); await page.getByRole('button', { name: '保存 AI 配置', exact: true }).click();
  254 |   await page.reload(); await page.getByRole('button', { name: '设置', exact: true }).click(); await page.getByRole('button', { name: 'AI 连接', exact: true }).click();
  255 |   await page.getByText('生成参数与模型兼容', { exact: true }).click(); await expect(selector).toHaveAttribute('value', '16384');
  256 |   await choose(page, '当前渠道', ids[1]); await expect(selector).toHaveAttribute('value', 'custom');
  257 |   await expect(page.getByLabel('自定义最大输出 Token')).toHaveValue('32768');
  258 | });
  259 | 
  260 | test('P6完善：自定义合法范围与4K/8K/16K往返，只保存玩家明确设置', async ({ page }) => {
  261 |   await page.goto('/'); await page.getByRole('button', { name: '设置', exact: true }).click(); await page.getByRole('button', { name: 'AI 连接', exact: true }).click();
  262 |   await page.getByRole('button', { name: '新增渠道', exact: true }).click();
  263 |   await page.getByText('生成参数与模型兼容', { exact: true }).click();
  264 |   const selector = page.getByLabel('最大输出 Token 档位', { exact: true }); await expect(selector).toHaveAttribute('value', '8192');
  265 |   for (const value of ['4096', '8192', '16384']) { await choose(page, '最大输出 Token 档位', value); await expect(selector).toHaveAttribute('value', value); }
  266 |   await choose(page, '最大输出 Token 档位', 'custom'); const custom = page.getByLabel('自定义最大输出 Token', { exact: true }); await expect(custom).toHaveValue('16384');
  267 |   await custom.fill('12345'); await page.getByLabel('API 密钥', { exact: true }).fill('custom-mock-key');
  268 |   await page.getByRole('button', { name: '保存 AI 配置', exact: true }).click();
  269 |   for (const value of ['0', '1000001']) {
  270 |     await custom.fill(value); await page.getByRole('button', { name: '保存 AI 配置', exact: true }).click();
  271 |     await expect(page.getByText(/配置无效：请核对/)).toBeVisible();
  272 |     expect(await page.evaluate(() => JSON.parse(localStorage.getItem('heijin.ai.v1')!).channels[0].parameters.maxOutputTokens)).toBe(12345);
  273 |   }
  274 |   await custom.fill('1000000'); await page.getByRole('button', { name: '保存 AI 配置', exact: true }).click();
  275 |   await page.reload(); await page.getByRole('button', { name: '设置', exact: true }).click(); await page.getByRole('button', { name: 'AI 连接', exact: true }).click();
  276 |   await page.getByText('生成参数与模型兼容', { exact: true }).click(); await expect(selector).toHaveAttribute('value', 'custom'); await expect(custom).toHaveValue('1000000');
  277 | });
  278 | 
```
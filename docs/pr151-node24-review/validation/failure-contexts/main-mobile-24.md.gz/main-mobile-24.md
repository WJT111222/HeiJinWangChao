# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: action-workflow.spec.ts >> 下一条行动绑定冲突显示发送失败，不误报等待行动且不请求模型
- Location: e2e/action-workflow.spec.ts:340:1

# Error details

```
Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - banner:
    - button "打开游戏菜单" [ref=f1e2] [cursor=pointer]: ☰
  - main [ref=f1e3]:
    - generic "城市与当前场景" [ref=f1e4]:
      - button "此时此地与主角状态" [ref=f1e5] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e6]: 渝
        - generic [ref=f1e7]:
          - generic [ref=f1e8]: 重庆
          - generic [ref=f1e9]: 重庆
        - time [ref=f1e10]: 14:01
        - generic "天气：天气待确认" [ref=f1e11]: —
      - generic [ref=f1e12]: 重庆，2015/7/8 星期三 14:01，天气：天气待确认
    - region "剧情与行动" [ref=f1e13]:
      - generic "正文阅读区域" [ref=f1e14]:
        - generic [ref=f1e15]:
          - generic [ref=f1e16]: THE STORY
          - generic [ref=f1e17]: 已结算历史
        - article [ref=f1e18]:
          - generic [ref=f1e19]:
            - generic [aria-hidden] [ref=f1e20]:
              - generic [ref=f1e21]: "1"
              - generic [ref=f1e22]:
                - generic [ref=f1e23]: 第一回
                - generic [ref=f1e24]: TURN 001
            - heading "第 1 回合" [level=2] [ref=f1e31]
            - generic [ref=f1e32]:
              - text: 2015/7/8 · 星期三 · 14:00
              - generic [ref=f1e33]: 重庆
          - paragraph [ref=f1e35]: 2015年7月8日14:00，重庆街头。第1幕。主角在街边观察周围，街道上人来人往。
          - generic [ref=f1e36]:
            - button "本回合变化 不可用" [disabled] [ref=f1e37]:
              - generic [ref=f1e38]: 本回合变化
              - generic [ref=f1e39]: 不可用
              - generic [aria-hidden] [ref=f1e40]: ▼
            - status [ref=f1e41]: 本回合没有可对比的结算前记录
      - generic [ref=f1e42]:
        - region "三阶段工作流" [ref=f1e44]:
          - button "三阶段工作流详情" [ref=f1e47] [cursor=pointer]:
            - status [ref=f1e52]:
              - generic [ref=f1e53]: 三阶段 ·
              - text: 行动发送失败 · 查看详情
            - generic [ref=f1e54]: 详情 ›
        - generic [ref=f1e55]:
          - button "撤回" [disabled] [ref=f1e58]:
            - generic [aria-hidden] [ref=f1e59]: 撤
          - generic [ref=f1e60]: 你的行动
          - textbox "你的行动" [ref=f1e61]:
            - /placeholder: 填写你的行动
            - text: 当前页面的行动
          - button "发送" [ref=f1e63] [cursor=pointer]
    - navigation "底部导航" [ref=f1e64]:
      - button "故事" [ref=f1e65] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e66]: 文
        - text: 故事
      - button "人物" [ref=f1e67] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e68]: 我
        - text: 人物
      - button "世界资料" [ref=f1e69] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e70]: 世
        - text: 世界资料
      - button "设置" [ref=f1e71] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e72]: 设
        - text: 设置
    - dialog [active] [ref=f1e73]:
      - generic [ref=f1e76]:
        - generic [aria-hidden] [ref=f1e77]: 诊
        - generic [ref=f1e78]:
          - paragraph [aria-hidden] [ref=f1e79]: WORKFLOW · 诊断
          - heading "重试与变更详情" [level=2] [ref=f1e80]
        - button "关闭资料界面" [ref=f1e81] [cursor=pointer]:
          - text: 关闭
          - generic [aria-hidden] [ref=f1e82]: ×
      - generic [ref=f1e83]:
        - tablist "诊断分类" [ref=f1e84]:
          - tab "概要" [ref=f1e85] [cursor=pointer]
          - tab "运行日志 1" [selected] [ref=f1e86] [cursor=pointer]:
            - text: 运行日志
            - generic [ref=f1e87]: "1"
          - tab "请求用量 3" [ref=f1e88] [cursor=pointer]:
            - text: 请求用量
            - generic [ref=f1e89]: "3"
          - tab "模型原文" [ref=f1e90] [cursor=pointer]
        - tabpanel "运行日志 1" [ref=f1e91]:
          - group [ref=f1e92]:
            - generic "运行日志 · 错误 1 条 最近错误 · DRAFT_CONFLICT" [ref=f1e93] [cursor=pointer]:
              - generic [ref=f1e94]: 运行日志 · 错误 1 条
              - strong [ref=f1e95]: 最近错误 · DRAFT_CONFLICT
            - generic [ref=f1e96]:
              - paragraph [ref=f1e97]: 仅显示本次页面会话的错误；每条可单独复制安全诊断，不含原始模型响应、请求正文或密钥。刷新即清空。
              - button "清空日志" [ref=f1e99] [cursor=pointer]
              - list "错误日志条目" [ref=f1e100]:
                - listitem [ref=f1e101]:
                  - generic [ref=f1e102]:
                    - generic [ref=f1e103]:
                      - time [ref=f1e104]: 16:24:49
                      - strong [ref=f1e105]: 自动工作流
                      - generic [ref=f1e106]: 错误
                    - button "复制此条" [ref=f1e107] [cursor=pointer]
                  - paragraph [ref=f1e108]: 当前草稿已过期或被更新。
                  - generic [ref=f1e109]: 错误码：DRAFT_CONFLICT
        - paragraph [ref=f1e110]: 仅本页临时保存 · 刷新即清空
```
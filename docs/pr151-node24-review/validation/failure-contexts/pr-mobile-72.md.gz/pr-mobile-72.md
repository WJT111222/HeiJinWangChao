# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: prompt-inspector.spec.ts >> 四开关显式保存：双页联动、未保存刷新丢弃、保存刷新持久化与再次编辑提示
- Location: e2e/prompt-inspector.spec.ts:475:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '提示词', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - main "游戏首页与存档馆" [ref=e4]:
    - generic [ref=e5]:
      - generic [aria-hidden] [ref=e6]: 黑
      - generic [ref=e7]:
        - text: 黑金王朝
        - generic [ref=e8]: HEIJINWANGCHAO
      - button "设置" [ref=e9] [cursor=pointer]
      - generic [ref=e10]: V1.0 Beta
    - generic [ref=e11]:
      - paragraph [ref=e12]: MODERN CITY / OPEN WORLD
      - heading "黑金王朝" [level=1] [ref=e13]
      - paragraph [ref=e14]: 起点有冲突，人生不预设结局。
    - status "终点 新人生，时刻 --:--，可购票" [ref=e15]:
      - generic [ref=e16]:
        - text: 终点
        - generic [ref=e17]: DEST
      - generic [ref=e18]:
        - generic [ref=e19]: 新
        - generic [ref=e20]: 人
        - generic [ref=e21]: 生
      - generic [ref=e22]:
        - generic [ref=e23]: "-"
        - generic [ref=e24]: "-"
        - generic [ref=e25]: ":"
        - generic [ref=e26]: "-"
        - generic [ref=e27]: "-"
      - generic [ref=e28]: 可购票
    - generic [ref=e29]:
      - generic [ref=e30]: 车票 00
      - generic [ref=e31]: 本地保存 · 无需账号
      - button "导入备份" [disabled] [ref=e32]: ⤓ 导入备份
      - button "刷新列表" [ref=e33] [cursor=pointer]
    - region "车票栏，左右方向键切换" [ref=e34]:
      - article "空白车票：开启新的人生" [ref=e36]:
        - generic [ref=e37]:
          - generic [ref=e38]:
            - generic [ref=e39]: 空白车票
            - generic [ref=e40]: NEW LIFE
            - generic [ref=e41]: NEW
          - generic [ref=e42]:
            - generic [ref=e43]:
              - generic [ref=e44]:
                - generic [ref=e45]: FROM
                - generic [ref=e46]: ？
              - generic [aria-hidden] [ref=e47]: 单程
              - generic [ref=e49]:
                - generic [ref=e50]: TO
                - generic [ref=e51]: ？
            - generic [ref=e52]:
              - generic [ref=e53]:
                - term [ref=e54]: 城市
                - definition [ref=e55]
              - generic [ref=e57]:
                - term [ref=e58]: 职业
                - definition [ref=e59]
              - generic [ref=e61]:
                - term [ref=e62]: 存档
                - definition [ref=e63]: —
            - paragraph [ref=e64]: 四座城市 · 自由职业 · 开放人生
        - generic [ref=e66]:
          - text: 开启新的人生
          - generic [ref=e67]: ↓ 按住票根往下撕
    - navigation "车票页码" [ref=e69]:
      - button "第 1 张，空白车票" [ref=e70] [cursor=pointer]
    - paragraph [ref=e71]: 还没有开始的人生。创建角色，留下第一份存档。
    - button "开始新游戏" [disabled] [ref=e73]:
      - text: 开始新游戏
      - generic [aria-hidden] [ref=e74]: ↗
    - generic [ref=e75]:
      - group "游玩信息" [ref=e76]:
        - button "游玩须知与免责声明" [ref=e77] [cursor=pointer]
        - button "王朝公告" [ref=e78] [cursor=pointer]
      - paragraph [ref=e79]: 四座城市 · 自由职业 · 开放人生三阶段生成 · 原子结算 · 连续回合
  - dialog [ref=e80]:
    - banner [ref=e83]:
      - generic [aria-hidden] [ref=e84]: 设
      - generic [ref=e85]:
        - paragraph [aria-hidden] [ref=e86]: SYSTEM · 系统
        - heading "设置" [level=2] [ref=e87]
      - button "关闭资料界面" [ref=e88] [cursor=pointer]:
        - text: 关闭
        - generic [aria-hidden] [ref=e89]: ×
    - generic [ref=e92]:
      - button "返回设置" [ref=e93] [cursor=pointer]: ‹ 设置
      - heading "提示词管理" [level=3] [ref=e94]
      - region "模块库" [ref=e96]:
        - generic [ref=e97]:
          - paragraph [ref=e98]: 游戏实际发给模型的提示词 · 原文只读
          - button "高级" [ref=e99] [cursor=pointer]:
            - generic [aria-hidden] [ref=e100]: ⚙
            - text: 高级
        - generic [ref=e101]:
          - group "提示词分类" [ref=e102]:
            - button "全部100" [ref=e103] [cursor=pointer]
            - button "核心设定14" [ref=e104] [cursor=pointer]
            - button "写作设定11" [pressed] [ref=e105] [cursor=pointer]
            - button "流程与输出16" [ref=e106] [cursor=pointer]
            - button "变量规则45" [ref=e107] [cursor=pointer]
            - button "记忆5" [ref=e108] [cursor=pointer]
            - button "参考资料9" [ref=e109] [cursor=pointer]
          - textbox "搜索模块" [ref=e111]:
            - /placeholder: 搜索名称
        - generic [ref=e112]:
          - heading "写作设定 11" [level=5] [ref=e113]:
            - text: 写作设定
            - generic [ref=e114]: "11"
          - list [ref=e115]:
            - listitem [ref=e116]:
              - generic [ref=e117]: 未选用
              - button "人称：第一人称 写作设定 · 155 字 · 正文" [ref=e119] [cursor=pointer]:
                - generic [ref=e120]:
                  - strong [ref=e121]: 人称：第一人称
                  - generic [ref=e122]: 写作设定 · 155 字 · 正文
            - listitem [ref=e123]:
              - generic [ref=e124]: 未选用
              - button "人称：第二人称 写作设定 · 110 字 · 正文" [ref=e126] [cursor=pointer]:
                - generic [ref=e127]:
                  - strong [ref=e128]: 人称：第二人称
                  - generic [ref=e129]: 写作设定 · 110 字 · 正文
            - listitem [ref=e130]:
              - generic [ref=e131]: 当前
              - button "人称：第三人称 写作设定 · 128 字 · 正文" [ref=e133] [cursor=pointer]:
                - generic [ref=e134]:
                  - strong [ref=e135]: 人称：第三人称
                  - generic [ref=e136]: 写作设定 · 128 字 · 正文
            - listitem [ref=e137]:
              - generic [ref=e138]: 当前
              - button "剧情风格：一般 写作设定 · 139 字 · 正文" [ref=e140] [cursor=pointer]:
                - generic [ref=e141]:
                  - strong [ref=e142]: 剧情风格：一般
                  - generic [ref=e143]: 写作设定 · 139 字 · 正文
            - listitem [ref=e144]:
              - generic [ref=e145]: ≥1500 字
              - button "硬性最低正文字数 写作设定 · 180 字 · 正文" [ref=e147] [cursor=pointer]:
                - generic [ref=e148]:
                  - strong [ref=e149]: 硬性最低正文字数
                  - generic [ref=e150]: 写作设定 · 180 字 · 正文
            - listitem [ref=e151]:
              - checkbox "打开提示词 防抢话 NoControl（可开关增强版）" [ref=e153] [cursor=pointer]
              - button "防抢话 NoControl（可开关增强版） 写作设定 · 215 字 · 正文" [ref=e154] [cursor=pointer]:
                - generic [ref=e155]:
                  - strong [ref=e156]: 防抢话 NoControl（可开关增强版）
                  - generic [ref=e157]: 写作设定 · 215 字 · 正文
            - listitem [ref=e158]:
              - checkbox "打开提示词 自然文风修复（黑金王朝适配稿）" [ref=e160] [cursor=pointer]
              - button "自然文风修复（黑金王朝适配稿） 写作设定 · 877 字 · 正文" [ref=e161] [cursor=pointer]:
                - generic [ref=e162]:
                  - strong [ref=e163]: 自然文风修复（黑金王朝适配稿）
                  - generic [ref=e164]: 写作设定 · 877 字 · 正文
            - listitem [ref=e165]:
              - checkbox "打开提示词 行动选项（开启时3～5条）" [ref=e167] [cursor=pointer]
              - button "行动选项（开启时3～5条） 写作设定 · 513 字 · 正文" [ref=e168] [cursor=pointer]:
                - generic [ref=e169]:
                  - strong [ref=e170]: 行动选项（开启时3～5条）
                  - generic [ref=e171]: 写作设定 · 513 字 · 正文
            - listitem [ref=e172]:
              - checkbox "打开提示词 真实世界模式协议（开启时）" [active] [ref=e174] [cursor=pointer]
              - button "真实世界模式协议（开启时） 写作设定 · 257 字 · 正文" [ref=e175] [cursor=pointer]:
                - generic [ref=e176]:
                  - strong [ref=e177]: 真实世界模式协议（开启时）
                  - generic [ref=e178]: 写作设定 · 257 字 · 正文
            - listitem [ref=e179]:
              - generic [ref=e180]: 常驻
              - button "成人题材常驻规则（用户手动适配版，非原版逐字移植） 写作设定 · 3,199 字 · 正文" [ref=e182] [cursor=pointer]:
                - generic [ref=e183]:
                  - strong [ref=e184]: 成人题材常驻规则（用户手动适配版，非原版逐字移植）
                  - generic [ref=e185]: 写作设定 · 3,199 字 · 正文
            - listitem [ref=e186]:
              - generic [ref=e187]: 常驻
              - button "人物亲密与自愿边界（关系发展审阅版） 写作设定 · 672 字 · 正文" [ref=e189] [cursor=pointer]:
                - generic [ref=e190]:
                  - strong [ref=e191]: 人物亲密与自愿边界（关系发展审阅版）
                  - generic [ref=e192]: 写作设定 · 672 字 · 正文
      - generic [ref=e193]:
        - status [ref=e194]:
          - generic [aria-hidden] [ref=e195]: 示
          - generic [ref=e196]: 本地设置尚未保存。
        - button "保存本地设置" [ref=e197] [cursor=pointer]
```

# Test source

```ts
  394 |     const { newChannel, defaultAiConfig } = await import(configPath);
  395 |     const { CredentialVault } = await import(credentialsPath);
  396 |     const { requestSnapshot } = await import(snapshotPath);
  397 |     const { AiClient } = await import(clientPath);
  398 |     const source = contextScaleFixture(count);
  399 |     source.state.saveId = 'ui-test';
  400 |     source.draft.saveId = 'ui-test';
  401 |     const prompt = await composePrompt({ ...source, stage: 'story', mode: 'regular', userInput: source.draft.userInput });
  402 |     const channel = { ...newChannel(), defaultModel: 'worker-scale-mock' };
  403 |     const config = defaultAiConfig(); config.channels = [channel]; config.routes.story = { channelId: channel.id, modelId: '' };
  404 |     const vault = new CredentialVault(sessionStorage, localStorage); vault.set(channel.id, 'worker-scale-secret');
  405 |     let calls = 0;
  406 |     const before = performance.now();
  407 |     await new AiClient(async () => {
  408 |       calls++;
  409 |       return Response.json({ choices: [{ message: { content: 'OK' }, finish_reason: 'stop' }], usage: { prompt_tokens: 42, completion_tokens: 2 } });
  410 |     }).generate(requestSnapshot(config, 'story', vault), prompt.messages, { inspection: { kind: 'stage', mode: 'regular', saveId: 'ui-test', revision: source.state.revision, modules: prompt.modules } });
  411 |     return { calls, captureAndMockResponseMs: performance.now() - before };
  412 |   }, count);
  413 |   expect(workers).toBe(0);
  414 |   expect(capture.calls).toBe(1);
  415 |   await inspector(page);
  416 |   await page.getByRole('combobox', { name: '回合模式', exact: true }).selectOption('regular');
  417 |   await page.getByRole('combobox', { name: '数据来源', exact: true }).selectOption('actual');
  418 |   const context = page.getByRole('region', { name: '上下文与统计' });
  419 |   expect(workers).toBe(0);
  420 |   await page.getByText('展开数据分类、召回预算与重复诊断', { exact: true }).click();
  421 |   await expect(context).toContainText('正在分析…');
  422 |   await backToList(page);
  423 |   await page.getByLabel('搜索模块', { exact: true }).fill('writing');
  424 |   await expect(page.getByLabel('搜索模块', { exact: true })).toHaveValue('writing');
  425 |   await openAdvanced(page);
  426 |   const progress = await page.evaluate(async () => {
  427 |     const storePath = '/src/services/ai/inspection.ts', analysisPath = '/src/prompts/budgetAnalysis.ts';
  428 |     const { requestInspections } = await import(storePath);
  429 |     const { budgetAnalysis } = await import(analysisPath);
  430 |     const analysis = budgetAnalysis(requestInspections.getSnapshot()[0].messages);
  431 |     let frames = 0;
  432 |     const start = performance.now();
  433 |     await new Promise<void>(resolve => {
  434 |       function frame() { frames++; if (analysis.getSnapshot().status === 'running') requestAnimationFrame(frame); else resolve(); }
  435 |       requestAnimationFrame(frame);
  436 |     });
  437 |     return { frames, analysisMs: performance.now() - start };
  438 |   });
  439 |   expect(progress.frames).toBeGreaterThan(1);
  440 |   await expect(context).toContainText('分析完成（本会话内存缓存）。');
  441 |   await expect(context).toContainText('字符差额 0，字节差额 0');
  442 |   expect(workers).toBe(1);
  443 |   const equality = await page.evaluate(async () => {
  444 |     const storePath = '/src/services/ai/inspection.ts', analysisPath = '/src/prompts/budgetAnalysis.ts', purePath = '/src/prompts/budgetInspection.ts';
  445 |     const { requestInspections } = await import(storePath);
  446 |     const { budgetAnalysis } = await import(analysisPath);
  447 |     const { inspectBudget } = await import(purePath);
  448 |     const snapshot = requestInspections.getSnapshot()[0];
  449 |     const state = budgetAnalysis(snapshot.messages).getSnapshot();
  450 |     // Test-only oracle runs after the real Worker completes; production has no main-thread fallback.
  451 |     return state.status === 'complete' && JSON.stringify(state.result) === JSON.stringify(inspectBudget(snapshot.messages));
  452 |   });
  453 |   expect(equality).toBe(true);
  454 |   await page.getByText('展开数据分类、召回预算与重复诊断', { exact: true }).click();
  455 |   await page.getByText('展开数据分类、召回预算与重复诊断', { exact: true }).click();
  456 |   await expect(context).toContainText('分析完成（本会话内存缓存）。');
  457 |   expect(workers).toBe(1);
  458 |   await writeFile(testInfo.outputPath('worker-measurement.json'), JSON.stringify({ count, ...capture, ...progress, workers, equality }, null, 2));
  459 |   await page.getByRole('button', { name: '清空内存请求记录' }).click();
  460 |   await expect(page.getByText(/此阶段\/模式没有实际请求快照/)).toBeVisible();
  461 | });
  462 | 
  463 | const promptSwitches = manifest.modules.filter((item) =>
  464 |   ['noControl', 'naturalProse', 'actionOptions', 'realWorld'].includes(item.toggle?.split(':')[0] ?? ''),
  465 | );
  466 | const evidenceDir = 'docs/pr124-review/screenshots';
  467 | async function screenshot(page: Page, name: string) {
  468 |   if (name === 'preview-invalidated') {
  469 |     await page.getByText('写作偏好已修改，请重新组装预览。', { exact: true })
  470 |       .evaluate(element => element.scrollIntoView({ block: 'center' }));
  471 |   }
  472 |   await page.screenshot({ path: `${evidenceDir}/${page.viewportSize()!.width}-${name}.png`, animations: 'disabled', scale: 'css' });
  473 | }
  474 | 
  475 | test('四开关显式保存：双页联动、未保存刷新丢弃、保存刷新持久化与再次编辑提示', async ({ page }) => {
  476 |   const errors: string[] = [];
  477 |   page.on('pageerror', error => errors.push(error.message));
  478 |   await page.route('https://**', route => route.abort());
  479 |   await page.goto('/');
  480 |   const before = await page.evaluate(() => localStorage.getItem('heijin.settings.v1'));
  481 |   await inspector(page, false);
  482 |   const groups = page.getByRole('group', { name: '提示词分类' });
  483 |   expect(promptSwitches).toHaveLength(4);
  484 |   await groups.getByRole('button', { name: /^写作设定/ }).click();
  485 |   await screenshot(page, 'list');
  486 |   for (const item of promptSwitches) {
  487 |     await page.locator(`[data-prompt-id="${item.id}"] input`).uncheck();
  488 |     await expect(page.locator('.local-save-bar').getByRole('status')).toContainText('本地设置尚未保存');
  489 |   }
  490 |   expect(await page.evaluate(() => localStorage.getItem('heijin.settings.v1'))).toBe(before);
  491 |   await expect(page.locator('.local-save-bar').getByRole('status')).toBeInViewport();
  492 |   await expect(page.getByRole('button', { name: '保存本地设置', exact: true })).toBeInViewport();
  493 |   await screenshot(page, 'unsaved');
> 494 |   await page.getByRole('button', { name: '提示词', exact: true }).click();
      |                                                                ^ Error: locator.click: Test timeout of 30000ms exceeded.
  495 |   for (const label of ['NoControl（防抢话）', '自然文风修复', '行动选项', '真实世界模式']) {
  496 |     await expect(page.getByLabel(label, { exact: true })).not.toBeChecked();
  497 |   }
  498 |   await page.getByRole('button', { name: '提示词管理', exact: true }).click();
  499 |   await expect(page.locator('.local-save-bar').getByRole('status')).toContainText('本地设置尚未保存');
  500 |   await page.reload();
  501 |   await inspector(page, false);
  502 |   for (const item of promptSwitches) await expect(page.locator(`[data-prompt-id="${item.id}"] input`)).toBeChecked();
  503 |   for (const item of promptSwitches) {
  504 |     const row = page.locator(`[data-prompt-id="${item.id}"]`);
  505 |     await row.locator('.pm-open').click();
  506 |     const source = page.getByRole('region', { name: '模块原文' });
  507 |     await source.getByRole('checkbox').uncheck();
  508 |     await expect(page.locator('.local-save-bar').getByRole('status')).toContainText('本地设置尚未保存');
  509 |     await source.getByRole('button', { name: /返回列表/ }).click();
  510 |     await expect(row.getByRole('checkbox')).not.toBeChecked();
  511 |   }
  512 |   const save = page.getByRole('button', { name: '保存本地设置', exact: true });
  513 |   await save.click();
  514 |   await expect(page.locator('.local-save-bar').getByRole('status')).toContainText('本地偏好已保存');
  515 |   await screenshot(page, 'saved');
  516 |   const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('heijin.settings.v1')!).prompts);
  517 |   for (const field of ['noControl', 'naturalProse', 'actionOptions', 'realWorld']) expect(saved[field]).toBe(false);
  518 |   await page.reload();
  519 |   await inspector(page, false);
  520 |   for (const item of promptSwitches) await expect(page.locator(`[data-prompt-id="${item.id}"] input`)).not.toBeChecked();
  521 |   await page.locator(`[data-prompt-id="${promptSwitches[0].id}"] input`).check();
  522 |   await save.click();
  523 |   await expect(page.locator('.local-save-bar').getByRole('status')).toContainText('本地偏好已保存');
  524 |   await page.locator(`[data-prompt-id="${promptSwitches[0].id}"] input`).uncheck();
  525 |   await expect(page.locator('.local-save-bar').getByRole('status')).toContainText('本地设置尚未保存');
  526 |   await expect(page.locator('.local-save-bar').getByRole('status')).toHaveClass(/l-info/);
  527 |   expect(errors).toEqual([]);
  528 | });
  529 | 
  530 | test('四开关取消旧组装：列表与原文修改立即失效，迟到成功不覆盖新任务，重新组装才有效', async ({ page }) => {
  531 |   // Observe completion of the real assembler in this test only; production stays unchanged.
  532 |   await page.route('**/src/prompts/preview.ts', async route => {
  533 |     const response = await route.fetch();
  534 |     const source = await response.text();
  535 |     expect(source).toContain('async function buildStagePreviews(');
  536 |     await route.fulfill({ response, body: source.replace('async function buildStagePreviews(', 'async function buildStagePreviewsForTest(') + '\nexport async function buildStagePreviews(...args) { try { return await buildStagePreviewsForTest(...args); } finally { window.__pr124Builds = (window.__pr124Builds || 0) + 1; } }' });
  537 |   });
  538 |   await page.route('https://**', route => route.abort());
  539 |   const before = await seed(page);
  540 |   await page.reload();
  541 |   await inspector(page);
  542 |   await page.getByRole('combobox', { name: '预览存档', exact: true }).selectOption('ui-test');
  543 |   const assemble = page.getByRole('button', { name: '生成三阶段组装预览（不联网）', exact: true });
  544 |   await assemble.click();
  545 |   await expect(page.getByText('已按此配置组装预览，尚未发送。', { exact: true })).toBeVisible();
  546 |   await screenshot(page, 'advanced');
  547 |   await page.evaluate(async () => {
  548 |     const path = '/src/services/storage/saveRepository.ts';
  549 |     const { SaveRepository } = await import(path);
  550 |     const target = window as unknown as { __pr124Loads: Array<() => void>; __pr124Restore: () => void };
  551 |     target.__pr124Loads = [];
  552 |     const original = SaveRepository.prototype.load;
  553 |     target.__pr124Restore = () => { SaveRepository.prototype.load = original; };
  554 |     SaveRepository.prototype.load = async function (id: string) {
  555 |       const value = await original.call(this, id);
  556 |       await new Promise<void>(resolve => target.__pr124Loads.push(resolve));
  557 |       return value;
  558 |     };
  559 |   });
  560 |   let completed = 1;
  561 |   for (const [index, item] of promptSwitches.entries()) {
  562 |     await assemble.click();
  563 |     await expect(page.getByRole('button', { name: '组装中…', exact: true })).toBeDisabled();
  564 |     await expect.poll(() => page.evaluate(() => (window as unknown as { __pr124Loads: unknown[] }).__pr124Loads.length)).toBe(1);
  565 |     await backToList(page);
  566 |     const row = page.locator(`[data-prompt-id="${item.id}"]`);
  567 |     if (index % 2) {
  568 |       await row.locator('.pm-open').click();
  569 |       await page.getByRole('region', { name: '模块原文' }).getByRole('checkbox').uncheck();
  570 |       await screenshot(page, 'source-unsaved');
  571 |     } else await row.getByRole('checkbox').uncheck();
  572 |     await openAdvanced(page);
  573 |     await expect(page.getByText('已按此配置组装预览，尚未发送。', { exact: true })).toHaveCount(0);
  574 |     await expect(page.locator('.stage-stat-cards')).not.toContainText('离线预览');
  575 |     await expect(page.getByText('写作偏好已修改，请重新组装预览。', { exact: true })).toBeVisible();
  576 |     await expect(page.getByRole('button', { name: '主动查看完整内部上下文' })).toHaveCount(0);
  577 |     if (!index) await screenshot(page, 'preview-invalidated');
  578 |     await assemble.click();
  579 |     await expect.poll(() => page.evaluate(() => (window as unknown as { __pr124Loads: unknown[] }).__pr124Loads.length)).toBe(2);
  580 |     // Finish the superseded job first, while the current job remains blocked.
  581 |     await page.evaluate(() => (window as unknown as { __pr124Loads: Array<() => void> }).__pr124Loads.shift()!());
  582 |     await expect.poll(() => page.evaluate(() => (window as unknown as { __pr124Builds: number }).__pr124Builds)).toBe(++completed);
  583 |     await expect(page.getByRole('button', { name: '组装中…', exact: true })).toBeDisabled();
  584 |     await expect(page.getByText('已按此配置组装预览，尚未发送。', { exact: true })).toHaveCount(0);
  585 |     await page.evaluate(() => (window as unknown as { __pr124Loads: Array<() => void> }).__pr124Loads.shift()!());
  586 |     await expect.poll(() => page.evaluate(() => (window as unknown as { __pr124Builds: number }).__pr124Builds)).toBe(++completed);
  587 |     await expect(page.getByText('已按此配置组装预览，尚未发送。', { exact: true })).toBeVisible();
  588 |     await expect(page.locator(`[data-module-id="${item.id}"]`)).toHaveCount(0);
  589 |     await expect(page.getByLabel('完整内部上下文', { exact: true })).toHaveCount(0);
  590 |   }
  591 |   await page.evaluate(() => (window as unknown as { __pr124Restore: () => void }).__pr124Restore());
  592 |   expect(await readFormal(page)).toBe(before);
  593 | });
  594 | 
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: action-workflow.spec.ts >> 一次创角确认自动执行开局三阶段，StrictMode和重复点击不重复请求
- Location: e2e/action-workflow.spec.ts:89:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: /读取存档/ })

```

# Page snapshot

```yaml
- main "游戏首页与存档馆" [ref=f2e4]:
  - generic [ref=f2e5]:
    - generic [aria-hidden] [ref=f2e6]: 黑
    - generic [ref=f2e7]:
      - text: 黑金王朝
      - generic [ref=f2e8]: HEIJINWANGCHAO
    - button "设置" [ref=f2e9] [cursor=pointer]
    - generic [ref=f2e10]: V1.0 Beta
  - generic [ref=f2e11]:
    - paragraph [ref=f2e12]: MODERN CITY / OPEN WORLD
    - heading "黑金王朝" [level=1] [ref=f2e13]
    - paragraph [ref=f2e14]: 起点有冲突，人生不预设结局。
  - status "终点 重庆，时刻 00:22，已选择" [ref=f2e15]:
    - generic [ref=f2e16]:
      - text: 终点
      - generic [ref=f2e17]: DEST
    - generic [ref=f2e18]:
      - generic [ref=f2e19]: 重
      - generic [ref=f2e20]: 庆
    - generic [ref=f2e22]:
      - generic [ref=f2e23]: "0"
      - generic [ref=f2e24]: "0"
      - generic [ref=f2e25]: ":"
      - generic [ref=f2e26]: "2"
      - generic [ref=f2e27]: "2"
    - generic [ref=f2e28]: 已选择
  - generic [ref=f2e29]:
    - generic [ref=f2e30]: 车票 01
    - generic [ref=f2e31]: 本地保存 · 无需账号
    - button "导入备份" [ref=f2e32] [cursor=pointer]: ⤓ 导入备份
    - button "刷新列表" [ref=f2e33] [cursor=pointer]
  - region "车票栏，左右方向键切换" [ref=f2e34]:
    - article "林舟 · 重庆，保存于 2026/11/15 00:22，已选择" [ref=f2e36]:
      - generic [ref=f2e37]:
        - generic [ref=f2e38]:
          - generic [ref=f2e39]: 重庆
          - generic [ref=f2e40]: CHONGQING
          - generic [ref=f2e41]: ARCHIVE 01
        - generic [ref=f2e42]:
          - generic [ref=f2e43]:
            - generic [ref=f2e44]:
              - generic [ref=f2e45]: FROM
              - generic [ref=f2e46]: 林舟
            - generic [aria-hidden] [ref=f2e47]: 单程
            - generic [ref=f2e49]:
              - generic [ref=f2e50]: TO
              - generic [ref=f2e51]: 重庆
          - generic [ref=f2e52]:
            - generic [ref=f2e53]:
              - term [ref=f2e54]: 保存日期
              - definition [ref=f2e55]: 2026/11/15
            - generic [ref=f2e56]:
              - term [ref=f2e57]: 时刻
              - definition [ref=f2e58]: 00:22
            - generic [ref=f2e59]:
              - generic [aria-hidden]:
                - text: 已检票
                - generic: SELECTED
          - paragraph [ref=f2e60]: 从未备份
          - generic [aria-hidden] [ref=f2e61]:
            - generic [ref=f2e78]: 29°33′N · 106°33′E
            - generic [ref=f2e79]: 山城 · 江雾 · 轻轨
            - generic [ref=f2e80]: 渝
      - generic [ref=f2e82]:
        - text: 继续游戏
        - generic [ref=f2e83]: ↓ 按住票根往下撕
    - article "空白车票：开启新的人生" [ref=f2e86]:
      - generic [ref=f2e87]:
        - generic [ref=f2e88]:
          - generic [ref=f2e89]: 空白车票
          - generic [ref=f2e90]: NEW LIFE
          - generic [ref=f2e91]: NEW
        - generic [ref=f2e92]:
          - generic [ref=f2e93]:
            - generic [ref=f2e94]:
              - generic [ref=f2e95]: FROM
              - generic [ref=f2e96]: ？
            - generic [aria-hidden] [ref=f2e97]: 单程
            - generic [ref=f2e99]:
              - generic [ref=f2e100]: TO
              - generic [ref=f2e101]: ？
          - generic [ref=f2e102]:
            - generic [ref=f2e103]:
              - term [ref=f2e104]: 城市
              - definition [ref=f2e105]
            - generic [ref=f2e107]:
              - term [ref=f2e108]: 职业
              - definition [ref=f2e109]
            - generic [ref=f2e111]:
              - term [ref=f2e112]: 存档
              - definition [ref=f2e113]: —
          - paragraph [ref=f2e114]: 四座城市 · 自由职业 · 开放人生
      - generic [ref=f2e116]:
        - text: 开启新的人生
        - generic [ref=f2e117]: ↓ 按住票根往下撕
  - navigation "车票页码" [ref=f2e119]:
    - button "第 1 张" [ref=f2e120] [cursor=pointer]
    - button "第 2 张，空白车票" [ref=f2e121] [cursor=pointer]
  - generic [ref=f2e122]:
    - button "继续游戏" [ref=f2e123] [cursor=pointer]:
      - text: 继续游戏
      - generic [aria-hidden] [ref=f2e124]: →
    - generic [ref=f2e125]:
      - button "导出备份" [ref=f2e126] [cursor=pointer]
      - button "删除" [ref=f2e127] [cursor=pointer]
  - generic [ref=f2e128]:
    - group "游玩信息" [ref=f2e129]:
      - button "游玩须知与免责声明" [ref=f2e130] [cursor=pointer]
      - button "王朝公告" [ref=f2e131] [cursor=pointer]
    - paragraph [ref=f2e132]: 四座城市 · 自由职业 · 开放人生三阶段生成 · 原子结算 · 连续回合
```

# Test source

```ts
  2   | import { expect, test } from './helpers/test';
  3   | import { workflowTrigger, workflowSummary, goHome, openWorkflow, openBoundInput } from './helpers/gameLayout';
  4   | import { addChannel, aiTab, saveAi, stageModel } from './helpers/aiSettings';
  5   | import type { Page } from '@playwright/test';
  6   | import { GameStateSchema } from '../src/domain/state';
  7   | import { TurnDraftSchema } from '../src/domain/drafts';
  8   | import { record, array, string } from '../src/services/ai/protocols';
  9   | 
  10  | type Stage = 'story' | 'variables' | 'world';
  11  | async function prepare(page: Page, configured = true, stages = { variables: true, world: true }) {
  12  |   await page.goto('/');
  13  |   await page.evaluate(async ({ configured, stages }) => {
  14  |     const cp = '/src/services/ai/configuration.ts', vp = '/src/services/ai/credentials.ts', sp = '/src/ui/settings/model.ts';
  15  |     const { defaultAiConfig, newChannel, saveAiConfig } = await import(cp), { CredentialVault } = await import(vp),
  16  |       { defaultSettings, settingsKey } = await import(sp);
  17  |     const settings = defaultSettings(); settings.prompts.minNarrativeChars = 5; settings.prompts.actionOptions = false;
  18  |     settings.runtime.useVariableStage = stages.variables; settings.runtime.useWorldStage = stages.world;
  19  |     localStorage.setItem(settingsKey, JSON.stringify(settings));
  20  |     if (configured) {
  21  |       const channel = newChannel(), config = defaultAiConfig(); channel.baseUrl = 'https://action.mock.invalid/v1';
  22  |       config.channels = [channel]; config.routes.story = { channelId: channel.id, modelId: 'story' };
  23  |       config.routes.variables = { mode: 'independent', channelId: channel.id, modelId: 'variables' };
  24  |       config.routes.world = { mode: 'independent', channelId: channel.id, modelId: 'world' };
  25  |       saveAiConfig(localStorage, config); new CredentialVault(sessionStorage, localStorage).set(channel.id, 'mock-action-key');
  26  |     }
  27  |   }, { configured, stages });
  28  |   await page.reload();
  29  | }
  30  | async function creation(page: Page) {
  31  |   await page.getByRole('button', { name: /开始新游戏/ }).click();
  32  |   for (const [label, value] of Object.entries({ 姓名: '林舟', 年龄: '30', 外貌: '短发', 性格: '沉稳' }))
  33  |     await page.getByLabel(label, { exact: true }).fill(value);
  34  |   await page.getByRole('radio', { name: '女性', exact: true }).check();
  35  |   await page.getByRole('button', { name: /下一步/ }).click();
  36  |   await page.getByRole('button', { name: '专业与公共服务', exact: true }).click();
  37  |   await page.getByRole('radio', { name: /^教师/ }).check();
  38  |   await page.getByRole('button', { name: /下一步/ }).click();
  39  |   await page.getByRole('button', { name: '跳过背景，继续' }).click();
  40  |   await page.getByRole('button', { name: '跳过同伴，继续' }).click();
  41  | }
  42  | async function confirm(page: Page) {
  43  |   await page.getByRole('button', { name: '确认并创建存档', exact: true }).evaluate((button: HTMLButtonElement) => { button.click(); button.click(); });
  44  |   await expect(page.locator('.game-layout')).toBeVisible();
  45  | }
  46  | async function stored(page: Page) {
  47  |   const data = await page.evaluate(async () => {
  48  |     const rp = '/src/services/storage/saveRepository.ts', { SaveRepository } = await import(rp), repo = await SaveRepository.open();
  49  |     try { const id = location.hash.slice(6); return await repo.loadGame(id); } finally { repo.close(); }
  50  |   });
  51  |   return { state: GameStateSchema.parse(data.state), draft: TurnDraftSchema.parse(data.draft) };
  52  | }
  53  | function gate() {
  54  |   let release!: () => void; const pending = new Promise<void>((resolve) => { release = resolve; }); return { pending, release };
  55  | }
  56  | async function mock(page: Page) {
  57  |   const calls: { stage: Stage; context: Record<string, unknown>; messages: string }[] = [];
  58  |   const plan: { failure?: Stage; status?: number; hold?: Stage; gate?: Promise<void>; network?: boolean; badSummary?: boolean } = {};
  59  |   await page.route('https://action.mock.invalid/**', async (route) => {
  60  |     if (route.request().method() === 'GET') { await route.fulfill({ json: { data: [{ id: 'story' }, { id: 'variables' }, { id: 'world' }] } }); return; }
  61  |     const body = record(route.request().postDataJSON()), stage = string(body.model);
  62  |     if (stage !== 'story' && stage !== 'variables' && stage !== 'world') throw new Error('unexpected model route');
  63  |     const messages = array(body.messages).map((item) => string(record(item).content)).join('\n');
  64  |     const match = messages.match(/<GAME_CONTEXT>\n([\s\S]*?)\n<\/GAME_CONTEXT>/); if (!match) throw new Error('missing actual context');
  65  |     const ctx = record(JSON.parse(match[1])); calls.push({ stage, context: ctx, messages });
  66  |     if (plan.hold === stage) await plan.gate;
  67  |     if (plan.failure === stage && plan.network) { await route.abort('failed'); return; }
  68  |     const state = record(ctx.SAVE_STATE), number = Number(state.turnNumber) + 1;
  69  |     const pending = Boolean(ctx.OPENING_TIME && record(ctx.OPENING_TIME).status === 'pending');
  70  |     const anchor = pending ? '2015年7月8日14:00，重庆街头。' : '';
  71  |     const openingGuide = pending ? [{ group: 'time', subjectHint: 'time:opening', observedFact: JSON.stringify({ startAt: '2015-07-08T14:00:00+08:00', endAt: '2015-07-08T14:01:00+08:00' }), textEvidence: anchor }] : [];
  72  |     const text = plan.failure === stage && !plan.status ? '{invalid-json' : stage === 'story'
  73  |       ? `<thinking>本轮创作提纲：保持连续，按当前行动呈现事实。</thinking><正文>${anchor}第${number}幕。主角在街边观察周围，街道上人来人往。</正文><短期记忆>${plan.badSummary ? '' : `主角第${number}次在街边观察环境。`}</短期记忆><变量规划>${JSON.stringify(openingGuide)}</变量规划>`
  74  |       : (stage === 'variables' ? variableReply : JSON.stringify)(stage === 'variables' ? { commands: [{ type: 'SetWorldClock', commandId: 'clock', worldClock: ctx.OPENING_TIME ? string(record(ctx.OPENING_TIME).endAt) : new Date(Date.parse(string(state.worldClock)) + 60000).toISOString(), evidence: '主角在街边观察周围，街道上人来人往。' }], rejectedSuggestions: [], unresolved: [] }
  75  |         : { worldCommands: [], taskCommands: [], eventCommands: [], visibleHooks: [{ text: '尚未公开的内部线索' }], unresolved: [] });
  76  |     await route.fulfill({ status: plan.failure === stage ? plan.status ?? 200 : 200,
  77  |       contentType: stage === 'story' ? 'text/event-stream' : 'application/json',
  78  |       body: stage === 'story' ? `data: ${JSON.stringify({ choices: [{ delta: { content: text } }] })}\n\ndata: [DONE]\n\n`
  79  |         : JSON.stringify({ choices: [{ message: { content: text }, finish_reason: 'stop' }] }),
  80  |     }).catch(() => undefined);
  81  |   });
  82  |   return { calls, plan };
  83  | }
  84  | const workflow = (page: Page) => page.getByRole('region', { name: '三阶段工作流', exact: true });
  85  | async function ready(page: Page) {
  86  |   await expect(workflow(page).getByRole('status')).toContainText('本回合已结算');
  87  | }
  88  | 
  89  | test('一次创角确认自动执行开局三阶段，StrictMode和重复点击不重复请求', async ({ page }) => {
  90  |   await prepare(page); const server = await mock(page); await creation(page);
  91  |   await confirm(page); await ready(page);
  92  |   expect(server.calls.map((call) => call.stage)).toEqual(['story', 'variables', 'world']);
  93  |   const result = await stored(page); expect(result.state.turnNumber).toBe(1); expect(result.state.revision).toBe(1);
  94  |   expect(result.state.journal).toHaveLength(1); expect(result.draft.userInput).toBe(''); expect(result.draft.stageStatus).toEqual({ story: 'pending', variables: 'pending', world: 'pending' });
  95  |   expect(server.calls[0].context.CREATION_PROFILE).toBeTruthy();
  96  |   await expect(page.locator('.workflow-disclosure')).not.toHaveAttribute('open');
  97  |   await expect(page.getByRole('button', { name: '生成变量候选', exact: true })).toBeHidden();
  98  |   await expect(page.getByRole('button', { name: '继续推演', exact: true })).toHaveCount(0);
  99  |   await expect(page.locator('main')).not.toContainText('尚未公开的内部线索');
  100 |   await page.reload(); await ready(page); expect(await stored(page)).toEqual(result); expect(server.calls).toHaveLength(3);
  101 |   await goHome(page);
> 102 |   await page.getByRole('button', { name: /读取存档/ }).click(); await ready(page); expect(server.calls).toHaveLength(3);
      |                                                    ^ Error: locator.click: Test timeout of 30000ms exceeded.
  103 | });
  104 | 
  105 | test('缺少AI配置零请求，设置后不自动补发，只在明确开始时运行', async ({ page }) => {
  106 |   await prepare(page, false); const server = await mock(page); await creation(page);
  107 |   await expect(page.locator('.notice')).toContainText('生成可能产生费用'); await confirm(page);
  108 |   await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toContainText('配置'); expect(server.calls).toHaveLength(0);
  109 |   const before = await stored(page); await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  110 |   await page.getByRole('button', { name: '打开 AI 设置', exact: true }).click();
  111 |   const settings = await aiTab(page);
  112 |   await addChannel(settings, { preset: 'OpenAI 兼容', name: '行动测试', url: 'https://action.mock.invalid/v1', key: 'mock-action-key' });
  113 |   // 填好后只自动读取模型列表（不产生费用）；从真实设置给三个阶段选同一渠道的不同模型，不通过生成请求探测模型。
  114 |   await expect(settings.locator('.ai-connect')).toContainText('连接正常');
  115 |   for (const [label, model] of [['正文生成', 'story'], ['变量管理', 'variables'], ['动态世界', 'world']]) await stageModel(settings, label, '行动测试', model, 'list');
  116 |   await saveAi(settings);
  117 |   await page.getByRole('button', { name: '关闭资料界面', exact: true }).click(); expect(server.calls).toHaveLength(0);
  118 |   expect(await stored(page)).toEqual(before);
  119 |   await page.getByRole('button', { name: '继续未完成阶段', exact: true }).click(); await ready(page);
  120 |   expect(server.calls.map((call) => call.stage)).toEqual(['story', 'variables', 'world']);
  121 | });
  122 | 
  123 | test('发送行动只结算一次并自动串联下一轮，刷新及再次读档不补发', async ({ page }) => {
  124 |   await prepare(page); const server = await mock(page); await creation(page); await confirm(page); await ready(page);
  125 |   const before = await stored(page); await page.getByLabel('你的行动', { exact: true }).fill('在街边继续观察');
  126 |   await page.getByRole('button', { name: '发送', exact: true }).evaluate((button: HTMLButtonElement) => { button.click(); button.click(); });
  127 |   await expect(page.getByTestId('story-reader')).toContainText('第2幕'); await ready(page);
  128 |   const after = await stored(page); expect(after.state.revision).toBe(2); expect(after.state.journal).toHaveLength(2);
  129 |   expect(after.state.memories.short).toHaveLength(2); expect(after.draft.userInput).toBe('');
  130 |   expect(after.state.economy).toEqual(before.state.economy); expect(after.state.npc).toEqual(before.state.npc);
  131 |   expect(server.calls.map((call) => call.stage)).toEqual(['story', 'variables', 'world', 'story', 'variables', 'world']);
  132 |   expect(server.calls[0].context.CREATION_PROFILE).toBeTruthy(); expect(server.calls[3].context.CREATION_PROFILE).toBeUndefined();
  133 |   expect(server.calls[3].context.PLAYER_ACTION).toBe('在街边继续观察');
  134 |   await page.reload(); await ready(page); expect(await stored(page)).toEqual(after); expect(server.calls).toHaveLength(6);
  135 | });
  136 | 
  137 | for (const stage of ['variables', 'world'] as const) {
  138 |   test(`${stage}失败保留上游，仅明确恢复缺少阶段，折叠无额外请求`, async ({ page }) => {
  139 |     await prepare(page); const server = await mock(page); server.plan.failure = stage;
  140 |     await creation(page); await confirm(page); await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toBeVisible();
  141 |     const failed = await stored(page); expect(failed.state.revision).toBe(0); expect(failed.draft.story).toBeTruthy();
  142 |     expect(server.calls.map((call) => call.stage)).toEqual(stage === 'variables' ? ['story', 'variables'] : ['story', 'variables', 'world']);
  143 |     await page.getByLabel('你的行动', { exact: true }).fill('下一步行动'); await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  144 |     await workflowTrigger(page).click(); await workflowTrigger(page).click();
  145 |     expect(server.calls).toHaveLength(stage === 'variables' ? 2 : 3);
  146 |     await page.reload(); await openWorkflow(page); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeEnabled();
  147 |     expect(await stored(page)).toEqual(failed); server.plan.failure = undefined;
  148 |     await page.getByRole('button', { name: '继续未完成阶段', exact: true }).evaluate((button: HTMLButtonElement) => { button.click(); button.click(); });
  149 |     await ready(page); const after = await stored(page); expect(after.state.revision).toBe(1); expect(after.state.journal[0].story).toEqual(failed.draft.story); expect(after.draft.userInput).toBe('');
  150 |     expect(server.calls.map((call) => call.stage)).toEqual(stage === 'variables' ? ['story', 'variables', 'variables', 'world'] : ['story', 'variables', 'world', 'world']);
  151 |   });
  152 | }
  153 | 
  154 | for (const status of [401, 403, 429]) {
  155 |   test(`自动开局HTTP ${status}停止、不无限重试，刷新不重新授权`, async ({ page }) => {
  156 |     await prepare(page); const server = await mock(page); server.plan.failure = 'story'; server.plan.status = status;
  157 |     await creation(page); await confirm(page); await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toBeVisible();
  158 |     expect(server.calls.map((call) => call.stage)).toEqual(['story']); const failed = await stored(page);
  159 |     expect(failed.draft.story).toBeUndefined(); expect(failed.state.revision).toBe(0);
  160 |     await page.reload(); await openWorkflow(page); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeEnabled();
  161 |     expect(server.calls).toHaveLength(1); expect(await stored(page)).toEqual(failed);
  162 |   });
  163 | }
  164 | 
  165 | test('取消中的迟到响应不启动下游，刷新保留待生成草稿且明确恢复', async ({ page }, info) => {
  166 |   await prepare(page); const server = await mock(page), held = gate(); server.plan.hold = 'story'; server.plan.gate = held.pending;
  167 |   await creation(page); await confirm(page); await expect.poll(() => server.calls.length).toBe(1);
  168 |   await workflowTrigger(page).click(); await workflowTrigger(page).click();
  169 |   expect(server.calls).toHaveLength(1); await openWorkflow(page);
  170 |   if (info.project.name === 'desktop') {
  171 |     await page.setViewportSize({ width: 1024, height: 520 });
  172 |     await expect(page.getByRole('button', { name: '取消自动执行', exact: true })).toBeInViewport({ ratio: 1 });
  173 |     await expect(page.getByRole('button', { name: '发送', exact: true })).toBeInViewport({ ratio: 1 });
  174 |     await page.screenshot({ path: 'docs/ui-pc-reading/screenshots/after-running-short-pc.png' });
  175 |   }
  176 |   await page.getByRole('button', { name: '取消自动执行', exact: true }).click();
  177 |   await expect(workflow(page).getByRole('status')).toContainText('取消'); held.release();
  178 |   const cancelled = await stored(page); expect(cancelled.draft.story).toBeUndefined(); expect(cancelled.state.revision).toBe(0);
  179 |   await page.reload(); await openWorkflow(page); await expect(page.getByRole('button', { name: '自动生成开局', exact: true })).toBeEnabled();
  180 |   expect(server.calls).toHaveLength(1); server.plan.hold = undefined;
  181 |   await page.getByRole('button', { name: '自动生成开局', exact: true }).click(); await ready(page); expect(server.calls).toHaveLength(4);
  182 | });
  183 | 
  184 | test('快速离开并重读同一存档或新标签不能延续开局收费授权', async ({ page, context }) => {
  185 |   await prepare(page); const server = await mock(page), held = gate(); server.plan.hold = 'variables'; server.plan.gate = held.pending;
  186 |   await creation(page); await confirm(page); await expect.poll(() => server.calls.length).toBe(2);
  187 |   const url = page.url(); await goHome(page);
  188 |   await page.getByRole('button', { name: /读取存档/ }).click();
  189 |   await openWorkflow(page); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeVisible();
  190 |   const other = await context.newPage(); let otherRequests = 0;
  191 |   await other.route('https://action.mock.invalid/**', async (route) => { otherRequests++; await route.abort(); });
  192 |   await other.goto(url); await expect(other.locator('.game-layout')).toBeVisible();
  193 |   held.release(); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeEnabled();
  194 |   expect(server.calls).toHaveLength(2); expect(otherRequests).toBe(0); const after = await stored(page); expect(after.draft.world).toBeUndefined(); expect(after.state.revision).toBe(0);
  195 |   await other.close();
  196 | });
  197 | 
  198 | test('关闭变量时世界只能预览，不因自动开局而强行启用或允许发送', async ({ page }) => {
  199 |   await prepare(page, true, { variables: false, world: true }); const server = await mock(page); await creation(page); await confirm(page);
  200 |   await expect(workflow(page).getByRole('status')).toContainText('预览');
  201 |   expect(server.calls.map((call) => call.stage)).toEqual(['story', 'world']); const result = await stored(page);
  202 |   expect(result.draft.world?.validation).toBe('preview'); expect(result.draft.variables).toBeUndefined(); expect(result.state.revision).toBe(0);
```
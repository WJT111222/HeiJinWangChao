# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: action-workflow.spec.ts >> 开局network不隐式重试，刷新不重发，草稿和正式状态安全
- Location: e2e/action-workflow.spec.ts:226:3

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('region', { name: '三阶段工作流', exact: true }).getByRole('alert')
Expected substring: "网络请求失败"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" getByRole('region', { name: '三阶段工作流', exact: true }).getByRole('alert') with timeout 5000ms
  - waiting for getByRole('region', { name: '三阶段工作流', exact: true }).getByRole('alert')

```

```yaml
- banner:
  - button "打开游戏菜单": ☰
- main:
  - button "此时此地与主角状态":
    - text: 重庆 重庆
    - time: "--:--"
    - text: —
  - text: 重庆，开局时间待确认 --:--，天气：天气待确认
  - region "剧情与行动":
    - text: THE STORY 等待开局
    - paragraph: A CITY. A TURNING POINT.
    - heading "故事，尚未落笔。" [level=1]
    - paragraph: 你的资料已保存。 配置 AI 渠道后，即可生成这座城市中的第一幕。
    - region "三阶段工作流":
      - button "三阶段工作流详情" [expanded]:
        - status: 三阶段 · 正文生成失败 · 查看详情
        - text: 详情 ›
    - button "回合操作": ⋯
    - text: 你的行动
    - textbox "你的行动":
      - /placeholder: 填写你的行动
    - button "发送" [disabled]
  - navigation "底部导航":
    - button "故事"
    - button "人物"
    - button "世界资料"
    - button "设置"
  - dialog "重试与变更详情":
    - heading "重试与变更详情" [level=2]
    - button "关闭资料界面": 关闭
    - tablist "诊断分类":
      - tab "概要"
      - tab "运行日志 1" [selected]
      - tab "请求用量 1"
      - tab "模型原文"
    - tabpanel "运行日志 1":
      - group:
        - text: 运行日志 · 错误 1 条
        - strong: 最近错误 · network
        - paragraph: 仅显示本次页面会话的错误；每条可单独复制安全诊断，不含原始模型响应、请求正文或密钥。刷新即清空。
        - button "清空日志"
        - list "错误日志条目":
          - listitem:
            - time: 16:18:29
            - strong: 正文生成
            - text: 错误
            - button "复制此条"
            - paragraph: 网络请求失败，可能涉及网络连接、CORS 或 TLS；浏览器无法据此判断密钥是否错误。请检查服务是否允许当前网页直连。
            - text: 错误码：network
    - paragraph: 仅本页临时保存 · 刷新即清空
- button "收起工作流暗区"
- dialog "三阶段工作流":
  - button "收起三阶段工作流"
  - button "行动输入"
  - region "三阶段详情":
    - text: THREE STAGES · 三阶段
    - heading "正文生成失败 · 查看详情" [level=3]
    - button "收起三阶段详情": ×
    - alert:
      - paragraph: 正文生成：网络请求失败，可能涉及网络连接、CORS 或 TLS；浏览器无法据此判断密钥是否错误。请检查服务是否允许当前网页直连。
      - text: 正文 · 安全失败码：network · 1 次尝试
      - button "打开 AI 设置"
      - button "关闭错误提示": ×
    - navigation "三阶段导航":
      - paragraph: STAGES
      - list:
        - listitem:
          - button "01正文生成 失败 · 可重试":
            - strong: 01正文生成
            - text: 失败 · 可重试
        - listitem:
          - button "02变量管理 待生成":
            - strong: 02变量管理
            - text: 待生成
          - checkbox "变量管理" [checked]
        - listitem:
          - button "03动态世界 待生成":
            - strong: 03动态世界
            - text: 待生成
          - checkbox "动态世界" [checked]
      - paragraph: 本回合
      - list:
        - listitem:
          - button "运行诊断 错误与用量 错误 1 条":
            - strong: 运行诊断
            - text: 错误与用量 1
        - listitem:
          - button "已绑定输入 只读":
            - strong: 已绑定输入
            - text: 只读
    - button "继续未完成阶段"
    - text: 生成可能产生费用。
```

# Test source

```ts
  139 |     await prepare(page); const server = await mock(page); server.plan.failure = stage;
  140 |     await creation(page); await confirm(page); await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toBeVisible();
  141 |     const failed = await stored(page); expect(failed.state.revision).toBe(0); expect(failed.draft.story).toBeTruthy();
  142 |     expect(server.calls.map((call) => call.stage)).toEqual(stage === 'variables' ? ['story', 'variables'] : ['story', 'variables', 'world']);
  143 |     await page.getByLabel('你的行动', { exact: true }).fill('下一步行动'); await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  144 |     await workflowTrigger(page).click(); await workflowTrigger(page).click();
  145 |     expect(server.calls).toHaveLength(stage === 'variables' ? 2 : 3);
  146 |     await page.reload(); await openWorkflow(page); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeEnabled();
  147 |     expect(await stored(page)).toEqual(failed); server.plan.failure = undefined;
  148 |     await page.getByRole('button', { name: '继续未完成阶段', exact: true }).evaluate((button: HTMLButtonElement) => { button.click(); button.click(); });
  149 |     await ready(page); const after = await stored(page); expect(after.state.revision).toBe(1); expect(after.state.journal[0].story).toEqual(failed.draft.story); expect(after.draft.userInput).toBe('');
  150 |     expect(server.calls.map((call) => call.stage)).toEqual(stage === 'variables' ? ['story', 'variables', 'variables', 'world'] : ['story', 'variables', 'world', 'world']);
  151 |   });
  152 | }
  153 | 
  154 | for (const status of [401, 403, 429]) {
  155 |   test(`自动开局HTTP ${status}停止、不无限重试，刷新不重新授权`, async ({ page }) => {
  156 |     await prepare(page); const server = await mock(page); server.plan.failure = 'story'; server.plan.status = status;
  157 |     await creation(page); await confirm(page); await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toBeVisible();
  158 |     expect(server.calls.map((call) => call.stage)).toEqual(['story']); const failed = await stored(page);
  159 |     expect(failed.draft.story).toBeUndefined(); expect(failed.state.revision).toBe(0);
  160 |     await page.reload(); await openWorkflow(page); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeEnabled();
  161 |     expect(server.calls).toHaveLength(1); expect(await stored(page)).toEqual(failed);
  162 |   });
  163 | }
  164 | 
  165 | test('取消中的迟到响应不启动下游，刷新保留待生成草稿且明确恢复', async ({ page }, info) => {
  166 |   await prepare(page); const server = await mock(page), held = gate(); server.plan.hold = 'story'; server.plan.gate = held.pending;
  167 |   await creation(page); await confirm(page); await expect.poll(() => server.calls.length).toBe(1);
  168 |   await workflowTrigger(page).click(); await workflowTrigger(page).click();
  169 |   expect(server.calls).toHaveLength(1); await openWorkflow(page);
  170 |   if (info.project.name === 'desktop') {
  171 |     await page.setViewportSize({ width: 1024, height: 520 });
  172 |     await expect(page.getByRole('button', { name: '取消自动执行', exact: true })).toBeInViewport({ ratio: 1 });
  173 |     await expect(page.getByRole('button', { name: '发送', exact: true })).toBeInViewport({ ratio: 1 });
  174 |     await page.screenshot({ path: 'docs/ui-pc-reading/screenshots/after-running-short-pc.png' });
  175 |   }
  176 |   await page.getByRole('button', { name: '取消自动执行', exact: true }).click();
  177 |   await expect(workflow(page).getByRole('status')).toContainText('取消'); held.release();
  178 |   const cancelled = await stored(page); expect(cancelled.draft.story).toBeUndefined(); expect(cancelled.state.revision).toBe(0);
  179 |   await page.reload(); await openWorkflow(page); await expect(page.getByRole('button', { name: '自动生成开局', exact: true })).toBeEnabled();
  180 |   expect(server.calls).toHaveLength(1); server.plan.hold = undefined;
  181 |   await page.getByRole('button', { name: '自动生成开局', exact: true }).click(); await ready(page); expect(server.calls).toHaveLength(4);
  182 | });
  183 | 
  184 | test('快速离开并重读同一存档或新标签不能延续开局收费授权', async ({ page, context }) => {
  185 |   await prepare(page); const server = await mock(page), held = gate(); server.plan.hold = 'variables'; server.plan.gate = held.pending;
  186 |   await creation(page); await confirm(page); await expect.poll(() => server.calls.length).toBe(2);
  187 |   const url = page.url(); await goHome(page);
  188 |   await page.getByRole('button', { name: /读取存档/ }).click();
  189 |   await openWorkflow(page); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeVisible();
  190 |   const other = await context.newPage(); let otherRequests = 0;
  191 |   await other.route('https://action.mock.invalid/**', async (route) => { otherRequests++; await route.abort(); });
  192 |   await other.goto(url); await expect(other.locator('.game-layout')).toBeVisible();
  193 |   held.release(); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeEnabled();
  194 |   expect(server.calls).toHaveLength(2); expect(otherRequests).toBe(0); const after = await stored(page); expect(after.draft.world).toBeUndefined(); expect(after.state.revision).toBe(0);
  195 |   await other.close();
  196 | });
  197 | 
  198 | test('关闭变量时世界只能预览，不因自动开局而强行启用或允许发送', async ({ page }) => {
  199 |   await prepare(page, true, { variables: false, world: true }); const server = await mock(page); await creation(page); await confirm(page);
  200 |   await expect(workflow(page).getByRole('status')).toContainText('预览');
  201 |   expect(server.calls.map((call) => call.stage)).toEqual(['story', 'world']); const result = await stored(page);
  202 |   expect(result.draft.world?.validation).toBe('preview'); expect(result.draft.variables).toBeUndefined(); expect(result.state.revision).toBe(0);
  203 |   await page.getByLabel('你的行动', { exact: true }).fill('继续观察'); await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  204 | });
  205 | 
  206 | test('正文摘要不合法时不保存、不运行下游、不结算', async ({ page }) => {
  207 |   await prepare(page); const server = await mock(page); server.plan.badSummary = true; await creation(page); await confirm(page);
  208 |   await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toBeVisible(); expect(server.calls.map((call) => call.stage)).toEqual(['story']);
  209 |   const result = await stored(page); expect(result.draft.story).toBeUndefined(); expect(result.state.journal).toEqual([]);
  210 |   await page.getByLabel('你的行动', { exact: true }).fill('继续'); await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  211 | });
  212 | 
  213 | test('开局组件加载前刷新销毁授权，未生成草稿保留且仅主动开始才请求', async ({ page }) => {
  214 |   await prepare(page); const server = await mock(page), held = gate(); let loading = false;
  215 |   const modulePath = '**/src/ui/game/GameScreen.tsx*';
  216 |   await page.route(modulePath, async (route) => { loading = true; await held.pending; await route.continue().catch(() => undefined); });
  217 |   await creation(page); await page.getByRole('button', { name: '确认并创建存档', exact: true }).click();
  218 |   await expect.poll(() => loading).toBe(true); expect(server.calls).toHaveLength(0);
  219 |   await page.unroute(modulePath); await page.reload(); held.release();
  220 |   await openWorkflow(page); await expect(page.getByRole('button', { name: '自动生成开局', exact: true })).toBeEnabled();
  221 |   const before = await stored(page); expect(before.draft.draftRevision).toBe(0); expect(before.draft.story).toBeUndefined(); expect(server.calls).toHaveLength(0);
  222 |   await page.getByRole('button', { name: '自动生成开局', exact: true }).click(); await ready(page); expect(server.calls).toHaveLength(3);
  223 | });
  224 | 
  225 | for (const failure of ['network', 'timeout'] as const) {
  226 |   test(`开局${failure}不隐式重试，刷新不重发，草稿和正式状态安全`, async ({ page }) => {
  227 |     await prepare(page);
  228 |     if (failure === 'timeout') {
  229 |       await page.evaluate(() => {
  230 |         const key = 'heijin.settings.v1', settings = JSON.parse(localStorage.getItem(key)!);
  231 |         settings.runtime.timeoutSeconds = 1; localStorage.setItem(key, JSON.stringify(settings));
  232 |       });
  233 |       await page.reload();
  234 |     }
  235 |     const server = await mock(page), held = gate();
  236 |     if (failure === 'network') { server.plan.failure = 'story'; server.plan.network = true; }
  237 |     else { server.plan.hold = 'story'; server.plan.gate = held.pending; }
  238 |     await creation(page); await confirm(page);
> 239 |     await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toContainText(failure === 'network' ? '网络请求失败' : '超时');
      |                                                                               ^ Error: expect(locator).toContainText(expected) failed
  240 |     held.release(); expect(server.calls.map((call) => call.stage)).toEqual(['story']);
  241 |     const failed = await stored(page); expect(failed.state.revision).toBe(0); expect(failed.draft.story).toBeUndefined();
  242 |     await page.reload(); await openWorkflow(page); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeEnabled();
  243 |     expect(server.calls).toHaveLength(1); expect(await stored(page)).toEqual(failed);
  244 |   });
  245 | }
  246 | 
  247 | for (const disabled of ['world', 'variables'] as const) {
  248 |   test(`关闭阶段时${disabled}：不显示无效继续，引导启用后只补必要候选并正常发送`, async ({ page }) => {
  249 |     test.setTimeout(60000);
  250 |     await prepare(page, true, { variables: disabled !== 'variables', world: disabled !== 'world' });
  251 |     const server = await mock(page); await creation(page); await confirm(page);
  252 |     await expect(workflow(page).getByRole('status')).toContainText(disabled === 'world' ? '阶段已关闭' : '预览');
  253 |     const before = await stored(page), initial = disabled === 'world' ? ['story', 'variables'] : ['story', 'world'];
  254 |     expect(server.calls.map((call) => call.stage)).toEqual(initial);
  255 |     await expect(workflow(page).getByRole('button', { name: '继续未完成阶段', exact: true })).toHaveCount(0);
  256 |     await expect(page.locator('.workflow-disclosure')).not.toHaveAttribute('open');
  257 |     await openWorkflow(page);
  258 |     const guidance = workflow(page).getByRole('note', { name: '阶段设置提示', exact: true });
  259 |     await expect(guidance).toContainText(disabled === 'world' ? '动态世界阶段已关闭' : '变量阶段未启用，当前世界结果仅为预览');
  260 |     await workflowTrigger(page).click();
  261 |     await expect(page.locator('.workflow-disclosure')).not.toHaveAttribute('open');
  262 |     await page.getByLabel('你的行动', { exact: true }).fill('继续观察街道');
  263 |     await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  264 |     await page.reload();
  265 |     await openWorkflow(page); await expect(guidance).toBeVisible();
  266 |     await page.getByLabel('你的行动', { exact: true }).fill('继续观察街道');
  267 |     await expect(workflow(page).getByRole('button', { name: '继续未完成阶段', exact: true })).toHaveCount(0);
  268 |     expect(await stored(page)).toEqual(before); expect(server.calls.map((call) => call.stage)).toEqual(initial);
  269 |     // PC 横幅按钮直达对应阶段开关；移动端仍展开高级设置。
  270 |     await guidance.getByRole('button', { name: /^(?:展开高级设置|前往阶段开关)$/ }).click();
  271 |     await expect(page.locator('.workflow-disclosure')).toHaveAttribute('open');
  272 |     const toggle = page.getByLabel(disabled === 'world' ? '动态世界' : '变量管理', { exact: true });
  273 |     await expect(toggle).toBeFocused(); await expect(toggle).not.toBeChecked();
  274 |     expect(await stored(page)).toEqual(before); expect(server.calls.map((call) => call.stage)).toEqual(initial);
  275 |     await toggle.check();
  276 |     const resume = workflow(page).getByRole('button', { name: '继续未完成阶段', exact: true });
  277 |     await expect(resume).toBeEnabled(); expect(server.calls.map((call) => call.stage)).toEqual(initial);
  278 |     expect(await stored(page)).toEqual(before);
  279 |     await workflowTrigger(page).click();
  280 |     await expect(resume).toBeHidden(); await openWorkflow(page); await resume.click(); await ready(page);
  281 |     const complete = await stored(page);
  282 |     expect(complete.state.revision).toBe(1); expect(complete.state.journal[0].story).toEqual(before.draft.story);
  283 |     if (disabled === 'world') expect(complete.state.appliedCommands).toEqual(expect.arrayContaining(before.draft.variables!.result.commands.map(command => expect.objectContaining({ commandId: command.commandId }))));
  284 |     const completedCalls = disabled === 'world' ? ['story', 'variables', 'world'] : ['story', 'world', 'variables', 'world'];
  285 |     expect(server.calls.map((call) => call.stage)).toEqual(completedCalls);
  286 |     await expect(resume).toHaveCount(0); await expect(page.getByRole('button', { name: '发送', exact: true })).toBeEnabled();
  287 |     await page.getByRole('button', { name: '发送', exact: true }).click();
  288 |     await expect(page.getByTestId('story-reader')).toContainText('第2幕'); await ready(page);
  289 |     const committed = await stored(page); expect(committed.state.revision).toBe(2); expect(committed.state.journal).toHaveLength(2);
  290 |     expect(committed.draft.userInput).toBe('');
  291 |     expect(server.calls.map((call) => call.stage)).toEqual([...completedCalls, 'story', 'variables', 'world']);
  292 |   });
  293 | }
  294 | 
  295 | test('单行状态跟随三个实际请求，展开收起不重发且自动结算后等待行动', async ({ page }) => {
  296 |   await prepare(page); const server = await mock(page);
  297 |   let held = gate(); server.plan.hold = 'story'; server.plan.gate = held.pending;
  298 |   await creation(page); await confirm(page);
  299 |   const details = page.locator('.workflow-disclosure'), summary = workflowSummary(page);
  300 |   for (const [index, stage] of (['story', 'variables', 'world'] as const).entries()) {
  301 |     await expect(summary).toContainText(`${{ story: '正文', variables: '变量', world: '动态世界' }[stage]}生成中 · ${index + 1}/3`);
  302 |     await expect.poll(() => server.calls.map(call => call.stage)).toEqual(['story', 'variables', 'world'].slice(0, index + 1));
  303 |     await expect(details).not.toHaveAttribute('open');
  304 |     await expect(workflow(page).getByRole('button', { name: '取消自动执行' })).toBeHidden();
  305 |     const before = await stored(page);
  306 |     await workflowTrigger(page).focus(); await page.keyboard.press('Enter');
  307 |     await expect(workflow(page).getByRole('button', { name: '取消自动执行' })).toBeEnabled();
  308 |     await openBoundInput(page);
  309 |     await expect(page.locator('.bound-input .prose')).toBeVisible();
  310 |     await workflowTrigger(page).click();
  311 |     expect(server.calls.map(call => call.stage)).toEqual(['story', 'variables', 'world'].slice(0, index + 1));
  312 |     expect(await stored(page)).toEqual(before);
  313 |     const release = held.release;
  314 |     held = gate(); server.plan.hold = (['variables', 'world'] as const)[index]; server.plan.gate = held.pending;
  315 |     release();
  316 |   }
  317 |   await ready(page); await expect(details).not.toHaveAttribute('open');
  318 |   const complete = await stored(page);
  319 |   expect(complete.state.revision).toBe(1); expect(complete.state.journal).toHaveLength(1);
  320 |   expect(complete.draft.userInput).toBe(''); expect(server.calls).toHaveLength(3);
  321 |   await openWorkflow(page); await expect(page.locator('.workflow-stages > li')).toHaveCount(3);
  322 |   for (const stage of await page.locator('.workflow-stages > li').all()) await expect(stage).toContainText('已结算');
  323 |   await workflowTrigger(page).click(); await page.reload(); await ready(page);
  324 |   await expect(details).not.toHaveAttribute('open'); expect(await stored(page)).toEqual(complete); expect(server.calls).toHaveLength(3);
  325 | });
  326 | 
  327 | test('最新阶段失败覆盖旧变量错误，状态栏准确指出World失败', async ({ page }) => {
  328 |   await prepare(page); const server = await mock(page); server.plan.failure = 'variables';
  329 |   await creation(page); await confirm(page); await openWorkflow(page);
  330 |   await expect(workflow(page).getByRole('status')).toHaveText('三阶段 · 变量生成失败 · 查看详情');
  331 |   await expect(page.getByRole('button', { name: '重新 Roll', exact: true })).toHaveCount(0);
  332 |   server.plan.failure = 'world'; server.plan.status = undefined;
  333 |   await page.getByRole('button', { name: '继续未完成阶段', exact: true }).click();
  334 |   await expect(workflow(page).getByRole('status')).toHaveText('三阶段 · 动态世界生成失败 · 查看详情');
  335 |   const result = await stored(page); expect(result.state.revision).toBe(0);
  336 |   expect(result.draft.story).toBeTruthy(); expect(result.draft.variables?.validation).toBe('validated');
  337 |   expect(server.calls.slice(-2).map(call => call.stage)).toEqual(['variables', 'world']);
  338 | });
  339 | 
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: continuous-turns.spec.ts >> 下一轮生成失败不回滚上轮结算；刷新后只恢复尚未完成的新回合
- Location: e2e/continuous-turns.spec.ts:243:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('region', { name: '三阶段工作流' }).getByRole('alert')
Expected substring: "正文生成"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" getByRole('region', { name: '三阶段工作流' }).getByRole('alert') with timeout 5000ms
  - waiting for getByRole('region', { name: '三阶段工作流' }).getByRole('alert')

```

```yaml
- banner:
  - button "打开游戏菜单": ☰
- main:
  - button "此时此地与主角状态":
    - text: 重庆 重庆
    - time: 14:01
    - text: —
  - text: 重庆，2015/7/8 星期三 14:01，天气：天气待确认
  - region "剧情与行动":
    - text: THE STORY 已结算历史
    - article:
      - heading "第 1 回合" [level=2]
      - text: 2015/7/8 · 星期三 · 14:00 重庆
      - paragraph: 2015年7月8日14:00，重庆街头。第1幕。主角收到了公司寄出的解雇通知。经过一分钟，主角在街边休息。主角心情趋于平静。
    - paragraph: 行动建议将在正文生成后显示。
    - region "三阶段工作流":
      - button "三阶段工作流详情" [expanded]:
        - status: 三阶段 · 正文生成失败 · 查看详情
        - text: 详情 ›
    - button "回合操作": ⋯
    - text: 你的行动
    - textbox "你的行动":
      - /placeholder: 填写你的行动
    - button "发送" [disabled]
  - navigation "底部导航":
    - button "故事"
    - button "人物"
    - button "世界资料"
    - button "设置"
  - dialog "重试与变更详情":
    - heading "重试与变更详情" [level=2]
    - button "关闭资料界面": 关闭
    - tablist "诊断分类":
      - tab "概要"
      - tab "运行日志 1" [selected]
      - tab "请求用量 4"
      - tab "模型原文"
    - tabpanel "运行日志 1":
      - group:
        - text: 运行日志 · 错误 1 条
        - strong: 最近错误 · invalid_output
        - paragraph: 仅显示本次页面会话的错误；每条可单独复制安全诊断，不含原始模型响应、请求正文或密钥。刷新即清空。
        - button "清空日志"
        - list "错误日志条目":
          - listitem:
            - time: 16:25:21
            - strong: 正文生成
            - text: 错误
            - button "复制此条"
            - paragraph: 正文生成失败：缺少必需的结构标签。 标签：<正文>。 本次正文未保存。
            - text: 错误码：invalid_output 正文失败类型：tag_missing · 缺少必需的结构标签
    - paragraph: 仅本页临时保存 · 刷新即清空
- button "收起工作流暗区"
- dialog "三阶段工作流":
  - button "收起三阶段工作流"
  - button "行动输入"
  - region "三阶段详情":
    - text: THREE STAGES · 三阶段
    - heading "正文生成失败 · 查看详情" [level=3]
    - button "收起三阶段详情": ×
    - alert:
      - paragraph: 正文生成：正文生成失败：缺少必需的结构标签。 标签：<正文>。 本次正文未保存。
      - text: 正文 · 安全失败码：invalid_output · 1 次尝试
      - button "打开 AI 设置"
      - button "关闭错误提示": ×
    - navigation "三阶段导航":
      - paragraph: STAGES
      - list:
        - listitem:
          - button "01正文生成 失败 · 可重试":
            - strong: 01正文生成
            - text: 失败 · 可重试
        - listitem:
          - button "02变量管理 待生成":
            - strong: 02变量管理
            - text: 待生成
          - checkbox "变量管理" [checked]
        - listitem:
          - button "03动态世界 待生成":
            - strong: 03动态世界
            - text: 待生成
          - checkbox "动态世界" [checked]
      - paragraph: 本回合
      - list:
        - listitem:
          - button "运行诊断 错误与用量 错误 1 条":
            - strong: 运行诊断
            - text: 错误与用量 1
        - listitem:
          - button "已绑定输入 只读":
            - strong: 已绑定输入
            - text: 只读
    - button "继续未完成阶段"
    - text: 生成可能产生费用。
```

# Test source

```ts
  151 |       })
  152 |       .catch(() => undefined);
  153 |   });
  154 |   return { plan, stories, calls };
  155 | }
  156 | async function stored(page: Page) {
  157 |   const saved = await page.evaluate(async () => {
  158 |     const path = '/src/services/storage/saveRepository.ts',
  159 |       { SaveRepository } = await import(path),
  160 |       repo = await SaveRepository.open();
  161 |     try {
  162 |       const [save] = await repo.list();
  163 |       return await repo.loadGame(save.saveId);
  164 |     } finally {
  165 |       repo.close();
  166 |     }
  167 |   });
  168 |   return { state: GameStateSchema.parse(saved.state), draft: TurnDraftSchema.parse(saved.draft) };
  169 | }
  170 | const workflow = (page: Page) => page.getByRole('region', { name: '三阶段工作流' });
  171 | async function ready(page: Page, number = 1) {
  172 |   await expect(page.getByTestId('story-reader').locator('article').last()).toContainText(
  173 |     `第${number}幕`,
  174 |   );
  175 |   await expect(workflow(page)).toContainText('本回合已结算');
  176 | }
  177 | async function opening(page: Page) {
  178 |   await workflow(page).getByRole('button', { name: '自动生成开局', exact: true }).click();
  179 |   await ready(page);
  180 | }
  181 | 
  182 | test('真实创角后连续正式游玩十回合；输入、资料、正文历史与刷新一致', async ({ page }, info) => {
  183 |   test.setTimeout(120000);
  184 |   await configure(page);
  185 |   const server = await mock(page);
  186 |   await createCharacter(page);
  187 |   await ready(page);
  188 |   const initial = await stored(page),
  189 |     start = Date.parse('2015-07-08T14:00:00+08:00');
  190 |   expect(initial.state.openingTimePending).toBeUndefined(); // 开局自动正式结算，待下一条行动。
  191 |   expect(initial.state.turnNumber).toBe(1);
  192 |   expect(initial.state.economy.cash).toBeNull();
  193 |   await expect(page.getByRole('complementary', { name: '主角信息' })).toContainText('未确认');
  194 |   for (let index = 1; index <= 9; index++) {
  195 |     const action = `行动${index}：在街边等待一分钟`;
  196 |     await page.getByLabel('你的行动', { exact: true }).fill(action);
  197 |     await page.getByRole('button', { name: '发送', exact: true }).click();
  198 |     await ready(page, index + 1);
  199 |     const result = await stored(page);
  200 |     expect(result.state.turnNumber).toBe(index + 1);
  201 |     expect(result.state.revision).toBe(index + 1);
  202 |     expect(result.state.journal).toHaveLength(index + 1);
  203 |     expect(result.state.memories.short).toHaveLength(index + 1);
  204 |     expect(result.state.memories.short.at(-1)).toMatchObject({
  205 |       text: `第${index + 1}幕的街边休息`,
  206 |       sourceTurnIds: [result.state.journal[index].turnId],
  207 |       createdAtGameTime: result.state.worldClock,
  208 |       visibility: 'player_known',
  209 |       affectedEntityRefs: [],
  210 |     });
  211 |     expect(result.draft.userInput).toBe('');
  212 |     expect(result.draft.turnKind).toBe('regular');
  213 |     expect(Date.parse(result.state.worldClock)).toBe(start + (index + 1) * 60000);
  214 |     expect(result.state.items.notice.ownerRef?.id).toBe(result.state.protagonist.id);
  215 |     expect(result.state.initialCompanionId).toBe(initial.state.initialCompanionId);
  216 |     expect(result.state.npc.companion).toEqual(initial.state.npc.companion);
  217 |     await expect(page.getByTestId('story-reader').locator('.chapter-heading').last()).toHaveText(
  218 |       `第 ${index + 1} 回合`,
  219 |     );
  220 |     expect(server.stories.find((s) => s.number === index + 1)?.action).toBe(action);
  221 |     expect(server.stories.find((s) => s.number === index + 1)?.context).toContain(
  222 |       `第${index}幕的街边休息`,
  223 |     );
  224 |     if (index === 5) {
  225 |       await page.reload(); await openGameTools(page);
  226 |       await ready(page, 6);
  227 |     }
  228 |   }
  229 |   const final = await stored(page);
  230 |   expect(server.calls).toHaveLength(30);
  231 |   expect(final.state.journal[0].story.turnKind).toBe('opening');
  232 |   expect(final.state.journal.slice(1).every((j) => j.story.turnKind === 'regular')).toBe(true);
  233 |   expect(JSON.stringify(final.state)).not.toContain('绝不自动发布的后台线索');
  234 |   expect(JSON.stringify(final.state.journal)).not.toContain('内部未解决事项');
  235 |   await expect(page.locator('main')).not.toContainText('绝不自动发布的后台线索');
  236 |   await page.reload(); await openGameTools(page);
  237 |   expect(await stored(page)).toEqual(final);
  238 |   await ready(page, 10);
  239 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  240 |   await page.screenshot({ path: info.outputPath('ten-committed-turns.png'), fullPage: true });
  241 | });
  242 | 
  243 | test('下一轮生成失败不回滚上轮结算；刷新后只恢复尚未完成的新回合', async ({ page }) => {
  244 |   await configure(page);
  245 |   const server = await mock(page);
  246 |   await createCharacter(page);
  247 |   await ready(page);
  248 |   server.plan.badStoryNumber = 2;
  249 |   await page.getByLabel('你的行动', { exact: true }).fill('去街边等待');
  250 |   await page.getByRole('button', { name: '发送', exact: true }).click();
> 251 |   await expect(workflow(page).getByRole('alert')).toContainText('正文生成');
      |                                                   ^ Error: expect(locator).toContainText(expected) failed
  252 |   const failed = await stored(page);
  253 |   expect(failed.state.turnNumber).toBe(1);
  254 |   expect(failed.draft.userInput).toBe('去街边等待');
  255 |   expect(failed.draft.stageStatus.story).toBe('failed');
  256 |   await page.reload(); await openGameTools(page);
  257 |   server.plan.badStoryNumber = 0;
  258 |   await workflow(page).getByRole('button', { name: '继续未完成阶段', exact: true }).click();
  259 |   await ready(page, 2);
  260 |   expect((await stored(page)).state.turnNumber).toBe(2);
  261 |   expect((await stored(page)).state.journal[0]).toEqual(failed.state.journal[0]);
  262 |   expect(server.calls).toEqual([
  263 |     'story',
  264 |     'variables',
  265 |     'world',
  266 |     'story',
  267 |     'story',
  268 |     'variables',
  269 |     'world',
  270 |   ]);
  271 | });
  272 | 
  273 | test('提交事务中途失败 UI 不虚报成功；重试后只结算一次', async ({ page }) => {
  274 |   await configure(page);
  275 |   await mock(page);
  276 |   await createCharacter(page);
  277 |   await ready(page);
  278 |   const before = await stored(page);
  279 |   await page.evaluate(() => {
  280 |     const original = IDBObjectStore.prototype.put;
  281 |     Object.defineProperty(window, '__restoreTurnPut', {
  282 |       value: () => {
  283 |         IDBObjectStore.prototype.put = original;
  284 |       },
  285 |       configurable: true,
  286 |     });
  287 |     IDBObjectStore.prototype.put = function (value, key) {
  288 |       if (this.name === 'drafts') throw new DOMException('isolated test', 'QuotaExceededError');
  289 |       return original.call(this, value, key);
  290 |     };
  291 |   });
  292 |   await page.getByLabel('你的行动', { exact: true }).fill('等待下一轮');
  293 |   await page.getByRole('button', { name: '发送', exact: true }).click();
  294 |   await expect(page.getByRole('alert')).toBeVisible();
  295 |   expect(await stored(page)).toEqual(before);
  296 |   await page.evaluate(() => {
  297 |     const restore = Reflect.get(window, '__restoreTurnPut');
  298 |     if (typeof restore === 'function') restore();
  299 |   });
  300 |   await page.getByRole('button', { name: '发送', exact: true }).click();
  301 |   await ready(page, 2);
  302 |   expect((await stored(page)).state.turnNumber).toBe(2);
  303 | });
  304 | 
  305 | test('快速双击与另一标签发送最多结算一次；成功后数据库保留唯一下一草稿', async ({
  306 |   page,
  307 |   context,
  308 | }) => {
  309 |   await configure(page);
  310 |   await mock(page);
  311 |   await createCharacter(page);
  312 |   await ready(page);
  313 |   const other = await context.newPage();
  314 |   await other.goto(page.url());
  315 |   // A new Playwright tab has independent sessionStorage. Both competing clients
  316 |   // need the same test-only credentials and the context-wide Mock above.
  317 |   await other.evaluate(async () => {
  318 |     const configPath = '/src/services/ai/configuration.ts', vaultPath = '/src/services/ai/credentials.ts';
  319 |     const { readAiConfig } = await import(configPath), { CredentialVault } = await import(vaultPath);
  320 |     const vault = new CredentialVault(sessionStorage, localStorage);
  321 |     for (const channel of readAiConfig(localStorage).channels) vault.set(channel.id, 'mock-loop-secret');
  322 |   });
  323 |   await other.reload();
  324 |   await page.getByLabel('你的行动', { exact: true }).fill('在街边等待');
  325 |   await other.getByLabel('你的行动', { exact: true }).fill('在街边等待');
  326 |   await Promise.all(
  327 |     [page, other].map((p) =>
  328 |       p.getByRole('button', { name: '发送', exact: true }).evaluate((button: HTMLButtonElement) => {
  329 |         button.click();
  330 |         button.click();
  331 |       }),
  332 |     ),
  333 |   );
  334 |   await expect.poll(async () => (await stored(page)).state.turnNumber).toBe(2);
  335 |   const result = await stored(page);
  336 |   expect(result.state.journal).toHaveLength(2);
  337 |   expect(result.draft.baseSaveRevision).toBe(2);
  338 |   expect(result.draft.userInput).toBe('');
  339 |   await other.close();
  340 | });
  341 | 
  342 | test('阶段未完成或主动关闭时，即使填写行动也不能部分结算', async ({ page }) => {
  343 |   await configure(page, false);
  344 |   const server = await mock(page);
  345 |   await createCharacter(page);
  346 |   await expect(page.getByLabel('动态世界', { exact: true })).not.toBeChecked();
  347 |   await expect(workflow(page).getByRole('status')).toContainText('阶段已关闭');
  348 |   await page.getByLabel('你的行动', { exact: true }).fill('等待');
  349 |   await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  350 |   expect((await stored(page)).state.turnNumber).toBe(0);
  351 |   await page.getByLabel('动态世界', { exact: true }).check();
```
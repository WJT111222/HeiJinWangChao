# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: prompt-inspector.spec.ts >> 1000 NPC 真实快照按需 Worker 分析、动画帧继续、结果与原算法一致且复用缓存
- Location: e2e/prompt-inspector.spec.ts:380:34

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 1
Received:   1
```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - main [ref=f1e4]:
    - region "游戏首页" [ref=f1e5]:
      - generic [ref=f1e7]:
        - text: HARBIN · 45°45′N
        - generic [ref=f1e8]: 冰雪 · 圆顶 · 长街
      - generic [aria-hidden] [ref=f1e9]: 哈尔滨
      - generic [ref=f1e10]:
        - generic [ref=f1e11]:
          - generic [aria-hidden] [ref=f1e12]: 黑
          - generic [ref=f1e13]:
            - text: 黑金王朝
            - generic [ref=f1e14]: HEIJINWANGCHAO
        - button "存档馆" [ref=f1e15] [cursor=pointer]
        - button "设置" [ref=f1e16] [cursor=pointer]
        - generic [ref=f1e17]: V1.0 Beta
      - generic [ref=f1e18]:
        - paragraph [ref=f1e19]: MODERN CITY / OPEN WORLD
        - heading "黑金王朝" [level=1] [ref=f1e20]
        - paragraph [ref=f1e21]: 起点有冲突，人生不预设结局。
        - paragraph [ref=f1e22]: 一款 AI 驱动的现代都市开放世界文字角色扮演游戏。在熟悉的城市里，写下属于你的人生。
        - generic [ref=f1e23]:
          - button "开始新游戏" [ref=f1e24] [cursor=pointer]:
            - text: 开始新游戏
            - generic [aria-hidden] [ref=f1e25]: ↗
          - button "继续游戏 界面测试存档（隔离） · 保存于 2026/11/15 00:21" [ref=f1e26] [cursor=pointer]:
            - generic [ref=f1e27]: 继续游戏
            - generic [ref=f1e28]: 界面测试存档（隔离） · 保存于 2026/11/15 00:21
            - generic [aria-hidden] [ref=f1e29]: →
          - button "存档馆01" [ref=f1e30] [cursor=pointer]
        - group "游玩信息" [ref=f1e31]:
          - button "游玩须知与免责声明" [ref=f1e32] [cursor=pointer]
          - button "王朝公告" [ref=f1e33] [cursor=pointer]
      - generic [ref=f1e34]:
        - generic [ref=f1e35]:
          - generic [ref=f1e36]: 四座城市 · 自由职业 · 开放人生
          - generic [ref=f1e37]: 三阶段生成 · 原子结算 · 连续回合
        - navigation "封面城市" [ref=f1e38]:
          - button "重庆" [ref=f1e39] [cursor=pointer]
          - button "上海" [ref=f1e40] [cursor=pointer]
          - button "哈尔滨" [pressed] [ref=f1e41] [cursor=pointer]
          - button "广州" [ref=f1e42] [cursor=pointer]
  - dialog [ref=f1e43]:
    - banner [ref=f1e44]:
      - generic [aria-hidden] [ref=f1e45]: 设
      - generic [ref=f1e46]:
        - generic [aria-hidden] [ref=f1e47]: SYSTEM · 系统
        - heading "设置" [level=2] [ref=f1e48]
        - text: 本地偏好与 AI 渠道
      - generic [aria-hidden] [ref=f1e49]: ESC
      - button "关闭资料界面" [ref=f1e50] [cursor=pointer]: 关闭 ×
    - generic [ref=f1e52]:
      - navigation "设置分类" [ref=f1e53]:
        - button "AI 连接" [ref=f1e54] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e55]: 连
        - button "提示词" [ref=f1e57] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e58]: 词
        - button "记忆" [ref=f1e60] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e61]: 忆
        - button "运行" [ref=f1e63] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e64]: 运
        - button "提示词管理" [pressed] [ref=f1e66] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e67]: 管
        - group "游玩信息" [ref=f1e69]:
          - button "游玩须知与免责声明" [ref=f1e70] [cursor=pointer]
          - button "王朝公告" [ref=f1e71] [cursor=pointer]
      - generic [ref=f1e72]:
        - heading "提示词管理" [level=3] [ref=f1e73]
        - region "高级" [ref=f1e75]:
          - generic [ref=f1e76]:
            - button "‹ 返回列表" [ref=f1e77] [cursor=pointer]
            - heading "高级" [level=4] [ref=f1e78]
          - paragraph [ref=f1e79]: 真实注册资源 · 只读原文 · 无网络组装预览 · 仅内存请求记录。当前使用本窗口编辑的七项写作偏好；排序独立保存。
          - generic [ref=f1e80]:
            - generic [ref=f1e81]:
              - text: 检查阶段
              - combobox "检查阶段" [ref=f1e82]:
                - option "正文生成" [selected]
                - option "变量管理"
                - option "动态世界"
            - generic [ref=f1e83]:
              - text: 回合模式
              - combobox "回合模式" [ref=f1e84]:
                - option "开局回合"
                - option "普通回合" [selected]
            - generic [ref=f1e85]:
              - text: 预览存档
              - combobox "预览存档" [ref=f1e86]:
                - option "请选择真实存档"
                - option "界面测试存档（隔离）" [selected]
            - button "生成三阶段组装预览（不联网）" [ref=f1e87] [cursor=pointer]
          - status
          - generic [ref=f1e88]:
            - generic [ref=f1e89]:
              - strong [ref=f1e90]: 正文生成
              - paragraph [ref=f1e91]: 尚未组装；统计未知
            - generic [ref=f1e92]:
              - strong [ref=f1e93]: 变量管理
              - paragraph [ref=f1e94]: 尚未组装；统计未知
            - generic [ref=f1e95]:
              - strong [ref=f1e96]: 动态世界
              - paragraph [ref=f1e97]: 尚未组装；统计未知
          - group [ref=f1e98]:
            - generic "开局与普通回合的模块差异" [ref=f1e99] [cursor=pointer]
          - group [ref=f1e100]:
            - generic "本次预览的相关变量域（不新增写作设置）" [ref=f1e101] [cursor=pointer]
          - generic [ref=f1e102]:
            - region "发送顺序" [ref=f1e103]:
              - heading "发送顺序" [level=5] [ref=f1e104]
              - paragraph [ref=f1e105]: 以下为真实选择器的模块顺序；游戏资料尚未成功组装。
              - list [ref=f1e106]:
                - listitem [ref=f1e107]:
                  - generic [ref=f1e108]:
                    - generic [ref=f1e109]: 0 · 万界叙事官·浮生
                    - generic [ref=f1e110]: identity.fusheng · system · identity · 880 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e111]: 固定
                - listitem [ref=f1e112]:
                  - generic [ref=f1e113]:
                    - generic [ref=f1e114]: 10 · 黑金王朝·世界观 V2.0
                    - generic [ref=f1e115]: worldbooks.heijin.worldview · system · worldbooks · 2685 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e116]: 固定
                - listitem [ref=f1e117]:
                  - generic [ref=f1e118]:
                    - generic [ref=f1e119]: 20 · 现代现实基本逻辑与地下社会生态 V2.0
                    - generic [ref=f1e120]: worldbooks.heijin.modern_underworld · system · worldbooks · 4376 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e121]: 固定
                - listitem [ref=f1e122]:
                  - generic [ref=f1e123]:
                    - generic [ref=f1e124]: 30 · 玩家自主权与因果
                    - generic [ref=f1e125]: shared.01_agency · system · shared · 447 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e126]: 固定
                - listitem [ref=f1e127]:
                  - generic [ref=f1e128]:
                    - generic [ref=f1e129]: 40 · 信息域和保密分层
                    - generic [ref=f1e130]: shared.02_knowledge · system · shared · 900 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e131]: 固定
                - listitem [ref=f1e132]:
                  - generic [ref=f1e133]:
                    - generic [ref=f1e134]: 50 · 统一时间与事件预检
                    - generic [ref=f1e135]: shared.03_time_events · system · shared · 4042 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e136]: 固定
                - listitem [ref=f1e137]:
                  - generic [ref=f1e138]:
                    - generic [ref=f1e139]: 60 · 状态真值与执行边界
                    - generic [ref=f1e140]: shared.04_state_authority · system · shared · 495 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e141]: 固定
                - listitem [ref=f1e142]:
                  - generic [ref=f1e143]:
                    - generic [ref=f1e144]: 70 · 上下文容器与可信度
                    - generic [ref=f1e145]: shared.05_context_protocol · system · shared · 1139 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e146]: 固定
                - listitem [ref=f1e147]:
                  - generic [ref=f1e148]:
                    - generic [ref=f1e149]: 80 · 现代现实冲突节奏
                    - generic [ref=f1e150]: writing.conflict_pacing · system · narrative_core · 595 字符 · 估算 Token 待组装
                  - generic [ref=f1e151]:
                    - button "上移 writing.conflict_pacing" [disabled] [ref=f1e152] [cursor=pointer]: ↑
                    - button "下移 writing.conflict_pacing" [ref=f1e153] [cursor=pointer]: ↓
                - listitem [ref=f1e154]:
                  - generic [ref=f1e155]:
                    - generic [ref=f1e156]: 81 · 人物情绪真实性
                    - generic [ref=f1e157]: writing.emotion_guard · system · narrative_core · 505 字符 · 估算 Token 待组装
                  - generic [ref=f1e158]:
                    - button "上移 writing.emotion_guard" [ref=f1e159] [cursor=pointer]: ↑
                    - button "下移 writing.emotion_guard" [ref=f1e160] [cursor=pointer]: ↓
                - listitem [ref=f1e161]:
                  - generic [ref=f1e162]:
                    - generic [ref=f1e163]: 82 · 现实行动可行性
                    - generic [ref=f1e164]: writing.action_feasibility · system · narrative_core · 516 字符 · 估算 Token 待组装
                  - generic [ref=f1e165]:
                    - button "上移 writing.action_feasibility" [ref=f1e166] [cursor=pointer]: ↑
                    - button "下移 writing.action_feasibility" [disabled] [ref=f1e167] [cursor=pointer]: ↓
                - listitem [ref=f1e168]:
                  - generic [ref=f1e169]:
                    - generic [ref=f1e170]: 210 · 硬性最低正文字数
                    - generic [ref=f1e171]: writing.min_length · system · writing · 180 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e172]: 固定
                - listitem [ref=f1e173]:
                  - generic [ref=f1e174]:
                    - generic [ref=f1e175]: 222 · 人称：第三人称
                    - generic [ref=f1e176]: writing.perspective_third · system · writing · 128 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e177]: 固定
                - listitem [ref=f1e178]:
                  - generic [ref=f1e179]:
                    - generic [ref=f1e180]: 223 · 剧情风格：一般
                    - generic [ref=f1e181]: writing.style_general · system · writing · 139 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e182]: 固定
                - listitem [ref=f1e183]:
                  - generic [ref=f1e184]:
                    - generic [ref=f1e185]: 224 · 防抢话 NoControl（可开关增强版）
                    - generic [ref=f1e186]: writing.no_control · system · writing · 215 字符 · 估算 Token 待组装
                  - generic [ref=f1e187]:
                    - button "上移 writing.no_control" [disabled] [ref=f1e188] [cursor=pointer]: ↑
                    - button "下移 writing.no_control" [ref=f1e189] [cursor=pointer]: ↓
                - listitem [ref=f1e190]:
                  - generic [ref=f1e191]:
                    - generic [ref=f1e192]: 225 · 自然文风修复（黑金王朝适配稿）
                    - generic [ref=f1e193]: writing.natural_prose · system · writing · 877 字符 · 估算 Token 待组装
                  - generic [ref=f1e194]:
                    - button "上移 writing.natural_prose" [ref=f1e195] [cursor=pointer]: ↑
                    - button "下移 writing.natural_prose" [ref=f1e196] [cursor=pointer]: ↓
                - listitem [ref=f1e197]:
                  - generic [ref=f1e198]:
                    - generic [ref=f1e199]: 226 · 行动选项（开启时3～5条）
                    - generic [ref=f1e200]: writing.action_options · system · writing · 513 字符 · 估算 Token 待组装
                  - generic [ref=f1e201]:
                    - button "上移 writing.action_options" [ref=f1e202] [cursor=pointer]: ↑
                    - button "下移 writing.action_options" [ref=f1e203] [cursor=pointer]: ↓
                - listitem [ref=f1e204]:
                  - generic [ref=f1e205]:
                    - generic [ref=f1e206]: 227 · 真实世界模式协议（开启时）
                    - generic [ref=f1e207]: writing.real_world · system · writing · 257 字符 · 估算 Token 待组装
                  - generic [ref=f1e208]:
                    - button "上移 writing.real_world" [ref=f1e209] [cursor=pointer]: ↑
                    - button "下移 writing.real_world" [disabled] [ref=f1e210] [cursor=pointer]: ↓
                - listitem [ref=f1e211]:
                  - generic [ref=f1e212]:
                    - generic [ref=f1e213]: 250 · 成人题材常驻规则（用户手动适配版，非原版逐字移植）
                    - generic [ref=f1e214]: writing.nsfw · system · writing · 3199 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e215]: 固定
                - listitem [ref=f1e216]:
                  - generic [ref=f1e217]:
                    - generic [ref=f1e218]: 251 · 人物亲密与自愿边界（关系发展审阅版）
                    - generic [ref=f1e219]: writing.intimacy_boundaries · system · writing · 672 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e220]: 固定
                - listitem [ref=f1e221]:
                  - generic [ref=f1e222]:
                    - generic [ref=f1e223]: 300 · 普通回合正文主提示词
                    - generic [ref=f1e224]: stages.regular.story · system · stage · 895 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e225]: 固定
                - listitem [ref=f1e226]:
                  - generic [ref=f1e227]:
                    - generic [ref=f1e228]: 350 · 普通回合原创叙事规划（Step 0–14）
                    - generic [ref=f1e229]: planning.regular · system · planning · 5710 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e230]: 固定
                - listitem [ref=f1e231]:
                  - generic [ref=f1e232]:
                    - generic [ref=f1e233]: 406 · 正文输出协议（标签与JSON规划）
                    - generic [ref=f1e234]: shared.06_story_output · system · output · 2838 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e235]: 固定
                - listitem [ref=f1e236]:
                  - generic [ref=f1e237]:
                    - generic [ref=f1e238]: 409 · 正文旁白／人物对白标记协议
                    - generic [ref=f1e239]: shared.09_dialogue_labels · system · output · 365 字符 · 估算 Token 待组装
                  - emphasis [ref=f1e240]: 固定
              - generic [ref=f1e241]:
                - button "恢复默认顺序" [ref=f1e242] [cursor=pointer]
                - button "保存提示词排序" [disabled] [ref=f1e243] [cursor=pointer]
            - region "上下文与统计" [ref=f1e244]:
              - heading "上下文与统计" [level=5] [ref=f1e245]
              - generic [ref=f1e246]:
                - text: 数据来源
                - combobox "数据来源" [ref=f1e247]:
                  - option "组装预览（未发送）"
                  - option "实际请求快照" [selected]
              - paragraph [ref=f1e248]: 只记录客户端真实发送尝试的脱敏副本，不代表服务已收到或游戏已结算。最多保留本会话内存中的 12 条，刷新即清空。
              - paragraph [ref=f1e249]: 记忆维护快照在选择请求中独立标识，不属于三阶段或开局/普通回合预览。
              - generic [ref=f1e250]:
                - text: 选择请求
                - combobox "选择请求" [ref=f1e251]:
                  - option "选择真实请求"
                  - option "regular 正文生成 · 2026-11-14T16:21:32.334Z · received" [selected]
              - button "清空内存请求记录" [ref=f1e252] [cursor=pointer]
              - generic [ref=f1e253]:
                - term [ref=f1e254]: 上下文字符数
                - definition [ref=f1e255]: "3533233"
                - term [ref=f1e256]: 内容 UTF-8 字节 / 消息数
                - definition [ref=f1e257]: 5784097 / 25
                - term [ref=f1e258]: JSON 消息数组 UTF-8 字节（非完整 HTTP 请求体）
                - definition [ref=f1e259]: "6148164"
                - term [ref=f1e260]: 估算输入 Token
                - definition [ref=f1e261]: ≈ 2290106
                - term [ref=f1e262]: 供应商输入 Token
                - definition [ref=f1e263]: "42"
                - term [ref=f1e264]: 供应商输出 Token
                - definition [ref=f1e265]: "2"
                - term [ref=f1e266]: 供应商总 Token
                - definition [ref=f1e267]: 未提供
                - term [ref=f1e268]: 供应商原生思考 Token
                - definition [ref=f1e269]: 未提供
                - term [ref=f1e270]: 估算方法
                - definition [ref=f1e271]: Unicode 启发式；ASCII 约 4 字符/Token，其他字符约 1.5 Token/字符。不含协议开销，不是精确 tokenizer 或真实消耗。估算保留消息间人工换行 24 字符；字符与字节总量不含这些换行。
              - generic [ref=f1e272]:
                - paragraph [ref=f1e273]: 路由：新渠道 / worker-scale-mock / openai
                - paragraph [ref=f1e274]: regular / 正文生成 / 存档版本 1000
                - paragraph [ref=f1e275]: 状态：收到完整文本响应（不代表候选校验或正式提交）
                - list [ref=f1e276]:
                  - listitem [ref=f1e277]: 0 · identity.fusheng · system · 868 字符 · 估算 ≈ 1156 Token
                  - listitem [ref=f1e278]: 10 · worldbooks.heijin.worldview · system · 2685 字符 · 估算 ≈ 3840 Token
                  - listitem [ref=f1e279]: 20 · worldbooks.heijin.modern_underworld · system · 4376 字符 · 估算 ≈ 6202 Token
                  - listitem [ref=f1e280]: 30 · shared.01_agency · system · 447 字符 · 估算 ≈ 651 Token
                  - listitem [ref=f1e281]: 40 · shared.02_knowledge · system · 900 字符 · 估算 ≈ 1273 Token
                  - listitem [ref=f1e282]: 50 · shared.03_time_events · system · 4051 字符 · 估算 ≈ 4506 Token
                  - listitem [ref=f1e283]: 60 · shared.04_state_authority · system · 495 字符 · 估算 ≈ 703 Token
                  - listitem [ref=f1e284]: 70 · shared.05_context_protocol · system · 1139 字符 · 估算 ≈ 986 Token
                  - listitem [ref=f1e285]: 80 · writing.conflict_pacing · system · 595 字符 · 估算 ≈ 872 Token
                  - listitem [ref=f1e286]: 81 · writing.emotion_guard · system · 505 字符 · 估算 ≈ 727 Token
                  - listitem [ref=f1e287]: 82 · writing.action_feasibility · system · 516 字符 · 估算 ≈ 743 Token
                  - listitem [ref=f1e288]: 210 · writing.min_length · system · 163 字符 · 估算 ≈ 224 Token
                  - listitem [ref=f1e289]: 222 · writing.perspective_third · system · 116 字符 · 估算 ≈ 168 Token
                  - listitem [ref=f1e290]: 223 · writing.style_general · system · 139 字符 · 估算 ≈ 208 Token
                  - listitem [ref=f1e291]: 224 · writing.no_control · system · 215 字符 · 估算 ≈ 304 Token
                  - listitem [ref=f1e292]: 225 · writing.natural_prose · system · 877 字符 · 估算 ≈ 1282 Token
                  - listitem [ref=f1e293]: 226 · writing.action_options · system · 513 字符 · 估算 ≈ 712 Token
                  - listitem [ref=f1e294]: 227 · writing.real_world · system · 257 字符 · 估算 ≈ 383 Token
                  - listitem [ref=f1e295]: 250 · writing.nsfw · system · 3199 字符 · 估算 ≈ 851 Token
                  - listitem [ref=f1e296]: 251 · writing.intimacy_boundaries · system · 672 字符 · 估算 ≈ 968 Token
                  - listitem [ref=f1e297]: 300 · stages.regular.story · system · 855 字符 · 估算 ≈ 1152 Token
                  - listitem [ref=f1e298]: 350 · planning.regular · system · 5710 字符 · 估算 ≈ 7508 Token
                  - listitem [ref=f1e299]: 406 · shared.06_story_output · system · 2821 字符 · 估算 ≈ 3084 Token
                  - listitem [ref=f1e300]: 409 · shared.09_dialogue_labels · system · 365 字符 · 估算 ≈ 493 Token
                - paragraph [ref=f1e301]: 当前模型上下文窗口未知，无法确认请求是否超限。 此提醒不阻断游戏，不自动裁剪数据或切换模型。
                - group [ref=f1e302]:
                  - generic "展开数据分类、召回预算与重复诊断" [ref=f1e303] [cursor=pointer]
                  - status [ref=f1e304]: 分析完成（本会话内存缓存）。
                  - paragraph [ref=f1e305]: NPC 1000；正式 NPC 记忆 3113；近期完整 Story 3；旧史召回 0。零召回不表示零 NPC 记忆。
                  - list [ref=f1e306]:
                    - listitem [ref=f1e307]: 系统提示词（固定/世界书/阶段/领域）：32479 字符 / 81865 UTF-8 字节 / ≈ 38988 Token / 0.9%
                    - listitem [ref=f1e308]: 主角档案、装备与经济资产：578 字符 / 820 UTF-8 字节 / ≈ 296 Token / 0.0%
                    - listitem [ref=f1e309]: NPC分层档案：315719 字符 / 595045 UTF-8 字节 / ≈ 253509 Token / 8.9%
                    - listitem [ref=f1e310]: NPC原始、长期与个人总结记忆：739897 字符 / 1579607 UTF-8 字节 / ≈ 709793 Token / 20.9%
                    - listitem [ref=f1e311]: 世界组织、地点、任务、事件与时间线：824079 字符 / 1853253 UTF-8 字节 / ≈ 849254 Token / 23.3%
                    - listitem [ref=f1e312]: 短中长期分层记忆：27623 字符 / 76853 UTF-8 字节 / ≈ 37675 Token / 0.8%
                    - listitem [ref=f1e313]: 近期完整正文：1013 字符 / 2573 UTF-8 字节 / ≈ 1229 Token / 0.0%
                    - listitem [ref=f1e314]: 历史召回原文与元数据：281 字符 / 533 UTF-8 字节 / ≈ 228 Token / 0.0%
                    - listitem [ref=f1e315]: 当前输入与阶段候选：27 字符 / 77 UTF-8 字节 / ≈ 38 Token / 0.0%
                    - listitem [ref=f1e316]: 命令协议与目录：0 字符 / 0 UTF-8 字节 / ≈ 0 Token / 0.0%
                    - listitem [ref=f1e317]: 其他资料：111155 字符 / 113089 UTF-8 字节 / ≈ 28998 Token / 3.1%
                    - listitem [ref=f1e318]: JSON键名、标点、容器与空白：1480382 字符 / 1480382 UTF-8 字节 / ≈ 370096 Token / 41.9%
                  - paragraph [ref=f1e319]: 以上来自最终消息的序列化值；键名、标点、容器及空白单列。字符差额 0，字节差额 0；分组取整与消息间人工换行造成 Token 估算差额 -2。重复表示全部计入，供应商协议开销未知。
                  - paragraph [ref=f1e320]: 召回预算只影响旧journal原文，不影响完整正式世界状态。
                  - paragraph [ref=f1e321]: 强相关 0 / 辅助 0 / 截断记录 0；召回正文 0 Unicode 字符，元数据与摘要 0 序列化 Unicode 字符（实际消息范围减去 narrativeExcerpt 序列化值，仍含字段名与标点）。原始预算诊断的字符与截取范围按 UTF-16，见下方。
                  - generic "召回预算诊断" [ref=f1e322]: "{ \"algorithm\": \"shared-journal-v2\", \"stage\": \"story\", \"eligibleTurns\": 0, \"selectedTurns\": 0, \"cueCharacters\": [ 25, 0, 0, 0 ], \"queryTerms\": 16, \"usedQueryTerms\": 15, \"strongTurns\": 0, \"auxiliaryTurns\": 0, \"truncatedTurns\": 0, \"metadataSerializedCharacters\": 2, \"truncatedCueCharacters\": [ 0, 0, 0, 0 ], \"derivedCueCharacters\": 8000, \"omittedDerivedCueCharacters\": 204508, \"omittedQueryTerms\": 0, \"suppressedFrequentTerms\": 1, \"omittedTurns\": 0, \"serializedCharacters\": 2, \"narrativeCharacters\": 0, \"budget\": { \"serializedCharacters\": 24000, \"narrativeCharacters\": 16000, \"fullTurnCharacters\": 7000, \"auxiliaryCharacters\": 600, \"summaryCharacters\": 400, \"metadataReferences\": 8, \"maximumRecords\": 32, \"queryCharacters\": 12000, \"terms\": 96 } }"
                  - paragraph [ref=f1e323]: 可验证重复组 0；额外体量表示首处之后仍传输的整个表示，可能包含不同字段。嵌套诊断会重叠，不能相加当作可节省总量；不判断语义相似，不删除。
                  - paragraph [ref=f1e324]: 后续重复表示的消息范围并集：0 字符 / 0 UTF-8 字节。此并集排除嵌套双计，仍不是可删除或可节省体量。
                  - list
                - paragraph [ref=f1e325]: 消息角色：system → system → system → system → system → system → system → system → system → system → system → system → system → system → system → system → system → system → system → system → system → system → system → system → user
                - paragraph [ref=f1e326]: 模块 24 个；状态资料结构：主动查看后读取
                - paragraph [ref=f1e327]: 模块版本与字符来自组装器记录；实际供应商协议可能合并 system 消息，数据分类基于发送边界消息，不假设每个模块仍为独立消息。
                - paragraph [ref=f1e328]: 完整内部内容可能包含后台人物情报。查看不会改变主角认知、游戏存档或普通日志；不包含模型内部思维链。
                - button "主动查看完整内部上下文" [ref=f1e329] [cursor=pointer]
        - generic [ref=f1e330]:
          - status
          - button "保存本地设置" [ref=f1e331] [cursor=pointer]
```

# Test source

```ts
  339 |   await page.getByRole('combobox', { name: '检查阶段', exact: true }).selectOption('world');
  340 |   await page.getByRole('combobox', { name: '数据来源', exact: true }).selectOption('actual');
  341 |   const context = page.getByRole('region', { name: '上下文与统计' });
  342 |   await expect(context).toContainText('mock-before');
  343 |   await expect(context).not.toContainText('mock-after');
  344 |   await expect(context).toContainText('42');
  345 |   await expect(context).toContainText('49');
  346 |   await expect(context).not.toContainText('秘密计划不可见');
  347 |   await page.getByRole('button', { name: '主动查看完整内部上下文' }).click();
  348 |   await page.getByRole('combobox', { name: '内部内容视图', exact: true }).selectOption('body');
  349 |   await expect(page.getByLabel('完整内部上下文', { exact: true })).toContainText('秘密计划不可见');
  350 |   await expect(context).not.toContainText('e2e-inspection-key');
  351 |   await expect(context).not.toContainText('Authorization');
  352 |   expect(await readFormal(page)).toBe(before);
  353 |   const persisted = await page.evaluate(() => JSON.stringify(localStorage));
  354 |   expect(persisted).not.toContain('秘密计划不可见');
  355 |   expect(persisted).not.toContain('e2e-inspection-key');
  356 |   await page.reload();
  357 |   await inspector(page);
  358 |   await page.getByRole('combobox', { name: '数据来源', exact: true }).selectOption('actual');
  359 |   await expect(page.getByText(/此阶段\/模式没有实际请求快照/)).toBeVisible();
  360 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  361 | });
  362 | 
  363 | test('无正文草稿的阶段预览诚实失败，七项写作偏好不因管理中心改变', async ({ page }) => {
  364 |   await seed(page, false);
  365 |   await page.reload();
  366 |   await inspector(page);
  367 |   await page.getByRole('button', { name: '生成三阶段组装预览（不联网）' }).click();
  368 |   await expect(
  369 |     page.getByText('预览已组装；未发送 API 请求、未执行回合、未写入正式存档。'),
  370 |   ).toBeVisible();
  371 |   await page.getByRole('combobox', { name: '检查阶段', exact: true }).selectOption('variables');
  372 |   await expect(page.getByRole('region', { name: '上下文与统计' })).toContainText(
  373 |     '缺少已选定的正文草稿',
  374 |   );
  375 |   await page.getByRole('button', { name: '提示词', exact: true }).click();
  376 |   await expect(page.locator('.settings-fields > label')).toHaveCount(7);
  377 |   await expect(page.getByLabel('叙事人称')).toHaveValue('third');
  378 | });
  379 | 
  380 | for (const count of [300, 1000]) test(`${count} NPC 真实快照按需 Worker 分析、动画帧继续、结果与原算法一致且复用缓存`, async ({ page }, testInfo) => {
  381 |   await seed(page);
  382 |   await page.reload();
  383 |   let workers = 0;
  384 |   page.on('worker', () => workers++);
  385 |   const capture = await page.evaluate(async count => {
  386 |     const fixturePath = '/src/tests/fixtures/contextScale.ts';
  387 |     const composerPath = '/src/prompts/composer.ts';
  388 |     const configPath = '/src/services/ai/configuration.ts';
  389 |     const credentialsPath = '/src/services/ai/credentials.ts';
  390 |     const snapshotPath = '/src/services/ai/snapshot.ts';
  391 |     const clientPath = '/src/services/ai/client.ts';
  392 |     const { contextScaleFixture } = await import(fixturePath);
  393 |     const { composePrompt } = await import(composerPath);
  394 |     const { newChannel, defaultAiConfig } = await import(configPath);
  395 |     const { CredentialVault } = await import(credentialsPath);
  396 |     const { requestSnapshot } = await import(snapshotPath);
  397 |     const { AiClient } = await import(clientPath);
  398 |     const source = contextScaleFixture(count);
  399 |     source.state.saveId = 'ui-test';
  400 |     source.draft.saveId = 'ui-test';
  401 |     const prompt = await composePrompt({ ...source, stage: 'story', mode: 'regular', userInput: source.draft.userInput });
  402 |     const channel = { ...newChannel(), defaultModel: 'worker-scale-mock' };
  403 |     const config = defaultAiConfig(); config.channels = [channel]; config.routes.story = { channelId: channel.id, modelId: '' };
  404 |     const vault = new CredentialVault(sessionStorage, localStorage); vault.set(channel.id, 'worker-scale-secret');
  405 |     let calls = 0;
  406 |     const before = performance.now();
  407 |     await new AiClient(async () => {
  408 |       calls++;
  409 |       return Response.json({ choices: [{ message: { content: 'OK' }, finish_reason: 'stop' }], usage: { prompt_tokens: 42, completion_tokens: 2 } });
  410 |     }).generate(requestSnapshot(config, 'story', vault), prompt.messages, { inspection: { kind: 'stage', mode: 'regular', saveId: 'ui-test', revision: source.state.revision, modules: prompt.modules } });
  411 |     return { calls, captureAndMockResponseMs: performance.now() - before };
  412 |   }, count);
  413 |   expect(workers).toBe(0);
  414 |   expect(capture.calls).toBe(1);
  415 |   await inspector(page);
  416 |   await page.getByRole('combobox', { name: '回合模式', exact: true }).selectOption('regular');
  417 |   await page.getByRole('combobox', { name: '数据来源', exact: true }).selectOption('actual');
  418 |   const context = page.getByRole('region', { name: '上下文与统计' });
  419 |   expect(workers).toBe(0);
  420 |   await page.getByText('展开数据分类、召回预算与重复诊断', { exact: true }).click();
  421 |   await expect(context).toContainText('正在分析…');
  422 |   await backToList(page);
  423 |   await page.getByLabel('搜索模块', { exact: true }).fill('writing');
  424 |   await expect(page.getByLabel('搜索模块', { exact: true })).toHaveValue('writing');
  425 |   await openAdvanced(page);
  426 |   const progress = await page.evaluate(async () => {
  427 |     const storePath = '/src/services/ai/inspection.ts', analysisPath = '/src/prompts/budgetAnalysis.ts';
  428 |     const { requestInspections } = await import(storePath);
  429 |     const { budgetAnalysis } = await import(analysisPath);
  430 |     const analysis = budgetAnalysis(requestInspections.getSnapshot()[0].messages);
  431 |     let frames = 0;
  432 |     const start = performance.now();
  433 |     await new Promise<void>(resolve => {
  434 |       function frame() { frames++; if (analysis.getSnapshot().status === 'running') requestAnimationFrame(frame); else resolve(); }
  435 |       requestAnimationFrame(frame);
  436 |     });
  437 |     return { frames, analysisMs: performance.now() - start };
  438 |   });
> 439 |   expect(progress.frames).toBeGreaterThan(1);
      |                           ^ Error: expect(received).toBeGreaterThan(expected)
  440 |   await expect(context).toContainText('分析完成（本会话内存缓存）。');
  441 |   await expect(context).toContainText('字符差额 0，字节差额 0');
  442 |   expect(workers).toBe(1);
  443 |   const equality = await page.evaluate(async () => {
  444 |     const storePath = '/src/services/ai/inspection.ts', analysisPath = '/src/prompts/budgetAnalysis.ts', purePath = '/src/prompts/budgetInspection.ts';
  445 |     const { requestInspections } = await import(storePath);
  446 |     const { budgetAnalysis } = await import(analysisPath);
  447 |     const { inspectBudget } = await import(purePath);
  448 |     const snapshot = requestInspections.getSnapshot()[0];
  449 |     const state = budgetAnalysis(snapshot.messages).getSnapshot();
  450 |     // Test-only oracle runs after the real Worker completes; production has no main-thread fallback.
  451 |     return state.status === 'complete' && JSON.stringify(state.result) === JSON.stringify(inspectBudget(snapshot.messages));
  452 |   });
  453 |   expect(equality).toBe(true);
  454 |   await page.getByText('展开数据分类、召回预算与重复诊断', { exact: true }).click();
  455 |   await page.getByText('展开数据分类、召回预算与重复诊断', { exact: true }).click();
  456 |   await expect(context).toContainText('分析完成（本会话内存缓存）。');
  457 |   expect(workers).toBe(1);
  458 |   await writeFile(testInfo.outputPath('worker-measurement.json'), JSON.stringify({ count, ...capture, ...progress, workers, equality }, null, 2));
  459 |   await page.getByRole('button', { name: '清空内存请求记录' }).click();
  460 |   await expect(page.getByText(/此阶段\/模式没有实际请求快照/)).toBeVisible();
  461 | });
  462 | 
  463 | const promptSwitches = manifest.modules.filter((item) =>
  464 |   ['noControl', 'naturalProse', 'actionOptions', 'realWorld'].includes(item.toggle?.split(':')[0] ?? ''),
  465 | );
  466 | const evidenceDir = 'docs/pr124-review/screenshots';
  467 | async function screenshot(page: Page, name: string) {
  468 |   if (name === 'preview-invalidated') {
  469 |     await page.getByText('写作偏好已修改，请重新组装预览。', { exact: true })
  470 |       .evaluate(element => element.scrollIntoView({ block: 'center' }));
  471 |   }
  472 |   await page.screenshot({ path: `${evidenceDir}/${page.viewportSize()!.width}-${name}.png`, animations: 'disabled', scale: 'css' });
  473 | }
  474 | 
  475 | test('四开关显式保存：双页联动、未保存刷新丢弃、保存刷新持久化与再次编辑提示', async ({ page }) => {
  476 |   const errors: string[] = [];
  477 |   page.on('pageerror', error => errors.push(error.message));
  478 |   await page.route('https://**', route => route.abort());
  479 |   await page.goto('/');
  480 |   const before = await page.evaluate(() => localStorage.getItem('heijin.settings.v1'));
  481 |   await inspector(page, false);
  482 |   const groups = page.getByRole('group', { name: '提示词分类' });
  483 |   expect(promptSwitches).toHaveLength(4);
  484 |   await groups.getByRole('button', { name: /^写作设定/ }).click();
  485 |   await screenshot(page, 'list');
  486 |   for (const item of promptSwitches) {
  487 |     await page.locator(`[data-prompt-id="${item.id}"] input`).uncheck();
  488 |     await expect(page.locator('.local-save-bar').getByRole('status')).toContainText('本地设置尚未保存');
  489 |   }
  490 |   expect(await page.evaluate(() => localStorage.getItem('heijin.settings.v1'))).toBe(before);
  491 |   await expect(page.locator('.local-save-bar').getByRole('status')).toBeInViewport();
  492 |   await expect(page.getByRole('button', { name: '保存本地设置', exact: true })).toBeInViewport();
  493 |   await screenshot(page, 'unsaved');
  494 |   await page.getByRole('button', { name: '提示词', exact: true }).click();
  495 |   for (const label of ['NoControl（防抢话）', '自然文风修复', '行动选项', '真实世界模式']) {
  496 |     await expect(page.getByLabel(label, { exact: true })).not.toBeChecked();
  497 |   }
  498 |   await page.getByRole('button', { name: '提示词管理', exact: true }).click();
  499 |   await expect(page.locator('.local-save-bar').getByRole('status')).toContainText('本地设置尚未保存');
  500 |   await page.reload();
  501 |   await inspector(page, false);
  502 |   for (const item of promptSwitches) await expect(page.locator(`[data-prompt-id="${item.id}"] input`)).toBeChecked();
  503 |   for (const item of promptSwitches) {
  504 |     const row = page.locator(`[data-prompt-id="${item.id}"]`);
  505 |     await row.locator('.pm-open').click();
  506 |     const source = page.getByRole('region', { name: '模块原文' });
  507 |     await source.getByRole('checkbox').uncheck();
  508 |     await expect(page.locator('.local-save-bar').getByRole('status')).toContainText('本地设置尚未保存');
  509 |     await source.getByRole('button', { name: /返回列表/ }).click();
  510 |     await expect(row.getByRole('checkbox')).not.toBeChecked();
  511 |   }
  512 |   const save = page.getByRole('button', { name: '保存本地设置', exact: true });
  513 |   await save.click();
  514 |   await expect(page.locator('.local-save-bar').getByRole('status')).toContainText('本地偏好已保存');
  515 |   await screenshot(page, 'saved');
  516 |   const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('heijin.settings.v1')!).prompts);
  517 |   for (const field of ['noControl', 'naturalProse', 'actionOptions', 'realWorld']) expect(saved[field]).toBe(false);
  518 |   await page.reload();
  519 |   await inspector(page, false);
  520 |   for (const item of promptSwitches) await expect(page.locator(`[data-prompt-id="${item.id}"] input`)).not.toBeChecked();
  521 |   await page.locator(`[data-prompt-id="${promptSwitches[0].id}"] input`).check();
  522 |   await save.click();
  523 |   await expect(page.locator('.local-save-bar').getByRole('status')).toContainText('本地偏好已保存');
  524 |   await page.locator(`[data-prompt-id="${promptSwitches[0].id}"] input`).uncheck();
  525 |   await expect(page.locator('.local-save-bar').getByRole('status')).toContainText('本地设置尚未保存');
  526 |   await expect(page.locator('.local-save-bar').getByRole('status')).toHaveClass(/l-info/);
  527 |   expect(errors).toEqual([]);
  528 | });
  529 | 
  530 | test('四开关取消旧组装：列表与原文修改立即失效，迟到成功不覆盖新任务，重新组装才有效', async ({ page }) => {
  531 |   // Observe completion of the real assembler in this test only; production stays unchanged.
  532 |   await page.route('**/src/prompts/preview.ts', async route => {
  533 |     const response = await route.fetch();
  534 |     const source = await response.text();
  535 |     expect(source).toContain('async function buildStagePreviews(');
  536 |     await route.fulfill({ response, body: source.replace('async function buildStagePreviews(', 'async function buildStagePreviewsForTest(') + '\nexport async function buildStagePreviews(...args) { try { return await buildStagePreviewsForTest(...args); } finally { window.__pr124Builds = (window.__pr124Builds || 0) + 1; } }' });
  537 |   });
  538 |   await page.route('https://**', route => route.abort());
  539 |   const before = await seed(page);
```
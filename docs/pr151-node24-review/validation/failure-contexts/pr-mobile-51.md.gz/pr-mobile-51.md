# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: continuous-turns.spec.ts >> 真实创角后连续正式游玩十回合；输入、资料、正文历史与刷新一致
- Location: e2e/continuous-turns.spec.ts:182:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('complementary', { name: '主角信息' })
Expected substring: "未确认"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" getByRole('complementary', { name: '主角信息' }) with timeout 5000ms
  - waiting for getByRole('complementary', { name: '主角信息' })

```

```yaml
- banner:
  - button "打开游戏菜单": ☰
- main:
  - button "此时此地与主角状态":
    - text: 重庆 重庆
    - time: 14:01
    - text: —
  - text: 重庆，2015/7/8 星期三 14:01，天气：天气待确认
  - region "剧情与行动":
    - text: THE STORY 已结算历史
    - article:
      - heading "第 1 回合" [level=2]
      - text: 2015/7/8 · 星期三 · 14:00 重庆
      - paragraph: 2015年7月8日14:00，重庆街头。第1幕。主角收到了公司寄出的解雇通知。经过一分钟，主角在街边休息。主角心情趋于平静。
      - button "本回合变化 不可用" [disabled]
      - status: 本回合没有可对比的结算前记录
    - region "行动建议":
      - paragraph: 接下来你想做什么 1 / 3
      - button "留在街边"
      - button "看看四周"
      - button "询问路线"
    - region "三阶段工作流":
      - button "三阶段工作流详情" [expanded]:
        - status: 三阶段 · 本回合已结算 · 等待行动
        - text: 详情 ›
    - button "撤回" [disabled]
    - text: 你的行动
    - textbox "你的行动":
      - /placeholder: 填写你的行动
    - button "发送" [disabled]
  - navigation "底部导航":
    - button "故事"
    - button "人物"
    - button "世界资料"
    - button "设置"
- button "收起工作流暗区"
- dialog "三阶段工作流":
  - button "收起三阶段工作流"
  - button "行动输入"
  - region "三阶段详情":
    - text: THREE STAGES · 三阶段
    - heading "本回合已结算 · 等待行动" [level=3]
    - button "收起三阶段详情": ×
    - navigation "三阶段导航":
      - paragraph: STAGES
      - list:
        - listitem:
          - button "01正文生成 已结算":
            - strong: 01正文生成
            - text: 已结算
        - listitem:
          - button "02变量管理 已结算":
            - strong: 02变量管理
            - text: 已结算
          - checkbox "变量管理" [checked]
        - listitem:
          - button "03动态世界 已结算":
            - strong: 03动态世界
            - text: 已结算
          - checkbox "动态世界" [checked]
      - paragraph: 本回合
      - list:
        - listitem:
          - button "运行诊断 错误与用量":
            - strong: 运行诊断
            - text: 错误与用量
        - listitem:
          - button "已绑定输入 只读":
            - strong: 已绑定输入
            - text: 只读
    - text: 生成可能产生费用。
```

# Test source

```ts
  93  |     }
  94  |     if (stage === 'variables') {
  95  |       const state = VariableStateProjectionSchema.parse(ctx.SAVE_STATE),
  96  |         story = StorySchema.parse(ctx.STORY_RESULT);
  97  |       const commands: DomainCommand[] = [
  98  |         {
  99  |           type: 'SetWorldClock',
  100 |           commandId: 'minute',
  101 |           evidence: '经过一分钟，主角在街边休息。',
  102 |           worldClock: ctx.OPENING_TIME ? string(record(ctx.OPENING_TIME).endAt) : new Date(Date.parse(state.worldClock) + 60000).toISOString(),
  103 |         },
  104 |         {
  105 |           type: 'UpdateProtagonist',
  106 |           commandId: 'mood',
  107 |           expectedRevision: state.revision,
  108 |           protagonistId: state.protagonist.id,
  109 |           changes: { emotionText: '平静' },
  110 |           evidence: '主角心情趋于平静。',
  111 |         },
  112 |       ];
  113 |       if (state.turnNumber === 0)
  114 |         commands.push({
  115 |           type: 'AcquireItem',
  116 |           commandId: 'notice',
  117 |           evidence: '主角收到了公司寄出的解雇通知。',
  118 |           item: {
  119 |             id: 'notice',
  120 |             name: '解雇通知',
  121 |             category: 'document',
  122 |             quantity: 1,
  123 |             ownerRef: { kind: 'protagonist', id: state.protagonist.id },
  124 |             conditionText: '完好',
  125 |           },
  126 |         });
  127 |       if (story.narrative.includes('主角已经用现金支付30元吃饭。'))
  128 |         commands.push({
  129 |           type: 'SpendFunds',
  130 |           commandId: 'meal',
  131 |           account: 'cash',
  132 |           amount: 3000,
  133 |           purpose: '用餐',
  134 |           evidence: '主角已经用现金支付30元吃饭。',
  135 |         });
  136 |       text = variableReply({ commands, rejectedSuggestions: [], unresolved: [] });
  137 |     } else {
  138 |       if (plan.holdWorld) await plan.holdWorld;
  139 |       text = JSON.stringify({
  140 |         worldCommands: [],
  141 |         taskCommands: [],
  142 |         eventCommands: [],
  143 |         visibleHooks: [{ text: '绝不自动发布的后台线索', revealAfter: string(ctx.worldClock) }],
  144 |         unresolved: ['内部未解决事项不可变成正文日志'],
  145 |       });
  146 |     }
  147 |     await route
  148 |       .fulfill({
  149 |         contentType: 'application/json',
  150 |         body: JSON.stringify({ choices: [{ message: { content: text }, finish_reason: 'stop' }] }),
  151 |       })
  152 |       .catch(() => undefined);
  153 |   });
  154 |   return { plan, stories, calls };
  155 | }
  156 | async function stored(page: Page) {
  157 |   const saved = await page.evaluate(async () => {
  158 |     const path = '/src/services/storage/saveRepository.ts',
  159 |       { SaveRepository } = await import(path),
  160 |       repo = await SaveRepository.open();
  161 |     try {
  162 |       const [save] = await repo.list();
  163 |       return await repo.loadGame(save.saveId);
  164 |     } finally {
  165 |       repo.close();
  166 |     }
  167 |   });
  168 |   return { state: GameStateSchema.parse(saved.state), draft: TurnDraftSchema.parse(saved.draft) };
  169 | }
  170 | const workflow = (page: Page) => page.getByRole('region', { name: '三阶段工作流' });
  171 | async function ready(page: Page, number = 1) {
  172 |   await expect(page.getByTestId('story-reader').locator('article').last()).toContainText(
  173 |     `第${number}幕`,
  174 |   );
  175 |   await expect(workflow(page)).toContainText('本回合已结算');
  176 | }
  177 | async function opening(page: Page) {
  178 |   await workflow(page).getByRole('button', { name: '自动生成开局', exact: true }).click();
  179 |   await ready(page);
  180 | }
  181 | 
  182 | test('真实创角后连续正式游玩十回合；输入、资料、正文历史与刷新一致', async ({ page }, info) => {
  183 |   test.setTimeout(120000);
  184 |   await configure(page);
  185 |   const server = await mock(page);
  186 |   await createCharacter(page);
  187 |   await ready(page);
  188 |   const initial = await stored(page),
  189 |     start = Date.parse('2015-07-08T14:00:00+08:00');
  190 |   expect(initial.state.openingTimePending).toBeUndefined(); // 开局自动正式结算，待下一条行动。
  191 |   expect(initial.state.turnNumber).toBe(1);
  192 |   expect(initial.state.economy.cash).toBeNull();
> 193 |   await expect(page.getByRole('complementary', { name: '主角信息' })).toContainText('未确认');
      |                                                                   ^ Error: expect(locator).toContainText(expected) failed
  194 |   for (let index = 1; index <= 9; index++) {
  195 |     const action = `行动${index}：在街边等待一分钟`;
  196 |     await page.getByLabel('你的行动', { exact: true }).fill(action);
  197 |     await page.getByRole('button', { name: '发送', exact: true }).click();
  198 |     await ready(page, index + 1);
  199 |     const result = await stored(page);
  200 |     expect(result.state.turnNumber).toBe(index + 1);
  201 |     expect(result.state.revision).toBe(index + 1);
  202 |     expect(result.state.journal).toHaveLength(index + 1);
  203 |     expect(result.state.memories.short).toHaveLength(index + 1);
  204 |     expect(result.state.memories.short.at(-1)).toMatchObject({
  205 |       text: `第${index + 1}幕的街边休息`,
  206 |       sourceTurnIds: [result.state.journal[index].turnId],
  207 |       createdAtGameTime: result.state.worldClock,
  208 |       visibility: 'player_known',
  209 |       affectedEntityRefs: [],
  210 |     });
  211 |     expect(result.draft.userInput).toBe('');
  212 |     expect(result.draft.turnKind).toBe('regular');
  213 |     expect(Date.parse(result.state.worldClock)).toBe(start + (index + 1) * 60000);
  214 |     expect(result.state.items.notice.ownerRef?.id).toBe(result.state.protagonist.id);
  215 |     expect(result.state.initialCompanionId).toBe(initial.state.initialCompanionId);
  216 |     expect(result.state.npc.companion).toEqual(initial.state.npc.companion);
  217 |     await expect(page.getByTestId('story-reader').locator('.chapter-heading').last()).toHaveText(
  218 |       `第 ${index + 1} 回合`,
  219 |     );
  220 |     expect(server.stories.find((s) => s.number === index + 1)?.action).toBe(action);
  221 |     expect(server.stories.find((s) => s.number === index + 1)?.context).toContain(
  222 |       `第${index}幕的街边休息`,
  223 |     );
  224 |     if (index === 5) {
  225 |       await page.reload(); await openGameTools(page);
  226 |       await ready(page, 6);
  227 |     }
  228 |   }
  229 |   const final = await stored(page);
  230 |   expect(server.calls).toHaveLength(30);
  231 |   expect(final.state.journal[0].story.turnKind).toBe('opening');
  232 |   expect(final.state.journal.slice(1).every((j) => j.story.turnKind === 'regular')).toBe(true);
  233 |   expect(JSON.stringify(final.state)).not.toContain('绝不自动发布的后台线索');
  234 |   expect(JSON.stringify(final.state.journal)).not.toContain('内部未解决事项');
  235 |   await expect(page.locator('main')).not.toContainText('绝不自动发布的后台线索');
  236 |   await page.reload(); await openGameTools(page);
  237 |   expect(await stored(page)).toEqual(final);
  238 |   await ready(page, 10);
  239 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  240 |   await page.screenshot({ path: info.outputPath('ten-committed-turns.png'), fullPage: true });
  241 | });
  242 | 
  243 | test('下一轮生成失败不回滚上轮结算；刷新后只恢复尚未完成的新回合', async ({ page }) => {
  244 |   await configure(page);
  245 |   const server = await mock(page);
  246 |   await createCharacter(page);
  247 |   await ready(page);
  248 |   server.plan.badStoryNumber = 2;
  249 |   await page.getByLabel('你的行动', { exact: true }).fill('去街边等待');
  250 |   await page.getByRole('button', { name: '发送', exact: true }).click();
  251 |   await expect(workflow(page).getByRole('alert')).toContainText('正文生成');
  252 |   const failed = await stored(page);
  253 |   expect(failed.state.turnNumber).toBe(1);
  254 |   expect(failed.draft.userInput).toBe('去街边等待');
  255 |   expect(failed.draft.stageStatus.story).toBe('failed');
  256 |   await page.reload(); await openGameTools(page);
  257 |   server.plan.badStoryNumber = 0;
  258 |   await workflow(page).getByRole('button', { name: '继续未完成阶段', exact: true }).click();
  259 |   await ready(page, 2);
  260 |   expect((await stored(page)).state.turnNumber).toBe(2);
  261 |   expect((await stored(page)).state.journal[0]).toEqual(failed.state.journal[0]);
  262 |   expect(server.calls).toEqual([
  263 |     'story',
  264 |     'variables',
  265 |     'world',
  266 |     'story',
  267 |     'story',
  268 |     'variables',
  269 |     'world',
  270 |   ]);
  271 | });
  272 | 
  273 | test('提交事务中途失败 UI 不虚报成功；重试后只结算一次', async ({ page }) => {
  274 |   await configure(page);
  275 |   await mock(page);
  276 |   await createCharacter(page);
  277 |   await ready(page);
  278 |   const before = await stored(page);
  279 |   await page.evaluate(() => {
  280 |     const original = IDBObjectStore.prototype.put;
  281 |     Object.defineProperty(window, '__restoreTurnPut', {
  282 |       value: () => {
  283 |         IDBObjectStore.prototype.put = original;
  284 |       },
  285 |       configurable: true,
  286 |     });
  287 |     IDBObjectStore.prototype.put = function (value, key) {
  288 |       if (this.name === 'drafts') throw new DOMException('isolated test', 'QuotaExceededError');
  289 |       return original.call(this, value, key);
  290 |     };
  291 |   });
  292 |   await page.getByLabel('你的行动', { exact: true }).fill('等待下一轮');
  293 |   await page.getByRole('button', { name: '发送', exact: true }).click();
```
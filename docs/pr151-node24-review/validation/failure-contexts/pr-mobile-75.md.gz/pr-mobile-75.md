# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: prompt-inspector.spec.ts >> 无正文草稿的阶段预览诚实失败，七项写作偏好不因管理中心改变
- Location: e2e/prompt-inspector.spec.ts:363:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '提示词', exact: true })

```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - main "游戏首页与存档馆" [ref=f1e4]:
    - generic [ref=f1e5]:
      - generic [aria-hidden] [ref=f1e6]: 黑
      - generic [ref=f1e7]:
        - text: 黑金王朝
        - generic [ref=f1e8]: HEIJINWANGCHAO
      - button "设置" [ref=f1e9] [cursor=pointer]
      - generic [ref=f1e10]: V1.0 Beta
    - generic [ref=f1e11]:
      - paragraph [ref=f1e12]: MODERN CITY / OPEN WORLD
      - heading "黑金王朝" [level=1] [ref=f1e13]
      - paragraph [ref=f1e14]: 起点有冲突，人生不预设结局。
    - status "终点 未知，时刻 00:22，已选择" [ref=f1e15]:
      - generic [ref=f1e16]:
        - text: 终点
        - generic [ref=f1e17]: DEST
      - generic [ref=f1e18]:
        - generic [ref=f1e19]: 未
        - generic [ref=f1e20]: 知
      - generic [ref=f1e22]:
        - generic [ref=f1e23]: "0"
        - generic [ref=f1e24]: "0"
        - generic [ref=f1e25]: ":"
        - generic [ref=f1e26]: "2"
        - generic [ref=f1e27]: "2"
      - generic [ref=f1e28]: 已选择
    - generic [ref=f1e29]:
      - generic [ref=f1e30]: 车票 01
      - generic [ref=f1e31]: 本地保存 · 无需账号
      - button "导入备份" [disabled] [ref=f1e32]: ⤓ 导入备份
      - button "刷新列表" [ref=f1e33] [cursor=pointer]
    - region "车票栏，左右方向键切换" [ref=f1e34]:
      - article "界面测试存档（隔离），保存于 2026/11/15 00:22，已选择" [ref=f1e36]:
        - generic [ref=f1e37]:
          - generic [ref=f1e38]: ARCHIVE 01
          - generic [ref=f1e40]:
            - generic [ref=f1e41]:
              - generic [ref=f1e42]:
                - generic [ref=f1e43]: FROM
                - generic [ref=f1e44]: 界面测试存档（隔离）
              - generic [aria-hidden] [ref=f1e45]: 单程
              - generic [ref=f1e47]: TO
            - generic [ref=f1e49]:
              - generic [ref=f1e50]:
                - term [ref=f1e51]: 保存日期
                - definition [ref=f1e52]: 2026/11/15
              - generic [ref=f1e53]:
                - term [ref=f1e54]: 时刻
                - definition [ref=f1e55]: 00:22
              - generic [ref=f1e56]:
                - generic [aria-hidden]:
                  - text: 已检票
                  - generic: SELECTED
            - paragraph [ref=f1e57]: 从未备份
        - generic [ref=f1e76]:
          - text: 继续游戏
          - generic [ref=f1e77]: ↓ 按住票根往下撕
      - article "空白车票：开启新的人生" [ref=f1e80]:
        - generic [ref=f1e81]:
          - generic [ref=f1e82]:
            - generic [ref=f1e83]: 空白车票
            - generic [ref=f1e84]: NEW LIFE
            - generic [ref=f1e85]: NEW
          - generic [ref=f1e86]:
            - generic [ref=f1e87]:
              - generic [ref=f1e88]:
                - generic [ref=f1e89]: FROM
                - generic [ref=f1e90]: ？
              - generic [aria-hidden] [ref=f1e91]: 单程
              - generic [ref=f1e93]:
                - generic [ref=f1e94]: TO
                - generic [ref=f1e95]: ？
            - generic [ref=f1e96]:
              - generic [ref=f1e97]:
                - term [ref=f1e98]: 城市
                - definition [ref=f1e99]
              - generic [ref=f1e101]:
                - term [ref=f1e102]: 职业
                - definition [ref=f1e103]
              - generic [ref=f1e105]:
                - term [ref=f1e106]: 存档
                - definition [ref=f1e107]: —
            - paragraph [ref=f1e108]: 四座城市 · 自由职业 · 开放人生
        - generic [ref=f1e110]:
          - text: 开启新的人生
          - generic [ref=f1e111]: ↓ 按住票根往下撕
    - navigation "车票页码" [ref=f1e113]:
      - button "第 1 张" [ref=f1e114] [cursor=pointer]
      - button "第 2 张，空白车票" [ref=f1e115] [cursor=pointer]
    - generic [ref=f1e116]:
      - button "继续游戏" [disabled] [ref=f1e117]:
        - text: 继续游戏
        - generic [aria-hidden] [ref=f1e118]: →
      - generic [ref=f1e119]:
        - button "导出备份" [disabled] [ref=f1e120]
        - button "删除" [disabled] [ref=f1e121]
    - generic [ref=f1e122]:
      - group "游玩信息" [ref=f1e123]:
        - button "游玩须知与免责声明" [ref=f1e124] [cursor=pointer]
        - button "王朝公告" [ref=f1e125] [cursor=pointer]
      - paragraph [ref=f1e126]: 四座城市 · 自由职业 · 开放人生三阶段生成 · 原子结算 · 连续回合
  - dialog [ref=f1e127]:
    - banner [ref=f1e130]:
      - generic [aria-hidden] [ref=f1e131]: 设
      - generic [ref=f1e132]:
        - paragraph [aria-hidden] [ref=f1e133]: SYSTEM · 系统
        - heading "设置" [level=2] [ref=f1e134]
      - button "关闭资料界面" [ref=f1e135] [cursor=pointer]:
        - text: 关闭
        - generic [aria-hidden] [ref=f1e136]: ×
    - generic [ref=f1e139]:
      - button "返回设置" [ref=f1e140] [cursor=pointer]: ‹ 设置
      - heading "提示词管理" [level=3] [ref=f1e141]
      - region "高级" [ref=f1e143]:
        - generic [ref=f1e144]:
          - button "‹ 返回列表" [ref=f1e145] [cursor=pointer]
          - heading "高级" [level=4] [ref=f1e146]
        - paragraph [ref=f1e147]: 真实注册资源 · 只读原文 · 无网络组装预览 · 仅内存请求记录。当前使用本窗口编辑的七项写作偏好；排序独立保存。
        - generic [ref=f1e148]:
          - generic [ref=f1e149]:
            - text: 检查阶段
            - combobox "检查阶段" [ref=f1e150]:
              - option "正文生成"
              - option "变量管理" [selected]
              - option "动态世界"
          - generic [ref=f1e151]:
            - text: 回合模式
            - combobox "回合模式" [ref=f1e152]:
              - option "开局回合" [selected]
              - option "普通回合"
          - generic [ref=f1e153]:
            - text: 预览存档
            - combobox "预览存档" [ref=f1e154]:
              - option "请选择真实存档"
              - option "界面测试存档（隔离）" [selected]
          - button "生成三阶段组装预览（不联网）" [ref=f1e155] [cursor=pointer]
        - status [ref=f1e156]: 预览已组装；未发送 API 请求、未执行回合、未写入正式存档。
        - generic [ref=f1e157]:
          - generic [ref=f1e158]:
            - strong [ref=f1e159]: 正文生成
            - paragraph [ref=f1e160]: 离线预览：42101 字符 · 估算 ≈ 43548 Token；主要来源待按需详细分析；窗口未知
          - generic [ref=f1e161]:
            - strong [ref=f1e162]: 变量管理
            - paragraph [ref=f1e163]: 缺少已选定的正文草稿；M4 尚未接入，不会伪造阶段请求。
          - generic [ref=f1e164]:
            - strong [ref=f1e165]: 动态世界
            - paragraph [ref=f1e166]: 缺少已选定的正文草稿；M4 尚未接入，不会伪造阶段请求。
        - group [ref=f1e167]:
          - generic "开局与普通回合的模块差异" [ref=f1e168] [cursor=pointer]
        - group [ref=f1e169]:
          - generic "本次预览的相关变量域（不新增写作设置）" [ref=f1e170] [cursor=pointer]
        - generic [ref=f1e171]:
          - region "发送顺序" [ref=f1e172]:
            - heading "发送顺序" [level=5] [ref=f1e173]
            - paragraph [ref=f1e174]: 以下为真实选择器的模块顺序；游戏资料尚未成功组装。
            - list [ref=f1e175]:
              - listitem [ref=f1e176]:
                - generic [ref=f1e177]:
                  - generic [ref=f1e178]: 10 · 黑金王朝·世界观 V2.0
                  - generic [ref=f1e179]: worldbooks.heijin.worldview · system · worldbooks · 2685 字符 · 估算 Token 待组装
                - emphasis [ref=f1e180]: 固定
              - listitem [ref=f1e181]:
                - generic [ref=f1e182]:
                  - generic [ref=f1e183]: 20 · 现代现实基本逻辑与地下社会生态 V2.0
                  - generic [ref=f1e184]: worldbooks.heijin.modern_underworld · system · worldbooks · 4376 字符 · 估算 Token 待组装
                - emphasis [ref=f1e185]: 固定
              - listitem [ref=f1e186]:
                - generic [ref=f1e187]:
                  - generic [ref=f1e188]: 30 · 玩家自主权与因果
                  - generic [ref=f1e189]: shared.01_agency · system · shared · 447 字符 · 估算 Token 待组装
                - emphasis [ref=f1e190]: 固定
              - listitem [ref=f1e191]:
                - generic [ref=f1e192]:
                  - generic [ref=f1e193]: 40 · 信息域和保密分层
                  - generic [ref=f1e194]: shared.02_knowledge · system · shared · 900 字符 · 估算 Token 待组装
                - emphasis [ref=f1e195]: 固定
              - listitem [ref=f1e196]:
                - generic [ref=f1e197]:
                  - generic [ref=f1e198]: 50 · 统一时间与事件预检
                  - generic [ref=f1e199]: shared.03_time_events · system · shared · 4042 字符 · 估算 Token 待组装
                - emphasis [ref=f1e200]: 固定
              - listitem [ref=f1e201]:
                - generic [ref=f1e202]:
                  - generic [ref=f1e203]: 60 · 状态真值与执行边界（文本变量）
                  - generic [ref=f1e204]: shared.04_state_authority.text · system · shared · 522 字符 · 估算 Token 待组装
                - emphasis [ref=f1e205]: 固定
              - listitem [ref=f1e206]:
                - generic [ref=f1e207]:
                  - generic [ref=f1e208]: 70 · 上下文容器与可信度（文本变量）
                  - generic [ref=f1e209]: shared.05_context_protocol.text · system · shared · 1967 字符 · 估算 Token 待组装
                - emphasis [ref=f1e210]: 固定
              - listitem [ref=f1e211]:
                - generic [ref=f1e212]:
                  - generic [ref=f1e213]: 300 · 开局变量初始化主提示词（文本变量）
                  - generic [ref=f1e214]: stages.opening.variables.text · system · stage · 1190 字符 · 估算 Token 待组装
                - emphasis [ref=f1e215]: 固定
              - listitem [ref=f1e216]:
                - generic [ref=f1e217]:
                  - generic [ref=f1e218]: 407 · 变量更新输出协议（文本变量）
                  - generic [ref=f1e219]: shared.07_command_output.text · system · output · 10058 字符 · 估算 Token 待组装
                - emphasis [ref=f1e220]: 固定
            - generic [ref=f1e221]:
              - button "恢复默认顺序" [ref=f1e222] [cursor=pointer]
              - button "保存提示词排序" [disabled] [ref=f1e223] [cursor=pointer]
          - region "上下文与统计" [ref=f1e224]:
            - heading "上下文与统计" [level=5] [ref=f1e225]
            - generic [ref=f1e226]:
              - text: 数据来源
              - combobox "数据来源" [ref=f1e227]:
                - option "组装预览（未发送）" [selected]
                - option "实际请求快照"
            - paragraph [ref=f1e228]: 模型路由：未配置可用路由 / 未知
            - paragraph [ref=f1e229]: 组装预览不会调用 API；没有实际使用量。
            - generic [ref=f1e230]:
              - term [ref=f1e231]: 上下文字符数
              - definition [ref=f1e232]: 未知
              - term [ref=f1e233]: 内容 UTF-8 字节 / 消息数
              - definition [ref=f1e234]: 未知
              - term [ref=f1e235]: JSON 消息数组 UTF-8 字节（非完整 HTTP 请求体）
              - definition [ref=f1e236]: 未知
              - term [ref=f1e237]: 估算输入 Token
              - definition [ref=f1e238]: 未知
              - term [ref=f1e239]: 供应商输入 Token
              - definition [ref=f1e240]: 未提供
              - term [ref=f1e241]: 供应商输出 Token
              - definition [ref=f1e242]: 未提供
              - term [ref=f1e243]: 供应商总 Token
              - definition [ref=f1e244]: 未提供
              - term [ref=f1e245]: 供应商原生思考 Token
              - definition [ref=f1e246]: 未提供
              - term [ref=f1e247]: 估算方法
              - definition [ref=f1e248]: Unicode 启发式；ASCII 约 4 字符/Token，其他字符约 1.5 Token/字符。不含协议开销，不是精确 tokenizer 或真实消耗。估算保留消息间人工换行 未知 字符；字符与字节总量不含这些换行。
            - paragraph [ref=f1e249]: 缺少已选定的正文草稿；M4 尚未接入，不会伪造阶段请求。
      - generic [ref=f1e250]:
        - status
        - button "保存本地设置" [ref=f1e251] [cursor=pointer]
```

# Test source

```ts
  275 |     const configPath = '/src/services/ai/configuration.ts';
  276 |     const credentialsPath = '/src/services/ai/credentials.ts';
  277 |     const settingsPath = '/src/ui/settings/model.ts';
  278 |     const { SaveRepository } = await import(repoPath);
  279 |     const { runStageRequest } = await import(runtimePath);
  280 |     const { newChannel, defaultAiConfig, saveAiConfig } = await import(configPath);
  281 |     const { CredentialVault } = await import(credentialsPath);
  282 |     const { defaultSettings } = await import(settingsPath);
  283 |     const channel = {
  284 |       ...newChannel(),
  285 |       baseUrl: 'https://inspector.mock.invalid/v1',
  286 |       defaultModel: 'mock-before',
  287 |     };
  288 |     const config = defaultAiConfig();
  289 |     config.channels = [channel];
  290 |     config.routes.story = { channelId: channel.id, modelId: '' };
  291 |     saveAiConfig(localStorage, config);
  292 |     const vault = new CredentialVault(sessionStorage, localStorage);
  293 |     vault.set(channel.id, 'e2e-inspection-key');
  294 |     const repo = await SaveRepository.open();
  295 |     try {
  296 |       const state = await repo.load('ui-test');
  297 |       const draft = await repo.loadDraft('ui-test');
  298 |       await runStageRequest(
  299 |         {
  300 |           state,
  301 |           draft,
  302 |           settings: defaultSettings(),
  303 |           stage: 'world',
  304 |           mode: 'regular',
  305 |           userInput: '',
  306 |           domains: ['economy'],
  307 |         },
  308 |         config,
  309 |         vault,
  310 |       );
  311 |       config.channels[0].defaultModel = 'mock-after';
  312 |       saveAiConfig(localStorage, config);
  313 |     } finally {
  314 |       repo.close();
  315 |     }
  316 |   });
  317 |   const snapshotExample = await page.evaluate(async () => {
  318 |     const path = '/src/services/ai/inspection.ts';
  319 |     const { requestInspections } = await import(path);
  320 |     const record = requestInspections.getSnapshot()[0];
  321 |     return {
  322 |       source: 'Mock HTTP intercepted by Playwright',
  323 |       route: record.route,
  324 |       status: record.status,
  325 |       mode: record.scope.mode,
  326 |       stage: record.stage,
  327 |       modules: record.scope.modules,
  328 |       statistics: record.statistics,
  329 |     };
  330 |   });
  331 |   await writeFile(
  332 |     testInfo.outputPath('request-summary.json'),
  333 |     JSON.stringify(snapshotExample, null, 2),
  334 |   );
  335 |   expect(transmitted).toContain('秘密计划不可见');
  336 |   expect(transmitted).not.toContain('e2e-inspection-key');
  337 |   await inspector(page);
  338 |   await page.getByRole('combobox', { name: '回合模式', exact: true }).selectOption('regular');
  339 |   await page.getByRole('combobox', { name: '检查阶段', exact: true }).selectOption('world');
  340 |   await page.getByRole('combobox', { name: '数据来源', exact: true }).selectOption('actual');
  341 |   const context = page.getByRole('region', { name: '上下文与统计' });
  342 |   await expect(context).toContainText('mock-before');
  343 |   await expect(context).not.toContainText('mock-after');
  344 |   await expect(context).toContainText('42');
  345 |   await expect(context).toContainText('49');
  346 |   await expect(context).not.toContainText('秘密计划不可见');
  347 |   await page.getByRole('button', { name: '主动查看完整内部上下文' }).click();
  348 |   await page.getByRole('combobox', { name: '内部内容视图', exact: true }).selectOption('body');
  349 |   await expect(page.getByLabel('完整内部上下文', { exact: true })).toContainText('秘密计划不可见');
  350 |   await expect(context).not.toContainText('e2e-inspection-key');
  351 |   await expect(context).not.toContainText('Authorization');
  352 |   expect(await readFormal(page)).toBe(before);
  353 |   const persisted = await page.evaluate(() => JSON.stringify(localStorage));
  354 |   expect(persisted).not.toContain('秘密计划不可见');
  355 |   expect(persisted).not.toContain('e2e-inspection-key');
  356 |   await page.reload();
  357 |   await inspector(page);
  358 |   await page.getByRole('combobox', { name: '数据来源', exact: true }).selectOption('actual');
  359 |   await expect(page.getByText(/此阶段\/模式没有实际请求快照/)).toBeVisible();
  360 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  361 | });
  362 | 
  363 | test('无正文草稿的阶段预览诚实失败，七项写作偏好不因管理中心改变', async ({ page }) => {
  364 |   await seed(page, false);
  365 |   await page.reload();
  366 |   await inspector(page);
  367 |   await page.getByRole('button', { name: '生成三阶段组装预览（不联网）' }).click();
  368 |   await expect(
  369 |     page.getByText('预览已组装；未发送 API 请求、未执行回合、未写入正式存档。'),
  370 |   ).toBeVisible();
  371 |   await page.getByRole('combobox', { name: '检查阶段', exact: true }).selectOption('variables');
  372 |   await expect(page.getByRole('region', { name: '上下文与统计' })).toContainText(
  373 |     '缺少已选定的正文草稿',
  374 |   );
> 375 |   await page.getByRole('button', { name: '提示词', exact: true }).click();
      |                                                                ^ Error: locator.click: Test timeout of 30000ms exceeded.
  376 |   await expect(page.locator('.settings-fields > label')).toHaveCount(7);
  377 |   await expect(page.getByLabel('叙事人称')).toHaveValue('third');
  378 | });
  379 | 
  380 | for (const count of [300, 1000]) test(`${count} NPC 真实快照按需 Worker 分析、动画帧继续、结果与原算法一致且复用缓存`, async ({ page }, testInfo) => {
  381 |   await seed(page);
  382 |   await page.reload();
  383 |   let workers = 0;
  384 |   page.on('worker', () => workers++);
  385 |   const capture = await page.evaluate(async count => {
  386 |     const fixturePath = '/src/tests/fixtures/contextScale.ts';
  387 |     const composerPath = '/src/prompts/composer.ts';
  388 |     const configPath = '/src/services/ai/configuration.ts';
  389 |     const credentialsPath = '/src/services/ai/credentials.ts';
  390 |     const snapshotPath = '/src/services/ai/snapshot.ts';
  391 |     const clientPath = '/src/services/ai/client.ts';
  392 |     const { contextScaleFixture } = await import(fixturePath);
  393 |     const { composePrompt } = await import(composerPath);
  394 |     const { newChannel, defaultAiConfig } = await import(configPath);
  395 |     const { CredentialVault } = await import(credentialsPath);
  396 |     const { requestSnapshot } = await import(snapshotPath);
  397 |     const { AiClient } = await import(clientPath);
  398 |     const source = contextScaleFixture(count);
  399 |     source.state.saveId = 'ui-test';
  400 |     source.draft.saveId = 'ui-test';
  401 |     const prompt = await composePrompt({ ...source, stage: 'story', mode: 'regular', userInput: source.draft.userInput });
  402 |     const channel = { ...newChannel(), defaultModel: 'worker-scale-mock' };
  403 |     const config = defaultAiConfig(); config.channels = [channel]; config.routes.story = { channelId: channel.id, modelId: '' };
  404 |     const vault = new CredentialVault(sessionStorage, localStorage); vault.set(channel.id, 'worker-scale-secret');
  405 |     let calls = 0;
  406 |     const before = performance.now();
  407 |     await new AiClient(async () => {
  408 |       calls++;
  409 |       return Response.json({ choices: [{ message: { content: 'OK' }, finish_reason: 'stop' }], usage: { prompt_tokens: 42, completion_tokens: 2 } });
  410 |     }).generate(requestSnapshot(config, 'story', vault), prompt.messages, { inspection: { kind: 'stage', mode: 'regular', saveId: 'ui-test', revision: source.state.revision, modules: prompt.modules } });
  411 |     return { calls, captureAndMockResponseMs: performance.now() - before };
  412 |   }, count);
  413 |   expect(workers).toBe(0);
  414 |   expect(capture.calls).toBe(1);
  415 |   await inspector(page);
  416 |   await page.getByRole('combobox', { name: '回合模式', exact: true }).selectOption('regular');
  417 |   await page.getByRole('combobox', { name: '数据来源', exact: true }).selectOption('actual');
  418 |   const context = page.getByRole('region', { name: '上下文与统计' });
  419 |   expect(workers).toBe(0);
  420 |   await page.getByText('展开数据分类、召回预算与重复诊断', { exact: true }).click();
  421 |   await expect(context).toContainText('正在分析…');
  422 |   await backToList(page);
  423 |   await page.getByLabel('搜索模块', { exact: true }).fill('writing');
  424 |   await expect(page.getByLabel('搜索模块', { exact: true })).toHaveValue('writing');
  425 |   await openAdvanced(page);
  426 |   const progress = await page.evaluate(async () => {
  427 |     const storePath = '/src/services/ai/inspection.ts', analysisPath = '/src/prompts/budgetAnalysis.ts';
  428 |     const { requestInspections } = await import(storePath);
  429 |     const { budgetAnalysis } = await import(analysisPath);
  430 |     const analysis = budgetAnalysis(requestInspections.getSnapshot()[0].messages);
  431 |     let frames = 0;
  432 |     const start = performance.now();
  433 |     await new Promise<void>(resolve => {
  434 |       function frame() { frames++; if (analysis.getSnapshot().status === 'running') requestAnimationFrame(frame); else resolve(); }
  435 |       requestAnimationFrame(frame);
  436 |     });
  437 |     return { frames, analysisMs: performance.now() - start };
  438 |   });
  439 |   expect(progress.frames).toBeGreaterThan(1);
  440 |   await expect(context).toContainText('分析完成（本会话内存缓存）。');
  441 |   await expect(context).toContainText('字符差额 0，字节差额 0');
  442 |   expect(workers).toBe(1);
  443 |   const equality = await page.evaluate(async () => {
  444 |     const storePath = '/src/services/ai/inspection.ts', analysisPath = '/src/prompts/budgetAnalysis.ts', purePath = '/src/prompts/budgetInspection.ts';
  445 |     const { requestInspections } = await import(storePath);
  446 |     const { budgetAnalysis } = await import(analysisPath);
  447 |     const { inspectBudget } = await import(purePath);
  448 |     const snapshot = requestInspections.getSnapshot()[0];
  449 |     const state = budgetAnalysis(snapshot.messages).getSnapshot();
  450 |     // Test-only oracle runs after the real Worker completes; production has no main-thread fallback.
  451 |     return state.status === 'complete' && JSON.stringify(state.result) === JSON.stringify(inspectBudget(snapshot.messages));
  452 |   });
  453 |   expect(equality).toBe(true);
  454 |   await page.getByText('展开数据分类、召回预算与重复诊断', { exact: true }).click();
  455 |   await page.getByText('展开数据分类、召回预算与重复诊断', { exact: true }).click();
  456 |   await expect(context).toContainText('分析完成（本会话内存缓存）。');
  457 |   expect(workers).toBe(1);
  458 |   await writeFile(testInfo.outputPath('worker-measurement.json'), JSON.stringify({ count, ...capture, ...progress, workers, equality }, null, 2));
  459 |   await page.getByRole('button', { name: '清空内存请求记录' }).click();
  460 |   await expect(page.getByText(/此阶段\/模式没有实际请求快照/)).toBeVisible();
  461 | });
  462 | 
  463 | const promptSwitches = manifest.modules.filter((item) =>
  464 |   ['noControl', 'naturalProse', 'actionOptions', 'realWorld'].includes(item.toggle?.split(':')[0] ?? ''),
  465 | );
  466 | const evidenceDir = 'docs/pr124-review/screenshots';
  467 | async function screenshot(page: Page, name: string) {
  468 |   if (name === 'preview-invalidated') {
  469 |     await page.getByText('写作偏好已修改，请重新组装预览。', { exact: true })
  470 |       .evaluate(element => element.scrollIntoView({ block: 'center' }));
  471 |   }
  472 |   await page.screenshot({ path: `${evidenceDir}/${page.viewportSize()!.width}-${name}.png`, animations: 'disabled', scale: 'css' });
  473 | }
  474 | 
  475 | test('四开关显式保存：双页联动、未保存刷新丢弃、保存刷新持久化与再次编辑提示', async ({ page }) => {
```
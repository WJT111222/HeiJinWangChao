# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: action-workflow.spec.ts >> 取消中的迟到响应不启动下游，刷新保留待生成草稿且明确恢复
- Location: e2e/action-workflow.spec.ts:165:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('details.workflow-disclosure > summary, .workflow-summary > .workflow-toggle')
    - locator resolved to <button type="button" aria-expanded="true" aria-label="三阶段工作流详情" class="workflow-toggle" aria-controls="workflow-pop">…</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <span class="workflow-fee">生成可能产生费用。</span> from <div class="app-shell-game workflow-drawer-root">…</div> subtree intercepts pointer events
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <span class="workflow-fee">生成可能产生费用。</span> from <div class="app-shell-game workflow-drawer-root">…</div> subtree intercepts pointer events
    - retrying click action
      - waiting 100ms
    41 × waiting for element to be visible, enabled and stable
       - element is visible, enabled and stable
       - scrolling into view if needed
       - done scrolling
       - <span class="workflow-fee">生成可能产生费用。</span> from <div class="app-shell-game workflow-drawer-root">…</div> subtree intercepts pointer events
     - retrying click action
       - waiting 500ms
    - waiting for element to be visible, enabled and stable

```

# Page snapshot

```yaml
- generic:
  - generic [ref=f1e1]:
    - banner:
      - button "打开游戏菜单" [ref=f1e2] [cursor=pointer]: ☰
    - main [ref=f1e3]:
      - generic "城市与当前场景" [ref=f1e4]:
        - button "此时此地与主角状态" [ref=f1e5] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e6]: 渝
          - generic [ref=f1e7]:
            - generic [ref=f1e8]: 重庆
            - generic [ref=f1e9]: 重庆
          - time [ref=f1e10]: "--:--"
          - generic "天气：天气待确认" [ref=f1e11]: —
        - generic [ref=f1e12]: 重庆，开局时间待确认 --:--，天气：天气待确认
      - region "剧情与行动" [ref=f1e13]:
        - generic "正文阅读区域" [ref=f1e14]:
          - generic [ref=f1e15]:
            - generic [ref=f1e16]: THE STORY
            - generic [ref=f1e17]: 生成预览 · 尚未保存
          - article "流式正文预览" [ref=f1e18]:
            - generic [ref=f1e19]:
              - generic [aria-hidden] [ref=f1e20]:
                - generic [ref=f1e21]: "1"
                - generic [ref=f1e22]:
                  - generic [ref=f1e23]: 第一回
                  - generic [ref=f1e24]: TURN 001
              - heading "第 1 回合" [level=2] [ref=f1e31]
              - generic [ref=f1e32]: 时间地点未记录 · 预览
            - text: 临时预览 · 完整校验前不保存
            - region "生成中的公开思考" [ref=f1e33]:
              - status [ref=f1e34]: 正在等待模型内容…
        - generic [ref=f1e35]:
          - region "三阶段工作流" [ref=f1e37]:
            - button "三阶段工作流详情" [expanded] [ref=f1e40] [cursor=pointer]:
              - status [ref=f1e45]:
                - generic [ref=f1e46]: 三阶段 ·
                - text: 正文生成中 · 1/3
              - generic [ref=f1e47]: 详情 ›
          - generic [ref=f1e48]:
            - button "回合操作" [ref=f1e50] [cursor=pointer]: ⋯
            - generic [ref=f1e51]: 你的行动
            - textbox "你的行动" [ref=f1e52]:
              - /placeholder: 填写你的行动
            - button "发送" [disabled] [ref=f1e54]
      - navigation "底部导航" [ref=f1e55]:
        - button "故事" [ref=f1e56] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e57]: 文
          - text: 故事
        - button "人物" [ref=f1e58] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e59]: 我
          - text: 人物
        - button "世界资料" [ref=f1e60] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e61]: 世
          - text: 世界资料
        - button "设置" [ref=f1e62] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e63]: 设
          - text: 设置
  - generic [ref=f1e64]:
    - button "收起工作流暗区" [ref=f1e65] [cursor=pointer]
    - dialog "三阶段工作流" [active] [ref=f1e66]:
      - generic [ref=f1e67]:
        - button "收起三阶段工作流" [ref=f1e68] [cursor=pointer]
        - button "行动输入" [ref=f1e70] [cursor=pointer]
      - region "三阶段详情" [ref=f1e71]:
        - generic [ref=f1e72]:
          - generic [ref=f1e73]:
            - text: THREE STAGES · 三阶段
            - heading "正文生成中 · 1/3" [level=3] [ref=f1e74]
          - button "收起三阶段详情" [ref=f1e75] [cursor=pointer]: ×
        - navigation "三阶段导航" [ref=f1e77]:
          - paragraph [ref=f1e78]: STAGES
          - list [ref=f1e79]:
            - listitem [ref=f1e80]:
              - button "01正文生成 生成中" [ref=f1e81] [cursor=pointer]:
                - strong [ref=f1e82]:
                  - generic [ref=f1e83]: "01"
                  - text: 正文生成
                - generic [ref=f1e84]: 生成中
            - listitem [ref=f1e85]:
              - button "02变量管理 待生成" [ref=f1e86] [cursor=pointer]:
                - strong [ref=f1e87]:
                  - generic [ref=f1e88]: "02"
                  - text: 变量管理
                - generic [ref=f1e89]: 待生成
              - generic "变量管理阶段开关" [ref=f1e90]:
                - checkbox "变量管理" [checked] [ref=f1e91]
            - listitem [ref=f1e92]:
              - button "03动态世界 待生成" [ref=f1e93] [cursor=pointer]:
                - strong [ref=f1e94]:
                  - generic [ref=f1e95]: "03"
                  - text: 动态世界
                - generic [ref=f1e96]: 待生成
              - generic "动态世界阶段开关" [ref=f1e97]:
                - checkbox "动态世界" [checked] [ref=f1e98]
          - paragraph [ref=f1e99]: 本回合
          - list [ref=f1e100]:
            - listitem [ref=f1e101]:
              - button "运行诊断 错误与用量" [ref=f1e102] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e103]: 诊
                - strong [ref=f1e104]: 运行诊断
                - generic [ref=f1e105]: 错误与用量
            - listitem [ref=f1e106]:
              - button "已绑定输入 只读" [ref=f1e107] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e108]: 述
                - strong [ref=f1e109]: 已绑定输入
                - generic [ref=f1e110]: 只读
        - generic [ref=f1e111]:
          - button "取消自动执行" [ref=f1e113] [cursor=pointer]
          - generic [ref=f1e114]: 生成可能产生费用。
```

# Test source

```ts
  68  |     const state = record(ctx.SAVE_STATE), number = Number(state.turnNumber) + 1;
  69  |     const pending = Boolean(ctx.OPENING_TIME && record(ctx.OPENING_TIME).status === 'pending');
  70  |     const anchor = pending ? '2015年7月8日14:00，重庆街头。' : '';
  71  |     const openingGuide = pending ? [{ group: 'time', subjectHint: 'time:opening', observedFact: JSON.stringify({ startAt: '2015-07-08T14:00:00+08:00', endAt: '2015-07-08T14:01:00+08:00' }), textEvidence: anchor }] : [];
  72  |     const text = plan.failure === stage && !plan.status ? '{invalid-json' : stage === 'story'
  73  |       ? `<thinking>本轮创作提纲：保持连续，按当前行动呈现事实。</thinking><正文>${anchor}第${number}幕。主角在街边观察周围，街道上人来人往。</正文><短期记忆>${plan.badSummary ? '' : `主角第${number}次在街边观察环境。`}</短期记忆><变量规划>${JSON.stringify(openingGuide)}</变量规划>`
  74  |       : (stage === 'variables' ? variableReply : JSON.stringify)(stage === 'variables' ? { commands: [{ type: 'SetWorldClock', commandId: 'clock', worldClock: ctx.OPENING_TIME ? string(record(ctx.OPENING_TIME).endAt) : new Date(Date.parse(string(state.worldClock)) + 60000).toISOString(), evidence: '主角在街边观察周围，街道上人来人往。' }], rejectedSuggestions: [], unresolved: [] }
  75  |         : { worldCommands: [], taskCommands: [], eventCommands: [], visibleHooks: [{ text: '尚未公开的内部线索' }], unresolved: [] });
  76  |     await route.fulfill({ status: plan.failure === stage ? plan.status ?? 200 : 200,
  77  |       contentType: stage === 'story' ? 'text/event-stream' : 'application/json',
  78  |       body: stage === 'story' ? `data: ${JSON.stringify({ choices: [{ delta: { content: text } }] })}\n\ndata: [DONE]\n\n`
  79  |         : JSON.stringify({ choices: [{ message: { content: text }, finish_reason: 'stop' }] }),
  80  |     }).catch(() => undefined);
  81  |   });
  82  |   return { calls, plan };
  83  | }
  84  | const workflow = (page: Page) => page.getByRole('region', { name: '三阶段工作流', exact: true });
  85  | async function ready(page: Page) {
  86  |   await expect(workflow(page).getByRole('status')).toContainText('本回合已结算');
  87  | }
  88  | 
  89  | test('一次创角确认自动执行开局三阶段，StrictMode和重复点击不重复请求', async ({ page }) => {
  90  |   await prepare(page); const server = await mock(page); await creation(page);
  91  |   await confirm(page); await ready(page);
  92  |   expect(server.calls.map((call) => call.stage)).toEqual(['story', 'variables', 'world']);
  93  |   const result = await stored(page); expect(result.state.turnNumber).toBe(1); expect(result.state.revision).toBe(1);
  94  |   expect(result.state.journal).toHaveLength(1); expect(result.draft.userInput).toBe(''); expect(result.draft.stageStatus).toEqual({ story: 'pending', variables: 'pending', world: 'pending' });
  95  |   expect(server.calls[0].context.CREATION_PROFILE).toBeTruthy();
  96  |   await expect(page.locator('.workflow-disclosure')).not.toHaveAttribute('open');
  97  |   await expect(page.getByRole('button', { name: '生成变量候选', exact: true })).toBeHidden();
  98  |   await expect(page.getByRole('button', { name: '继续推演', exact: true })).toHaveCount(0);
  99  |   await expect(page.locator('main')).not.toContainText('尚未公开的内部线索');
  100 |   await page.reload(); await ready(page); expect(await stored(page)).toEqual(result); expect(server.calls).toHaveLength(3);
  101 |   await goHome(page);
  102 |   await page.getByRole('button', { name: /读取存档/ }).click(); await ready(page); expect(server.calls).toHaveLength(3);
  103 | });
  104 | 
  105 | test('缺少AI配置零请求，设置后不自动补发，只在明确开始时运行', async ({ page }) => {
  106 |   await prepare(page, false); const server = await mock(page); await creation(page);
  107 |   await expect(page.locator('.notice')).toContainText('生成可能产生费用'); await confirm(page);
  108 |   await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toContainText('配置'); expect(server.calls).toHaveLength(0);
  109 |   const before = await stored(page); await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  110 |   await page.getByRole('button', { name: '打开 AI 设置', exact: true }).click();
  111 |   const settings = await aiTab(page);
  112 |   await addChannel(settings, { preset: 'OpenAI 兼容', name: '行动测试', url: 'https://action.mock.invalid/v1', key: 'mock-action-key' });
  113 |   // 填好后只自动读取模型列表（不产生费用）；从真实设置给三个阶段选同一渠道的不同模型，不通过生成请求探测模型。
  114 |   await expect(settings.locator('.ai-connect')).toContainText('连接正常');
  115 |   for (const [label, model] of [['正文生成', 'story'], ['变量管理', 'variables'], ['动态世界', 'world']]) await stageModel(settings, label, '行动测试', model, 'list');
  116 |   await saveAi(settings);
  117 |   await page.getByRole('button', { name: '关闭资料界面', exact: true }).click(); expect(server.calls).toHaveLength(0);
  118 |   expect(await stored(page)).toEqual(before);
  119 |   await page.getByRole('button', { name: '继续未完成阶段', exact: true }).click(); await ready(page);
  120 |   expect(server.calls.map((call) => call.stage)).toEqual(['story', 'variables', 'world']);
  121 | });
  122 | 
  123 | test('发送行动只结算一次并自动串联下一轮，刷新及再次读档不补发', async ({ page }) => {
  124 |   await prepare(page); const server = await mock(page); await creation(page); await confirm(page); await ready(page);
  125 |   const before = await stored(page); await page.getByLabel('你的行动', { exact: true }).fill('在街边继续观察');
  126 |   await page.getByRole('button', { name: '发送', exact: true }).evaluate((button: HTMLButtonElement) => { button.click(); button.click(); });
  127 |   await expect(page.getByTestId('story-reader')).toContainText('第2幕'); await ready(page);
  128 |   const after = await stored(page); expect(after.state.revision).toBe(2); expect(after.state.journal).toHaveLength(2);
  129 |   expect(after.state.memories.short).toHaveLength(2); expect(after.draft.userInput).toBe('');
  130 |   expect(after.state.economy).toEqual(before.state.economy); expect(after.state.npc).toEqual(before.state.npc);
  131 |   expect(server.calls.map((call) => call.stage)).toEqual(['story', 'variables', 'world', 'story', 'variables', 'world']);
  132 |   expect(server.calls[0].context.CREATION_PROFILE).toBeTruthy(); expect(server.calls[3].context.CREATION_PROFILE).toBeUndefined();
  133 |   expect(server.calls[3].context.PLAYER_ACTION).toBe('在街边继续观察');
  134 |   await page.reload(); await ready(page); expect(await stored(page)).toEqual(after); expect(server.calls).toHaveLength(6);
  135 | });
  136 | 
  137 | for (const stage of ['variables', 'world'] as const) {
  138 |   test(`${stage}失败保留上游，仅明确恢复缺少阶段，折叠无额外请求`, async ({ page }) => {
  139 |     await prepare(page); const server = await mock(page); server.plan.failure = stage;
  140 |     await creation(page); await confirm(page); await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toBeVisible();
  141 |     const failed = await stored(page); expect(failed.state.revision).toBe(0); expect(failed.draft.story).toBeTruthy();
  142 |     expect(server.calls.map((call) => call.stage)).toEqual(stage === 'variables' ? ['story', 'variables'] : ['story', 'variables', 'world']);
  143 |     await page.getByLabel('你的行动', { exact: true }).fill('下一步行动'); await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  144 |     await workflowTrigger(page).click(); await workflowTrigger(page).click();
  145 |     expect(server.calls).toHaveLength(stage === 'variables' ? 2 : 3);
  146 |     await page.reload(); await openWorkflow(page); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeEnabled();
  147 |     expect(await stored(page)).toEqual(failed); server.plan.failure = undefined;
  148 |     await page.getByRole('button', { name: '继续未完成阶段', exact: true }).evaluate((button: HTMLButtonElement) => { button.click(); button.click(); });
  149 |     await ready(page); const after = await stored(page); expect(after.state.revision).toBe(1); expect(after.state.journal[0].story).toEqual(failed.draft.story); expect(after.draft.userInput).toBe('');
  150 |     expect(server.calls.map((call) => call.stage)).toEqual(stage === 'variables' ? ['story', 'variables', 'variables', 'world'] : ['story', 'variables', 'world', 'world']);
  151 |   });
  152 | }
  153 | 
  154 | for (const status of [401, 403, 429]) {
  155 |   test(`自动开局HTTP ${status}停止、不无限重试，刷新不重新授权`, async ({ page }) => {
  156 |     await prepare(page); const server = await mock(page); server.plan.failure = 'story'; server.plan.status = status;
  157 |     await creation(page); await confirm(page); await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toBeVisible();
  158 |     expect(server.calls.map((call) => call.stage)).toEqual(['story']); const failed = await stored(page);
  159 |     expect(failed.draft.story).toBeUndefined(); expect(failed.state.revision).toBe(0);
  160 |     await page.reload(); await openWorkflow(page); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeEnabled();
  161 |     expect(server.calls).toHaveLength(1); expect(await stored(page)).toEqual(failed);
  162 |   });
  163 | }
  164 | 
  165 | test('取消中的迟到响应不启动下游，刷新保留待生成草稿且明确恢复', async ({ page }, info) => {
  166 |   await prepare(page); const server = await mock(page), held = gate(); server.plan.hold = 'story'; server.plan.gate = held.pending;
  167 |   await creation(page); await confirm(page); await expect.poll(() => server.calls.length).toBe(1);
> 168 |   await workflowTrigger(page).click(); await workflowTrigger(page).click();
      |                                                                    ^ Error: locator.click: Test timeout of 30000ms exceeded.
  169 |   expect(server.calls).toHaveLength(1); await openWorkflow(page);
  170 |   if (info.project.name === 'desktop') {
  171 |     await page.setViewportSize({ width: 1024, height: 520 });
  172 |     await expect(page.getByRole('button', { name: '取消自动执行', exact: true })).toBeInViewport({ ratio: 1 });
  173 |     await expect(page.getByRole('button', { name: '发送', exact: true })).toBeInViewport({ ratio: 1 });
  174 |     await page.screenshot({ path: 'docs/ui-pc-reading/screenshots/after-running-short-pc.png' });
  175 |   }
  176 |   await page.getByRole('button', { name: '取消自动执行', exact: true }).click();
  177 |   await expect(workflow(page).getByRole('status')).toContainText('取消'); held.release();
  178 |   const cancelled = await stored(page); expect(cancelled.draft.story).toBeUndefined(); expect(cancelled.state.revision).toBe(0);
  179 |   await page.reload(); await openWorkflow(page); await expect(page.getByRole('button', { name: '自动生成开局', exact: true })).toBeEnabled();
  180 |   expect(server.calls).toHaveLength(1); server.plan.hold = undefined;
  181 |   await page.getByRole('button', { name: '自动生成开局', exact: true }).click(); await ready(page); expect(server.calls).toHaveLength(4);
  182 | });
  183 | 
  184 | test('快速离开并重读同一存档或新标签不能延续开局收费授权', async ({ page, context }) => {
  185 |   await prepare(page); const server = await mock(page), held = gate(); server.plan.hold = 'variables'; server.plan.gate = held.pending;
  186 |   await creation(page); await confirm(page); await expect.poll(() => server.calls.length).toBe(2);
  187 |   const url = page.url(); await goHome(page);
  188 |   await page.getByRole('button', { name: /读取存档/ }).click();
  189 |   await openWorkflow(page); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeVisible();
  190 |   const other = await context.newPage(); let otherRequests = 0;
  191 |   await other.route('https://action.mock.invalid/**', async (route) => { otherRequests++; await route.abort(); });
  192 |   await other.goto(url); await expect(other.locator('.game-layout')).toBeVisible();
  193 |   held.release(); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeEnabled();
  194 |   expect(server.calls).toHaveLength(2); expect(otherRequests).toBe(0); const after = await stored(page); expect(after.draft.world).toBeUndefined(); expect(after.state.revision).toBe(0);
  195 |   await other.close();
  196 | });
  197 | 
  198 | test('关闭变量时世界只能预览，不因自动开局而强行启用或允许发送', async ({ page }) => {
  199 |   await prepare(page, true, { variables: false, world: true }); const server = await mock(page); await creation(page); await confirm(page);
  200 |   await expect(workflow(page).getByRole('status')).toContainText('预览');
  201 |   expect(server.calls.map((call) => call.stage)).toEqual(['story', 'world']); const result = await stored(page);
  202 |   expect(result.draft.world?.validation).toBe('preview'); expect(result.draft.variables).toBeUndefined(); expect(result.state.revision).toBe(0);
  203 |   await page.getByLabel('你的行动', { exact: true }).fill('继续观察'); await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  204 | });
  205 | 
  206 | test('正文摘要不合法时不保存、不运行下游、不结算', async ({ page }) => {
  207 |   await prepare(page); const server = await mock(page); server.plan.badSummary = true; await creation(page); await confirm(page);
  208 |   await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toBeVisible(); expect(server.calls.map((call) => call.stage)).toEqual(['story']);
  209 |   const result = await stored(page); expect(result.draft.story).toBeUndefined(); expect(result.state.journal).toEqual([]);
  210 |   await page.getByLabel('你的行动', { exact: true }).fill('继续'); await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  211 | });
  212 | 
  213 | test('开局组件加载前刷新销毁授权，未生成草稿保留且仅主动开始才请求', async ({ page }) => {
  214 |   await prepare(page); const server = await mock(page), held = gate(); let loading = false;
  215 |   const modulePath = '**/src/ui/game/GameScreen.tsx*';
  216 |   await page.route(modulePath, async (route) => { loading = true; await held.pending; await route.continue().catch(() => undefined); });
  217 |   await creation(page); await page.getByRole('button', { name: '确认并创建存档', exact: true }).click();
  218 |   await expect.poll(() => loading).toBe(true); expect(server.calls).toHaveLength(0);
  219 |   await page.unroute(modulePath); await page.reload(); held.release();
  220 |   await openWorkflow(page); await expect(page.getByRole('button', { name: '自动生成开局', exact: true })).toBeEnabled();
  221 |   const before = await stored(page); expect(before.draft.draftRevision).toBe(0); expect(before.draft.story).toBeUndefined(); expect(server.calls).toHaveLength(0);
  222 |   await page.getByRole('button', { name: '自动生成开局', exact: true }).click(); await ready(page); expect(server.calls).toHaveLength(3);
  223 | });
  224 | 
  225 | for (const failure of ['network', 'timeout'] as const) {
  226 |   test(`开局${failure}不隐式重试，刷新不重发，草稿和正式状态安全`, async ({ page }) => {
  227 |     await prepare(page);
  228 |     if (failure === 'timeout') {
  229 |       await page.evaluate(() => {
  230 |         const key = 'heijin.settings.v1', settings = JSON.parse(localStorage.getItem(key)!);
  231 |         settings.runtime.timeoutSeconds = 1; localStorage.setItem(key, JSON.stringify(settings));
  232 |       });
  233 |       await page.reload();
  234 |     }
  235 |     const server = await mock(page), held = gate();
  236 |     if (failure === 'network') { server.plan.failure = 'story'; server.plan.network = true; }
  237 |     else { server.plan.hold = 'story'; server.plan.gate = held.pending; }
  238 |     await creation(page); await confirm(page);
  239 |     await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toContainText(failure === 'network' ? '网络请求失败' : '超时');
  240 |     held.release(); expect(server.calls.map((call) => call.stage)).toEqual(['story']);
  241 |     const failed = await stored(page); expect(failed.state.revision).toBe(0); expect(failed.draft.story).toBeUndefined();
  242 |     await page.reload(); await openWorkflow(page); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeEnabled();
  243 |     expect(server.calls).toHaveLength(1); expect(await stored(page)).toEqual(failed);
  244 |   });
  245 | }
  246 | 
  247 | for (const disabled of ['world', 'variables'] as const) {
  248 |   test(`关闭阶段时${disabled}：不显示无效继续，引导启用后只补必要候选并正常发送`, async ({ page }) => {
  249 |     test.setTimeout(60000);
  250 |     await prepare(page, true, { variables: disabled !== 'variables', world: disabled !== 'world' });
  251 |     const server = await mock(page); await creation(page); await confirm(page);
  252 |     await expect(workflow(page).getByRole('status')).toContainText(disabled === 'world' ? '阶段已关闭' : '预览');
  253 |     const before = await stored(page), initial = disabled === 'world' ? ['story', 'variables'] : ['story', 'world'];
  254 |     expect(server.calls.map((call) => call.stage)).toEqual(initial);
  255 |     await expect(workflow(page).getByRole('button', { name: '继续未完成阶段', exact: true })).toHaveCount(0);
  256 |     await expect(page.locator('.workflow-disclosure')).not.toHaveAttribute('open');
  257 |     await openWorkflow(page);
  258 |     const guidance = workflow(page).getByRole('note', { name: '阶段设置提示', exact: true });
  259 |     await expect(guidance).toContainText(disabled === 'world' ? '动态世界阶段已关闭' : '变量阶段未启用，当前世界结果仅为预览');
  260 |     await workflowTrigger(page).click();
  261 |     await expect(page.locator('.workflow-disclosure')).not.toHaveAttribute('open');
  262 |     await page.getByLabel('你的行动', { exact: true }).fill('继续观察街道');
  263 |     await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  264 |     await page.reload();
  265 |     await openWorkflow(page); await expect(guidance).toBeVisible();
  266 |     await page.getByLabel('你的行动', { exact: true }).fill('继续观察街道');
  267 |     await expect(workflow(page).getByRole('button', { name: '继续未完成阶段', exact: true })).toHaveCount(0);
  268 |     expect(await stored(page)).toEqual(before); expect(server.calls.map((call) => call.stage)).toEqual(initial);
```
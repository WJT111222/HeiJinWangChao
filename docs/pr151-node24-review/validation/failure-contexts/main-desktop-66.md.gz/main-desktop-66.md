# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: prompt-inspector.spec.ts >> 无存档浏览真实模块、过滤与全文，缺少阶段请求时不伪造使用量
- Location: e2e/prompt-inspector.spec.ts:85:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  getByRole('region', { name: '模块原文' }).getByRole('button', { name: '初始化', exact: true })
Expected: "true"
Received: ""

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - main [ref=e4]:
    - region "游戏首页" [ref=e5]:
      - generic [ref=e7]:
        - text: GUANGZHOU · 23°07′N
        - generic [ref=e8]: 早茶 · 榕荫 · 珠江
      - generic [aria-hidden] [ref=e9]: 广州
      - generic [ref=e10]:
        - generic [ref=e11]:
          - generic [aria-hidden] [ref=e12]: 黑
          - generic [ref=e13]:
            - text: 黑金王朝
            - generic [ref=e14]: HEIJINWANGCHAO
        - button "存档馆" [ref=e15] [cursor=pointer]
        - button "设置" [ref=e16] [cursor=pointer]
        - generic [ref=e17]: V1.0 Beta
      - generic [ref=e18]:
        - paragraph [ref=e19]: MODERN CITY / OPEN WORLD
        - heading "黑金王朝" [level=1] [ref=e20]
        - paragraph [ref=e21]: 起点有冲突，人生不预设结局。
        - paragraph [ref=e22]: 一款 AI 驱动的现代都市开放世界文字角色扮演游戏。在熟悉的城市里，写下属于你的人生。
        - generic [ref=e23]:
          - button "开始新游戏" [ref=e24] [cursor=pointer]:
            - text: 开始新游戏
            - generic [aria-hidden] [ref=e25]: ↗
          - button "继续游戏 暂无可继续的存档" [disabled] [ref=e26]:
            - generic [ref=e27]: 继续游戏
            - generic [ref=e28]: 暂无可继续的存档
            - generic [aria-hidden] [ref=e29]: →
          - button "存档馆00" [ref=e30] [cursor=pointer]
        - group "游玩信息" [ref=e31]:
          - button "游玩须知与免责声明" [ref=e32] [cursor=pointer]
          - button "王朝公告" [ref=e33] [cursor=pointer]
      - generic [ref=e34]:
        - generic [ref=e35]:
          - generic [ref=e36]: 四座城市 · 自由职业 · 开放人生
          - generic [ref=e37]: 三阶段生成 · 原子结算 · 连续回合
        - navigation "封面城市" [ref=e38]:
          - button "重庆" [pressed] [ref=e39] [cursor=pointer]
          - button "上海" [ref=e40] [cursor=pointer]
          - button "哈尔滨" [ref=e41] [cursor=pointer]
          - button "广州" [ref=e42] [cursor=pointer]
  - dialog [ref=e43]:
    - banner [ref=e44]:
      - generic [aria-hidden] [ref=e45]: 设
      - generic [ref=e46]:
        - generic [aria-hidden] [ref=e47]: SYSTEM · 系统
        - heading "设置" [level=2] [ref=e48]
        - text: 本地偏好与 AI 渠道
      - generic [aria-hidden] [ref=e49]: ESC
      - button "关闭资料界面" [ref=e50] [cursor=pointer]: 关闭 ×
    - generic [ref=e52]:
      - navigation "设置分类" [ref=e53]:
        - button "AI 连接" [ref=e54] [cursor=pointer]:
          - generic [aria-hidden] [ref=e55]: 连
        - button "提示词" [ref=e57] [cursor=pointer]:
          - generic [aria-hidden] [ref=e58]: 词
        - button "记忆" [ref=e60] [cursor=pointer]:
          - generic [aria-hidden] [ref=e61]: 忆
        - button "运行" [ref=e63] [cursor=pointer]:
          - generic [aria-hidden] [ref=e64]: 运
        - button "提示词管理" [pressed] [ref=e66] [cursor=pointer]:
          - generic [aria-hidden] [ref=e67]: 管
        - group "游玩信息" [ref=e69]:
          - button "游玩须知与免责声明" [ref=e70] [cursor=pointer]
          - button "王朝公告" [ref=e71] [cursor=pointer]
      - generic [ref=e72]:
        - heading "提示词管理" [level=3] [ref=e73]
        - region "模块原文" [ref=e75]:
          - generic [ref=e76]:
            - button "‹ 返回列表" [ref=e77] [cursor=pointer]
            - button "高级" [ref=e78] [cursor=pointer]:
              - generic [aria-hidden] [ref=e79]: ⚙
              - text: 高级
          - heading "主角 · 变量规则" [level=4] [ref=e80]
          - paragraph [ref=e81]:
            - generic [ref=e82]: 变量规则
            - generic [ref=e83]: 1,525 字
            - generic [ref=e84]: 变量
            - generic [ref=e85]: 按需
          - generic [ref=e86]:
            - group "规则阶段" [ref=e87]:
              - button "初始化" [active] [pressed] [ref=e88] [cursor=pointer]
              - button "常规更新" [ref=e89] [cursor=pointer]
              - button "场外规则" [ref=e90] [cursor=pointer]
            - group "变量格式" [ref=e91]:
              - button "JSON 变量" [ref=e92] [cursor=pointer]
              - button "文本变量" [pressed] [ref=e93] [cursor=pointer]
          - paragraph [ref=e94]:
            - generic [ref=e95]: 什么时候用
            - generic [ref=e96]: 本回合涉及「主角」时，才会加进变量请求。
          - generic "模块完整原文" [ref=e97]: 正在读取真实资源…
          - paragraph [ref=e98]:
            - generic [ref=e99]: 尚未读取
            - generic [ref=e100]: 原文只读
          - group [ref=e101]:
            - generic "技术信息" [ref=e102] [cursor=pointer]
        - generic [ref=e103]:
          - status
          - button "保存本地设置" [ref=e104] [cursor=pointer]
```

# Test source

```ts
  47  |           narrative: '【旁白】你在街边观察。',
  48  |           summary: '',
  49  |           variableGuide: [],
  50  |         }),
  51  |         0,
  52  |       );
  53  |     }
  54  |     opened.close();
  55  |     return JSON.stringify(state);
  56  |   }, ready);
  57  | }
  58  | async function inspector(page: Page, advanced = true) {
  59  |   await page.getByRole('button', { name: '设置', exact: true }).click();
  60  |   await page.getByRole('button', { name: '提示词管理', exact: true }).click();
  61  |   await expect(page.getByRole('region', { name: '模块库' })).toBeVisible();
  62  |   if (advanced) await openAdvanced(page);
  63  | }
  64  | async function openAdvanced(page: Page) {
  65  |   await page.getByRole('button', { name: '高级', exact: true }).click();
  66  |   await expect(page.getByRole('region', { name: '高级' })).toBeVisible();
  67  | }
  68  | async function backToList(page: Page) {
  69  |   await page.getByRole('region', { name: '高级' }).getByRole('button', { name: /返回列表/ }).click();
  70  |   await expect(page.getByRole('region', { name: '模块库' })).toBeVisible();
  71  | }
  72  | async function readFormal(page: Page) {
  73  |   return page.evaluate(async () => {
  74  |     const path = '/src/services/storage/saveRepository.ts';
  75  |     const { SaveRepository } = await import(path);
  76  |     const repo = await SaveRepository.open();
  77  |     try {
  78  |       return JSON.stringify(await repo.load('ui-test'));
  79  |     } finally {
  80  |       repo.close();
  81  |     }
  82  |   });
  83  | }
  84  | 
  85  | test('无存档浏览真实模块、过滤与全文，缺少阶段请求时不伪造使用量', async ({ page, baseURL }) => {
  86  |   const external: string[] = [];
  87  |   page.on('request', (request) => {
  88  |     if (new URL(request.url()).origin !== new URL(baseURL!).origin) external.push(request.url());
  89  |   });
  90  |   await page.goto('/');
  91  |   await inspector(page, false);
  92  |   const moduleCount = manifest.modules.length;
  93  |   const variableModules = manifest.modules.filter((item) => item.category === 'variable_group');
  94  |   const variableDomains = new Set(variableModules.map((item) => item.domain)).size;
  95  |   const groups = page.getByRole('group', { name: '提示词分类' });
  96  |   await expect(groups.getByRole('button', { name: /^全部/ })).toContainText(String(moduleCount));
  97  |   await expect(page.locator('.pm-list [data-prompt-id]')).toHaveCount(moduleCount - variableModules.length);
  98  |   await expect(page.locator('.pm-list [data-domain]')).toHaveCount(variableDomains);
  99  |   await openAdvanced(page);
  100 |   await page.getByText('开局与普通回合的模块差异', { exact: true }).click();
  101 |   await expect(page.getByRole('region', { name: '回合模式差异' })).toContainText(
  102 |     'stages.opening.story',
  103 |   );
  104 |   await expect(page.getByRole('region', { name: '回合模式差异' })).toContainText(
  105 |     'stages.regular.story',
  106 |   );
  107 |   await expect(page.getByRole('button', { name: '生成三阶段组装预览（不联网）' })).toBeDisabled();
  108 |   await expect(
  109 |     page.getByText('没有已选存档，无法组装游戏上下文。模块资源仍可浏览。'),
  110 |   ).toBeVisible();
  111 |   await backToList(page);
  112 |   await page.getByLabel('搜索模块', { exact: true }).fill('writing.nsfw');
  113 |   await expect(page.locator('.pm-list [data-prompt-id]')).toHaveCount(1);
  114 |   await page.locator('.pm-list [data-prompt-id="writing.nsfw"] .pm-open').click();
  115 |   const source = page.getByRole('region', { name: '模块原文' });
  116 |   await expect(source).toContainText('prompts/writing/nsfw.md');
  117 |   await expect(source).toContainText('所属阶段常驻 · 不可关闭');
  118 |   await expect(page.getByLabel('模块完整原文')).not.toContainText('正在读取');
  119 |   await expect(page.getByLabel('模块完整原文')).not.toBeEmpty();
  120 |   await source.getByRole('button', { name: /返回列表/ }).click();
  121 |   await page.getByLabel('搜索模块', { exact: true }).fill('');
  122 |   await groups.getByRole('button', { name: /^参考资料/ }).click();
  123 |   await expect(page.locator('.pm-list [data-prompt-id]')).toHaveCount(
  124 |     manifest.modules.filter((item) => ['documentation', 'example', 'reference'].includes(item.category)).length,
  125 |   );
  126 |   await groups.getByRole('button', { name: /^记忆/ }).click();
  127 |   await expect(page.locator('.pm-list [data-prompt-id]')).toHaveCount(5);
  128 |   await groups.getByRole('button', { name: /^变量规则/ }).click();
  129 |   await page.getByRole('button', { name: '查看主角常规更新规则', exact: true }).click();
  130 |   await expect(source).toContainText('主角 · 变量规则');
  131 |   await expect(source.getByRole('button', { name: '文本变量', exact: true })).toHaveAttribute('aria-pressed', 'true');
  132 |   await source.getByRole('button', { name: 'JSON 变量', exact: true }).click();
  133 |   await expect(source).toContainText('variableGroups.protagonist.update');
  134 |   await expect(source).not.toContainText('variableGroups.protagonist.update.text');
  135 |   for (const format of ['json', 'text'] as const) {
  136 |     await source.getByRole('button', { name: format === 'json' ? 'JSON 变量' : '文本变量', exact: true }).click();
  137 |     const id = `variableGroups.protagonist.update${format === 'text' ? '.text' : ''}`;
  138 |     const expected = await page.evaluate(async id => {
  139 |       const path = '/src/prompts/loader.ts';
  140 |       return (await import(path)).readPromptResource(id);
  141 |     }, id);
  142 |     await expect(page.getByLabel('模块完整原文')).toHaveText(expected);
  143 |     await screenshot(page, `source-${format}`);
  144 |   }
  145 |   for (const label of ['初始化', '场外规则', '常规更新']) {
  146 |     await source.getByRole('group', { name: '规则阶段' }).getByRole('button', { name: label, exact: true }).click();
> 147 |     await expect(source.getByRole('button', { name: label, exact: true })).toHaveAttribute('aria-pressed', 'true');
      |                                                                            ^ Error: expect(locator).toHaveAttribute(expected) failed
  148 |     await expect(page.getByLabel('模块完整原文')).not.toBeEmpty();
  149 |   }
  150 |   await source.getByRole('button', { name: '高级', exact: true }).click();
  151 |   await page.getByRole('combobox', { name: '数据来源', exact: true }).selectOption('actual');
  152 |   await expect(page.getByText(/此阶段\/模式没有实际请求快照/)).toBeVisible();
  153 |   await expect(page.getByRole('button', { name: '主动查看完整内部上下文' })).toHaveCount(0);
  154 |   await expect(page.getByRole('region', { name: '上下文与统计' })).toContainText('未提供');
  155 |   expect(external).toEqual([]);
  156 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  157 | });
  158 | 
  159 | test('真实存档六种模式预览、内部内容主动揭示、合法排序保存恢复及状态隔离', async ({
  160 |   page,
  161 | }, testInfo) => {
  162 |   const errors: string[] = [];
  163 |   page.on('pageerror', (error) => errors.push(error.message));
  164 |   const before = await seed(page);
  165 |   await page.reload();
  166 |   await inspector(page);
  167 |   await page.getByRole('combobox', { name: '回合模式', exact: true }).selectOption('regular');
  168 |   await page.getByRole('button', { name: '下移 writing.conflict_pacing', exact: true }).click();
  169 |   await expect(page.getByRole('button', { name: '保存提示词排序' })).toBeEnabled();
  170 |   await page.getByRole('combobox', { name: '检查阶段', exact: true }).selectOption('variables');
  171 |   await expect(page.getByRole('button', { name: '保存提示词排序' })).toBeEnabled();
  172 |   await page.getByRole('combobox', { name: '检查阶段', exact: true }).selectOption('story');
  173 |   const order = page.locator('.prompt-order-list li');
  174 |   await expect(order.first()).toContainText('identity.fusheng');
  175 |   await expect(page.locator('[data-module-id="identity.fusheng"]')).toContainText('固定');
  176 |   await page.getByRole('button', { name: '保存提示词排序' }).click();
  177 |   await page.getByRole('button', { name: '生成三阶段组装预览（不联网）' }).click();
  178 |   await expect(
  179 |     page.getByText('预览已组装；未发送 API 请求、未执行回合、未写入正式存档。'),
  180 |   ).toBeVisible();
  181 |   await expect(page.locator('.stage-stat-cards')).toContainText('离线预览');
  182 |   await expect(page.getByRole('region', { name: '上下文与统计' })).toContainText('当前模型上下文窗口未知，无法确认请求是否超限。');
  183 |   await page.getByText('展开数据分类、召回预算与重复诊断', { exact: true }).click();
  184 |   await expect(page.getByRole('region', { name: '上下文与统计' })).toContainText('召回预算只影响旧journal原文，不影响完整正式世界状态。');
  185 |   await expect(page.getByRole('region', { name: '上下文与统计' })).toContainText('字符差额 0，字节差额 0');
  186 |   for (const stage of ['story', 'variables', 'world']) {
  187 |     await page.getByRole('combobox', { name: '检查阶段', exact: true }).selectOption(stage);
  188 |     await expect(
  189 |       page.locator(`.prompt-order-list [data-module-id="stages.regular.${stage}${stage === 'variables' ? '.text' : ''}"]`),
  190 |     ).toBeVisible();
  191 |     await expect(page.getByLabel('完整内部上下文', { exact: true })).toHaveCount(0);
  192 |     await expect(page.getByRole('region', { name: '上下文与统计' })).not.toContainText(
  193 |       '秘密计划不可见',
  194 |     );
  195 |   }
  196 |   await page.screenshot({ path: testInfo.outputPath('prompt-inspector.png') });
  197 |   await page.getByRole('button', { name: '主动查看完整内部上下文' }).click();
  198 |   await page.getByRole('combobox', { name: '内部内容视图', exact: true }).selectOption('context');
  199 |   await expect(page.getByLabel('完整内部上下文', { exact: true })).toContainText('秘密计划不可见');
  200 |   await expect(page.getByLabel('完整内部上下文', { exact: true })).toContainText('OFFSCREEN_STATE');
  201 |   await page.getByRole('combobox', { name: '检查阶段', exact: true }).selectOption('story');
  202 |   await expect(page.getByLabel('完整内部上下文', { exact: true })).toHaveCount(0);
  203 |   await page.getByRole('button', { name: '主动查看完整内部上下文' }).click();
  204 |   await expect(page.getByLabel('完整内部上下文', { exact: true })).toContainText('秘密计划不可见');
  205 |   await page.getByRole('combobox', { name: '回合模式', exact: true }).selectOption('opening');
  206 |   await page.getByRole('button', { name: '生成三阶段组装预览（不联网）' }).click();
  207 |   await expect(
  208 |     page.getByText('预览已组装；未发送 API 请求、未执行回合、未写入正式存档。'),
  209 |   ).toBeVisible();
  210 |   await expect(page.locator('[data-module-id="stages.opening.story"]')).toBeVisible();
  211 |   await page.getByRole('combobox', { name: '检查阶段', exact: true }).selectOption('variables');
  212 |   await expect(page.getByRole('region', { name: '上下文与统计' })).toContainText('模式不匹配');
  213 |   expect(await readFormal(page)).toBe(before);
  214 |   await page.reload();
  215 |   await inspector(page);
  216 |   const saved = await page.evaluate(() =>
  217 |     JSON.parse(localStorage.getItem('heijin.prompt-order.v1')!),
  218 |   );
  219 |   expect(saved.overrides['writing.conflict_pacing']).toBe(81);
  220 |   const ids = await page
  221 |     .locator('.prompt-order-list li')
  222 |     .evaluateAll((items) => items.map((item) => item.getAttribute('data-module-id')));
  223 |   expect(ids.indexOf('writing.emotion_guard')).toBeLessThan(ids.indexOf('writing.conflict_pacing'));
  224 |   await page.getByRole('button', { name: '恢复默认顺序' }).click();
  225 |   const reset = await page
  226 |     .locator('.prompt-order-list li')
  227 |     .evaluateAll((items) => items.map((item) => item.getAttribute('data-module-id')));
  228 |   expect(reset.indexOf('writing.conflict_pacing')).toBeLessThan(
  229 |     reset.indexOf('writing.emotion_guard'),
  230 |   );
  231 |   await page.keyboard.press('Escape');
  232 |   await openLibrary(page);await page.getByRole('button', { name: /读取存档/ }).click();
  233 |   await expect(page.locator('.game-layout')).toBeVisible();
  234 |   await openWorldArchive(page);
  235 |   await page
  236 |     .getByRole('complementary', { name: '世界资料' })
  237 |     .getByRole('button', { name: /NPC/ })
  238 |     .click();
  239 |   await expect(page.getByRole('dialog', { name: 'NPC', exact: true })).toContainText('隐藏人物不可见');
  240 |   expect(await readFormal(page)).toBe(before);
  241 |   expect(errors).toEqual([]);
  242 | });
  243 | 
  244 | test('已发送阶段快照保留原请求数据与真实 usage，默认隐藏秘密且始终去密钥，刷新不持久化', async ({
  245 |   page,
  246 | }, testInfo) => {
  247 |   const before = await seed(page);
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: action-workflow.spec.ts >> 取消中的迟到响应不启动下游，刷新保留待生成草稿且明确恢复
- Location: e2e/action-workflow.spec.ts:165:1

# Error details

```
Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic:
  - generic [ref=f1e1]:
    - banner:
      - button "打开游戏菜单" [ref=f1e2] [cursor=pointer]: ☰
    - main [ref=f1e3]:
      - generic "城市与当前场景" [ref=f1e4]:
        - button "此时此地与主角状态" [ref=f1e5] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e6]: 渝
          - generic [ref=f1e7]:
            - generic [ref=f1e8]: 重庆
            - generic [ref=f1e9]: 重庆
          - time [ref=f1e10]: "--:--"
          - generic "天气：天气待确认" [ref=f1e11]: —
        - generic [ref=f1e12]: 重庆，开局时间待确认 --:--，天气：天气待确认
      - region "剧情与行动" [ref=f1e13]:
        - generic "正文阅读区域" [ref=f1e14]:
          - generic [ref=f1e15]:
            - generic [ref=f1e16]: THE STORY
            - generic [ref=f1e17]: 生成预览 · 尚未保存
          - article "流式正文预览" [ref=f1e18]:
            - generic [ref=f1e19]:
              - generic [aria-hidden] [ref=f1e20]:
                - generic [ref=f1e21]: "1"
                - generic [ref=f1e22]:
                  - generic [ref=f1e23]: 第一回
                  - generic [ref=f1e24]: TURN 001
              - heading "第 1 回合" [level=2] [ref=f1e31]
              - generic [ref=f1e32]: 时间地点未记录 · 预览
            - text: 临时预览 · 完整校验前不保存
            - region "生成中的公开思考" [ref=f1e33]:
              - status [ref=f1e34]: 正在等待模型内容…
        - generic [ref=f1e35]:
          - region "三阶段工作流" [ref=f1e37]:
            - button "三阶段工作流详情" [expanded] [ref=f1e40] [cursor=pointer]:
              - status [ref=f1e45]:
                - generic [ref=f1e46]: 三阶段 ·
                - text: 正文生成中 · 1/3
              - generic [ref=f1e47]: 详情 ›
          - generic [ref=f1e48]:
            - button "回合操作" [ref=f1e50] [cursor=pointer]: ⋯
            - generic [ref=f1e51]: 你的行动
            - textbox "你的行动" [ref=f1e52]:
              - /placeholder: 填写你的行动
            - button "发送" [disabled] [ref=f1e54]
      - navigation "底部导航" [ref=f1e55]:
        - button "故事" [ref=f1e56] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e57]: 文
          - text: 故事
        - button "人物" [ref=f1e58] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e59]: 我
          - text: 人物
        - button "世界资料" [ref=f1e60] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e61]: 世
          - text: 世界资料
        - button "设置" [ref=f1e62] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e63]: 设
          - text: 设置
  - generic [ref=f1e64]:
    - button "收起工作流暗区" [ref=f1e65] [cursor=pointer]
    - dialog "三阶段工作流" [active] [ref=f1e66]:
      - generic [ref=f1e67]:
        - button "收起三阶段工作流" [ref=f1e68] [cursor=pointer]
        - button "行动输入" [ref=f1e70] [cursor=pointer]
      - region "三阶段详情" [ref=f1e71]:
        - generic [ref=f1e72]:
          - generic [ref=f1e73]:
            - text: THREE STAGES · 三阶段
            - heading "正文生成中 · 1/3" [level=3] [ref=f1e74]
          - button "收起三阶段详情" [ref=f1e75] [cursor=pointer]: ×
        - navigation "三阶段导航" [ref=f1e77]:
          - paragraph [ref=f1e78]: STAGES
          - list [ref=f1e79]:
            - listitem [ref=f1e80]:
              - button "01正文生成 生成中" [ref=f1e81] [cursor=pointer]:
                - strong [ref=f1e82]:
                  - generic [ref=f1e83]: "01"
                  - text: 正文生成
                - generic [ref=f1e84]: 生成中
            - listitem [ref=f1e85]:
              - button "02变量管理 待生成" [ref=f1e86] [cursor=pointer]:
                - strong [ref=f1e87]:
                  - generic [ref=f1e88]: "02"
                  - text: 变量管理
                - generic [ref=f1e89]: 待生成
              - generic "变量管理阶段开关" [ref=f1e90]:
                - checkbox "变量管理" [checked] [ref=f1e91]
            - listitem [ref=f1e92]:
              - button "03动态世界 待生成" [ref=f1e93] [cursor=pointer]:
                - strong [ref=f1e94]:
                  - generic [ref=f1e95]: "03"
                  - text: 动态世界
                - generic [ref=f1e96]: 待生成
              - generic "动态世界阶段开关" [ref=f1e97]:
                - checkbox "动态世界" [checked] [ref=f1e98]
          - paragraph [ref=f1e99]: 本回合
          - list [ref=f1e100]:
            - listitem [ref=f1e101]:
              - button "运行诊断 错误与用量" [ref=f1e102] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e103]: 诊
                - strong [ref=f1e104]: 运行诊断
                - generic [ref=f1e105]: 错误与用量
            - listitem [ref=f1e106]:
              - button "已绑定输入 只读" [ref=f1e107] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e108]: 述
                - strong [ref=f1e109]: 已绑定输入
                - generic [ref=f1e110]: 只读
        - generic [ref=f1e111]:
          - button "取消自动执行" [ref=f1e113] [cursor=pointer]
          - generic [ref=f1e114]: 生成可能产生费用。
```
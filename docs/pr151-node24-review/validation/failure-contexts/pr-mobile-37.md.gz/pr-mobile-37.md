# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: action-workflow.spec.ts >> 缺少AI配置零请求，设置后不自动补发，只在明确开始时运行
- Location: e2e/action-workflow.spec.ts:105:1

# Error details

```
Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - banner:
    - button "打开游戏菜单" [ref=f1e2] [cursor=pointer]: ☰
  - main [ref=f1e3]:
    - generic "城市与当前场景" [ref=f1e4]:
      - button "此时此地与主角状态" [ref=f1e5] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e6]: 渝
        - generic [ref=f1e7]:
          - generic [ref=f1e8]: 重庆
          - generic [ref=f1e9]: 重庆
        - time [ref=f1e10]: "--:--"
        - generic "天气：天气待确认" [ref=f1e11]: —
      - generic [ref=f1e12]: 重庆，开局时间待确认 --:--，天气：天气待确认
    - region "剧情与行动" [ref=f1e13]:
      - generic "正文阅读区域" [ref=f1e14]:
        - generic [ref=f1e15]:
          - generic [ref=f1e16]: THE STORY
          - generic [ref=f1e17]: 等待开局
        - generic [ref=f1e18]:
          - generic [aria-hidden] [ref=f1e19]: 序
          - paragraph [ref=f1e20]: A CITY. A TURNING POINT.
          - heading "故事，尚未落笔。" [level=1] [ref=f1e21]
          - paragraph [ref=f1e22]: 你的资料已保存。配置 AI 渠道后，即可生成这座城市中的第一幕。
      - generic [ref=f1e23]:
        - region "三阶段工作流" [ref=f1e25]:
          - button "三阶段工作流详情" [ref=f1e28] [cursor=pointer]:
            - status [ref=f1e33]:
              - generic [ref=f1e34]: 三阶段 ·
              - text: 生成失败 · 查看详情
            - generic [ref=f1e35]: 详情 ›
        - generic [ref=f1e36]:
          - button "回合操作" [ref=f1e38] [cursor=pointer]: ⋯
          - generic [ref=f1e39]: 你的行动
          - textbox "你的行动" [ref=f1e40]:
            - /placeholder: 填写你的行动
          - button "发送" [disabled] [ref=f1e42]
    - navigation "底部导航" [ref=f1e43]:
      - button "故事" [ref=f1e44] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e45]: 文
        - text: 故事
      - button "人物" [ref=f1e46] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e47]: 我
        - text: 人物
      - button "世界资料" [ref=f1e48] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e49]: 世
        - text: 世界资料
      - button "设置" [ref=f1e50] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e51]: 设
        - text: 设置
    - dialog [active] [ref=f1e52]:
      - generic [ref=f1e55]:
        - generic [aria-hidden] [ref=f1e56]: 诊
        - generic [ref=f1e57]:
          - paragraph [aria-hidden] [ref=f1e58]: WORKFLOW · 诊断
          - heading "重试与变更详情" [level=2] [ref=f1e59]
        - button "关闭资料界面" [ref=f1e60] [cursor=pointer]:
          - text: 关闭
          - generic [aria-hidden] [ref=f1e61]: ×
      - generic [ref=f1e62]:
        - tablist "诊断分类" [ref=f1e63]:
          - tab "概要" [ref=f1e64] [cursor=pointer]
          - tab "运行日志 1" [selected] [ref=f1e65] [cursor=pointer]:
            - text: 运行日志
            - generic [ref=f1e66]: "1"
          - tab "请求用量 0" [ref=f1e67] [cursor=pointer]:
            - text: 请求用量
            - generic [ref=f1e68]: "0"
          - tab "模型原文" [ref=f1e69] [cursor=pointer]
        - tabpanel "运行日志 1" [ref=f1e70]:
          - group [ref=f1e71]:
            - generic "运行日志 · 错误 1 条 最近错误 · configuration" [ref=f1e72] [cursor=pointer]:
              - generic [ref=f1e73]: 运行日志 · 错误 1 条
              - strong [ref=f1e74]: 最近错误 · configuration
            - generic [ref=f1e75]:
              - paragraph [ref=f1e76]: 仅显示本次页面会话的错误；每条可单独复制安全诊断，不含原始模型响应、请求正文或密钥。刷新即清空。
              - button "清空日志" [ref=f1e78] [cursor=pointer]
              - list "错误日志条目" [ref=f1e79]:
                - listitem [ref=f1e80]:
                  - generic [ref=f1e81]:
                    - generic [ref=f1e82]:
                      - time [ref=f1e83]: 16:16:08
                      - strong [ref=f1e84]: 自动工作流
                      - generic [ref=f1e85]: 错误
                    - button "复制此条" [ref=f1e86] [cursor=pointer]
                  - paragraph [ref=f1e87]: 渠道、模型或路由配置无效，请检查设置。
                  - generic [ref=f1e88]: 错误码：configuration
        - paragraph [ref=f1e89]: 仅本页临时保存 · 刷新即清空
```
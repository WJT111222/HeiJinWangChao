# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: action-workflow.spec.ts >> 快速离开并重读同一存档或新标签不能延续开局收费授权
- Location: e2e/action-workflow.spec.ts:184:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: /读取存档/ })

```

# Page snapshot

```yaml
- main "游戏首页与存档馆" [ref=f1e4]:
  - generic [ref=f1e5]:
    - generic [aria-hidden] [ref=f1e6]: 黑
    - generic [ref=f1e7]:
      - text: 黑金王朝
      - generic [ref=f1e8]: HEIJINWANGCHAO
    - button "设置" [ref=f1e9] [cursor=pointer]
    - generic [ref=f1e10]: V1.0 Beta
  - generic [ref=f1e11]:
    - paragraph [ref=f1e12]: MODERN CITY / OPEN WORLD
    - heading "黑金王朝" [level=1] [ref=f1e13]
    - paragraph [ref=f1e14]: 起点有冲突，人生不预设结局。
  - status "终点 重庆，时刻 00:23，已选择" [ref=f1e15]:
    - generic [ref=f1e16]:
      - text: 终点
      - generic [ref=f1e17]: DEST
    - generic [ref=f1e18]:
      - generic [ref=f1e19]: 重
      - generic [ref=f1e20]: 庆
    - generic [ref=f1e22]:
      - generic [ref=f1e23]: "0"
      - generic [ref=f1e24]: "0"
      - generic [ref=f1e25]: ":"
      - generic [ref=f1e26]: "2"
      - generic [ref=f1e27]: "3"
    - generic [ref=f1e28]: 已选择
  - generic [ref=f1e29]:
    - generic [ref=f1e30]: 车票 01
    - generic [ref=f1e31]: 本地保存 · 无需账号
    - button "导入备份" [ref=f1e32] [cursor=pointer]: ⤓ 导入备份
    - button "刷新列表" [ref=f1e33] [cursor=pointer]
  - region "车票栏，左右方向键切换" [ref=f1e34]:
    - article "林舟 · 重庆，保存于 2026/11/15 00:23，已选择" [ref=f1e36]:
      - generic [ref=f1e37]:
        - generic [ref=f1e38]:
          - generic [ref=f1e39]: 重庆
          - generic [ref=f1e40]: CHONGQING
          - generic [ref=f1e41]: ARCHIVE 01
        - generic [ref=f1e42]:
          - generic [ref=f1e43]:
            - generic [ref=f1e44]:
              - generic [ref=f1e45]: FROM
              - generic [ref=f1e46]: 林舟
            - generic [aria-hidden] [ref=f1e47]: 单程
            - generic [ref=f1e49]:
              - generic [ref=f1e50]: TO
              - generic [ref=f1e51]: 重庆
          - generic [ref=f1e52]:
            - generic [ref=f1e53]:
              - term [ref=f1e54]: 保存日期
              - definition [ref=f1e55]: 2026/11/15
            - generic [ref=f1e56]:
              - term [ref=f1e57]: 时刻
              - definition [ref=f1e58]: 00:23
            - generic [ref=f1e59]:
              - generic [aria-hidden]:
                - text: 已检票
                - generic: SELECTED
          - paragraph [ref=f1e60]: 从未备份
          - generic [aria-hidden] [ref=f1e61]:
            - generic [ref=f1e78]: 29°33′N · 106°33′E
            - generic [ref=f1e79]: 山城 · 江雾 · 轻轨
            - generic [ref=f1e80]: 渝
      - generic [ref=f1e82]:
        - text: 继续游戏
        - generic [ref=f1e83]: ↓ 按住票根往下撕
    - article "空白车票：开启新的人生" [ref=f1e86]:
      - generic [ref=f1e87]:
        - generic [ref=f1e88]:
          - generic [ref=f1e89]: 空白车票
          - generic [ref=f1e90]: NEW LIFE
          - generic [ref=f1e91]: NEW
        - generic [ref=f1e92]:
          - generic [ref=f1e93]:
            - generic [ref=f1e94]:
              - generic [ref=f1e95]: FROM
              - generic [ref=f1e96]: ？
            - generic [aria-hidden] [ref=f1e97]: 单程
            - generic [ref=f1e99]:
              - generic [ref=f1e100]: TO
              - generic [ref=f1e101]: ？
          - generic [ref=f1e102]:
            - generic [ref=f1e103]:
              - term [ref=f1e104]: 城市
              - definition [ref=f1e105]
            - generic [ref=f1e107]:
              - term [ref=f1e108]: 职业
              - definition [ref=f1e109]
            - generic [ref=f1e111]:
              - term [ref=f1e112]: 存档
              - definition [ref=f1e113]: —
          - paragraph [ref=f1e114]: 四座城市 · 自由职业 · 开放人生
      - generic [ref=f1e116]:
        - text: 开启新的人生
        - generic [ref=f1e117]: ↓ 按住票根往下撕
  - navigation "车票页码" [ref=f1e119]:
    - button "第 1 张" [ref=f1e120] [cursor=pointer]
    - button "第 2 张，空白车票" [ref=f1e121] [cursor=pointer]
  - generic [ref=f1e122]:
    - button "继续游戏" [ref=f1e123] [cursor=pointer]:
      - text: 继续游戏
      - generic [aria-hidden] [ref=f1e124]: →
    - generic [ref=f1e125]:
      - button "导出备份" [ref=f1e126] [cursor=pointer]
      - button "删除" [ref=f1e127] [cursor=pointer]
  - generic [ref=f1e128]:
    - group "游玩信息" [ref=f1e129]:
      - button "游玩须知与免责声明" [ref=f1e130] [cursor=pointer]
      - button "王朝公告" [ref=f1e131] [cursor=pointer]
    - paragraph [ref=f1e132]: 四座城市 · 自由职业 · 开放人生三阶段生成 · 原子结算 · 连续回合
```

# Test source

```ts
  88  | 
  89  | test('一次创角确认自动执行开局三阶段，StrictMode和重复点击不重复请求', async ({ page }) => {
  90  |   await prepare(page); const server = await mock(page); await creation(page);
  91  |   await confirm(page); await ready(page);
  92  |   expect(server.calls.map((call) => call.stage)).toEqual(['story', 'variables', 'world']);
  93  |   const result = await stored(page); expect(result.state.turnNumber).toBe(1); expect(result.state.revision).toBe(1);
  94  |   expect(result.state.journal).toHaveLength(1); expect(result.draft.userInput).toBe(''); expect(result.draft.stageStatus).toEqual({ story: 'pending', variables: 'pending', world: 'pending' });
  95  |   expect(server.calls[0].context.CREATION_PROFILE).toBeTruthy();
  96  |   await expect(page.locator('.workflow-disclosure')).not.toHaveAttribute('open');
  97  |   await expect(page.getByRole('button', { name: '生成变量候选', exact: true })).toBeHidden();
  98  |   await expect(page.getByRole('button', { name: '继续推演', exact: true })).toHaveCount(0);
  99  |   await expect(page.locator('main')).not.toContainText('尚未公开的内部线索');
  100 |   await page.reload(); await ready(page); expect(await stored(page)).toEqual(result); expect(server.calls).toHaveLength(3);
  101 |   await goHome(page);
  102 |   await page.getByRole('button', { name: /读取存档/ }).click(); await ready(page); expect(server.calls).toHaveLength(3);
  103 | });
  104 | 
  105 | test('缺少AI配置零请求，设置后不自动补发，只在明确开始时运行', async ({ page }) => {
  106 |   await prepare(page, false); const server = await mock(page); await creation(page);
  107 |   await expect(page.locator('.notice')).toContainText('生成可能产生费用'); await confirm(page);
  108 |   await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toContainText('配置'); expect(server.calls).toHaveLength(0);
  109 |   const before = await stored(page); await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  110 |   await page.getByRole('button', { name: '打开 AI 设置', exact: true }).click();
  111 |   const settings = await aiTab(page);
  112 |   await addChannel(settings, { preset: 'OpenAI 兼容', name: '行动测试', url: 'https://action.mock.invalid/v1', key: 'mock-action-key' });
  113 |   // 填好后只自动读取模型列表（不产生费用）；从真实设置给三个阶段选同一渠道的不同模型，不通过生成请求探测模型。
  114 |   await expect(settings.locator('.ai-connect')).toContainText('连接正常');
  115 |   for (const [label, model] of [['正文生成', 'story'], ['变量管理', 'variables'], ['动态世界', 'world']]) await stageModel(settings, label, '行动测试', model, 'list');
  116 |   await saveAi(settings);
  117 |   await page.getByRole('button', { name: '关闭资料界面', exact: true }).click(); expect(server.calls).toHaveLength(0);
  118 |   expect(await stored(page)).toEqual(before);
  119 |   await page.getByRole('button', { name: '继续未完成阶段', exact: true }).click(); await ready(page);
  120 |   expect(server.calls.map((call) => call.stage)).toEqual(['story', 'variables', 'world']);
  121 | });
  122 | 
  123 | test('发送行动只结算一次并自动串联下一轮，刷新及再次读档不补发', async ({ page }) => {
  124 |   await prepare(page); const server = await mock(page); await creation(page); await confirm(page); await ready(page);
  125 |   const before = await stored(page); await page.getByLabel('你的行动', { exact: true }).fill('在街边继续观察');
  126 |   await page.getByRole('button', { name: '发送', exact: true }).evaluate((button: HTMLButtonElement) => { button.click(); button.click(); });
  127 |   await expect(page.getByTestId('story-reader')).toContainText('第2幕'); await ready(page);
  128 |   const after = await stored(page); expect(after.state.revision).toBe(2); expect(after.state.journal).toHaveLength(2);
  129 |   expect(after.state.memories.short).toHaveLength(2); expect(after.draft.userInput).toBe('');
  130 |   expect(after.state.economy).toEqual(before.state.economy); expect(after.state.npc).toEqual(before.state.npc);
  131 |   expect(server.calls.map((call) => call.stage)).toEqual(['story', 'variables', 'world', 'story', 'variables', 'world']);
  132 |   expect(server.calls[0].context.CREATION_PROFILE).toBeTruthy(); expect(server.calls[3].context.CREATION_PROFILE).toBeUndefined();
  133 |   expect(server.calls[3].context.PLAYER_ACTION).toBe('在街边继续观察');
  134 |   await page.reload(); await ready(page); expect(await stored(page)).toEqual(after); expect(server.calls).toHaveLength(6);
  135 | });
  136 | 
  137 | for (const stage of ['variables', 'world'] as const) {
  138 |   test(`${stage}失败保留上游，仅明确恢复缺少阶段，折叠无额外请求`, async ({ page }) => {
  139 |     await prepare(page); const server = await mock(page); server.plan.failure = stage;
  140 |     await creation(page); await confirm(page); await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toBeVisible();
  141 |     const failed = await stored(page); expect(failed.state.revision).toBe(0); expect(failed.draft.story).toBeTruthy();
  142 |     expect(server.calls.map((call) => call.stage)).toEqual(stage === 'variables' ? ['story', 'variables'] : ['story', 'variables', 'world']);
  143 |     await page.getByLabel('你的行动', { exact: true }).fill('下一步行动'); await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  144 |     await workflowTrigger(page).click(); await workflowTrigger(page).click();
  145 |     expect(server.calls).toHaveLength(stage === 'variables' ? 2 : 3);
  146 |     await page.reload(); await openWorkflow(page); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeEnabled();
  147 |     expect(await stored(page)).toEqual(failed); server.plan.failure = undefined;
  148 |     await page.getByRole('button', { name: '继续未完成阶段', exact: true }).evaluate((button: HTMLButtonElement) => { button.click(); button.click(); });
  149 |     await ready(page); const after = await stored(page); expect(after.state.revision).toBe(1); expect(after.state.journal[0].story).toEqual(failed.draft.story); expect(after.draft.userInput).toBe('');
  150 |     expect(server.calls.map((call) => call.stage)).toEqual(stage === 'variables' ? ['story', 'variables', 'variables', 'world'] : ['story', 'variables', 'world', 'world']);
  151 |   });
  152 | }
  153 | 
  154 | for (const status of [401, 403, 429]) {
  155 |   test(`自动开局HTTP ${status}停止、不无限重试，刷新不重新授权`, async ({ page }) => {
  156 |     await prepare(page); const server = await mock(page); server.plan.failure = 'story'; server.plan.status = status;
  157 |     await creation(page); await confirm(page); await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toBeVisible();
  158 |     expect(server.calls.map((call) => call.stage)).toEqual(['story']); const failed = await stored(page);
  159 |     expect(failed.draft.story).toBeUndefined(); expect(failed.state.revision).toBe(0);
  160 |     await page.reload(); await openWorkflow(page); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeEnabled();
  161 |     expect(server.calls).toHaveLength(1); expect(await stored(page)).toEqual(failed);
  162 |   });
  163 | }
  164 | 
  165 | test('取消中的迟到响应不启动下游，刷新保留待生成草稿且明确恢复', async ({ page }, info) => {
  166 |   await prepare(page); const server = await mock(page), held = gate(); server.plan.hold = 'story'; server.plan.gate = held.pending;
  167 |   await creation(page); await confirm(page); await expect.poll(() => server.calls.length).toBe(1);
  168 |   await workflowTrigger(page).click(); await workflowTrigger(page).click();
  169 |   expect(server.calls).toHaveLength(1); await openWorkflow(page);
  170 |   if (info.project.name === 'desktop') {
  171 |     await page.setViewportSize({ width: 1024, height: 520 });
  172 |     await expect(page.getByRole('button', { name: '取消自动执行', exact: true })).toBeInViewport({ ratio: 1 });
  173 |     await expect(page.getByRole('button', { name: '发送', exact: true })).toBeInViewport({ ratio: 1 });
  174 |     await page.screenshot({ path: 'docs/ui-pc-reading/screenshots/after-running-short-pc.png' });
  175 |   }
  176 |   await page.getByRole('button', { name: '取消自动执行', exact: true }).click();
  177 |   await expect(workflow(page).getByRole('status')).toContainText('取消'); held.release();
  178 |   const cancelled = await stored(page); expect(cancelled.draft.story).toBeUndefined(); expect(cancelled.state.revision).toBe(0);
  179 |   await page.reload(); await openWorkflow(page); await expect(page.getByRole('button', { name: '自动生成开局', exact: true })).toBeEnabled();
  180 |   expect(server.calls).toHaveLength(1); server.plan.hold = undefined;
  181 |   await page.getByRole('button', { name: '自动生成开局', exact: true }).click(); await ready(page); expect(server.calls).toHaveLength(4);
  182 | });
  183 | 
  184 | test('快速离开并重读同一存档或新标签不能延续开局收费授权', async ({ page, context }) => {
  185 |   await prepare(page); const server = await mock(page), held = gate(); server.plan.hold = 'variables'; server.plan.gate = held.pending;
  186 |   await creation(page); await confirm(page); await expect.poll(() => server.calls.length).toBe(2);
  187 |   const url = page.url(); await goHome(page);
> 188 |   await page.getByRole('button', { name: /读取存档/ }).click();
      |                                                    ^ Error: locator.click: Test timeout of 30000ms exceeded.
  189 |   await openWorkflow(page); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeVisible();
  190 |   const other = await context.newPage(); let otherRequests = 0;
  191 |   await other.route('https://action.mock.invalid/**', async (route) => { otherRequests++; await route.abort(); });
  192 |   await other.goto(url); await expect(other.locator('.game-layout')).toBeVisible();
  193 |   held.release(); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeEnabled();
  194 |   expect(server.calls).toHaveLength(2); expect(otherRequests).toBe(0); const after = await stored(page); expect(after.draft.world).toBeUndefined(); expect(after.state.revision).toBe(0);
  195 |   await other.close();
  196 | });
  197 | 
  198 | test('关闭变量时世界只能预览，不因自动开局而强行启用或允许发送', async ({ page }) => {
  199 |   await prepare(page, true, { variables: false, world: true }); const server = await mock(page); await creation(page); await confirm(page);
  200 |   await expect(workflow(page).getByRole('status')).toContainText('预览');
  201 |   expect(server.calls.map((call) => call.stage)).toEqual(['story', 'world']); const result = await stored(page);
  202 |   expect(result.draft.world?.validation).toBe('preview'); expect(result.draft.variables).toBeUndefined(); expect(result.state.revision).toBe(0);
  203 |   await page.getByLabel('你的行动', { exact: true }).fill('继续观察'); await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  204 | });
  205 | 
  206 | test('正文摘要不合法时不保存、不运行下游、不结算', async ({ page }) => {
  207 |   await prepare(page); const server = await mock(page); server.plan.badSummary = true; await creation(page); await confirm(page);
  208 |   await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toBeVisible(); expect(server.calls.map((call) => call.stage)).toEqual(['story']);
  209 |   const result = await stored(page); expect(result.draft.story).toBeUndefined(); expect(result.state.journal).toEqual([]);
  210 |   await page.getByLabel('你的行动', { exact: true }).fill('继续'); await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  211 | });
  212 | 
  213 | test('开局组件加载前刷新销毁授权，未生成草稿保留且仅主动开始才请求', async ({ page }) => {
  214 |   await prepare(page); const server = await mock(page), held = gate(); let loading = false;
  215 |   const modulePath = '**/src/ui/game/GameScreen.tsx*';
  216 |   await page.route(modulePath, async (route) => { loading = true; await held.pending; await route.continue().catch(() => undefined); });
  217 |   await creation(page); await page.getByRole('button', { name: '确认并创建存档', exact: true }).click();
  218 |   await expect.poll(() => loading).toBe(true); expect(server.calls).toHaveLength(0);
  219 |   await page.unroute(modulePath); await page.reload(); held.release();
  220 |   await openWorkflow(page); await expect(page.getByRole('button', { name: '自动生成开局', exact: true })).toBeEnabled();
  221 |   const before = await stored(page); expect(before.draft.draftRevision).toBe(0); expect(before.draft.story).toBeUndefined(); expect(server.calls).toHaveLength(0);
  222 |   await page.getByRole('button', { name: '自动生成开局', exact: true }).click(); await ready(page); expect(server.calls).toHaveLength(3);
  223 | });
  224 | 
  225 | for (const failure of ['network', 'timeout'] as const) {
  226 |   test(`开局${failure}不隐式重试，刷新不重发，草稿和正式状态安全`, async ({ page }) => {
  227 |     await prepare(page);
  228 |     if (failure === 'timeout') {
  229 |       await page.evaluate(() => {
  230 |         const key = 'heijin.settings.v1', settings = JSON.parse(localStorage.getItem(key)!);
  231 |         settings.runtime.timeoutSeconds = 1; localStorage.setItem(key, JSON.stringify(settings));
  232 |       });
  233 |       await page.reload();
  234 |     }
  235 |     const server = await mock(page), held = gate();
  236 |     if (failure === 'network') { server.plan.failure = 'story'; server.plan.network = true; }
  237 |     else { server.plan.hold = 'story'; server.plan.gate = held.pending; }
  238 |     await creation(page); await confirm(page);
  239 |     await openWorkflow(page); await expect(workflow(page).getByRole('alert')).toContainText(failure === 'network' ? '网络请求失败' : '超时');
  240 |     held.release(); expect(server.calls.map((call) => call.stage)).toEqual(['story']);
  241 |     const failed = await stored(page); expect(failed.state.revision).toBe(0); expect(failed.draft.story).toBeUndefined();
  242 |     await page.reload(); await openWorkflow(page); await expect(page.getByRole('button', { name: '继续未完成阶段', exact: true })).toBeEnabled();
  243 |     expect(server.calls).toHaveLength(1); expect(await stored(page)).toEqual(failed);
  244 |   });
  245 | }
  246 | 
  247 | for (const disabled of ['world', 'variables'] as const) {
  248 |   test(`关闭阶段时${disabled}：不显示无效继续，引导启用后只补必要候选并正常发送`, async ({ page }) => {
  249 |     test.setTimeout(60000);
  250 |     await prepare(page, true, { variables: disabled !== 'variables', world: disabled !== 'world' });
  251 |     const server = await mock(page); await creation(page); await confirm(page);
  252 |     await expect(workflow(page).getByRole('status')).toContainText(disabled === 'world' ? '阶段已关闭' : '预览');
  253 |     const before = await stored(page), initial = disabled === 'world' ? ['story', 'variables'] : ['story', 'world'];
  254 |     expect(server.calls.map((call) => call.stage)).toEqual(initial);
  255 |     await expect(workflow(page).getByRole('button', { name: '继续未完成阶段', exact: true })).toHaveCount(0);
  256 |     await expect(page.locator('.workflow-disclosure')).not.toHaveAttribute('open');
  257 |     await openWorkflow(page);
  258 |     const guidance = workflow(page).getByRole('note', { name: '阶段设置提示', exact: true });
  259 |     await expect(guidance).toContainText(disabled === 'world' ? '动态世界阶段已关闭' : '变量阶段未启用，当前世界结果仅为预览');
  260 |     await workflowTrigger(page).click();
  261 |     await expect(page.locator('.workflow-disclosure')).not.toHaveAttribute('open');
  262 |     await page.getByLabel('你的行动', { exact: true }).fill('继续观察街道');
  263 |     await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  264 |     await page.reload();
  265 |     await openWorkflow(page); await expect(guidance).toBeVisible();
  266 |     await page.getByLabel('你的行动', { exact: true }).fill('继续观察街道');
  267 |     await expect(workflow(page).getByRole('button', { name: '继续未完成阶段', exact: true })).toHaveCount(0);
  268 |     expect(await stored(page)).toEqual(before); expect(server.calls.map((call) => call.stage)).toEqual(initial);
  269 |     // PC 横幅按钮直达对应阶段开关；移动端仍展开高级设置。
  270 |     await guidance.getByRole('button', { name: /^(?:展开高级设置|前往阶段开关)$/ }).click();
  271 |     await expect(page.locator('.workflow-disclosure')).toHaveAttribute('open');
  272 |     const toggle = page.getByLabel(disabled === 'world' ? '动态世界' : '变量管理', { exact: true });
  273 |     await expect(toggle).toBeFocused(); await expect(toggle).not.toBeChecked();
  274 |     expect(await stored(page)).toEqual(before); expect(server.calls.map((call) => call.stage)).toEqual(initial);
  275 |     await toggle.check();
  276 |     const resume = workflow(page).getByRole('button', { name: '继续未完成阶段', exact: true });
  277 |     await expect(resume).toBeEnabled(); expect(server.calls.map((call) => call.stage)).toEqual(initial);
  278 |     expect(await stored(page)).toEqual(before);
  279 |     await workflowTrigger(page).click();
  280 |     await expect(resume).toBeHidden(); await openWorkflow(page); await resume.click(); await ready(page);
  281 |     const complete = await stored(page);
  282 |     expect(complete.state.revision).toBe(1); expect(complete.state.journal[0].story).toEqual(before.draft.story);
  283 |     if (disabled === 'world') expect(complete.state.appliedCommands).toEqual(expect.arrayContaining(before.draft.variables!.result.commands.map(command => expect.objectContaining({ commandId: command.commandId }))));
  284 |     const completedCalls = disabled === 'world' ? ['story', 'variables', 'world'] : ['story', 'world', 'variables', 'world'];
  285 |     expect(server.calls.map((call) => call.stage)).toEqual(completedCalls);
  286 |     await expect(resume).toHaveCount(0); await expect(page.getByRole('button', { name: '发送', exact: true })).toBeEnabled();
  287 |     await page.getByRole('button', { name: '发送', exact: true }).click();
  288 |     await expect(page.getByTestId('story-reader')).toContainText('第2幕'); await ready(page);
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: continuous-turns.spec.ts >> 提交事务中途失败 UI 不虚报成功；重试后只结算一次
- Location: e2e/continuous-turns.spec.ts:273:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '发送', exact: true })
    - locator resolved to <button class="primary">发送</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <div class="modal-body">…</div> from <dialog open="" tabindex="-1" aria-modal="true" aria-labelledby="_r_5_" class="modal mobile-diagnostics-sheet mobile-sheet sheet-full">…</dialog> subtree intercepts pointer events
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <div class="modal-body">…</div> from <dialog open="" tabindex="-1" aria-modal="true" aria-labelledby="_r_5_" class="modal mobile-diagnostics-sheet mobile-sheet sheet-full">…</dialog> subtree intercepts pointer events
    - retrying click action
      - waiting 100ms
    23 × waiting for element to be visible, enabled and stable
       - element is visible, enabled and stable
       - scrolling into view if needed
       - done scrolling
       - <div class="modal-body">…</div> from <dialog open="" tabindex="-1" aria-modal="true" aria-labelledby="_r_5_" class="modal mobile-diagnostics-sheet mobile-sheet sheet-full">…</dialog> subtree intercepts pointer events
     - retrying click action
       - waiting 500ms
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed

```

# Page snapshot

```yaml
- generic:
  - generic [ref=f1e1]:
    - banner:
      - button "打开游戏菜单" [ref=f1e2] [cursor=pointer]: ☰
    - main [ref=f1e3]:
      - generic "城市与当前场景" [ref=f1e4]:
        - button "此时此地与主角状态" [ref=f1e5] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e6]: 渝
          - generic [ref=f1e7]:
            - generic [ref=f1e8]: 重庆
            - generic [ref=f1e9]: 重庆
          - time [ref=f1e10]: 14:01
          - generic "天气：天气待确认" [ref=f1e11]: —
        - generic [ref=f1e12]: 重庆，2015/7/8 星期三 14:01，天气：天气待确认
      - region "剧情与行动" [ref=f1e13]:
        - generic "正文阅读区域" [ref=f1e14]:
          - generic [ref=f1e15]:
            - generic [ref=f1e16]: THE STORY
            - generic [ref=f1e17]: 已结算历史
          - article [ref=f1e18]:
            - generic [ref=f1e19]:
              - generic [aria-hidden] [ref=f1e20]:
                - generic [ref=f1e21]: "1"
                - generic [ref=f1e22]:
                  - generic [ref=f1e23]: 第一回
                  - generic [ref=f1e24]: TURN 001
              - heading "第 1 回合" [level=2] [ref=f1e31]
              - generic [ref=f1e32]:
                - text: 2015/7/8 · 星期三 · 14:00
                - generic [ref=f1e33]: 重庆
            - paragraph [ref=f1e35]: 2015年7月8日14:00，重庆街头。第1幕。主角收到了公司寄出的解雇通知。经过一分钟，主角在街边休息。主角心情趋于平静。
            - generic [ref=f1e36]:
              - button "本回合变化 不可用" [disabled] [ref=f1e37]:
                - generic [ref=f1e38]: 本回合变化
                - generic [ref=f1e39]: 不可用
                - generic [aria-hidden] [ref=f1e40]: ▼
              - status [ref=f1e41]: 本回合没有可对比的结算前记录
          - region "行动建议" [ref=f1e42]:
            - paragraph [ref=f1e43]:
              - text: 接下来你想做什么
              - generic [ref=f1e44]: 1 / 3
            - generic [ref=f1e45]:
              - button "留在街边" [ref=f1e46] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e47]: "01"
                - generic [aria-hidden] [ref=f1e49]: 点按填入 →
              - button "看看四周" [ref=f1e50] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e51]: "02"
                - generic [aria-hidden] [ref=f1e53]: 点按填入 →
              - button "询问路线" [ref=f1e54] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e55]: "03"
                - generic [aria-hidden] [ref=f1e57]: 点按填入 →
        - generic [ref=f1e62]:
          - region "三阶段工作流" [ref=f1e64]:
            - button "三阶段工作流详情" [expanded] [ref=f1e67] [cursor=pointer]:
              - status [ref=f1e72]:
                - generic [ref=f1e73]: 三阶段 ·
                - text: 行动发送失败 · 查看详情
              - generic [ref=f1e74]: 详情 ›
          - generic [ref=f1e75]:
            - button "撤回" [disabled] [ref=f1e78]:
              - generic [aria-hidden] [ref=f1e79]: 撤
            - generic [ref=f1e80]: 你的行动
            - textbox "你的行动" [ref=f1e81]:
              - /placeholder: 填写你的行动
              - text: 等待下一轮
            - button "发送" [ref=f1e83] [cursor=pointer]
      - navigation "底部导航" [ref=f1e84]:
        - button "故事" [ref=f1e85] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e86]: 文
          - text: 故事
        - button "人物" [ref=f1e87] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e88]: 我
          - text: 人物
        - button "世界资料" [ref=f1e89] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e90]: 世
          - text: 世界资料
        - button "设置" [ref=f1e91] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e92]: 设
          - text: 设置
      - dialog [active] [ref=f1e93]:
        - generic [ref=f1e96]:
          - generic [aria-hidden] [ref=f1e97]: 诊
          - generic [ref=f1e98]:
            - paragraph [aria-hidden] [ref=f1e99]: WORKFLOW · 诊断
            - heading "重试与变更详情" [level=2] [ref=f1e100]
          - button "关闭资料界面" [ref=f1e101] [cursor=pointer]:
            - text: 关闭
            - generic [aria-hidden] [ref=f1e102]: ×
        - generic [ref=f1e103]:
          - tablist "诊断分类" [ref=f1e104]:
            - tab "概要" [ref=f1e105] [cursor=pointer]
            - tab "运行日志 1" [selected] [ref=f1e106] [cursor=pointer]:
              - text: 运行日志
              - generic [ref=f1e107]: "1"
            - tab "请求用量 3" [ref=f1e108] [cursor=pointer]:
              - text: 请求用量
              - generic [ref=f1e109]: "3"
            - tab "模型原文" [ref=f1e110] [cursor=pointer]
          - tabpanel "运行日志 1" [ref=f1e111]:
            - group [ref=f1e112]:
              - generic "运行日志 · 错误 1 条 最近错误 · unknown" [ref=f1e113] [cursor=pointer]:
                - generic [ref=f1e114]: 运行日志 · 错误 1 条
                - strong [ref=f1e115]: 最近错误 · unknown
              - generic [ref=f1e116]:
                - paragraph [ref=f1e117]: 仅显示本次页面会话的错误；每条可单独复制安全诊断，不含原始模型响应、请求正文或密钥。刷新即清空。
                - button "清空日志" [ref=f1e119] [cursor=pointer]
                - list "错误日志条目" [ref=f1e120]:
                  - listitem [ref=f1e121]:
                    - generic [ref=f1e122]:
                      - generic [ref=f1e123]:
                        - time [ref=f1e124]: 16:20:21
                        - strong [ref=f1e125]: 自动工作流
                        - generic [ref=f1e126]: 错误
                      - button "复制此条" [ref=f1e127] [cursor=pointer]
                    - paragraph [ref=f1e128]: 操作失败，请检查配置或浏览器存储权限后重试。
                    - generic [ref=f1e129]: 错误码：unknown
          - paragraph [ref=f1e130]: 仅本页临时保存 · 刷新即清空
  - generic [ref=f1e131]:
    - button "收起工作流暗区" [ref=f1e132] [cursor=pointer]
    - dialog "三阶段工作流" [ref=f1e133]:
      - generic [ref=f1e134]:
        - button "收起三阶段工作流" [ref=f1e135] [cursor=pointer]
        - button "行动输入" [ref=f1e137] [cursor=pointer]
      - region "三阶段详情" [ref=f1e138]:
        - generic [ref=f1e139]:
          - generic [ref=f1e140]:
            - text: THREE STAGES · 三阶段
            - heading "行动发送失败 · 查看详情" [level=3] [ref=f1e141]
          - button "收起三阶段详情" [ref=f1e142] [cursor=pointer]: ×
        - alert [ref=f1e144]:
          - text: 误
          - paragraph [ref=f1e146]: 行动未发送：草稿版本冲突或存储失败。输入仍保留，请重新读取存档后重试。
          - button "关闭错误提示" [ref=f1e147] [cursor=pointer]: ×
        - navigation "三阶段导航" [ref=f1e149]:
          - paragraph [ref=f1e150]: STAGES
          - list [ref=f1e151]:
            - listitem [ref=f1e152]:
              - button "01正文生成 已结算" [ref=f1e153] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e154]: ✓
                - strong [ref=f1e155]:
                  - generic [ref=f1e156]: "01"
                  - text: 正文生成
                - generic [ref=f1e157]: 已结算
            - listitem [ref=f1e158]:
              - button "02变量管理 已结算" [ref=f1e159] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e160]: ✓
                - strong [ref=f1e161]:
                  - generic [ref=f1e162]: "02"
                  - text: 变量管理
                - generic [ref=f1e163]: 已结算
              - generic "变量管理阶段开关" [ref=f1e164]:
                - checkbox "变量管理" [checked] [ref=f1e165]
            - listitem [ref=f1e166]:
              - button "03动态世界 已结算" [ref=f1e167] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e168]: ✓
                - strong [ref=f1e169]:
                  - generic [ref=f1e170]: "03"
                  - text: 动态世界
                - generic [ref=f1e171]: 已结算
              - generic "动态世界阶段开关" [ref=f1e172]:
                - checkbox "动态世界" [checked] [ref=f1e173]
          - paragraph [ref=f1e174]: 本回合
          - list [ref=f1e175]:
            - listitem [ref=f1e176]:
              - button "运行诊断 错误与用量 错误 1 条" [ref=f1e177] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e178]: 诊
                - strong [ref=f1e179]: 运行诊断
                - generic [ref=f1e180]: 错误与用量
                - generic "错误 1 条" [ref=f1e181]: "1"
            - listitem [ref=f1e182]:
              - button "已绑定输入 只读" [ref=f1e183] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e184]: 述
                - strong [ref=f1e185]: 已绑定输入
                - generic [ref=f1e186]: 只读
        - generic [ref=f1e187]: 生成可能产生费用。
```

# Test source

```ts
  200 |     expect(result.state.turnNumber).toBe(index + 1);
  201 |     expect(result.state.revision).toBe(index + 1);
  202 |     expect(result.state.journal).toHaveLength(index + 1);
  203 |     expect(result.state.memories.short).toHaveLength(index + 1);
  204 |     expect(result.state.memories.short.at(-1)).toMatchObject({
  205 |       text: `第${index + 1}幕的街边休息`,
  206 |       sourceTurnIds: [result.state.journal[index].turnId],
  207 |       createdAtGameTime: result.state.worldClock,
  208 |       visibility: 'player_known',
  209 |       affectedEntityRefs: [],
  210 |     });
  211 |     expect(result.draft.userInput).toBe('');
  212 |     expect(result.draft.turnKind).toBe('regular');
  213 |     expect(Date.parse(result.state.worldClock)).toBe(start + (index + 1) * 60000);
  214 |     expect(result.state.items.notice.ownerRef?.id).toBe(result.state.protagonist.id);
  215 |     expect(result.state.initialCompanionId).toBe(initial.state.initialCompanionId);
  216 |     expect(result.state.npc.companion).toEqual(initial.state.npc.companion);
  217 |     await expect(page.getByTestId('story-reader').locator('.chapter-heading').last()).toHaveText(
  218 |       `第 ${index + 1} 回合`,
  219 |     );
  220 |     expect(server.stories.find((s) => s.number === index + 1)?.action).toBe(action);
  221 |     expect(server.stories.find((s) => s.number === index + 1)?.context).toContain(
  222 |       `第${index}幕的街边休息`,
  223 |     );
  224 |     if (index === 5) {
  225 |       await page.reload(); await openGameTools(page);
  226 |       await ready(page, 6);
  227 |     }
  228 |   }
  229 |   const final = await stored(page);
  230 |   expect(server.calls).toHaveLength(30);
  231 |   expect(final.state.journal[0].story.turnKind).toBe('opening');
  232 |   expect(final.state.journal.slice(1).every((j) => j.story.turnKind === 'regular')).toBe(true);
  233 |   expect(JSON.stringify(final.state)).not.toContain('绝不自动发布的后台线索');
  234 |   expect(JSON.stringify(final.state.journal)).not.toContain('内部未解决事项');
  235 |   await expect(page.locator('main')).not.toContainText('绝不自动发布的后台线索');
  236 |   await page.reload(); await openGameTools(page);
  237 |   expect(await stored(page)).toEqual(final);
  238 |   await ready(page, 10);
  239 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  240 |   await page.screenshot({ path: info.outputPath('ten-committed-turns.png'), fullPage: true });
  241 | });
  242 | 
  243 | test('下一轮生成失败不回滚上轮结算；刷新后只恢复尚未完成的新回合', async ({ page }) => {
  244 |   await configure(page);
  245 |   const server = await mock(page);
  246 |   await createCharacter(page);
  247 |   await ready(page);
  248 |   server.plan.badStoryNumber = 2;
  249 |   await page.getByLabel('你的行动', { exact: true }).fill('去街边等待');
  250 |   await page.getByRole('button', { name: '发送', exact: true }).click();
  251 |   await expect(workflow(page).getByRole('alert')).toContainText('正文生成');
  252 |   const failed = await stored(page);
  253 |   expect(failed.state.turnNumber).toBe(1);
  254 |   expect(failed.draft.userInput).toBe('去街边等待');
  255 |   expect(failed.draft.stageStatus.story).toBe('failed');
  256 |   await page.reload(); await openGameTools(page);
  257 |   server.plan.badStoryNumber = 0;
  258 |   await workflow(page).getByRole('button', { name: '继续未完成阶段', exact: true }).click();
  259 |   await ready(page, 2);
  260 |   expect((await stored(page)).state.turnNumber).toBe(2);
  261 |   expect((await stored(page)).state.journal[0]).toEqual(failed.state.journal[0]);
  262 |   expect(server.calls).toEqual([
  263 |     'story',
  264 |     'variables',
  265 |     'world',
  266 |     'story',
  267 |     'story',
  268 |     'variables',
  269 |     'world',
  270 |   ]);
  271 | });
  272 | 
  273 | test('提交事务中途失败 UI 不虚报成功；重试后只结算一次', async ({ page }) => {
  274 |   await configure(page);
  275 |   await mock(page);
  276 |   await createCharacter(page);
  277 |   await ready(page);
  278 |   const before = await stored(page);
  279 |   await page.evaluate(() => {
  280 |     const original = IDBObjectStore.prototype.put;
  281 |     Object.defineProperty(window, '__restoreTurnPut', {
  282 |       value: () => {
  283 |         IDBObjectStore.prototype.put = original;
  284 |       },
  285 |       configurable: true,
  286 |     });
  287 |     IDBObjectStore.prototype.put = function (value, key) {
  288 |       if (this.name === 'drafts') throw new DOMException('isolated test', 'QuotaExceededError');
  289 |       return original.call(this, value, key);
  290 |     };
  291 |   });
  292 |   await page.getByLabel('你的行动', { exact: true }).fill('等待下一轮');
  293 |   await page.getByRole('button', { name: '发送', exact: true }).click();
  294 |   await expect(page.getByRole('alert')).toBeVisible();
  295 |   expect(await stored(page)).toEqual(before);
  296 |   await page.evaluate(() => {
  297 |     const restore = Reflect.get(window, '__restoreTurnPut');
  298 |     if (typeof restore === 'function') restore();
  299 |   });
> 300 |   await page.getByRole('button', { name: '发送', exact: true }).click();
      |                                                               ^ Error: locator.click: Test timeout of 30000ms exceeded.
  301 |   await ready(page, 2);
  302 |   expect((await stored(page)).state.turnNumber).toBe(2);
  303 | });
  304 | 
  305 | test('快速双击与另一标签发送最多结算一次；成功后数据库保留唯一下一草稿', async ({
  306 |   page,
  307 |   context,
  308 | }) => {
  309 |   await configure(page);
  310 |   await mock(page);
  311 |   await createCharacter(page);
  312 |   await ready(page);
  313 |   const other = await context.newPage();
  314 |   await other.goto(page.url());
  315 |   // A new Playwright tab has independent sessionStorage. Both competing clients
  316 |   // need the same test-only credentials and the context-wide Mock above.
  317 |   await other.evaluate(async () => {
  318 |     const configPath = '/src/services/ai/configuration.ts', vaultPath = '/src/services/ai/credentials.ts';
  319 |     const { readAiConfig } = await import(configPath), { CredentialVault } = await import(vaultPath);
  320 |     const vault = new CredentialVault(sessionStorage, localStorage);
  321 |     for (const channel of readAiConfig(localStorage).channels) vault.set(channel.id, 'mock-loop-secret');
  322 |   });
  323 |   await other.reload();
  324 |   await page.getByLabel('你的行动', { exact: true }).fill('在街边等待');
  325 |   await other.getByLabel('你的行动', { exact: true }).fill('在街边等待');
  326 |   await Promise.all(
  327 |     [page, other].map((p) =>
  328 |       p.getByRole('button', { name: '发送', exact: true }).evaluate((button: HTMLButtonElement) => {
  329 |         button.click();
  330 |         button.click();
  331 |       }),
  332 |     ),
  333 |   );
  334 |   await expect.poll(async () => (await stored(page)).state.turnNumber).toBe(2);
  335 |   const result = await stored(page);
  336 |   expect(result.state.journal).toHaveLength(2);
  337 |   expect(result.draft.baseSaveRevision).toBe(2);
  338 |   expect(result.draft.userInput).toBe('');
  339 |   await other.close();
  340 | });
  341 | 
  342 | test('阶段未完成或主动关闭时，即使填写行动也不能部分结算', async ({ page }) => {
  343 |   await configure(page, false);
  344 |   const server = await mock(page);
  345 |   await createCharacter(page);
  346 |   await expect(page.getByLabel('动态世界', { exact: true })).not.toBeChecked();
  347 |   await expect(workflow(page).getByRole('status')).toContainText('阶段已关闭');
  348 |   await page.getByLabel('你的行动', { exact: true }).fill('等待');
  349 |   await expect(page.getByRole('button', { name: '发送', exact: true })).toBeDisabled();
  350 |   expect((await stored(page)).state.turnNumber).toBe(0);
  351 |   await page.getByLabel('动态世界', { exact: true }).check();
  352 |   await workflow(page).getByRole('button', { name: '继续未完成阶段', exact: true }).click();
  353 |   await ready(page);
  354 |   await expect(page.getByRole('button', { name: '发送', exact: true })).toBeEnabled();
  355 |   expect(server.calls).toEqual(['story', 'variables', 'world']);
  356 | });
  357 | 
  358 | test('正式资金与时间显示新版本，结算后刷新不重复扣款', async ({ page }) => {
  359 |   await configure(page);
  360 |   await mock(page);
  361 |   // 隔离经济界面测试数据；上面的十回合验收完全通过真实创角建立存档。
  362 |   await page.evaluate(async () => {
  363 |     const rp = '/src/services/storage/saveRepository.ts',
  364 |       fp = '/src/tests/fixtures/world.ts',
  365 |       dp = '/src/domain/drafts.ts';
  366 |     const { SaveRepository } = await import(rp),
  367 |       { worldState } = await import(fp),
  368 |       { createTurnDraft } = await import(dp);
  369 |     const repo = await SaveRepository.open();
  370 |     await repo.create(worldState());
  371 |     await repo.saveDraft(createTurnDraft('save-a', 0, 'opening-known-money', 'opening', ''), null);
  372 |     repo.close();
  373 |   });
  374 |   await page.goto('/#game/save-a'); await openGameTools(page);
  375 |   await opening(page);
  376 |   await page.getByLabel('你的行动', { exact: true }).fill('继续休息');
  377 |   await page.getByRole('button', { name: '发送', exact: true }).click();
  378 |   await ready(page, 2);
  379 |   const state = (await stored(page)).state;
  380 |   expect(state.economy.cash).toBe(4000);
  381 |   expect(state.worldClock).not.toBe('2026-10-18T08:00:00+08:00');
  382 |   await expect(page.getByRole('complementary', { name: '主角信息' })).toContainText('40.00 元');
  383 |   await page.reload(); await openGameTools(page);
  384 |   expect((await stored(page)).state).toEqual(state);
  385 | });
  386 | 
```
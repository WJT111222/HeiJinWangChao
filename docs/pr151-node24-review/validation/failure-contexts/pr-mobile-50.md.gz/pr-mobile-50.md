# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: continuous-turns.spec.ts >> 正式资金与时间显示新版本，结算后刷新不重复扣款
- Location: e2e/continuous-turns.spec.ts:358:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('region', { name: '三阶段工作流' }).getByRole('button', { name: '自动生成开局', exact: true })

```

# Page snapshot

```yaml
- generic:
  - generic [ref=f1e1]:
    - banner:
      - button "打开游戏菜单" [ref=f1e2] [cursor=pointer]: ☰
    - main [ref=f1e3]:
      - generic "城市与当前场景" [ref=f1e4]:
        - button "此时此地与主角状态" [ref=f1e5] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e6]: 城
          - generic [ref=f1e7]:
            - generic [ref=f1e8]: 当前地点
            - generic [ref=f1e9]: 重庆
          - time [ref=f1e10]: 08:00
          - generic "天气：天气待确认" [ref=f1e11]: —
        - generic [ref=f1e12]: 重庆，2026/10/18 星期日 08:00，天气：天气待确认
      - region "剧情与行动" [ref=f1e13]:
        - generic "正文阅读区域" [ref=f1e14]:
          - generic [ref=f1e15]:
            - generic [ref=f1e16]: THE STORY
            - generic [ref=f1e17]: 等待开局
          - generic [ref=f1e18]:
            - generic [aria-hidden] [ref=f1e19]: 序
            - paragraph [ref=f1e20]: A CITY. A TURNING POINT.
            - heading "故事，尚未落笔。" [level=1] [ref=f1e21]
            - paragraph [ref=f1e22]: 你的资料已保存。配置 AI 渠道后，即可生成这座城市中的第一幕。
          - paragraph [ref=f1e23]: 行动建议将在正文生成后显示。
        - generic [ref=f1e24]:
          - region "三阶段工作流" [ref=f1e26]:
            - button "三阶段工作流详情" [expanded] [ref=f1e29] [cursor=pointer]:
              - status [ref=f1e34]:
                - generic [ref=f1e35]: 三阶段 ·
                - text: 等待开始
              - generic [ref=f1e36]: 详情 ›
          - generic [ref=f1e37]:
            - button "回合操作" [ref=f1e39] [cursor=pointer]: ⋯
            - generic [ref=f1e40]: 你的行动
            - textbox "你的行动" [ref=f1e41]:
              - /placeholder: 填写你的行动
            - button "发送" [disabled] [ref=f1e43]
      - navigation "底部导航" [ref=f1e44]:
        - button "故事" [ref=f1e45] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e46]: 文
          - text: 故事
        - button "人物" [ref=f1e47] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e48]: 我
          - text: 人物
        - button "世界资料" [ref=f1e49] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e50]: 世
          - text: 世界资料
        - button "设置" [ref=f1e51] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e52]: 设
          - text: 设置
  - generic [ref=f1e53]:
    - button "收起工作流暗区" [ref=f1e54] [cursor=pointer]
    - dialog "三阶段工作流" [active] [ref=f1e55]:
      - generic [ref=f1e56]:
        - button "收起三阶段工作流" [ref=f1e57] [cursor=pointer]
        - button "行动输入" [ref=f1e59] [cursor=pointer]
      - region "三阶段详情" [ref=f1e60]:
        - generic [ref=f1e61]:
          - generic [ref=f1e62]:
            - text: THREE STAGES · 三阶段
            - heading "等待开始" [level=3] [ref=f1e63]
          - button "收起三阶段详情" [ref=f1e64] [cursor=pointer]: ×
        - navigation "三阶段导航" [ref=f1e66]:
          - paragraph [ref=f1e67]: STAGES
          - list [ref=f1e68]:
            - listitem [ref=f1e69]:
              - button "01正文生成 待生成" [ref=f1e70] [cursor=pointer]:
                - strong [ref=f1e71]:
                  - generic [ref=f1e72]: "01"
                  - text: 正文生成
                - generic [ref=f1e73]: 待生成
            - listitem [ref=f1e74]:
              - button "02变量管理 待生成" [ref=f1e75] [cursor=pointer]:
                - strong [ref=f1e76]:
                  - generic [ref=f1e77]: "02"
                  - text: 变量管理
                - generic [ref=f1e78]: 待生成
              - generic "变量管理阶段开关" [ref=f1e79]:
                - checkbox "变量管理" [checked] [ref=f1e80]
            - listitem [ref=f1e81]:
              - button "03动态世界 待生成" [ref=f1e82] [cursor=pointer]:
                - strong [ref=f1e83]:
                  - generic [ref=f1e84]: "03"
                  - text: 动态世界
                - generic [ref=f1e85]: 待生成
              - generic "动态世界阶段开关" [ref=f1e86]:
                - checkbox "动态世界" [checked] [ref=f1e87]
          - paragraph [ref=f1e88]: 本回合
          - list [ref=f1e89]:
            - listitem [ref=f1e90]:
              - button "运行诊断 错误与用量" [ref=f1e91] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e92]: 诊
                - strong [ref=f1e93]: 运行诊断
                - generic [ref=f1e94]: 错误与用量
            - listitem [ref=f1e95]:
              - button "已绑定输入 只读" [ref=f1e96] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e97]: 述
                - strong [ref=f1e98]: 已绑定输入
                - generic [ref=f1e99]: 只读
        - generic [ref=f1e100]:
          - button "自动生成开局" [ref=f1e102] [cursor=pointer]
          - generic [ref=f1e103]: 生成可能产生费用。
```

# Test source

```ts
  78  |       const paid = typeof record(state.economy).cash === 'number';
  79  |       const pending = Boolean(ctx.OPENING_TIME && record(ctx.OPENING_TIME).status === 'pending');
  80  |       const anchor = pending ? '2015年7月8日14:00，重庆街头。' : '';
  81  |       const narrative = `${anchor}第${number}幕。${number === 1 ? '主角收到了公司寄出的解雇通知。' : '主角仍保留着此前收到的通知。'}经过一分钟，主角在街边休息。主角心情趋于平静。${paid ? '主角已经用现金支付30元吃饭。' : ''}`;
  82  |       const preflight = ctx.TIME_PREFLIGHT ? record(ctx.TIME_PREFLIGHT) : undefined;
  83  |       const timeGuide = pending ? [{ group: 'time', subjectHint: 'time:opening', observedFact: JSON.stringify({ startAt: '2015-07-08T14:00:00+08:00', endAt: '2015-07-08T14:01:00+08:00' }), textEvidence: anchor }] : preflight?.targetAt ? [{ group: 'time', subjectHint: 'time:end', observedFact: preflight.targetAt, textEvidence: '经过一分钟，主角在街边休息。' }] : [];
  84  |       text =
  85  |         plan.badStoryNumber === number
  86  |           ? '{bad-output'
  87  |           : `<thinking>本轮创作提纲：保持人物与场景连续，按行动呈现事实。</thinking><正文>${narrative}</正文><短期记忆>第${number}幕的街边休息</短期记忆><变量规划>${JSON.stringify(timeGuide)}</变量规划><行动选项>留在街边\n看看四周\n询问路线</行动选项>`;
  88  |       await route.fulfill({
  89  |         contentType: 'text/event-stream',
  90  |         body: `data: ${JSON.stringify({ choices: [{ delta: { content: text } }] })}\n\ndata: [DONE]\n\n`,
  91  |       });
  92  |       return;
  93  |     }
  94  |     if (stage === 'variables') {
  95  |       const state = VariableStateProjectionSchema.parse(ctx.SAVE_STATE),
  96  |         story = StorySchema.parse(ctx.STORY_RESULT);
  97  |       const commands: DomainCommand[] = [
  98  |         {
  99  |           type: 'SetWorldClock',
  100 |           commandId: 'minute',
  101 |           evidence: '经过一分钟，主角在街边休息。',
  102 |           worldClock: ctx.OPENING_TIME ? string(record(ctx.OPENING_TIME).endAt) : new Date(Date.parse(state.worldClock) + 60000).toISOString(),
  103 |         },
  104 |         {
  105 |           type: 'UpdateProtagonist',
  106 |           commandId: 'mood',
  107 |           expectedRevision: state.revision,
  108 |           protagonistId: state.protagonist.id,
  109 |           changes: { emotionText: '平静' },
  110 |           evidence: '主角心情趋于平静。',
  111 |         },
  112 |       ];
  113 |       if (state.turnNumber === 0)
  114 |         commands.push({
  115 |           type: 'AcquireItem',
  116 |           commandId: 'notice',
  117 |           evidence: '主角收到了公司寄出的解雇通知。',
  118 |           item: {
  119 |             id: 'notice',
  120 |             name: '解雇通知',
  121 |             category: 'document',
  122 |             quantity: 1,
  123 |             ownerRef: { kind: 'protagonist', id: state.protagonist.id },
  124 |             conditionText: '完好',
  125 |           },
  126 |         });
  127 |       if (story.narrative.includes('主角已经用现金支付30元吃饭。'))
  128 |         commands.push({
  129 |           type: 'SpendFunds',
  130 |           commandId: 'meal',
  131 |           account: 'cash',
  132 |           amount: 3000,
  133 |           purpose: '用餐',
  134 |           evidence: '主角已经用现金支付30元吃饭。',
  135 |         });
  136 |       text = variableReply({ commands, rejectedSuggestions: [], unresolved: [] });
  137 |     } else {
  138 |       if (plan.holdWorld) await plan.holdWorld;
  139 |       text = JSON.stringify({
  140 |         worldCommands: [],
  141 |         taskCommands: [],
  142 |         eventCommands: [],
  143 |         visibleHooks: [{ text: '绝不自动发布的后台线索', revealAfter: string(ctx.worldClock) }],
  144 |         unresolved: ['内部未解决事项不可变成正文日志'],
  145 |       });
  146 |     }
  147 |     await route
  148 |       .fulfill({
  149 |         contentType: 'application/json',
  150 |         body: JSON.stringify({ choices: [{ message: { content: text }, finish_reason: 'stop' }] }),
  151 |       })
  152 |       .catch(() => undefined);
  153 |   });
  154 |   return { plan, stories, calls };
  155 | }
  156 | async function stored(page: Page) {
  157 |   const saved = await page.evaluate(async () => {
  158 |     const path = '/src/services/storage/saveRepository.ts',
  159 |       { SaveRepository } = await import(path),
  160 |       repo = await SaveRepository.open();
  161 |     try {
  162 |       const [save] = await repo.list();
  163 |       return await repo.loadGame(save.saveId);
  164 |     } finally {
  165 |       repo.close();
  166 |     }
  167 |   });
  168 |   return { state: GameStateSchema.parse(saved.state), draft: TurnDraftSchema.parse(saved.draft) };
  169 | }
  170 | const workflow = (page: Page) => page.getByRole('region', { name: '三阶段工作流' });
  171 | async function ready(page: Page, number = 1) {
  172 |   await expect(page.getByTestId('story-reader').locator('article').last()).toContainText(
  173 |     `第${number}幕`,
  174 |   );
  175 |   await expect(workflow(page)).toContainText('本回合已结算');
  176 | }
  177 | async function opening(page: Page) {
> 178 |   await workflow(page).getByRole('button', { name: '自动生成开局', exact: true }).click();
      |                                                                             ^ Error: locator.click: Test timeout of 30000ms exceeded.
  179 |   await ready(page);
  180 | }
  181 | 
  182 | test('真实创角后连续正式游玩十回合；输入、资料、正文历史与刷新一致', async ({ page }, info) => {
  183 |   test.setTimeout(120000);
  184 |   await configure(page);
  185 |   const server = await mock(page);
  186 |   await createCharacter(page);
  187 |   await ready(page);
  188 |   const initial = await stored(page),
  189 |     start = Date.parse('2015-07-08T14:00:00+08:00');
  190 |   expect(initial.state.openingTimePending).toBeUndefined(); // 开局自动正式结算，待下一条行动。
  191 |   expect(initial.state.turnNumber).toBe(1);
  192 |   expect(initial.state.economy.cash).toBeNull();
  193 |   await expect(page.getByRole('complementary', { name: '主角信息' })).toContainText('未确认');
  194 |   for (let index = 1; index <= 9; index++) {
  195 |     const action = `行动${index}：在街边等待一分钟`;
  196 |     await page.getByLabel('你的行动', { exact: true }).fill(action);
  197 |     await page.getByRole('button', { name: '发送', exact: true }).click();
  198 |     await ready(page, index + 1);
  199 |     const result = await stored(page);
  200 |     expect(result.state.turnNumber).toBe(index + 1);
  201 |     expect(result.state.revision).toBe(index + 1);
  202 |     expect(result.state.journal).toHaveLength(index + 1);
  203 |     expect(result.state.memories.short).toHaveLength(index + 1);
  204 |     expect(result.state.memories.short.at(-1)).toMatchObject({
  205 |       text: `第${index + 1}幕的街边休息`,
  206 |       sourceTurnIds: [result.state.journal[index].turnId],
  207 |       createdAtGameTime: result.state.worldClock,
  208 |       visibility: 'player_known',
  209 |       affectedEntityRefs: [],
  210 |     });
  211 |     expect(result.draft.userInput).toBe('');
  212 |     expect(result.draft.turnKind).toBe('regular');
  213 |     expect(Date.parse(result.state.worldClock)).toBe(start + (index + 1) * 60000);
  214 |     expect(result.state.items.notice.ownerRef?.id).toBe(result.state.protagonist.id);
  215 |     expect(result.state.initialCompanionId).toBe(initial.state.initialCompanionId);
  216 |     expect(result.state.npc.companion).toEqual(initial.state.npc.companion);
  217 |     await expect(page.getByTestId('story-reader').locator('.chapter-heading').last()).toHaveText(
  218 |       `第 ${index + 1} 回合`,
  219 |     );
  220 |     expect(server.stories.find((s) => s.number === index + 1)?.action).toBe(action);
  221 |     expect(server.stories.find((s) => s.number === index + 1)?.context).toContain(
  222 |       `第${index}幕的街边休息`,
  223 |     );
  224 |     if (index === 5) {
  225 |       await page.reload(); await openGameTools(page);
  226 |       await ready(page, 6);
  227 |     }
  228 |   }
  229 |   const final = await stored(page);
  230 |   expect(server.calls).toHaveLength(30);
  231 |   expect(final.state.journal[0].story.turnKind).toBe('opening');
  232 |   expect(final.state.journal.slice(1).every((j) => j.story.turnKind === 'regular')).toBe(true);
  233 |   expect(JSON.stringify(final.state)).not.toContain('绝不自动发布的后台线索');
  234 |   expect(JSON.stringify(final.state.journal)).not.toContain('内部未解决事项');
  235 |   await expect(page.locator('main')).not.toContainText('绝不自动发布的后台线索');
  236 |   await page.reload(); await openGameTools(page);
  237 |   expect(await stored(page)).toEqual(final);
  238 |   await ready(page, 10);
  239 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  240 |   await page.screenshot({ path: info.outputPath('ten-committed-turns.png'), fullPage: true });
  241 | });
  242 | 
  243 | test('下一轮生成失败不回滚上轮结算；刷新后只恢复尚未完成的新回合', async ({ page }) => {
  244 |   await configure(page);
  245 |   const server = await mock(page);
  246 |   await createCharacter(page);
  247 |   await ready(page);
  248 |   server.plan.badStoryNumber = 2;
  249 |   await page.getByLabel('你的行动', { exact: true }).fill('去街边等待');
  250 |   await page.getByRole('button', { name: '发送', exact: true }).click();
  251 |   await expect(workflow(page).getByRole('alert')).toContainText('正文生成');
  252 |   const failed = await stored(page);
  253 |   expect(failed.state.turnNumber).toBe(1);
  254 |   expect(failed.draft.userInput).toBe('去街边等待');
  255 |   expect(failed.draft.stageStatus.story).toBe('failed');
  256 |   await page.reload(); await openGameTools(page);
  257 |   server.plan.badStoryNumber = 0;
  258 |   await workflow(page).getByRole('button', { name: '继续未完成阶段', exact: true }).click();
  259 |   await ready(page, 2);
  260 |   expect((await stored(page)).state.turnNumber).toBe(2);
  261 |   expect((await stored(page)).state.journal[0]).toEqual(failed.state.journal[0]);
  262 |   expect(server.calls).toEqual([
  263 |     'story',
  264 |     'variables',
  265 |     'world',
  266 |     'story',
  267 |     'story',
  268 |     'variables',
  269 |     'world',
  270 |   ]);
  271 | });
  272 | 
  273 | test('提交事务中途失败 UI 不虚报成功；重试后只结算一次', async ({ page }) => {
  274 |   await configure(page);
  275 |   await mock(page);
  276 |   await createCharacter(page);
  277 |   await ready(page);
  278 |   const before = await stored(page);
```
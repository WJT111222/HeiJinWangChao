# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: prompt-inspector.spec.ts >> 真实存档六种模式预览、内部内容主动揭示、合法排序保存恢复及状态隔离
- Location: e2e/prompt-inspector.spec.ts:159:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: /读取存档/ })

```

# Page snapshot

```yaml
- main "游戏首页与存档馆" [ref=f2e4]:
  - generic [ref=f2e5]:
    - generic [aria-hidden] [ref=f2e6]: 黑
    - generic [ref=f2e7]:
      - text: 黑金王朝
      - generic [ref=f2e8]: HEIJINWANGCHAO
    - button "设置" [active] [ref=f2e9] [cursor=pointer]
    - generic [ref=f2e10]: V1.0 Beta
  - generic [ref=f2e11]:
    - paragraph [ref=f2e12]: MODERN CITY / OPEN WORLD
    - heading "黑金王朝" [level=1] [ref=f2e13]
    - paragraph [ref=f2e14]: 起点有冲突，人生不预设结局。
  - status "终点 未知，时刻 00:26，已选择" [ref=f2e15]:
    - generic [ref=f2e16]:
      - text: 终点
      - generic [ref=f2e17]: DEST
    - generic [ref=f2e18]:
      - generic [ref=f2e19]: 未
      - generic [ref=f2e20]: 知
    - generic [ref=f2e22]:
      - generic [ref=f2e23]: "0"
      - generic [ref=f2e24]: "0"
      - generic [ref=f2e25]: ":"
      - generic [ref=f2e26]: "2"
      - generic [ref=f2e27]: "6"
    - generic [ref=f2e28]: 已选择
  - generic [ref=f2e29]:
    - generic [ref=f2e30]: 车票 01
    - generic [ref=f2e31]: 本地保存 · 无需账号
    - button "导入备份" [ref=f2e32] [cursor=pointer]: ⤓ 导入备份
    - button "刷新列表" [ref=f2e33] [cursor=pointer]
  - region "车票栏，左右方向键切换" [ref=f2e34]:
    - article "界面测试存档（隔离），保存于 2026/11/15 00:26，已选择" [ref=f2e36]:
      - generic [ref=f2e37]:
        - generic [ref=f2e38]: ARCHIVE 01
        - generic [ref=f2e40]:
          - generic [ref=f2e41]:
            - generic [ref=f2e42]:
              - generic [ref=f2e43]: FROM
              - generic [ref=f2e44]: 界面测试存档（隔离）
            - generic [aria-hidden] [ref=f2e45]: 单程
            - generic [ref=f2e47]: TO
          - generic [ref=f2e49]:
            - generic [ref=f2e50]:
              - term [ref=f2e51]: 保存日期
              - definition [ref=f2e52]: 2026/11/15
            - generic [ref=f2e53]:
              - term [ref=f2e54]: 时刻
              - definition [ref=f2e55]: 00:26
            - generic [ref=f2e56]:
              - generic [aria-hidden]:
                - text: 已检票
                - generic: SELECTED
          - paragraph [ref=f2e57]: 从未备份
      - generic [ref=f2e76]:
        - text: 继续游戏
        - generic [ref=f2e77]: ↓ 按住票根往下撕
    - article "空白车票：开启新的人生" [ref=f2e80]:
      - generic [ref=f2e81]:
        - generic [ref=f2e82]:
          - generic [ref=f2e83]: 空白车票
          - generic [ref=f2e84]: NEW LIFE
          - generic [ref=f2e85]: NEW
        - generic [ref=f2e86]:
          - generic [ref=f2e87]:
            - generic [ref=f2e88]:
              - generic [ref=f2e89]: FROM
              - generic [ref=f2e90]: ？
            - generic [aria-hidden] [ref=f2e91]: 单程
            - generic [ref=f2e93]:
              - generic [ref=f2e94]: TO
              - generic [ref=f2e95]: ？
          - generic [ref=f2e96]:
            - generic [ref=f2e97]:
              - term [ref=f2e98]: 城市
              - definition [ref=f2e99]
            - generic [ref=f2e101]:
              - term [ref=f2e102]: 职业
              - definition [ref=f2e103]
            - generic [ref=f2e105]:
              - term [ref=f2e106]: 存档
              - definition [ref=f2e107]: —
          - paragraph [ref=f2e108]: 四座城市 · 自由职业 · 开放人生
      - generic [ref=f2e110]:
        - text: 开启新的人生
        - generic [ref=f2e111]: ↓ 按住票根往下撕
  - navigation "车票页码" [ref=f2e113]:
    - button "第 1 张" [ref=f2e114] [cursor=pointer]
    - button "第 2 张，空白车票" [ref=f2e115] [cursor=pointer]
  - generic [ref=f2e116]:
    - button "继续游戏" [ref=f2e117] [cursor=pointer]:
      - text: 继续游戏
      - generic [aria-hidden] [ref=f2e118]: →
    - generic [ref=f2e119]:
      - button "导出备份" [ref=f2e120] [cursor=pointer]
      - button "删除" [ref=f2e121] [cursor=pointer]
  - generic [ref=f2e122]:
    - group "游玩信息" [ref=f2e123]:
      - button "游玩须知与免责声明" [ref=f2e124] [cursor=pointer]
      - button "王朝公告" [ref=f2e125] [cursor=pointer]
    - paragraph [ref=f2e126]: 四座城市 · 自由职业 · 开放人生三阶段生成 · 原子结算 · 连续回合
```

# Test source

```ts
  132 |   await source.getByRole('button', { name: 'JSON 变量', exact: true }).click();
  133 |   await expect(source).toContainText('variableGroups.protagonist.update');
  134 |   await expect(source).not.toContainText('variableGroups.protagonist.update.text');
  135 |   for (const format of ['json', 'text'] as const) {
  136 |     await source.getByRole('button', { name: format === 'json' ? 'JSON 变量' : '文本变量', exact: true }).click();
  137 |     const id = `variableGroups.protagonist.update${format === 'text' ? '.text' : ''}`;
  138 |     const expected = await page.evaluate(async id => {
  139 |       const path = '/src/prompts/loader.ts';
  140 |       return (await import(path)).readPromptResource(id);
  141 |     }, id);
  142 |     await expect(page.getByLabel('模块完整原文')).toHaveText(expected);
  143 |     await screenshot(page, `source-${format}`);
  144 |   }
  145 |   for (const label of ['初始化', '场外规则', '常规更新']) {
  146 |     await source.getByRole('group', { name: '规则阶段' }).getByRole('button', { name: label, exact: true }).click();
  147 |     await expect(source.getByRole('button', { name: label, exact: true })).toHaveAttribute('aria-pressed', 'true');
  148 |     await expect(page.getByLabel('模块完整原文')).not.toBeEmpty();
  149 |   }
  150 |   await source.getByRole('button', { name: '高级', exact: true }).click();
  151 |   await page.getByRole('combobox', { name: '数据来源', exact: true }).selectOption('actual');
  152 |   await expect(page.getByText(/此阶段\/模式没有实际请求快照/)).toBeVisible();
  153 |   await expect(page.getByRole('button', { name: '主动查看完整内部上下文' })).toHaveCount(0);
  154 |   await expect(page.getByRole('region', { name: '上下文与统计' })).toContainText('未提供');
  155 |   expect(external).toEqual([]);
  156 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  157 | });
  158 | 
  159 | test('真实存档六种模式预览、内部内容主动揭示、合法排序保存恢复及状态隔离', async ({
  160 |   page,
  161 | }, testInfo) => {
  162 |   const errors: string[] = [];
  163 |   page.on('pageerror', (error) => errors.push(error.message));
  164 |   const before = await seed(page);
  165 |   await page.reload();
  166 |   await inspector(page);
  167 |   await page.getByRole('combobox', { name: '回合模式', exact: true }).selectOption('regular');
  168 |   await page.getByRole('button', { name: '下移 writing.conflict_pacing', exact: true }).click();
  169 |   await expect(page.getByRole('button', { name: '保存提示词排序' })).toBeEnabled();
  170 |   await page.getByRole('combobox', { name: '检查阶段', exact: true }).selectOption('variables');
  171 |   await expect(page.getByRole('button', { name: '保存提示词排序' })).toBeEnabled();
  172 |   await page.getByRole('combobox', { name: '检查阶段', exact: true }).selectOption('story');
  173 |   const order = page.locator('.prompt-order-list li');
  174 |   await expect(order.first()).toContainText('identity.fusheng');
  175 |   await expect(page.locator('[data-module-id="identity.fusheng"]')).toContainText('固定');
  176 |   await page.getByRole('button', { name: '保存提示词排序' }).click();
  177 |   await page.getByRole('button', { name: '生成三阶段组装预览（不联网）' }).click();
  178 |   await expect(
  179 |     page.getByText('预览已组装；未发送 API 请求、未执行回合、未写入正式存档。'),
  180 |   ).toBeVisible();
  181 |   await expect(page.locator('.stage-stat-cards')).toContainText('离线预览');
  182 |   await expect(page.getByRole('region', { name: '上下文与统计' })).toContainText('当前模型上下文窗口未知，无法确认请求是否超限。');
  183 |   await page.getByText('展开数据分类、召回预算与重复诊断', { exact: true }).click();
  184 |   await expect(page.getByRole('region', { name: '上下文与统计' })).toContainText('召回预算只影响旧journal原文，不影响完整正式世界状态。');
  185 |   await expect(page.getByRole('region', { name: '上下文与统计' })).toContainText('字符差额 0，字节差额 0');
  186 |   for (const stage of ['story', 'variables', 'world']) {
  187 |     await page.getByRole('combobox', { name: '检查阶段', exact: true }).selectOption(stage);
  188 |     await expect(
  189 |       page.locator(`.prompt-order-list [data-module-id="stages.regular.${stage}${stage === 'variables' ? '.text' : ''}"]`),
  190 |     ).toBeVisible();
  191 |     await expect(page.getByLabel('完整内部上下文', { exact: true })).toHaveCount(0);
  192 |     await expect(page.getByRole('region', { name: '上下文与统计' })).not.toContainText(
  193 |       '秘密计划不可见',
  194 |     );
  195 |   }
  196 |   await page.screenshot({ path: testInfo.outputPath('prompt-inspector.png') });
  197 |   await page.getByRole('button', { name: '主动查看完整内部上下文' }).click();
  198 |   await page.getByRole('combobox', { name: '内部内容视图', exact: true }).selectOption('context');
  199 |   await expect(page.getByLabel('完整内部上下文', { exact: true })).toContainText('秘密计划不可见');
  200 |   await expect(page.getByLabel('完整内部上下文', { exact: true })).toContainText('OFFSCREEN_STATE');
  201 |   await page.getByRole('combobox', { name: '检查阶段', exact: true }).selectOption('story');
  202 |   await expect(page.getByLabel('完整内部上下文', { exact: true })).toHaveCount(0);
  203 |   await page.getByRole('button', { name: '主动查看完整内部上下文' }).click();
  204 |   await expect(page.getByLabel('完整内部上下文', { exact: true })).toContainText('秘密计划不可见');
  205 |   await page.getByRole('combobox', { name: '回合模式', exact: true }).selectOption('opening');
  206 |   await page.getByRole('button', { name: '生成三阶段组装预览（不联网）' }).click();
  207 |   await expect(
  208 |     page.getByText('预览已组装；未发送 API 请求、未执行回合、未写入正式存档。'),
  209 |   ).toBeVisible();
  210 |   await expect(page.locator('[data-module-id="stages.opening.story"]')).toBeVisible();
  211 |   await page.getByRole('combobox', { name: '检查阶段', exact: true }).selectOption('variables');
  212 |   await expect(page.getByRole('region', { name: '上下文与统计' })).toContainText('模式不匹配');
  213 |   expect(await readFormal(page)).toBe(before);
  214 |   await page.reload();
  215 |   await inspector(page);
  216 |   const saved = await page.evaluate(() =>
  217 |     JSON.parse(localStorage.getItem('heijin.prompt-order.v1')!),
  218 |   );
  219 |   expect(saved.overrides['writing.conflict_pacing']).toBe(81);
  220 |   const ids = await page
  221 |     .locator('.prompt-order-list li')
  222 |     .evaluateAll((items) => items.map((item) => item.getAttribute('data-module-id')));
  223 |   expect(ids.indexOf('writing.emotion_guard')).toBeLessThan(ids.indexOf('writing.conflict_pacing'));
  224 |   await page.getByRole('button', { name: '恢复默认顺序' }).click();
  225 |   const reset = await page
  226 |     .locator('.prompt-order-list li')
  227 |     .evaluateAll((items) => items.map((item) => item.getAttribute('data-module-id')));
  228 |   expect(reset.indexOf('writing.conflict_pacing')).toBeLessThan(
  229 |     reset.indexOf('writing.emotion_guard'),
  230 |   );
  231 |   await page.keyboard.press('Escape');
> 232 |   await openLibrary(page);await page.getByRole('button', { name: /读取存档/ }).click();
      |                                                                            ^ Error: locator.click: Test timeout of 30000ms exceeded.
  233 |   await expect(page.locator('.game-layout')).toBeVisible();
  234 |   await openWorldArchive(page);
  235 |   await page
  236 |     .getByRole('complementary', { name: '世界资料' })
  237 |     .getByRole('button', { name: /NPC/ })
  238 |     .click();
  239 |   await expect(page.getByRole('dialog', { name: 'NPC', exact: true })).toContainText('隐藏人物不可见');
  240 |   expect(await readFormal(page)).toBe(before);
  241 |   expect(errors).toEqual([]);
  242 | });
  243 | 
  244 | test('已发送阶段快照保留原请求数据与真实 usage，默认隐藏秘密且始终去密钥，刷新不持久化', async ({
  245 |   page,
  246 | }, testInfo) => {
  247 |   const before = await seed(page);
  248 |   await page.reload();
  249 |   let transmitted = '';
  250 |   await page.route('https://inspector.mock.invalid/**', async (route) => {
  251 |     transmitted = route.request().postData() ?? '';
  252 |     await route.fulfill({
  253 |       json: {
  254 |         choices: [
  255 |           {
  256 |             message: {
  257 |               content: JSON.stringify({
  258 |                 worldCommands: [],
  259 |                 taskCommands: [],
  260 |                 eventCommands: [],
  261 |                 visibleHooks: [],
  262 |                 unresolved: [],
  263 |               }),
  264 |             },
  265 |             finish_reason: 'stop',
  266 |           },
  267 |         ],
  268 |         usage: { prompt_tokens: 42, completion_tokens: 7, total_tokens: 49 },
  269 |       },
  270 |     });
  271 |   });
  272 |   await page.evaluate(async () => {
  273 |     const repoPath = '/src/services/storage/saveRepository.ts';
  274 |     const runtimePath = '/src/services/ai/runtime.ts';
  275 |     const configPath = '/src/services/ai/configuration.ts';
  276 |     const credentialsPath = '/src/services/ai/credentials.ts';
  277 |     const settingsPath = '/src/ui/settings/model.ts';
  278 |     const { SaveRepository } = await import(repoPath);
  279 |     const { runStageRequest } = await import(runtimePath);
  280 |     const { newChannel, defaultAiConfig, saveAiConfig } = await import(configPath);
  281 |     const { CredentialVault } = await import(credentialsPath);
  282 |     const { defaultSettings } = await import(settingsPath);
  283 |     const channel = {
  284 |       ...newChannel(),
  285 |       baseUrl: 'https://inspector.mock.invalid/v1',
  286 |       defaultModel: 'mock-before',
  287 |     };
  288 |     const config = defaultAiConfig();
  289 |     config.channels = [channel];
  290 |     config.routes.story = { channelId: channel.id, modelId: '' };
  291 |     saveAiConfig(localStorage, config);
  292 |     const vault = new CredentialVault(sessionStorage, localStorage);
  293 |     vault.set(channel.id, 'e2e-inspection-key');
  294 |     const repo = await SaveRepository.open();
  295 |     try {
  296 |       const state = await repo.load('ui-test');
  297 |       const draft = await repo.loadDraft('ui-test');
  298 |       await runStageRequest(
  299 |         {
  300 |           state,
  301 |           draft,
  302 |           settings: defaultSettings(),
  303 |           stage: 'world',
  304 |           mode: 'regular',
  305 |           userInput: '',
  306 |           domains: ['economy'],
  307 |         },
  308 |         config,
  309 |         vault,
  310 |       );
  311 |       config.channels[0].defaultModel = 'mock-after';
  312 |       saveAiConfig(localStorage, config);
  313 |     } finally {
  314 |       repo.close();
  315 |     }
  316 |   });
  317 |   const snapshotExample = await page.evaluate(async () => {
  318 |     const path = '/src/services/ai/inspection.ts';
  319 |     const { requestInspections } = await import(path);
  320 |     const record = requestInspections.getSnapshot()[0];
  321 |     return {
  322 |       source: 'Mock HTTP intercepted by Playwright',
  323 |       route: record.route,
  324 |       status: record.status,
  325 |       mode: record.scope.mode,
  326 |       stage: record.stage,
  327 |       modules: record.scope.modules,
  328 |       statistics: record.statistics,
  329 |     };
  330 |   });
  331 |   await writeFile(
  332 |     testInfo.outputPath('request-summary.json'),
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: event-stages-v2.spec.ts >> 固定阶段积压结算保留原时刻并退役，失败仅重试World后刷新不重复请求
- Location: e2e/event-stages-v2.spec.ts:23:40

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByTestId('runtime-log')
Expected substring: "stage_result"
Error: strict mode violation: getByTestId('runtime-log') resolved to 2 elements:
    1) <details open="" class="runtime-log" data-testid="runtime-log">…</details> aka getByRole('tabpanel', { name: '运行日志' }).getByTestId('runtime-log')
    2) <details open="" class="runtime-log" data-testid="runtime-log">…</details> aka getByRole('region', { name: '三阶段详情' }).getByTestId('runtime-log')

Call log:
  - Expect "toContainText" getByTestId('runtime-log') with timeout 5000ms
  - waiting for getByTestId('runtime-log')

```

# Page snapshot

```yaml
- generic:
  - generic [ref=f1e1]:
    - banner:
      - button "打开游戏菜单" [ref=f1e2] [cursor=pointer]: ☰
    - main [ref=f1e3]:
      - generic "城市与当前场景" [ref=f1e4]:
        - button "此时此地与主角状态" [ref=f1e5] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e6]: 城
          - generic [ref=f1e7]:
            - generic [ref=f1e8]: 当前地点
            - generic [ref=f1e9]: 重庆
          - time [ref=f1e10]: 00:00
          - generic "天气：天气待确认" [ref=f1e11]: —
        - generic [ref=f1e12]: 重庆，2027/1/1 星期五 00:00，天气：天气待确认
      - region "剧情与行动" [ref=f1e13]:
        - generic "正文阅读区域" [ref=f1e14]:
          - generic [ref=f1e15]:
            - generic [ref=f1e16]: THE STORY
            - generic [ref=f1e17]: 已保存草稿
          - article [ref=f1e18]:
            - generic [ref=f1e19]:
              - heading "第 1 回合" [level=2] [ref=f1e20]
              - generic [aria-hidden] [ref=f1e21]: 第一回
              - generic [ref=f1e22]:
                - text: 2027/1/1 · 星期五 · 00:00
                - generic [ref=f1e23]: 重庆
                - text: · 草稿
            - text: 正文草稿 · 世界状态尚未确认
            - paragraph [ref=f1e25]: 日常工作与生活继续。
        - generic [ref=f1e26]:
          - region "三阶段工作流" [ref=f1e28]:
            - button "三阶段工作流详情" [expanded] [ref=f1e31] [cursor=pointer]:
              - status [ref=f1e36]:
                - generic [ref=f1e37]: 三阶段 ·
                - text: 动态世界生成失败 · 查看详情
              - generic [ref=f1e38]: 详情 ›
          - generic [ref=f1e39]:
            - button "撤回" [disabled] [ref=f1e42]:
              - generic [aria-hidden] [ref=f1e43]: 撤
            - generic [ref=f1e44]: 你的行动
            - textbox "你的行动" [ref=f1e45]:
              - /placeholder: 填写你的行动
            - button "发送" [disabled] [ref=f1e47]
      - navigation "底部导航" [ref=f1e48]:
        - button "故事" [ref=f1e49] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e50]: 文
          - text: 故事
        - button "人物" [ref=f1e51] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e52]: 我
          - text: 人物
        - button "世界资料" [ref=f1e53] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e54]: 世
          - text: 世界资料
        - button "设置" [ref=f1e55] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e56]: 设
          - text: 设置
      - dialog [active] [ref=f1e57]:
        - generic [ref=f1e60]:
          - generic [aria-hidden] [ref=f1e61]: 诊
          - generic [ref=f1e62]:
            - paragraph [aria-hidden] [ref=f1e63]: WORKFLOW · 诊断
            - heading "重试与变更详情" [level=2] [ref=f1e64]
          - button "关闭资料界面" [ref=f1e65] [cursor=pointer]:
            - text: 关闭
            - generic [aria-hidden] [ref=f1e66]: ×
        - generic [ref=f1e67]:
          - tablist "诊断分类" [ref=f1e68]:
            - tab "概要" [ref=f1e69] [cursor=pointer]
            - tab "运行日志 1" [selected] [ref=f1e70] [cursor=pointer]:
              - text: 运行日志
              - generic [ref=f1e71]: "1"
            - tab "请求用量 1" [ref=f1e72] [cursor=pointer]:
              - text: 请求用量
              - generic [ref=f1e73]: "1"
            - tab "模型原文" [ref=f1e74] [cursor=pointer]
          - tabpanel "运行日志 1" [ref=f1e75]:
            - group [ref=f1e76]:
              - generic "运行日志 · 错误 1 条 最近错误 · data_integrity" [ref=f1e77] [cursor=pointer]:
                - generic [ref=f1e78]: 运行日志 · 错误 1 条
                - strong [ref=f1e79]: 最近错误 · data_integrity
              - generic [ref=f1e80]:
                - paragraph [ref=f1e81]: 仅显示本次页面会话的错误；每条可单独复制安全诊断，不含原始模型响应、请求正文或密钥。刷新即清空。
                - button "清空日志" [ref=f1e83] [cursor=pointer]
                - list "错误日志条目" [ref=f1e84]:
                  - listitem [ref=f1e85]:
                    - generic [ref=f1e86]:
                      - generic [ref=f1e87]:
                        - time [ref=f1e88]: 16:21:37
                        - strong [ref=f1e89]: 动态世界
                        - generic [ref=f1e90]: 错误
                      - button "复制此条" [ref=f1e91] [cursor=pointer]
                    - paragraph [ref=f1e92]: 候选的实体引用、归属、数量或状态不合法，候选未保存。
                    - generic [ref=f1e93]: 错误码：data_integrity
                    - generic [ref=f1e94]: 字段：eventCommands.1
                    - generic [ref=f1e95]: 命令序号：第 2 条
                    - generic [ref=f1e96]: 命令类型：DeleteEvent
                    - generic [ref=f1e97]: 世界校验：stage_result · 阶段结案成果不完整
          - paragraph [ref=f1e98]: 仅本页临时保存 · 刷新即清空
  - generic [ref=f1e99]:
    - button "收起工作流暗区" [ref=f1e100] [cursor=pointer]
    - dialog "三阶段工作流" [ref=f1e101]:
      - generic [ref=f1e102]:
        - button "收起三阶段工作流" [ref=f1e103] [cursor=pointer]
        - button "行动输入" [ref=f1e105] [cursor=pointer]
      - region "三阶段详情" [ref=f1e106]:
        - generic [ref=f1e107]:
          - generic [ref=f1e108]:
            - text: THREE STAGES · 三阶段
            - heading "动态世界生成失败 · 查看详情" [level=3] [ref=f1e109]
          - button "收起三阶段详情" [ref=f1e110] [cursor=pointer]: ×
        - alert [ref=f1e112]:
          - text: 误
          - generic [ref=f1e113]:
            - paragraph [ref=f1e114]: 动态世界：候选的实体引用、归属、数量或状态不合法，候选未保存。 字段：eventCommands.1（DeleteEvent，第2条）。
            - generic [ref=f1e115]: 动态世界 · 安全失败码：data_integrity · 1 次尝试
          - button "打开 AI 设置" [ref=f1e116] [cursor=pointer]
          - button "关闭错误提示" [ref=f1e117] [cursor=pointer]: ×
        - navigation "三阶段导航" [ref=f1e119]:
          - paragraph [ref=f1e120]: STAGES
          - list [ref=f1e121]:
            - listitem [ref=f1e122]:
              - button "01正文生成 已完成" [ref=f1e123] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e124]: ✓
                - strong [ref=f1e125]:
                  - generic [ref=f1e126]: "01"
                  - text: 正文生成
                - generic [ref=f1e127]: 已完成
            - listitem [ref=f1e128]:
              - button "02变量管理 已完成" [ref=f1e129] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e130]: ✓
                - strong [ref=f1e131]:
                  - generic [ref=f1e132]: "02"
                  - text: 变量管理
                - generic [ref=f1e133]: 已完成
              - generic "变量管理阶段开关" [ref=f1e134]:
                - checkbox "变量管理" [checked] [ref=f1e135]
            - listitem [ref=f1e136]:
              - button "03动态世界 失败 · 可重试" [ref=f1e137] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e138]: "!"
                - strong [ref=f1e139]:
                  - generic [ref=f1e140]: "03"
                  - text: 动态世界
                - generic [ref=f1e141]: 失败 · 可重试
              - generic "动态世界阶段开关" [ref=f1e142]:
                - checkbox "动态世界" [checked] [ref=f1e143]
          - paragraph [ref=f1e144]: 本回合
          - list [ref=f1e145]:
            - listitem [ref=f1e146]:
              - button "运行诊断 错误与用量 错误 1 条" [ref=f1e147] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e148]: 诊
                - strong [ref=f1e149]: 运行诊断
                - generic [ref=f1e150]: 错误与用量
                - generic "错误 1 条" [ref=f1e151]: "1"
            - listitem [ref=f1e152]:
              - button "已绑定输入 只读" [ref=f1e153] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e154]: 述
                - strong [ref=f1e155]: 已绑定输入
                - generic [ref=f1e156]: 只读
        - generic [ref=f1e157]:
          - button "继续未完成阶段" [ref=f1e159] [cursor=pointer]
          - generic [ref=f1e160]: 生成可能产生费用。
```

# Test source

```ts
  1  | import { expect, test } from './helpers/test';
  2  | import type { Page } from '@playwright/test';
  3  | import { openGameTools } from './helpers/gameLayout';
  4  | async function seed(page:Page,clock?:string,unseen=false) {
  5  |   await page.goto('/');
  6  |   const response=await page.evaluate(async({clock,unseen})=>{
  7  |     const paths=['/src/services/storage/saveRepository.ts','/src/tests/fixtures/eventStages.ts','/src/domain/drafts.ts','/src/services/ai/configuration.ts','/src/services/ai/credentials.ts','/src/ui/settings/model.ts'];
  8  |     const [{SaveRepository},{stageContext,endStage,stageCommand},{createTurnDraft,rerollStory},{defaultAiConfig,newChannel,saveAiConfig},{CredentialVault},{defaultSettings,settingsKey}]=await Promise.all(paths.map(path=>import(path)));
  9  |     const settings=defaultSettings();settings.prompts.minNarrativeChars=1;settings.prompts.actionOptions=false;
  10 |     for(const value of Object.values(settings.memory.summaries) as {automatic:boolean}[])value.automatic=false;
  11 |     localStorage.setItem(settingsKey,JSON.stringify(settings));
  12 |     const config=defaultAiConfig(),channel=newChannel();channel.baseUrl='https://event-stages.mock.invalid/v1';channel.defaultModel='world-stage-mock';
  13 |     config.channels=[channel];config.routes.story={channelId:channel.id,modelId:'story'};config.routes.variables={mode:'independent',channelId:channel.id,modelId:'variables'};config.routes.world={mode:'independent',channelId:channel.id,modelId:'world'};saveAiConfig(localStorage,config);
  14 |     new CredentialVault(sessionStorage,localStorage).set(channel.id,'stage-browser-test-only');
  15 |     const a=stageContext(clock),repo=await SaveRepository.open();
  16 |     if(unseen){const stage=a.state.events['stage-one'];stage.sourceTurnIds=[a.draft.turnId];stage.protagonistEntry={id:'unseen-stage-entry',sourceTurnId:a.draft.turnId,queuedAt:a.state.worldClock,channel:'电话',cue:'尚未呈现的旧安排',status:'pending'};}
  17 |     try {await repo.create(a.state);const initial=createTurnDraft('save-a',0,a.draft.turnId,'opening','');await repo.saveDraft(initial,null);await repo.saveDraft(rerollStory(initial,a.draft.story),0);await repo.saveDraft({...a.draft,draftRevision:2},1);}finally{repo.close();}
  18 |     return {...a.response,eventCommands:[stageCommand(endStage(a.state.events['stage-one'])),{type:'DeleteEvent',commandId:'cleanup-stage',eventId:'stage-one',expectedStatus:'resolved',reason:'阶段成果保留后清理',evidence:'合成测试'}]};
  19 |   },{clock,unseen});
  20 |   await page.goto('/#game/save-a');await page.reload();await openGameTools(page);return response;
  21 | }
  22 | const stored=(page:Page)=>page.evaluate(async()=>{const path='/src/services/storage/saveRepository.ts',{SaveRepository}=await import(path),repo=await SaveRepository.open();try{return await repo.loadGame('save-a');}finally{repo.close();}});
  23 | for(const firstFailure of [false,true])test(`固定阶段积压结算保留原时刻并退役，${firstFailure?'失败仅重试World':'直接自动提交'}后刷新不重复请求`,async({page})=>{
  24 |   const response=await seed(page),initial=await stored(page);let invalid=firstFailure,calls=0;
  25 |   await page.route('https://event-stages.mock.invalid/**',async route=>{
  26 |     calls++;const reply=structuredClone(response);
  27 |     if(invalid)delete reply.eventCommands[0].event.outcome;
  28 |     await route.fulfill({contentType:'application/json',body:JSON.stringify({choices:[{message:{content:JSON.stringify(reply)},finish_reason:'stop'}]})});
  29 |   });
  30 |   await page.getByRole('button',{name:'继续未完成阶段',exact:true}).click();
  31 |   if(firstFailure){
> 32 |     await expect(page.getByTestId('runtime-log')).toContainText('stage_result');
     |                                                   ^ Error: expect(locator).toContainText(expected) failed
  33 |     const failed=await stored(page);expect(failed.state).toEqual(initial.state);expect(failed.draft.story).toEqual(initial.draft.story);expect(failed.draft.variables).toEqual(initial.draft.variables);
  34 |     expect(calls).toBe(1);await page.reload();await openGameTools(page);expect(calls).toBe(1);invalid=false;
  35 |     await page.getByRole('button',{name:'继续未完成阶段',exact:true}).click();
  36 |   }
  37 |   await expect(page.getByRole('region',{name:'三阶段工作流'}).getByRole('status')).toContainText('本回合已结算');
  38 |   const saved=await stored(page);expect(saved.state.events['stage-one']).toBeUndefined();
  39 |   expect(saved.state.retiredEvents['stage-one'].detail).toMatchObject({resolvedAt:'2027-01-03T00:00:00+08:00',outcome:'success',resolutionText:expect.any(String),resultKnowledge:{reported:['值班人员提出另一种说法']}});
  40 |   expect(saved.state.events['main-stage']).toEqual(initial.state.events['main-stage']);expect(saved.state.worldClock).toBe('2027-04-01T00:00:00+08:00');
  41 |   expect(calls).toBe(firstFailure?2:1);await page.reload();await openGameTools(page);
  42 |   expect((await stored(page)).state).toEqual(saved.state);expect(calls).toBe(firstFailure?2:1);await expect(page.getByLabel('你的行动',{exact:true})).toHaveValue('');
  43 | });
  44 | 
  45 | test('真实新阶段入场→下一轮Story回执→Variables提前结案，World不覆盖，不增加阶段调用',async({page})=>{
  46 |   const response=await seed(page,'2027-01-02T00:00:00+08:00'),calls:string[]=[];let worlds=0;
  47 |   const invited={...response.eventCommands[0].event,id:'early-invited',title:'提前入场的阶段',status:'active',continuation:{direction:'protagonist',reason:'现在需要电话核对',entry:{channel:'电话',cue:'请核对本阶段材料'}}};
  48 |   for(const key of ['resolvedAt','outcome','resolutionText','resultKnowledge'])delete invited[key];
  49 |   await page.route('https://event-stages.mock.invalid/**',async route=>{
  50 |     const body=route.request().postDataJSON(),stage=String(body.model);calls.push(stage);
  51 |     const joined=body.messages.map((m:{content:string})=>m.content).join('\n'),matched=joined.match(/<GAME_CONTEXT>\n([\s\S]*?)\n<\/GAME_CONTEXT>/);if(!matched)throw Error('missing final context');
  52 |     const context=JSON.parse(matched[1]);let text:string;
  53 |     if(stage==='story') {
  54 |       const entry=context.EVENT_ENTRIES.find((e:{eventId:string})=>e.eventId==='early-invited');expect(entry).toBeTruthy();
  55 |       text=`<thinking>按玩家行动处理当前来电。</thinking><正文>【旁白】主角在通话中实际核对并结束了本阶段。</正文><短期记忆>主角已经完成本次核对。</短期记忆><变量规划>${JSON.stringify([{group:'event',observedFact:'阶段实际结束',textEvidence:'通话中核对完成',eventInteraction:{eventId:'early-invited',entryId:entry.entryId,action:'left'}}])}</变量规划>`;
  56 |     } else if(stage==='variables') {
  57 |       text='<thinking>只落实本幕现场变化。</thinking><说明>实际提前结束本阶段。</说明><命令>set worldClock = "2027-01-02T01:00:00+08:00"\nset events[early-invited].sceneState = {"status":"resolved","resolvedAt":"2027-01-02T01:00:00+08:00","outcome":"changed","resolutionText":"主角实际核对并结束了阶段。"}</命令>';
  58 |     } else {
  59 |       worlds++;if(worlds===2)expect(context.SAVE_STATE.events['early-invited'].status).toBe('resolved');
  60 |       text=JSON.stringify({worldCommands:[],taskCommands:[],eventCommands:worlds===1?[{type:'SaveEvent',commandId:'invite-stage',event:invited,evidence:'真实开始的合成阶段'}]:[],visibleHooks:[],unresolved:[]});
  61 |     }
  62 |     await route.fulfill({contentType:stage==='story'?'text/event-stream':'application/json',body:stage==='story'?`data: ${JSON.stringify({choices:[{delta:{content:text}}]})}\n\ndata: [DONE]\n\n`:JSON.stringify({choices:[{message:{content:text},finish_reason:'stop'}]})});
  63 |   });
  64 |   await page.getByRole('button',{name:'继续未完成阶段',exact:true}).click();
  65 |   await expect.poll(async()=>(await stored(page)).state.turnNumber).toBe(1);
  66 |   expect((await stored(page)).state.events['early-invited'].protagonistEntry.status).toBe('pending');
  67 |   await page.getByLabel('你的行动',{exact:true}).fill('接听并结束本阶段');await page.getByRole('button',{name:'发送',exact:true}).click();
  68 |   await expect.poll(async()=>(await stored(page)).state.turnNumber).toBe(2);
  69 |   const data=await stored(page);expect(data.state.events['early-invited']).toMatchObject({resolvedAt:'2027-01-02T01:00:00+08:00',fixedEndAt:'2027-01-03T00:00:00+08:00',outcome:'changed',protagonistEntry:{status:'left'}});
  70 |   expect(calls).toEqual(['world','story','variables','world']);await page.reload();expect(calls).toHaveLength(4);
  71 | });
  72 | 
  73 | test('阶段成功自然结束且不需后继时，未呈现邀请可原子失效，不强造取消结果或玩家回应',async({page})=>{
  74 |   const response=await seed(page,undefined,true),before=await stored(page);let calls=0;
  75 |   await page.route('https://event-stages.mock.invalid/**',async route=>{calls++;await route.fulfill({contentType:'application/json',body:JSON.stringify({choices:[{message:{content:JSON.stringify(response)},finish_reason:'stop'}]})});});
  76 |   await page.getByRole('button',{name:'继续未完成阶段',exact:true}).click();
  77 |   await expect.poll(async()=>(await stored(page)).state.turnNumber).toBe(1);
  78 |   const saved=await stored(page);expect(saved.state.events['stage-one']).toBeUndefined();expect(saved.state.retiredEvents['stage-one'].detail.outcome).toBe('success');
  79 |   expect(Object.values(saved.state.events).some((e:unknown)=>Boolean((e as {protagonistEntry?:unknown}).protagonistEntry))).toBe(false);
  80 |   expect(saved.state.protagonist).toEqual(before.state.protagonist);expect(calls).toBe(1);await page.reload();expect((await stored(page)).state).toEqual(saved.state);expect(calls).toBe(1);
  81 | });
  82 | 
```
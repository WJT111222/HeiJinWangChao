import { createServer } from './c2/node_modules/vite/dist/node/index.js';
import { createSession } from './c2/experiments/spreset/core.mjs';
import { writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
const server=await createServer({root:resolve('c2'),server:{middlewareMode:true,hmr:false},cacheDir:resolve('evidence/parser-cache'),logLevel:'error'});
const {readPrototypeResponse}=await server.ssrLoadModule('/src/presets/spreset/response.ts');
const rows=[], arg={content:'码头交班。'}, call={id:'fixture-one',name:'submit_scene',args:arg};
const stream=(events)=>new Response(events.map(o=>'data: '+(typeof o==='string'?o:JSON.stringify(o))+'\n\n').join(''),{headers:{'content-type':'text/event-stream'}});
const test=async(p,format,kind,response,expected)=>{const session=createSession();session('prepare',{messages:[],stream:format==='sse'});let result,returns;try{const parsed=await readPrototypeResponse(response,p,new AbortController().signal);const final=session('finish',{text:parsed.text,call:parsed.call});result='deliver';returns={finish:parsed.finish,receipt:final.receipt}}catch(e){result='reject';returns={error:e.code??e.name}}rows.push({p,format,kind,expected,result,pass:expected===result,...returns})};
const gem=(calls,finishReason)=>({candidates:[{content:{role:'model',parts:calls.map(functionCall=>({functionCall}))},finishReason}]});
try{
for (const index of [0,null,2]) {
 const start={type:'content_block_start',index:0,content_block:{type:'tool_use',id:call.id,name:call.name,input:{}}};
 const delta={type:'content_block_delta',index:0,delta:{type:'input_json_delta',partial_json:JSON.stringify(arg)}};
 await test('anthropic','sse','close-index-'+index,stream([start,delta,{type:'content_block_stop',index},{type:'message_delta',delta:{stop_reason:'tool_use'}},{type:'message_stop'}]),index===0?'deliver':'reject');
}
writeFileSync('evidence/c2-close.json',JSON.stringify(rows,null,2));console.log({pass:rows.filter(r=>r.pass).length,fail:rows.filter(r=>!r.pass).length,total:rows.length})
}finally{await server.close()}

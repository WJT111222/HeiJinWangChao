import {resolve} from 'node:path';import {writeFileSync,readFileSync} from 'node:fs';import {createHash} from 'node:crypto';
const repo=process.argv[2],root=resolve(repo),out='evidence/'+repo+'-extra-frames.json'; const {createServer}=await import('./'+repo+'/node_modules/vite/dist/node/index.js');const {chromium,devices}=await import('./'+repo+'/node_modules/playwright/index.mjs');
const port={c1:5461,c2:5412,combined:5413}[repo];const url='http://127.0.0.1:'+port;
const server=await createServer({root,cacheDir:resolve('evidence',repo+'-extra-frames-cache'),server:{host:'127.0.0.1',port,strictPort:true,hmr:false},logLevel:'error'});await server.listen();
const browser=await chromium.launch({executablePath:'/usr/bin/chromium'}), results=[];
const story='<正文>海风掀起码头上的白纸，守门人拾起纸条。</正文><短期记忆>拾起纸条</短期记忆><变量规划>[]</变量规划>';const two='<正文>守门人对着台历核对日期。</正文><短期记忆>核对日期</短期记忆><变量规划>[]</变量规划>';
const sha=s=>createHash('sha256').update(s).digest('hex');
async function run(mode,protocol,kind,device='desktop') {
 const ctx=await browser.newContext(device==='mobile'?devices['Pixel 7']:{viewport:{width:1440,height:1000}});const page=await ctx.newPage();
 await ctx.addInitScript(()=>{Math.random=()=>.42});await ctx.clock.setFixedTime(new Date('2026-11-01T02:00:00Z'));
 const received=[],workerCaps=[],blocked=[];let refs=[];
 page.on('worker',w=>{refs.push(w); w.evaluate(()=>({name:self.name,origin:self.origin,idbType:typeof self.indexedDB,fetchType:typeof self.fetch,windowType:typeof window,localStorageType:typeof localStorage})).then(v=>workerCaps.push(v)).catch(()=>{});});
 await page.route('**/*',async route=>{
  const u=new URL(route.request().url());
  if(u.hostname==='joint.mock.invalid'){
   const post=route.request().postData();received.push({sha:sha(post),bytes:Buffer.byteLength(post)});const req=JSON.parse(post);
   const tool=protocol==='gemini'?req.tools?.[0]?.functionDeclarations?.[0]?.name:protocol==='anthropic'?req.tools?.[0]?.name:req.tools?.[0]?.function?.name;
   const tools=JSON.stringify(req.tools??[]), name=tools.includes('actual_content')?'actual_content':tool;
   const again=received.length>1&&kind==='reroll';
   const text=again||kind==='badTag'?'缺少正式正文标签':story;
   if(kind==='cancel'){await page.evaluate(()=>window.dispatchEvent(new Event('independent-cancel')));return route.abort();}
   if(kind==='error')return route.fulfill({status:503,json:{error:{message:'本地服务错误'}}});
   if(kind==='refuse')return route.fulfill({json:{choices:[{message:{refusal:'本地拒答'},finish_reason:'content_filter'}]}});
   if(kind==='truncated')return route.fulfill({json:{choices:[{message:{content:'<正文>片段'},finish_reason:'length'}]}});
   const sendFrames=(frames)=>{received.at(-1).events=frames;return route.fulfill({contentType:'text/event-stream',body:frames.map(f=>'data: '+(typeof f==='string'?f:JSON.stringify(f))+'\n\n').join('')});};
   if(protocol==='anthropic'){
    const start={type:'content_block_start',index:0,content_block:{type:'tool_use',name,id:'fixture-1',input:{}}};
    const delta={type:'content_block_delta',index:0,delta:{type:'input_json_delta',partial_json:JSON.stringify({content:story})}};
    const close={type:'content_block_stop',index:kind==='null-close'?null:0};
    const end={type:'message_delta',delta:{stop_reason:'tool_use'},usage:{output_tokens:12}};
    return sendFrames([{type:'message_start',message:{id:'sample',type:'message',role:'assistant',model:'mock',content:[],stop_reason:null}},start,delta,...(kind==='no-close'?[]:[close]),end,...(kind==='no-stop'?[]:[{type:'message_stop'}])]);
   }
   if(protocol==='gemini'){
    const c={functionCall:{id:'fixture-1',name,args:{content:story}}};
    const pack=(parts,reason)=>({candidates:[{content:{role:'model',parts},...(reason&&{finishReason:reason})}]});
    return sendFrames(kind==='reroll'&&received.length>1?[pack([c,c],'STOP')]:[pack([c]),pack([c],'STOP')]);
   }
   const args=JSON.stringify({content:story});
   const item=delta=>({choices:[{index:0,delta:{tool_calls:[{index:0,...delta}]}}]});
   const finish={choices:[{index:0,delta:{},finish_reason:'tool_calls'}]};
   return sendFrames([item({id:'fixture-1',type:'function',function:{name,arguments:args.slice(0,12)}}),item({function:{arguments:args.slice(12)}}),...(kind==='done-only'?[]:[finish]),'[DONE]']);
  }
  if(u.origin===url||u.protocol==='blob:')return route.continue();blocked.push(u.hostname);return route.abort();
 });
 try {
  const query=mode==='c2'?'/?spreset=prototype':'/';
  await page.goto(url+query);
  if(mode!=='c2'&&mode!=='native'){
   await page.evaluate(async mode=>{const st=await import('/src/presets/settings.ts');const settings={enabled:mode!=='standalone',selected:mode==='standalone'?null:mode,packages:{}};if(mode==='standalone')st.enableNativeDelivery(settings);st.savePresetSettings(settings);},mode);
   await page.reload();await page.waitForFunction(expected=>document.querySelectorAll('iframe[data-tavern-script]').length===expected,mode==='standalone'?1:mode==='peinture-1118'?2:3);
  }
  const report=await page.evaluate(async({kind,protocol,mode})=>{
   const [repoAPI,fixtures,drafts,workflow,ai,creds,lib,host,rt]=await Promise.all(['/src/services/storage/saveRepository.ts','/src/tests/fixtures/talentPrompt.ts','/src/domain/drafts.ts','/src/workflows/storyStage.ts','/src/services/ai/configuration.ts','/src/services/ai/credentials.ts','/src/presets/library.ts','/src/presets/tavern/hostState.ts','/src/services/ai/runtime.ts'].map(x=>import(x)));
   const repo=await repoAPI.SaveRepository.open(),stage=new workflow.StoryStage(repo);const input=fixtures.talentPromptInput('story','regular'); Object.assign(input.settings.runtime,{streamStory:true,useVariableStage:false,useWorldStage:false,failureAutoRetry:false});
   window.addEventListener('independent-cancel',()=>stage.cancel(),{once:true});const cfg=ai.defaultAiConfig(),ch=ai.newChannel(protocol);ch.baseUrl='https://joint.mock.invalid';ch.defaultModel='mock';cfg.channels=[ch];cfg.routes.story={channelId:ch.id,modelId:''};const vault=new creds.CredentialVault(sessionStorage,localStorage);vault.set(ch.id,'joint-fixture');
   try{
    const blank=drafts.createTurnDraft(input.state.saveId,input.state.revision,'independent', 'regular',input.userInput,false,false);const backup={state:input.state,draft:blank};await repo.importBackup(backup,(await repo.compareBackup(backup)).confirmation);
    const selection=lib.captureAssistantSelection();const before=await lib.captureStoryWriting(selection,input.settings.prompts);
    const id='wave-length-800-1000';let selected=selection;
    if(kind==='comment'||kind==='real'){
      const pack=await lib.resolveStoryPreset(selection);const content=pack.entries.find(x=>x.identifier===id).content+(kind==='comment'?'{{// 本地校对备注 }}':'请写出码头上路灯的颜色。');
      const next={entries:{[id]:{content}},scripts:{},version:selection.definition.version};host.storeEditorOverride(selection.definition.id,host.readEditorOverride(selection.definition.id),next);selected=lib.captureAssistantSelection();
    }
    const after=await lib.captureStoryWriting(selected,input.settings.prompts);let first=null,second=null,committed=null,receipt=null,continueError=null;
    const generate=async()=>stage.generate({draft:await repo.loadDraft(blank.saveId),settings:input.settings,config:cfg,vault,onFailureSaved:()=>{}});
    try{await generate()}catch(e){first=[e.code,e.details?.fieldPath,String(e.message)]}
    const winner=await repo.loadDraft(blank.saveId);const candidateRev=(await repo.load(blank.saveId)).revision;
    if(kind==='reroll')try{await generate()}catch(e){second=[e.code,e.details?.fieldPath]}
    const draft=await repo.loadDraft(blank.saveId);
    if(kind==='comment'||kind==='real'){
      const partial={text:'<正文>港口的风',storyRevision:blank.storyRevision,continuations:0,writing:before};
      try{await rt.runStageRequest({...input,draft:{...blank,storyPartial:partial}},cfg,vault,{continuation:{partial:partial.text},presetSelection:selected})}catch(e){continueError=[e.code,e.details?.fieldPath,e.message?.slice(0,130)]}
    }
    if(draft.story)try{await repo.commitTurn({draft,nextAction:'',useVariableStage:false,useWorldStage:false});committed=(await repo.load(blank.saveId)).revision;const replay=await repo.commitTurn({draft,nextAction:'',useVariableStage:false,useWorldStage:false});receipt=replay.replayed;}catch(e){committed=e.code??e.message;}
    return {first,second,stageStatus:draft.stageStatus.story,candidate:!!draft.story,retained:!!winner.story&&draft.story?.narrative===winner.story.narrative,baseRevision:input.state.revision,candidateRev,committed,receipt,before,after,continueError,canResume:await lib.canResumeWriting(before,after,selected)};
   }finally{stage.dispose();repo.close();}
  },{kind,protocol,mode});
  return {mode,protocol,kind,device,received,blocked,workerCaps,workersAfter:page.workers().length,...report};
 }finally{await ctx.close();}
}
try{
const tests=[...['valid','no-close','no-stop','null-close'].map(k=>['peinture-1124','anthropic',k]),['peinture-1118','anthropic','null-close'],['peinture-1124','gemini','reroll'],...['openai','deepseek'].flatMap(p=>['split','done-only'].map(k=>['peinture-1124',p,k]))];
for (const device of ['desktop','mobile']) for(const args of tests){try{results.push(await run(...args,device));}catch(e){results.push({args,device,probeError:String(e).slice(0,500)})}writeFileSync(out,JSON.stringify(results,null,2));}
}finally{await browser.close();await server.close()}

import { createServer } from './c2/node_modules/vite/dist/node/index.js';
import { createSession } from './c2/experiments/spreset/core.mjs';
import { writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
const server=await createServer({root:resolve('c2'),server:{middlewareMode:true,hmr:false},cacheDir:resolve('evidence/parser-cache'),logLevel:'error'});
const {readPrototypeResponse}=await server.ssrLoadModule('/src/presets/spreset/response.ts');
const rows=[], arg={content:'码头交班。'}, call={id:'fixture-one',name:'submit_scene',args:arg};
const stream=(events)=>new Response(events.map(o=>'data: '+(typeof o==='string'?o:JSON.stringify(o))+'\n\n').join(''),{headers:{'content-type':'text/event-stream'}});
const test=async(p,format,kind,response,expected)=>{const session=createSession();session('prepare',{messages:[],stream:format==='sse'});let result,returns;try{const parsed=await readPrototypeResponse(response,p,new AbortController().signal);const final=session('finish',{text:parsed.text,call:parsed.call});result='deliver';returns={finish:parsed.finish,receipt:final.receipt}}catch(e){result='reject';returns={error:e.code??e.name}}rows.push({p,format,kind,expected,result,pass:expected===result,...returns})};
const gem=(calls,finishReason)=>({candidates:[{content:{role:'model',parts:calls.map(functionCall=>({functionCall}))},finishReason}]});
try{
for(const format of ['json','sse']){
 for(const protocol of ['openai','deepseek']){
  for(const [kind,finish,id,args,text,name,expected] of [
   ['valid','tool_calls',call.id,JSON.stringify(arg),'',call.name,'deliver'],
   ['other-protocol','tool_use',call.id,JSON.stringify(arg),'',call.name,'reject'],
   ['missing-id','tool_calls','',JSON.stringify(arg),'',call.name,'reject'],
   ['wrong-name','tool_calls',call.id,JSON.stringify(arg),'','other','reject'],
   ['invalid-args','tool_calls',call.id,'{"content":','',call.name,'reject'],
   ['mixed-text','tool_calls',call.id,JSON.stringify(arg),'竞争的正文',call.name,'reject'],
   ['missing-finish',null,call.id,JSON.stringify(arg),'',call.name,'reject']]){
   const body={role:'assistant',content:text,tool_calls:[{index:0,id,type:'function',function:{name,arguments:args}}]};
   const response=format==='json'?Response.json({choices:[{message:body,finish_reason:finish}]}):stream([{choices:[{delta:body}]},{choices:[{delta:{},finish_reason:finish}]},'[DONE]']);
   await test(protocol,format,kind,response,expected)
  }
 }
 for(const [kind,calls,expected] of [['valid',[call],'deliver'],['duplicate-part-same-id',[call,call],'reject'],['two-distinct-ids',[call,{...call,id:'fixture-two'}],'reject'],['partial',[{...call,willContinue:true}],'reject']]){
  await test('gemini',format,kind,format==='json'?Response.json(gem(calls,'STOP')):stream([gem(calls,'STOP')]),expected)
 }
 const block={type:'tool_use',id:call.id,name:call.name,input:arg};
 for(const [kind,reason,expected] of [['valid','tool_use','deliver'],['other-protocol','tool_calls','reject'],['output-limit','max_tokens','reject']]){
  await test('anthropic',format,kind,format==='json'?Response.json({role:'assistant',content:[block],stop_reason:reason}):stream([{type:'message_start',message:{role:'assistant'}},{type:'content_block_start',index:0,content_block:block},{type:'content_block_stop',index:0},{type:'message_delta',delta:{stop_reason:reason}},{type:'message_stop'}]),expected)
 }
}
await test('gemini','sse','snapshot-repeated-across-events',stream([gem([call],undefined),gem([call],'STOP')]),'deliver');
const start={type:'content_block_start',index:0,content_block:{type:'tool_use',id:call.id,name:call.name,input:arg}};
await test('anthropic','sse','no-block-stop',stream([start,{type:'message_delta',delta:{stop_reason:'tool_use'}},{type:'message_stop'}]),'reject');
await test('anthropic','sse','no-message-stop',stream([start,{type:'content_block_stop',index:0},{type:'message_delta',delta:{stop_reason:'tool_use'}}]),'reject');
writeFileSync('evidence/c2-parser.json',JSON.stringify(rows,null,2));console.log({pass:rows.filter(r=>r.pass).length,fail:rows.filter(r=>!r.pass).length,total:rows.length})
}finally{await server.close()}

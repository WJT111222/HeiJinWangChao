本轮 C1 Anthropic SSE 内容块专项复跑
before 为 #252 审查 HEAD eb94e5c6、#251 固定 HEAD db434208；after 为 C1 公共提交 6332ba62 以及 #251 独立应用该提交的临时工作树。所有浏览器用例使用 Chromium 与本地 Mock，自动重试为 0。
extra-frames.mjs 与 c2-close.mjs 均直接来自独立复审。c1-extra-frames.json 保存实际请求摘要、原始事件、候选、正式 revision 与重放回执。kind=null-close 即本次四个反例。c1-anthropic-reroll.json 的第二次回复携带不同正文及非法关闭索引，unchangedDraft 比较失败前后从 IndexedDB 读取的完整草稿。c2-worker-*.json 在真实开发宿主的 MessagePort 统计 finish 调用与收据。没有执行真实供应商请求。
probes 下脚本从检出目录 c1 和 c2 的父目录运行，结果写到同级 evidence。执行 node extra-frames.mjs c1、node anthropic-reroll.mjs c1、node boundary-probes.mjs c1、node c2-close.mjs、node parser-probe.mjs。C2 Chromium 补充用例复用 #251 的 e2e/helpers/test，针对其开发服务器运行。协议回归已纳入 Vitest。

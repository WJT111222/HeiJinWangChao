const CONFIG = {"family": "wave-1103-dame", "groups": [{"name": "人物与关系", "ids": ["wave-core-character-motivation", "wave-core-independent-regard", "wave-core-knowledge-boundaries", "wave-core-grounded-intimacy", "wave-core-grounded-demeanor", "wave-character-situated", "wave-character-anti-default", "wave-character-own-response", "wave-portrait-clean"]}, {"name": "局势与节奏", "ids": ["wave-fortune-hostile", "wave-fortune-neutral", "wave-fortune-favored", "wave-plot-revolution", "wave-pace-slow", "wave-pace-normal", "wave-pace-fast", "wave-ending-unasked", "wave-ending-earned-question"]}, {"name": "互动与视角", "ids": ["wave-speech-on", "wave-speech-off", "wave-dialogue-more", "wave-dialogue-medium", "wave-dialogue-less", "wave-dialogue-only", "wave-restate-on", "wave-restate-expand", "wave-restate-off", "wave-person-first", "wave-person-second", "wave-person-third", "wave-person-character-third", "wave-person-interaction-first", "wave-person-omniscient", "wave-mind-blackbox", "wave-mind-folded", "wave-mind-inline"]}, {"name": "篇幅与文风", "ids": ["wave-length-800-1000", "wave-length-dynamic-more", "wave-length-dynamic-less", "wave-paragraph-length", "wave-style-light-novel", "wave-style-japanese-fantasy", "wave-style-chinese-campus", "wave-style-classical-vernacular", "wave-style-xianxia", "wave-style-urban", "wave-style-rural", "wave-style-western", "wave-style-wuxia", "wave-style-essay", "wave-style-adaptive", "wave-style-sensual", "wave-style-ear-whisper"]}, {"name": "修辞与语言", "ids": ["wave-prose-word-ban", "wave-prose-lived-language", "wave-prose-modern-diction", "wave-prose-vary-portrait", "wave-prose-adjective-ban", "wave-prose-metaphor", "wave-prose-body-plain", "wave-prose-language", "wave-prose-language-purity", "wave-prose-bilingual"]}, {"name": "亲密与形貌", "ids": ["wave-intimacy-terms", "wave-intimacy-gentle", "wave-intimacy-conquest", "wave-age-light", "wave-age-young", "wave-age-mature", "wave-grooming", "wave-appearance", "wave-body-chest", "wave-body-hip", "wave-body-leg", "wave-body-foot", "wave-body-stocking", "wave-body-physics", "wave-relation-intruder", "wave-relation-yielding"]}, {"name": "附页与资料", "ids": ["wave-timebar", "wave-extra-options", "wave-extra-summary", "wave-extra-review", "wave-extra-comment", "wave-extra-parallel", "wave-mvu-adapter", "wave-reference-canon", "wave-reference-facts", "wave-archive-memory", "wave-summary-all", "wave-chat-with-wave"]}, {"name": "进阶调节", "ids": ["wave-attention-dilution", "wave-noise-anchor", "wave-native-thinking-detour", "wave-thinking-tail"]}, {"name": "自定义", "ids": ["wave-style-custom", "wave-prose-private-ban", "wave-custom-seam", "wave-custom-intimacy", "wave-custom-format", "wave-custom-content", "wave-custom-cot"]}], "exclusive": [{"name": "局势难度 · 三选一", "ids": ["wave-fortune-hostile", "wave-fortune-neutral", "wave-fortune-favored"]}, {"name": "推进速度 · 三选一", "ids": ["wave-pace-slow", "wave-pace-normal", "wave-pace-fast"]}, {"name": "结尾问话 · 二选一", "ids": ["wave-ending-unasked", "wave-ending-earned-question"]}, {"name": "抢话 · 二选一", "ids": ["wave-speech-on", "wave-speech-off"]}, {"name": "对话比重 · 四选一", "ids": ["wave-dialogue-more", "wave-dialogue-medium", "wave-dialogue-less", "wave-dialogue-only"]}, {"name": "转述 · 三选一", "ids": ["wave-restate-on", "wave-restate-expand", "wave-restate-off"]}, {"name": "视角 · 单选", "ids": ["wave-person-first", "wave-person-second", "wave-person-third", "wave-person-character-third", "wave-person-interaction-first", "wave-person-omniscient"]}, {"name": "心声 · 三选一", "ids": ["wave-mind-blackbox", "wave-mind-folded", "wave-mind-inline"]}, {"name": "篇幅 · 三选一", "ids": ["wave-length-800-1000", "wave-length-dynamic-more", "wave-length-dynamic-less"]}, {"name": "文风 · 单选", "ids": ["wave-style-light-novel", "wave-style-japanese-fantasy", "wave-style-chinese-campus", "wave-style-classical-vernacular", "wave-style-xianxia", "wave-style-urban", "wave-style-rural", "wave-style-western", "wave-style-wuxia", "wave-style-essay", "wave-style-adaptive", "wave-style-sensual", "wave-style-ear-whisper", "wave-style-custom"]}, {"name": "亲密风格 · 二选一", "ids": ["wave-intimacy-gentle", "wave-intimacy-conquest"]}]};

const fs=require('node:fs'),zlib=require('node:zlib');
const raw=JSON.parse(fs.readFileSync('src/presets/resources/peinture-1118.json'));
const byId=new Map(raw.prompts.map(x=>[x.identifier,x]));
const style=CONFIG.exclusive.find(g=>g.ids.includes('wave-style-essay')).ids;
const prompts=raw.prompt_order[0].order.map(x=>({id:x.identifier,content:byId.get(x.identifier).content??'',enabled:style.includes(x.identifier)?x.identifier==='wave-style-essay':x.enabled}));
const essay=prompts.find(p=>p.id==='wave-style-essay');essay.content+='旧方案校样：渡船离岸。';
let lastPreset,presetName;
const api=k=>k==='getLoadedPresetName'?()=>'1118 peinture':()=>({prompts});
  function readPreset() {
    const get = api('getPreset');
    const name = api('getLoadedPresetName');
    if (!get || !name) throw new Error('需要提供预设读取接口的酒馆助手版本。请更新酒馆助手后重试。');
    const currentName = name();
    const preset = get('in_use');
    if (!preset?.prompts?.some(p => p.id === 'wave-context-begin') || !preset.prompts.some(p => p.id === 'wave-vars-reset')) {
      throw new Error('当前预设不属于我即浪潮，已停止调整。');
    }
    if (presetName && currentName !== presetName) throw new Error('预设刚刚切换，请重新打开控制台。');
    presetName = currentName;
    lastPreset = preset;
    return preset;
  }
  const hidden = id => ['main','nsfw','jailbreak','wave-usage','wave-vars-reset','wave-license','wave-tool-definitions'].includes(id)
    || id.startsWith('wave-context-') || id.startsWith('wave-section-') || id.startsWith('wave-plan-');
  function entries(preset = lastPreset) {
    return [...(preset?.prompts || []), ...(preset?.prompts_unused || [])].filter(p => typeof p.content === 'string' && !hidden(p.id) && (p.content.trim() || CONFIG.groups.some(g => g.ids.includes(p.id))));
  }
  function snapshot(name) {
    return { format: 'wave-console-scheme', version: 1, family: CONFIG.family, name,
      createdAt: new Date().toISOString(), prompts: entries(readPreset()).map(p => ({ id: p.id, enabled: p.enabled, content: p.content })) };
  }
  function validateScheme(value) {
    if (!value || value.format !== 'wave-console-scheme' || value.version !== 1 || value.family !== CONFIG.family || !Array.isArray(value.prompts)) throw new Error('文件不是兼容的浪潮方案 JSON。');
    if (typeof value.name !== 'string' || !value.name.trim() || value.name.length > 80 || value.prompts.length > 500) throw new Error('方案名称或条目数量不符合要求。');
    const ids = new Set();
    for (const p of value.prompts) {
      if (!p || typeof p.id !== 'string' || p.id.length > 150 || ids.has(p.id) || typeof p.enabled !== 'boolean' || typeof p.content !== 'string' || p.content.length > 1000000) throw new Error('方案含有重复或不合法的条目。');
      ids.add(p.id);
    }
    for (const group of CONFIG.exclusive) if (value.prompts.filter(p => group.ids.includes(p.id) && p.enabled).length > 1) throw new Error(`${group.name}在方案中开启了多项，请先调整为单项后保存。`);
    return { format: value.format, version: 1, family: CONFIG.family, name: value.name.trim(), createdAt: value.createdAt, prompts: value.prompts.map(p => ({ id: p.id, enabled: p.enabled, content: p.content })) };
  }
const scheme=snapshot('1118 码头散文');
const wire=JSON.stringify(validateScheme(scheme),null,2);
fs.writeFileSync('e2e/fixtures/peinture-1118-essay.json.gz',zlib.gzipSync(wire));
console.log(scheme.prompts.length,scheme.createdAt,require('node:crypto').createHash('sha256').update(wire).digest('hex'));

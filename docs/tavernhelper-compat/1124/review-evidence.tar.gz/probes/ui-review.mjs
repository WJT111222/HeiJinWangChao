import {writeFileSync,readFileSync} from 'node:fs';import {resolve} from 'node:path';
import {createServer} from './c1/node_modules/vite/dist/node/index.js';import {chromium,devices} from './c1/node_modules/playwright/index.mjs';
const url='http://127.0.0.1:5421';const s=await createServer({root:resolve('c1'),cacheDir:resolve('evidence/ui-vitecache'),logLevel:'error',server:{port:5421,hmr:false,host:'127.0.0.1',strictPort:true}});await s.listen();
const b=await chromium.launch({executablePath:'/usr/bin/chromium'});const results=[];
const raw=JSON.parse(readFileSync('c1/src/presets/resources/peinture-1118.json'));const controls=JSON.parse(readFileSync('c1/src/presets/resources/peinture-controls.json'));const menu=new Set(controls.sections.flatMap(x=>x.ids));const style=controls.groups.find(g=>g.name==='文风').ids;
const enabled=new Map(raw.prompt_order[0].order.map(r=>[r.identifier,r.enabled]));
const scheme={format:'wave-console-scheme',version:1,family:'wave-1103-dame',name:'1118 散文方案',prompts:raw.prompts.filter(r=>menu.has(r.identifier)).map(r=>({id:r.identifier,enabled:style.includes(r.identifier)?r.identifier==='wave-style-essay':enabled.get(r.identifier),content:r.content}))};
scheme.prompts.push({id:'main',enabled:true,content:'独审锁定标记'});const section=(panel,name)=>panel.getByRole('navigation',{name:'预设设置分区'}).getByRole('button').filter({has:panel.page().getByText(name,{exact:true})});
async function editor(p){
 await p.getByRole('button',{name:'设置',exact:true}).first().click();const d=p.getByRole('dialog',{name:'设置',exact:true});
 const back=d.getByRole('button',{name:'返回设置',exact:true});if(await back.isVisible())await back.click();
 await d.getByRole('button',{name:'运行',exact:true}).click();await d.getByRole('button',{name:'王朝预设设置',exact:true}).click();return p.getByRole('dialog',{name:'王朝预设设置',exact:true});
}
try{for(const device of ['desktop','mobile']) {
 const ctx=await b.newContext(device==='mobile'?devices['Pixel 7']:{viewport:{width:1440,height:1000}});let posts=0;const data={device};
 try{
 await ctx.route('**/*',route=>{const u=new URL(route.request().url());if(u.origin===url||u.protocol==='blob:')return route.continue();posts++;return route.abort();});
 await ctx.addInitScript(()=>{if(!localStorage.getItem('heijin.story-presets.v1'))localStorage.setItem('heijin.story-presets.v1',JSON.stringify({selected:'peinture-1124',enabled:true,packages:{}}));const d=new Date();localStorage.setItem('heijin.notices.hidden-on.v1',[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-'));});
 const p=await ctx.newPage();await p.goto(url);const panel=await editor(p);
 await section(panel,'篇幅与文风').click();await panel.locator('button[value="wave-style-stream-of-consciousness"]').click();await panel.getByRole('button',{name:'保存调整'}).click();
 const other=await ctx.newPage();await other.goto(url);const second=await editor(other);
 await second.getByLabel('温度',{exact:true}).fill('0.37');
 await section(panel,'我的方案').click();const down=p.waitForEvent('download');await panel.getByRole('button',{name:'导出当前方案'}).click();const file=await down;
 const exported=JSON.parse(readFileSync(await file.path(),'utf8'));data.exported={name:exported.name,n:exported.prompts.length,stream:exported.prompts.find(x=>x.id==='wave-style-stream-of-consciousness').enabled};
 await panel.getByLabel('导入方案 JSON').setInputFiles({name:'legacy.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(scheme))});
 await panel.getByRole('button',{name:'载入编辑区'}).click();data.importNotice=await panel.locator('[role=status]').first().innerText();
 await section(panel,'篇幅与文风').click();data.chosenAfterLegacy=await panel.getByRole('group',{name:'文风',exact:true}).locator('[aria-pressed="true"]').getAttribute('value');
 await panel.getByRole('button',{name:'保存调整'}).click();await second.getByRole('button',{name:'保存调整'}).click();
 data.staleWarning=await second.getByRole('alert').first().innerText({timeout:10000});data.staleEditorKept=await second.getByLabel('温度',{exact:true}).inputValue();
 other.on('dialog',d=>d.accept());await second.getByRole('button',{name:'关闭预设设置',exact:true}).click();
 data.stored=await p.evaluate(()=>{const pkg=JSON.parse(localStorage.getItem('heijin.story-presets.v1')).packages['peinture-1124'];return {locked:Object.hasOwn(pkg.entries,'main'),temperature:pkg.sampling?.temperature??1,essay:pkg.entries['wave-style-essay']?.enabled??false,stream:pkg.entries['wave-style-stream-of-consciousness']?.enabled};});
 data.posts=posts;await p.screenshot({path:'evidence/c1-import-'+device+'.png'});
 }catch(e){data.probeError=String(e).slice(0,550)}finally{await ctx.close();}
 results.push(data);writeFileSync('evidence/c1-ui-independent.json',JSON.stringify(results,null,2));
}}finally{await b.close();await s.close()}

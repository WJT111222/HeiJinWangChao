const {devices}=require('./base/node_modules/@playwright/test');
module.exports={testDir:__dirname+'/base/e2e',fullyParallel:true,retries:0,workers:1,use:{baseURL:'http://127.0.0.1:5184',trace:'off',launchOptions:{executablePath:'/usr/bin/chromium'}},projects:[{name:'desktop',use:{...devices['Desktop Chrome'],viewport:{width:1440,height:1000}}},{name:'mobile',use:{...devices['Pixel 7']}}]};

from pathlib import Path
import json,csv,collections
p=Path(__file__).resolve().parent;e=p/'evidence'
S=json.loads((e/'audit-outcomes.json').read_text())
assert S['head_unreported']==S['baseline_unreported']==0 and S['both_collected']==2098
g=S['classes'];rs=list(csv.DictReader((e/'browser-reviewed.tsv').open(),delimiter='\t'))
def spot(key):return g.get(key,0)
def fmt(n):return format(n,',')
def strip(r):return [str(r.get(k,0)) for k in ['passed','failed','timedOut','skipped']]
text=['## 全仓 Chromium 差异','',f"默认套件按「桌面或手机项目 + 文件 + 测试标题」配对，核查了一项旧标题的双端改名。基线 2,098 个身份在分支均有对应，分支另新增 10 个身份。两端各自的全部收集项均有结果，原测试代码声明的条件跳过单列。",'','| 版本与轮次 | 通过 | 失败 | 超时 | 条件跳过 | 未调度 |','|---|---:|---:|---:|---:|---:|']
for label,kind in [('锁定分支首轮，2,108 项','head_first'),('基线各身份首次记录，2,098 项','baseline_first')]:
 text.append('| '+label+' | '+' | '.join(strip(S[kind]))+' | 0 |')
text+=['', '分支首轮的 517 项失败或超时，各只进入下表一行。基线先对照分支的失败，再补跑其余 1,582 项。基线为分批运行记录；同名对照、原端口复跑与全仓首轮的退出状态均保留在明细中。','', '| 分支首轮失败或超时的归属 | 数量 |','|---|---:|']
mapping={'同断言的基线失败':'基线在相同断言或等待位置也失败','HEAD 复跑通过':'分支独立复跑通过，首轮失败未稳定复现','基线通过，HEAD 失败':'基线通过，分支控制复跑仍失败','新增触发点经双版本探针证实，基线整项亦失败':'基线整项也失败，但另有双版本实测确认本分支新增的失败位置','新增用例失败，实测为入场动画采样':'分支新增的手机日间视觉用例，在转场过程中采样导致失败','两端均失败，需比对触发点':'两版本都失败，位置不同或缺少足够的错误定位，无法唯一归因'}
assert sum(spot(k) for k in mapping)==517,g
for k,name in mapping.items():text.append('| '+name+' | '+str(spot(k))+' |')
text+=['',f"269 项优先控制复跑的原始结果是 173 通过、27 失败、69 超时，后续专门复跑另列。分支新加的 10 个身份首轮有 9 个通过；手机日间视觉用例首轮在「外观与提示音」读到 392 像素，复跑时在另一页触发相同宽度断言。逐帧证据见上文。",'', '常规首轮均使用 Chromium、原测试断言、零重试和遇错继续。耗时或结果不一致的诊断批次允许更长的测试总时限，默认断言时限未放宽。暂停前后两边各有两项在途；所有跨暂停的失败都在恢复后重跑，两个基线用例均通过。首轮记录与复跑结果分开列示。','','[全量配对与归因明细](evidence/browser-reviewed.tsv) · [机器可读计数](evidence/audit-outcomes.json) · [首轮原始记录](evidence/head.jsonl) · [定向复跑原始记录](evidence/headctl001.jsonl) · [暂停边界](evidence/resumed-tests.json)','']
fresh=[json.loads(x) for x in (e/'headctl012.jsonl').read_text().splitlines()]
assert len(fresh)==2
for r in fresh:
 outcome='通过' if r['status']=='passed' else ('超时' if r['status']=='timedOut' else '失败')
 text.append(f"- 移动小剧场「{r['title'][-1]}」在标准端口与单工作进程的最终复跑结果为{outcome}。[原始结果](evidence/headctl012.jsonl)")
sec='\n'.join(text)+'\n\n'
doc=p/'REPORT.md';s=doc.read_text();i=s.index('## P1 ·');s=s[:i]+sec+s[i:]
s=s.replace('工程检查、视觉通过数与业务缺陷分开计数。','本轮未复现 P0，共记录 1 组 P1、5 组 P2、2 组 P3。各类浏览器用例的失败数与产品缺陷数分别统计。')
start=s.index('同一迁移错误也阻断候选流式回归。');end=s.index('## 手机五步工程专用配置',start);block=s[start:end];s=s[:start]+s[end:];i=s.index('## P3 ·');s=s[:i]+block+s[i:]
s+='\n## 交付状态\n\n复审固定在 `1974ab6e14f63fb48e440477022c02fe42a3b7f7`。建议优先修复 AI 配置与凭证的并发保存，再处理存档隔离、草稿保护及窄桌面布局。请保持现有业务断言，按新页面归属和稳定布局重新取样。原工作区与 PR 均未写入修复；#262 和 #246 均保持 Draft。[#262](https://github.com/WJT111222/HeiJinWangChao/pull/262) · [#246](https://github.com/WJT111222/HeiJinWangChao/pull/246)\n'
doc.write_text(s)

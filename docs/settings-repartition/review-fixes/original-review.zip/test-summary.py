import csv,collections,json
from pathlib import Path
p=Path(__file__).resolve().parent/'evidence'
rows=list(csv.DictReader((p/'browser-reviewed.tsv').open(),delimiter='\t'))
def cnt(k):return dict(collections.Counter(r[k] for r in rows))
def read(f):return [json.loads(x) for x in f.read_text().splitlines()] if f.exists() else []
def table(rs):return dict(collections.Counter(r['status'] for r in rs))
lines=['# 浏览器原始结果与配对复跑','',str(cnt('head-original')),'',str(cnt('review_attribution')),'','## 项目','']
h=read(p/'head.jsonl')
for pr in ['desktop','mobile']:lines+=['- '+pr+' '+str(table(r for r in h if r['title'][0]==pr))]
lines+=['','## 可重复的分支差异','']
for r in rows:
 if r['classification']=='基线通过，HEAD 失败':lines+=['- '+r['project']+' · '+r['spec']+' · '+r['test']+' · '+(r['head-control-error'] or r['head-error'])[:130]]
lines+=['','## 定向复跑','']
for f in sorted([*p.glob('*ctl*.jsonl'),*p.glob('mobile-special-*.jsonl')]):lines+=['- '+f.name+' '+str(table(read(f)))]
(p/'test-summary.md').write_text('\n'.join(lines)+'\n')

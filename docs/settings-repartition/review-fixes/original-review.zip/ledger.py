from pathlib import Path
import json,re,csv,collections
e=Path(__file__).resolve().parent/'evidence'
def read(f):
 try:return [json.loads(s) for s in f.read_text().splitlines() if s.rstrip().endswith('}')]
 except FileNotFoundError:return []
def key(r):
 return tuple(s.replace('手机私聊继承现场模型，独立选择保存后可恢复','私聊回复继承现场模型，独立选择保存后可恢复') for s in r['title'])
def index(glob):
 return {key(r):r for f in sorted(e.glob(glob)) for r in read(f)}
def expected(r):return r['status']==r['expected'] and r['status']!='skipped'
def err(r):
 return '\n'.join(str(x) for x in r.get('errors',[]) if x)
def sigs(r):
 if not r:return ''
 s=err(r)
 s=re.sub(r'http://127\.0\.0\.1:\d+','http://local',s)
 s=re.sub(r'^Test timeout of \d+ms exceeded\.?\s*','',s)
 waiting=re.search(r'(?:waiting for|navigating to) ([^\n]+)',s)
 s=re.sub(r'Test timeout of \d+ms exceeded\.?','timed out',s)
 s=s.split('Call log:')[0]
 s=s.split('Received array:')[0]
 s=re.sub(r'\s+',' ',s).strip()
 if waiting:s+=' | '+waiting[1].strip()
 return s
def signature(r):return sigs(r)[:550]
def callsite(r):
 for attachment in (r or {}).get('attachments',[]):
  if not attachment.endswith('error-context.md'):continue
  f=Path(attachment)
  if not f.exists():continue
  md=f.read_text(errors='replace'); m=re.search(r'^>\s*\d+\s*\|\s*(.*)$',md,re.M)
  if m:return m[1].strip()
 return ''
def source_column(r):
 for item in r.get('attachments',[]):
  if item.endswith('error-context.md') and Path(item).is_file():
   m=re.search(r'^>[^\n]*\n[^|\n]*\|([^\n^]*)\^',Path(item).read_text(errors='replace'),re.M)
   if m:return len(m[1])
 return None
def site_kind(s):
 m=re.search(r'(?:page|locator|browserContext)\.\w+:|expect\([^)]*\)\.\w+',s)
 return m[0] if m else None
def comparable(a,b):
 if not a or not b:return False
 sa,sb=signature(a),signature(b)
 # Long minified source lines can contain multiple assertions; require matching error text as well.
 aa,bb=callsite(a),callsite(b)
 if sa and sa==sb and (not aa or not bb or aa==bb) and (len(sa)>65 or (aa and aa==bb and len(aa)<200)):return True
 if aa and aa==bb and source_column(a) is not None and source_column(a)==source_column(b) and site_kind(sa) and site_kind(sa)==site_kind(sb):return True
 if not aa or aa!=bb or len(aa)>200:return False
 la=re.search(r'Locator: (.*)',sa); lb=re.search(r'Locator: (.*)',sb)
 if la and lb and la[1].split(' Expected:')[0]!=lb[1].split(' Expected:')[0]:return False
 if ' | ' in sa and ' | ' in sb and sa.split(' | ')[-1]==sb.split(' | ')[-1]:return True
 time_msg=lambda x: bool(re.search(r'timed out|(?:test )?timeout',x,re.I))
 if time_msg(sa) and time_msg(sb):
  ma=re.search(r'(?:page|locator|browserContext)\.(\w+):',sa);mb=re.search(r'(?:page|locator|browserContext)\.(\w+):',sb)
  if ma and mb and ma[0]==mb[0]:return True
 patterns=[r"locator\.(\w+):",r"expect\(([^)]*)\)\.(\w+)"]
 return any((ma:=re.search(pat,sa)) and (mb:=re.search(pat,sb)) and ma.groups()==mb.groups() for pat in patterns)
H=index('head.jsonl');B={**index('base-extra*.jsonl'),**index('base-batch*.jsonl')};BR=index('basectl*.jsonl');HR=index('headctl*.jsonl')
plan=json.loads((e/'head.jsonl.plan').read_text());baseplan={key(t) for t in json.loads((e/'baselist.plan').read_text())}
counts=collections.Counter();TODO=[];done=[]
for t in plan:
 k=key(t);h=H.get(k);b=B.get(k);bc=BR.get(k);hc=HR.get(k);other=bc or b;h2=hc or h
 if not h:cl='未运行'
 elif h['status']=='skipped':cl='套件条件跳过'
 elif expected(h):cl='通过'
 elif hc and expected(hc):cl='HEAD 复跑通过'
 elif not other:cl='无基线同名用例' if k not in baseplan else '待基线对照'
 elif other['status']=='skipped':cl='基线条件跳过'
 elif expected(other):cl='基线通过，HEAD 失败'
 elif comparable(h2,other):cl='同断言的基线失败'
 else:cl='两端均失败，需比对触发点'
 counts[cl]+=1
 if h and h['status'] not in ('passed','skipped') and not expected(h) and cl not in ('HEAD 复跑通过','同断言的基线失败'):
  TODO.append(t)
 done.append([t['title'][0],t['file'],t['line'],t['title'][-1],h and h['status'],b and b['status'],hc and hc['status'],bc and bc['status'],cl,signature(h or {}),signature(other or {}),callsite(h),callsite(other),signature(hc or {}),callsite(hc),signature(b or {})])
with (e/'browser-ledger.tsv').open('w') as f:
 w=csv.writer(f,delimiter='\t');w.writerow(['project','spec','line','test','head-original','baseline','head-control','baseline-control','classification','head-error','baseline-error','head-callsite','baseline-callsite','head-control-error','head-control-callsite','baseline-first-error']);w.writerows(done)
print(dict(counts))
(e/'ambiguous.json').write_text(json.dumps(TODO,ensure_ascii=False))

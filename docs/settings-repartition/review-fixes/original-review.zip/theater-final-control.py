from pathlib import Path
import os,time,subprocess
p=Path(__file__).resolve().parent;e=p/'evidence'
while not (e/'base-full.done').exists():time.sleep(6)
sel=e/'headctl012.txt';sel.write_text('\n'.join([line for line in (e/'headctl001.txt').read_text().splitlines() if line.startswith('[mobile]') and 'dynasty-theater.spec.ts' in line and any(t in line for t in ['日间 · 自定义万字剧场','设置可编辑与恢复独立提示词'])])+'\n')
with (e/'headctl012.log').open('w') as log:
 res=subprocess.run([str(p/'head/node_modules/.bin/playwright'),'test','--test-list',str(sel),'--workers=1','--retries=0','--max-failures=0','--trace=off','--timeout=120000','--reporter='+str(p/'record.cjs'),'--output='+str(e/'headctl012-results')],cwd=p/'head',env={**os.environ,'CHROMIUM_PATH':'/usr/bin/chromium','REVIEW_LOG':str(e/'headctl012.jsonl')},stdout=log,stderr=subprocess.STDOUT)
(e/'headctl012.exit').write_text(str(res.returncode))

from pathlib import Path
import json,subprocess,time,os,csv
p=Path(__file__).resolve().parent;e=p/'evidence'
while not (e/'controls.done').exists():time.sleep(5)
subprocess.run(['python','ledger.py'],stdout=subprocess.DEVNULL,cwd=p,check=True)
areas={'settings-worldbook-variables.spec.ts','mobile-batch2.spec.ts','archive-final.spec.ts','archive-step2.spec.ts','ui-compatibility.spec.ts'}
rows=list(csv.DictReader((e/'browser-ledger.tsv').open(),delimiter='\t'))
ks={(r['project'],r['spec'],r['test']) for r in rows if r['classification'].startswith('两端均失败') and r['spec'] in areas}
items=[r for r in json.loads((e/'baselist.plan').read_text()) if (r['title'][0],r['file'],r['title'][-1]) in ks]
if items:
 f=e/'basectl010.txt';f.write_text('\n'.join(' › '.join(['['+r['title'][0]+']',*r['title'][1:]]) for r in items)+'\n')
 with (e/'basectl010.log').open('w') as log:
  result=subprocess.run([str(p/'base/node_modules/.bin/playwright'),'test','-c',str(p/'base-config.cjs'),'--test-list',str(f),'--timeout=120000','--workers=1','--retries=0','--max-failures=0','--trace=off','--reporter='+str(p/'record.cjs'),'--output='+str(e/'basectl010-results')],cwd=p/'base',env={**os.environ,'CHROMIUM_PATH':'/usr/bin/chromium','REVIEW_LOG':str(e/'basectl010.jsonl')},stdout=log,stderr=subprocess.STDOUT)
  (e/'basectl010.exit').write_text(str(result.returncode))
(e/'final-baseline-controls.done').write_text(str(len(items)))

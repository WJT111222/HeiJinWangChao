from pathlib import Path
import os,subprocess,time,json,re
root=Path(__file__).resolve().parent;e=root/'evidence'
while not (e/'headctl001.jsonl.plan').exists() and not (e/'controls.done').exists():time.sleep(15)
for config,spec in [('batch1','mobile-main-batch1'),('batch2','mobile-batch2'),('batch3','mobile-home'),('batch4','mobile-batch4'),('archives','mobile-archives')]:
 for tree in ['head','base']:
  key='mobile-special-'+config+'-'+tree
  out=e/(key+'.jsonl')
  env={**os.environ,'CHROMIUM_PATH':'/usr/bin/chromium','REVIEW_LOG':str(out)}
  args=[str(root/tree/'node_modules/.bin/playwright'),'test','-c','playwright.mobile-'+config+'.config.ts',spec+'.spec.ts','--max-failures=0','--retries=0','--trace=off','--reporter='+str(root/'record.cjs'),'--output='+str(e/(key+'-results'))]
  if tree=='base':
   h=[json.loads(s) for s in (e/('mobile-special-'+config+'-head.jsonl')).read_text().splitlines()];nonpass=[r['title'][-1] for r in h if r['status'] not in ('passed','skipped')]
   if not nonpass:continue
   args+=['--grep','|'.join(re.sub(r'([\\.^$|?*+(){}\[\]])',r'\\\1',t) for t in nonpass)]
  with (e/(key+'.log')).open('w') as log:ret=subprocess.run(args,cwd=root/tree,env=env,stdout=log,stderr=subprocess.STDOUT)
  (e/(key+'.exit')).write_text(str(ret.returncode))
(e/'mobile-special.done').write_text('ok')

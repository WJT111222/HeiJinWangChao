import re
from pathlib import Path
root=Path('base/e2e').resolve()
def usesport(p,seen):
 if p in seen or not p.exists():return False
 seen.add(p);text=p.read_text()
 if '127.0.0.1:5174' in text or 'localhost:5174' in text:return True
 for ref in re.findall(r"""(?:from\s*|import\s*\(\s*)['"](\.[^'"]+)['"]""",text):
  d=p.parent/ref
  f=d if d.suffix=='.ts' else Path(str(d)+'.ts')
  if root in f.resolve().parents and usesport(f,seen):return True
 return False
names=sorted(p.name for p in root.glob('*.spec.ts') if usesport(p,set()))
Path('evidence/origin-sensitive.txt').write_text('\n'.join(names)+'\n');print(names)

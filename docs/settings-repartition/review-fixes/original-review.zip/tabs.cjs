const {chromium}=require('./head/node_modules/playwright');
const fs=require('node:fs');
const btn=(s,n)=>s.getByRole('button',{name:n,exact:true});
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true});
 try {
 for(const version of ['head','base']) for(const away of [false,true]){
 const url='http://127.0.0.1:'+(version==='head'?5174:5184);
 const context=await browser.newContext({viewport:{width:1440,height:1000}});let posts=0;
 await context.addInitScript(()=>{let n=new Date();localStorage.setItem('heijin.notices.hidden-on.v1',[n.getFullYear(),String(n.getMonth()+1).padStart(2,'0'),String(n.getDate()).padStart(2,'0')].join('-'));});
 await context.route('https://**/*',async r=>{if(r.request().method()==='POST')posts++;await r.fulfill({json:{data:[]}});});
 const a=await context.newPage(),b=await context.newPage();
 await a.goto(url);await a.evaluate(async()=>{
 const {defaultAiConfig,newChannel,saveAiConfig}=await import('/src/services/ai/configuration.ts');
 const cfg=defaultAiConfig();cfg.channels=['first','second'].map(id=>({...newChannel(),id,name:id,baseUrl:'https://'+id+'.mock.invalid/v1',defaultModel:'model-old'}));
 cfg.routes.story={channelId:'first',modelId:'model-old'};saveAiConfig(localStorage,cfg);
 localStorage.setItem('heijin.credential.v1:first','synthetic-initial');localStorage.setItem('heijin.credential.v1:second','synthetic-second');
 });await b.goto(url);await a.reload();
 const panes=[];for(const pg of [a,b]){await btn(pg,'设置').first().click();panes.push(pg.getByRole('dialog',{name:'设置',exact:true}));}
 const [pa,pb]=panes;
 if(away) await btn(pb,'记忆').click();
 else {await btn(pb,'编辑渠道：second').click();await pb.getByLabel('渠道名称',{exact:true}).fill('B-only');}
 await btn(pa,'编辑渠道：first').click();await pa.getByLabel('渠道名称',{exact:true}).fill('A-only');
 await pa.getByLabel('API 密钥',{exact:true}).fill('synthetic-rotated');
 if(version==='head')await pa.getByRole('navigation').getByRole('button',{name:'模型分配',exact:true}).click();
 let input=pa.getByLabel('正文生成模型 ID',{exact:true});if(!await input.isVisible())await btn(pa,'列表里没有？手动填写正文生成模型 ID').click();
 await input.fill('model-changed');await btn(pa,'保存 AI 配置').click();
 async function snapshot(){return b.evaluate(()=>{const cfg=JSON.parse(localStorage.getItem('heijin.ai.v1'));return {names:cfg.channels.map(c=>c.name),storyModel:cfg.routes.story.modelId,rotatedKeyPreserved:localStorage.getItem('heijin.credential.v1:first')==='synthetic-rotated'};});}
 const afterA=await snapshot();
 if(away){await btn(pb,version==='head'?'渠道与密钥':'AI 连接').click();await btn(pb,'编辑渠道：second').click();await pb.getByLabel('渠道名称',{exact:true}).fill('B-only');}
 await btn(pb,'保存 AI 配置').click(); const afterB=await snapshot();
 const row={version,away,afterA,afterB,feedback:await pb.locator('.ai-save-bar [role=status]').innerText(),posts};
 fs.appendFileSync('evidence/tabs.jsonl',JSON.stringify(row)+'\n');console.log(row);await context.close();
 }
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});

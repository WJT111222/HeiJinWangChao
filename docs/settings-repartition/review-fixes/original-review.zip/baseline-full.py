from pathlib import Path
import json,subprocess,os,time
root=Path(__file__).resolve().parent;e=root/'evidence'
def read(f):return [json.loads(s) for s in f.read_text().splitlines() if s.endswith('}')] if f.exists() else []
def key(t):return tuple(t['title'])
def wait_for(path):
 while not path.exists():time.sleep(10)
wait_for(e/'base-compare.done');plan=json.loads((e/'baselist.plan').read_text());sensitive=set((e/'origin-sensitive.txt').read_text().splitlines())
i=0
def remaining():
 tested={key(t) for pat in ['base-batch*.jsonl','basectl*.jsonl','base-extra*.jsonl'] for f in e.glob(pat) for t in read(f)}
 return [t for t in plan if key(t) not in tested]
def run(items,original):
 global i
 i+=1;name='base-extra%03d'%i
 while (e/(name+'.txt')).exists():
  i+=1;name='base-extra%03d'%i
 sel=e/(name+'.txt');sel.write_text('\n'.join(' › '.join(['['+t['title'][0]+']',*t['title'][1:]]) for t in items)+'\n')
 args=[str(root/'base/node_modules/.bin/playwright'),'test']
 if not original:args+=['-c',str(root/'base-default-alt.cjs')]
 args+=['--workers='+('4' if original else '2'),'--max-failures=0','--retries=0','--trace=off','--test-list',str(sel),'--reporter='+str(root/'record.cjs'),'--output='+str(e/(name+'-results'))]
 with (e/(name+'.log')).open('w') as log:result=subprocess.run(args,cwd=root/'base',env={**os.environ,'CHROMIUM_PATH':'/usr/bin/chromium','REVIEW_LOG':str(e/(name+'.jsonl'))},stdout=log,stderr=subprocess.STDOUT)
 (e/(name+'.exit')).write_text(str(result.returncode))
 if not read(e/(name+'.jsonl')):raise Exception(name+' collected no tests')
while not (e/'cat-controls.done').exists():
 left=[t for t in remaining() if t['file'] not in sensitive]
 if not left:break
 run(left[:55],False)
wait_for(e/'cat-controls.done')
left=remaining()
if left:run(left,True)
n=len(remaining())
if n:raise Exception(str(n)+' tests missing from baseline')
(e/'base-full.done').write_text(str(len(plan)))

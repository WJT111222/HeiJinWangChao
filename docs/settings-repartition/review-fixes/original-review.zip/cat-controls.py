from pathlib import Path
import subprocess,os,time,json
root=Path(__file__).resolve().parent;e=root/'evidence';env={**os.environ,'CHROMIUM_PATH':'/usr/bin/chromium'}
while not (e/'controls.done').exists():time.sleep(15)
before=[r for p in sorted(e.glob('headctl*.jsonl')) for r in map(json.loads,p.open()) if r['file']=='meowssiah.spec.ts' and '双标签设置' in r['title'][-1]]
if len(before)!=2 or any(r['status']!='passed' for r in before):
 for role,prefix in [('head','headctl002'),('base','basectl002')]:
  with (e/(prefix+'.log')).open('w') as f:
   s=subprocess.run([str(root/role/'node_modules/.bin/playwright'),'test','meowssiah.spec.ts','-g','双标签设置冲突','--workers=1','--timeout=120000','--max-failures=0','--retries=0','--trace=off','--reporter='+str(root/'record.cjs'),'--output='+str(e/(prefix+'-results'))],cwd=root/role,env={**env,'REVIEW_LOG':str(e/(prefix+'.jsonl'))},stdout=f,stderr=subprocess.STDOUT)
   (e/(prefix+'.exit')).write_text(str(s.returncode))
(e/'cat-controls.done').write_text('ok')

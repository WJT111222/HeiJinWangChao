# 十七页实测截图

桌面采用 1440 × 1000，Chromium 手机模拟采用 390 × 844。

| 页名 | 桌面日间 | 桌面夜间 | 手机日间 | 手机夜间 |
|---|---|---|---|---|
| 渠道与密钥 | [桌面日间](desktop-day/channels.jpg) | [桌面夜间](desktop-night/channels.jpg) | [手机日间](mobile-day/channels.jpg) | [手机夜间](mobile-night/channels.jpg) |
| 模型分配 | [桌面日间](desktop-day/routing.jpg) | [桌面夜间](desktop-night/routing.jpg) | [手机日间](mobile-day/routing.jpg) | [手机夜间](mobile-night/routing.jpg) |
| 跨域与网络 | [桌面日间](desktop-day/network.jpg) | [桌面夜间](desktop-night/network.jpg) | [手机日间](mobile-day/network.jpg) | [手机夜间](mobile-night/network.jpg) |
| 正文与风格 | [桌面日间](desktop-day/writing.jpg) | [桌面夜间](desktop-night/writing.jpg) | [手机日间](mobile-day/writing.jpg) | [手机夜间](mobile-night/writing.jpg) |
| 文学预设 | [桌面日间](desktop-day/literary.jpg) | [桌面夜间](desktop-night/literary.jpg) | [手机日间](mobile-day/literary.jpg) | [手机夜间](mobile-night/literary.jpg) |
| 提示词开关 | [桌面日间](desktop-day/prompts.jpg) | [桌面夜间](desktop-night/prompts.jpg) | [手机日间](mobile-day/prompts.jpg) | [手机夜间](mobile-night/prompts.jpg) |
| 世界书 | [桌面日间](desktop-day/worldbooks.jpg) | [桌面夜间](desktop-night/worldbooks.jpg) | [手机日间](mobile-day/worldbooks.jpg) | [手机夜间](mobile-night/worldbooks.jpg) |
| 生成阶段 | [桌面日间](desktop-day/stages.jpg) | [桌面夜间](desktop-night/stages.jpg) | [手机日间](mobile-day/stages.jpg) | [手机夜间](mobile-night/stages.jpg) |
| 超时与重试 | [桌面日间](desktop-day/timing.jpg) | [桌面夜间](desktop-night/timing.jpg) | [手机日间](mobile-day/timing.jpg) | [手机夜间](mobile-night/timing.jpg) |
| 记忆 | [桌面日间](desktop-day/memory.jpg) | [桌面夜间](desktop-night/memory.jpg) | [手机日间](mobile-day/memory.jpg) | [手机夜间](mobile-night/memory.jpg) |
| 手机 | [桌面日间](desktop-day/phone.jpg) | [桌面夜间](desktop-night/phone.jpg) | [手机日间](mobile-day/phone.jpg) | [手机夜间](mobile-night/phone.jpg) |
| 文生图 | [桌面日间](desktop-day/images.jpg) | [桌面夜间](desktop-night/images.jpg) | [手机日间](mobile-day/images.jpg) | [手机夜间](mobile-night/images.jpg) |
| 小剧场 | [桌面日间](desktop-day/theater.jpg) | [桌面夜间](desktop-night/theater.jpg) | [手机日间](mobile-day/theater.jpg) | [手机夜间](mobile-night/theater.jpg) |
| 外观与提示音 | [桌面日间](desktop-day/look.jpg) | [桌面夜间](desktop-night/look.jpg) | [手机日间](mobile-day/look.jpg) | [手机夜间](mobile-night/look.jpg) |
| 变量管理 | [桌面日间](desktop-day/variables.jpg) | [桌面夜间](desktop-night/variables.jpg) | [手机日间](mobile-day/variables.jpg) | [手机夜间](mobile-night/variables.jpg) |
| 提示词管理 | [桌面日间](desktop-day/promptmgr.jpg) | [桌面夜间](desktop-night/promptmgr.jpg) | [手机日间](mobile-day/promptmgr.jpg) | [手机夜间](mobile-night/promptmgr.jpg) |
| 反馈建议 | [桌面日间](desktop-day/feedback.jpg) | [桌面夜间](desktop-night/feedback.jpg) | [手机日间](mobile-day/feedback.jpg) | [手机夜间](mobile-night/feedback.jpg) |

另有手机渠道编辑二级页的日间和夜间截图。

- [手机日间渠道编辑](mobile-day/channel-editor-review.jpg)
- [手机夜间渠道编辑](mobile-night/channel-editor-review.jpg)

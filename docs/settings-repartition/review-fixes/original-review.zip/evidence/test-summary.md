# 浏览器原始结果与配对复跑

{'passed': 1291, 'failed': 312, 'timedOut': 205, 'skipped': 300}

{'通过': 1291, '同断言的基线失败': 307, 'HEAD 复跑通过': 175, '套件条件跳过': 300, '基线通过，HEAD 失败': 18, '两端均失败，需比对触发点': 13, '新增触发点经双版本探针证实，基线整项亦失败': 3, '新增用例失败，实测为入场动画采样': 1}

## 项目

- desktop {'passed': 634, 'failed': 165, 'timedOut': 129, 'skipped': 126}
- mobile {'passed': 657, 'skipped': 174, 'failed': 147, 'timedOut': 76}

## 可重复的分支差异

- desktop · candidate-streaming.spec.ts · 旧运行设置不重置：两个独立开关默认关闭，显式保存、刷新和未保存取消 · Error: expect(locator).toHaveValue(expected) failed Locator: getByLabel('请求超时（秒）') Expected: "73" Timeout: 5000ms Error: element(s
- desktop · memory-maintenance.spec.ts · 选择并恢复独立模型；手动整理、原文来源及真实memory快照/Token统计 · Error: expect(locator).toHaveAttribute(expected) failed Locator: getByRole('dialog', { name: '设置', exact: true }).getByRole('group
- desktop · model-list-hardening.spec.ts · 官方结构的model字段真实选用，name-only不冒充模型 · Error: locator.click: timed out | getByRole('combobox', { name: '正文生成模型', exact: true })
- desktop · narrative-length.spec.ts · 新玩家默认低档；选中档 / 高档后保存，刷新仍在；高档提示输出长度 · Error: expect(locator).toContainText(expected) failed Locator: getByRole('dialog', { name: '设置', exact: true }).getByRole('group',
- desktop · settings-worldbook-variables.spec.ts · 世界书与变量设置保护未保存修改，保存后同时进入下一次正文请求 · Error: expect(locator).toHaveCount(expected) failed Locator: getByRole('dialog', { name: '设置', exact: true }).getByRole('navigatio
- mobile · candidate-streaming.spec.ts · 旧运行设置不重置：两个独立开关默认关闭，显式保存、刷新和未保存取消 · Error: expect(locator).toHaveValue(expected) failed Locator: getByLabel('请求超时（秒）') Expected: "73" Timeout: 5000ms Error: element(s
- mobile · mobile-batch2.spec.ts · 手机 375×667：候选、选择器和操作表 · Error: locator.click: timed out | getByRole('dialog', { name: '设置', exact: true }).getByRole('combobox', { name: '正文生成渠道', exact: 
- mobile · mobile-batch2.spec.ts · 手机 390×844：候选、选择器和操作表 · Error: locator.click: timed out | getByRole('dialog', { name: '设置', exact: true }).getByRole('combobox', { name: '正文生成渠道', exact: 
- mobile · mobile-batch2.spec.ts · 手机 430×932：候选、选择器和操作表 · Error: locator.click: timed out | getByRole('dialog', { name: '设置', exact: true }).getByRole('combobox', { name: '正文生成渠道', exact: 
- mobile · mobile-batch2.spec.ts · 手机 750×800：候选、选择器和操作表 · Error: locator.click: timed out | getByRole('dialog', { name: '设置', exact: true }).getByRole('combobox', { name: '正文生成渠道', exact: 
- mobile · mobile-batch2.spec.ts · 手机 900×800：候选、选择器和操作表 · Error: locator.click: timed out | getByRole('dialog', { name: '设置', exact: true }).getByRole('combobox', { name: '正文生成渠道', exact: 
- mobile · mobile-batch2.spec.ts · 模型选择：搜索高亮、原键盘语义、缓存及显式刷新，Token 值不改语义 · Error: locator.click: timed out | getByRole('dialog', { name: '设置', exact: true }).getByRole('combobox', { name: '正文生成模型', exact: 
- mobile · mobile-batch2.spec.ts · 底部选择器：无匹配、Tab 环、Esc、遮罩与下拉仅关闭顶层 · Error: locator.click: timed out | getByRole('dialog', { name: '设置', exact: true }).getByRole('combobox', { name: '正文生成模型', exact: 
- mobile · mobile-select-sheet.spec.ts · 手机选择抽屉：选项远离屏幕底边；没有渠道时提示先添加渠道 · Error: expect(locator).toBeVisible() failed Locator: getByRole('dialog', { name: '设置', exact: true }).getByText('还没有渠道：先在下方「我的渠道」点
- mobile · mobile-select-sheet.spec.ts · 手机选择抽屉：选项多时可以用手指滑到底并选中最后一项；高亮项为纸页浅金、文字清楚 · Error: locator.click: timed out | getByRole('dialog', { name: '设置', exact: true }).getByRole('combobox', { name: '正文生成渠道', exact: 
- mobile · model-list-hardening.spec.ts · 官方结构的model字段真实选用，name-only不冒充模型 · Error: locator.click: timed out | getByRole('combobox', { name: '正文生成模型', exact: true })
- mobile · narrative-length.spec.ts · 新玩家默认低档；选中档 / 高档后保存，刷新仍在；高档提示输出长度 · Error: expect(locator).toContainText(expected) failed Locator: getByRole('dialog', { name: '设置', exact: true }).getByRole('group',
- mobile · settings-worldbook-variables.spec.ts · 世界书与变量设置保护未保存修改，保存后同时进入下一次正文请求 · Error: expect(locator).toHaveCount(expected) failed Locator: getByRole('dialog', { name: '设置', exact: true }).getByRole('navigatio

## 定向复跑

- basectl001.jsonl {'failed': 26, 'passed': 36, 'timedOut': 3}
- basectl009.jsonl {'passed': 2}
- basectl010.jsonl {'passed': 2, 'failed': 5}
- headctl001.jsonl {'passed': 173, 'failed': 27, 'timedOut': 69}
- headctl009.jsonl {'timedOut': 1}
- headctl012.jsonl {'passed': 2}
- mobile-special-archives-base.jsonl {'passed': 5}
- mobile-special-archives-head.jsonl {'failed': 4, 'timedOut': 1, 'passed': 16, 'skipped': 2}
- mobile-special-batch1-base.jsonl {'failed': 2}
- mobile-special-batch1-head.jsonl {'passed': 15, 'failed': 2, 'skipped': 2}
- mobile-special-batch2-base.jsonl {'passed': 8, 'timedOut': 1, 'failed': 3}
- mobile-special-batch2-head.jsonl {'timedOut': 9, 'passed': 6, 'failed': 3, 'skipped': 2}
- mobile-special-batch3-base.jsonl {'failed': 1}
- mobile-special-batch3-head.jsonl {'passed': 18, 'failed': 1}
- mobile-special-batch4-head.jsonl {'passed': 16}

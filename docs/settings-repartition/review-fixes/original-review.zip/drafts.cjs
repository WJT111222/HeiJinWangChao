const fs=require('fs'),{chromium}=require('./head/node_modules/playwright');
(async()=>{const br=await chromium.launch({executablePath:'/usr/bin/chromium'});try{for(const mode of ['head','base']){
 const ctx=await br.newContext({viewport:{width:1440,height:1000}});const p=await ctx.newPage();
 p.setDefaultTimeout(18000);await ctx.addInitScript(()=>{const n=new Date();localStorage.setItem('heijin.notices.hidden-on.v1',[n.getFullYear(),String(n.getMonth()+1).padStart(2,'0'),String(n.getDate()).padStart(2,'0')].join('-'));});
 await p.goto('http://127.0.0.1:'+(mode==='head'?5174:5184));
 await p.evaluate(async()=>{const {defaults,configKey}=await import('/src/services/images/config.ts');const c=structuredClone(defaults);c.enabled=true;c.connections.openai.base='https://demo.mock.invalid/v1';localStorage.setItem(configKey,JSON.stringify(c));});
 await p.getByRole('button',{name:'设置',exact:true}).first().click();const root=p.getByRole('dialog',{name:'设置',exact:true});
 const nav=n=>root.getByRole('navigation').getByRole('button',{name:n,exact:true});
 await nav('文生图').click();const key=root.getByLabel('图片密钥',{exact:true});await key.fill('only-demo-not-stored');
 const imageDot=await nav('文生图').locator('.dirty').count();await nav('记忆').click();
 await root.getByRole('heading',{name:/^记忆/}).first().waitFor();const warningWhenLeavingImage=await p.getByRole('dialog',{name:/尚未保存/}).count();
 await nav('文生图').click();const restored=await key.inputValue();await nav('提示词管理').click();await root.getByRole('button',{name:/高级/}).first().click();
 const sortable=root.getByRole('button',{name:/^下移 /}).and(root.locator('button:enabled')).first();await sortable.click();
 const before=await root.getByRole('button',{name:'保存提示词排序'}).isEnabled();const sortDot=await nav('提示词管理').locator('.dirty').count();await nav('记忆').click();await root.getByRole('heading',{name:/^记忆/}).first().waitFor();
 await nav('提示词管理').click();await root.getByRole('button',{name:/高级/}).first().click();const after=await root.getByRole('button',{name:'保存提示词排序'}).isEnabled();
 const result={mode,imageDot,warningWhenLeavingImage,imageKeyEditRetained:restored==='only-demo-not-stored',sortDirtyBefore:before,sortDot,sortDirtyAfterReturn:after};fs.appendFileSync('evidence/drafts.jsonl',JSON.stringify(result)+'\n');await ctx.close();
}}finally{await br.close();}})().catch(e=>{console.error(e);process.exitCode=1;});

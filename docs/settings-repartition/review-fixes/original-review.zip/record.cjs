const fs=require('node:fs');
class Records {
 onBegin(config,suite){fs.writeFileSync(process.env.REVIEW_LOG+'.plan',JSON.stringify(suite.allTests().map(t=>({id:t.id,file:t.location.file.split('/e2e/').at(-1),line:t.location.line,title:t.titlePath().slice(1)}))));}
 onTestEnd(t,r){fs.appendFileSync(process.env.REVIEW_LOG, JSON.stringify({id:t.id,file:t.location.file.split('/e2e/').at(-1),line:t.location.line,title:t.titlePath().slice(1),expected:t.expectedStatus,status:r.status,ms:r.duration,errors:r.errors.map(e=>(e.message||e.value||'').replace(/\x1b\[[0-9;]*m/g,'').slice(0,2900)),attachments:r.attachments.filter(a=>a.path).map(a=>a.path)})+'\n');}
 onError(e){fs.appendFileSync(process.env.REVIEW_LOG+'.errors',(e.message||e.value||String(e))+'\n');}
 onEnd(result){fs.writeFileSync(process.env.REVIEW_LOG+'.end',JSON.stringify(result));}
}
module.exports=Records;

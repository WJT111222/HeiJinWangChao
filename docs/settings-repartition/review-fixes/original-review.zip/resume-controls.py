from pathlib import Path
import json,os,time,subprocess
p=Path(__file__).resolve().parent;e=p/'evidence';boundary=json.loads((e/'resume-boundary.json').read_text())
checked=[]
for tree in ['base','head']:
 fn=next(n for n in boundary['counts'] if n.startswith(tree));start=boundary['counts'][fn]
 def read():return [json.loads(s) for s in (e/fn).read_text().splitlines() if s.endswith('}')]
 while len(read())<start+2:time.sleep(3)
 window=read()[start:start+2]
 checked.extend(dict(tree=tree,title=r['title'],status=r['status'],ms=r['ms']) for r in window)
 affected=[r for r in window if r['status'] not in ('passed','skipped')]
 if not affected:continue
 name=tree+'ctl009'
 sel=e/(name+'.txt'); sel.write_text('\n'.join(' › '.join(['['+r['title'][0]+']',*r['title'][1:]]) for r in affected)+'\n')
 args=[str(p/tree/'node_modules/.bin/playwright'),'test']
 if tree=='base':args+=['-c',str(p/'base-default-alt.cjs')]
 else:args+=['--timeout=120000']
 args+=['--workers=1','--retries=0','--max-failures=0','--trace=off','--test-list',str(sel),'--reporter='+str(p/'record.cjs'),'--output='+str(e/(name+'-results'))]
 with (e/(name+'.log')).open('w') as log:
  res=subprocess.run(args,cwd=p/tree,env={**os.environ,'CHROMIUM_PATH':'/usr/bin/chromium','REVIEW_LOG':str(e/(name+'.jsonl'))},stdout=log,stderr=subprocess.STDOUT)
 (e/(name+'.exit')).write_text(str(res.returncode))
(e/'resumed-tests.json').write_text(json.dumps(checked,ensure_ascii=False,indent=2))

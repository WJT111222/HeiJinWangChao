from pathlib import Path
import json,os,signal,subprocess,time,csv
root=Path(__file__).resolve().parent;ev=root/'evidence'
env={**os.environ,'CHROMIUM_PATH':'/usr/bin/chromium'}
def wait_for(check):
 while not check():time.sleep(12)
def readrows(path):
 return [json.loads(x) for x in path.read_text().splitlines() if x.endswith('}')] if path.exists() else []
def command(args,repo,name,extra={}):
 with (ev/(name+'.log')).open('w') as f:
  ret=subprocess.run(args,cwd=root/repo,env={**env,**extra},stdout=f,stderr=subprocess.STDOUT)
 (ev/(name+'.exit')).write_text(str(ret.returncode));return ret.returncode
def key(t):return tuple(n.replace('手机私聊继承现场模型，独立选择保存后可恢复','私聊回复继承现场模型，独立选择保存后可恢复') for n in t['title'])
def catalog(p):return {key(t):t for t in json.loads(p.read_text())}
def records(glob):return {key(t):t for f in sorted(ev.glob(glob)) for t in readrows(f)}
def run_cases(repo,name,items):
 if not items:return
 cases=ev/(name+'.txt');cases.write_text('\n'.join(' › '.join(['['+t['title'][0]+']',*t['title'][1:]]) for t in items)+'\n')
 command([str(root/repo/'node_modules/.bin/playwright'),'test','--workers=2','--timeout=120000','--max-failures=0','--retries=0','--trace=off','--test-list',str(cases),'--reporter='+str(root/'record.cjs'),'--output='+str(ev/(name+'-results'))],repo,name,{'REVIEW_LOG':str(ev/(name+'.jsonl'))})
subprocess.run(['python','ledger.py'],cwd=root)
wait_for(lambda:(ev/'head.jsonl.end').exists())
# Run engineering tests with no active browser runners; pause the external comparison driver, waiting for its current batch to finish normally.
pid=425661;proc=Path('/proc')/str(pid)
paused=False
if proc.exists() and b'diff-batches-normal.py' in (proc/'cmdline').read_bytes():
 os.kill(pid,signal.SIGSTOP);paused=True
 def none_active():
  rows=subprocess.run(['ps','--ppid',str(pid),'-o','stat='],capture_output=True,text=True).stdout.split()
  return all(state.startswith('Z') for state in rows)
 wait_for(none_active)
try:
 if not (ev/'node24-clean.exit').exists():
  code=command(['npm','run','check'],'head','node24-clean',{'VITEST_MAX_WORKERS':'2'})
  if code:command(['npm','run','build'],'head','build-clean')
finally:
 if paused and proc.exists():os.kill(pid,signal.SIGCONT)
wait_for(lambda:(ev/'base-compare.done').exists())
hc=catalog(ev/'head.jsonl.plan');bc=catalog(ev/'baselist.plan');sensitive=set((ev/'origin-sensitive.txt').read_text().splitlines())
H=records('head.jsonl');B=records('base-batch*.jsonl')
# Repeat controls whose author-supplied tests use origin-specific URLs or initially starved 30s baseline slots at the canonical port, preserving assertions.
first={key(t) for n in ['001','002'] for t in readrows(ev/('base-batch'+n+'.jsonl'))}
items=[bc[k] for k,r in H.items() if r['status'] not in ('passed','skipped') and k in bc and (k in first or r['file'] in sensitive or k not in B)]
run_cases('base','basectl001',items)
subprocess.run(['python','ledger.py'],cwd=root)
cols=list(csv.DictReader((ev/'browser-ledger.tsv').open(),delimiter='\t'))
needed={(x['project'],x['spec'],x['test']) for x in cols if x['classification'] not in ('通过','同断言的基线失败','套件条件跳过','HEAD 复跑通过')}
items=[t for k,t in hc.items() if (k[0],t['file'],k[-1]) in needed];run_cases('head','headctl001',items)
subprocess.run(['python','ledger.py'],cwd=root)
(ev/'controls.done').write_text('ok')

import json,os,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
ev=root/'evidence'
def rows(p):
 if not p.exists(): return []
 return [json.loads(x) for x in p.read_text().splitlines() if x.endswith('}')]
def identical(t): return tuple(t['title'])
while not (ev/'baselist.plan').exists(): time.sleep(2)
catalog={identical(x):x for x in json.loads((ev/'baselist.plan').read_text())}
def line(t): return ' › '.join(['['+t['title'][0]+']',*t['title'][1:]])
done=set()
for old in ev.glob('base-batch*.jsonl'):done.update(identical(t) for t in rows(old))
i=len(list(ev.glob('base-batch*.txt')))
while True:
 fails={identical(x):x for x in rows(ev/'head.jsonl') if x['status'] not in ('passed','skipped') and x['status']!=x['expected']}
 eligible=[x for k,x in fails.items() if k in catalog and k not in done]
 finished=(ev/'head.jsonl.end').exists()
 if eligible and (len(eligible)>=8 or finished):
  batch=eligible[:45];i+=1
  name='base-batch%03d'%i
  (ev/(name+'.txt')).write_text('\n'.join(line(catalog[identical(t)]) for t in batch)+'\n')
  env={**os.environ,'CHROMIUM_PATH':'/usr/bin/chromium','REVIEW_LOG':str(ev/(name+'.jsonl'))}
  with (ev/(name+'.log')).open('w') as f:
   ret=subprocess.run([str(root/'base/node_modules/.bin/playwright'),'test','-c',str(root/'base-config.cjs'),'--workers=2','--timeout=120000','--max-failures=0','--test-list',str(ev/(name+'.txt')),'--reporter='+str(root/'record.cjs'),'--output='+str(ev/(name+'-results'))],cwd=root/'base',env=env,stdout=f,stderr=subprocess.STDOUT)
  actual=rows(ev/(name+'.jsonl'));done.update(identical(t) for t in actual)
  if not actual: raise RuntimeError(name+' collected no cases')
 elif finished: break
 else: time.sleep(20)
(ev/'base-compare.done').write_text(str(len(done)))

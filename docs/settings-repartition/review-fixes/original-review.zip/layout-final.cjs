const {chromium,devices}=require('./head/node_modules/playwright'),fs=require('fs'),path=require('path');
const spec=fs.readFileSync(process.env.HTML_REF,'utf8').match(/const pages=(\[[\s\S]*?\]);/)[1];
const groups=JSON.parse(spec.replace(/'/g,'"'));const pages=groups.flatMap(k=>k[1]);const folder='evidence/visual';fs.mkdirSync(folder,{recursive:true});
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/chromium'});try{for(const mobile of [false,true])for(const theme of ['day','night']){const context=await b.newContext(mobile?{...devices['Pixel 7'],viewport:{width:390,height:844}}:{viewport:{width:1440,height:1000}});const p=await context.newPage();p.setDefaultTimeout(20000);const device=mobile?'mobile':'desktop',d=folder+'/'+device+'-'+theme;fs.mkdirSync(d,{recursive:true});
await context.addInitScript(()=>{const n=new Date();localStorage.setItem('heijin.notices.hidden-on.v1',[n.getFullYear(),String(n.getMonth()+1).padStart(2,'0'),String(n.getDate()).padStart(2,'0')].join('-'));});
let posts=0;await context.route('https://**/*',r=>{if(r.request().method()==='POST')posts++;return r.abort()});
await p.goto('http://127.0.0.1:5174');
await p.evaluate(async theme=>{const [{game},{SaveRepository},{defaultSettings,settingsKey},{defaultAiConfig,newChannel,saveAiConfig},{configKey,defaults}]=await Promise.all(['/src/tests/fixtures/game.ts','/src/services/storage/saveRepository.ts','/src/ui/settings/model.ts','/src/services/ai/configuration.ts','/src/services/images/config.ts'].map(q=>import(q)));const prefs=defaultSettings();prefs.display.appearance=theme;localStorage.setItem(settingsKey,JSON.stringify(prefs));localStorage.setItem(configKey,JSON.stringify({...defaults,enabled:true}));const config=defaultAiConfig(),channel={...newChannel(),name:'审查用渠道',baseUrl:'https://review.mock.invalid/v1/'+ 'long-address-'.repeat(7),defaultModel:'normal-model'};config.channels.push(channel);config.routes.story={channelId:channel.id,modelId:channel.defaultModel};saveAiConfig(localStorage,config);const r=await SaveRepository.open();await r.create(game());r.close();},theme);
await p.goto('http://127.0.0.1:5174/#game/save-a');await p.reload();
if(mobile)await p.getByRole('navigation',{name:'底部导航'}).getByRole('button',{name:'设置',exact:true}).click();else await p.locator('.dock-system [data-settings-open]').click();
const root=p.getByRole('dialog',{name:'设置',exact:true}),nav=root.getByRole('navigation',{name:'设置分类'});
const btn=n=>root.getByRole('button',{name:n,exact:true});
const groupsDOM=await nav.locator('.settings-group-name').allTextContents();
const rows=await nav.locator('[data-page]').evaluateAll(ns=>ns.map(n=>({id:n.dataset.page,name:n.getAttribute('aria-label'),seal:n.querySelector('i')?.textContent,sub:n.querySelector('small')?.textContent})));
const planOK=groupsDOM.join('|')===groups.map(r=>r[0]).join('|')&&rows.length===17&&rows.every((r,i)=>r.id===pages[i][0]&&r.seal===pages[i][1]&&r.name===pages[i][2]&&(!mobile||r.sub===pages[i][3]));
const capture=[];for(const [id,seal,name,sub] of pages){
 if(mobile&&await btn('返回设置').isVisible())await btn('返回设置').click();await nav.getByRole('button',{name,exact:true}).click();await root.getByRole('heading',{name,exact:true}).first().waitFor();
 if(id==='worldbooks'){await root.locator('.wb-empty').waitFor();await root.getByRole('region',{name:'内置主世界书'}).waitFor();}
 if(id==='variables')await root.locator('.vm-domains').waitFor();
 if(id==='promptmgr')await root.locator('.pm-list').first().waitFor();
 if(id==='images')await root.getByRole('checkbox',{name:/启用文生图/}).first().waitFor().catch(()=>{});
 await p.evaluate(()=>document.fonts.ready);const row=await root.evaluate(el=>{const v=el.querySelector('.settings-content'),r=v.getBoundingClientRect();return {client:v.clientWidth,scroll:v.scrollWidth,right:r.right,viewport:innerWidth,heading:v.querySelector('h3')?.textContent,theme:document.documentElement.dataset.appearance||document.querySelector('[data-appearance]')?.getAttribute('data-appearance')};});capture.push({id,...row,headingOK:row.heading?.includes(name)&& (mobile||row.heading?.includes(sub))});await p.screenshot({path:d+'/'+id+'.jpg',type:'jpeg',quality:57,animations:'disabled'});
 if(id==='variables'&&!mobile)await btn('‹ 返回设置分类').click();
 }
 fs.appendFileSync('evidence/visual.jsonl',JSON.stringify({device,theme,posts,planOK,capture})+'\n');
 await context.close();
}}finally{await b.close()}})().catch(e=>{console.error(e);process.exitCode=1});

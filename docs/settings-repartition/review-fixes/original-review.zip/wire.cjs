const {chromium}=require('./head/node_modules/playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/chromium'});try{const p=await b.newPage();await p.goto('http://127.0.0.1:5174');let kind='normal',protocol='',delayed,seen,calls=[];
await p.route('https://**/*',async r=>{
 const u=new URL(r.request().url()),body=r.request().postDataJSON();calls.push({host:u.hostname,path:u.pathname,method:r.request().method(),model:body.model??(u.pathname.match(/models\/([^:]+)/)||[])[1],stream:!!body.stream,structured:!!(body.response_format||body.generationConfig?.responseMimeType),injectedKey:JSON.stringify(body).includes('mock-key-')});
 if(kind==='wait'){delayed=r;seen();return;}
 const content=kind==='image-key'?'picture mock-key-picture':kind==='text-key'?'words mock-key-words':'<think>draft</think>green window';
 await r.fulfill({json:protocol==='gemini'?{candidates:[{content:{role:'model',parts:[{text:content}]},finishReason:'STOP'}]}:protocol==='anthropic'?{type:'message',content:[{type:'text',text:content}],stop_reason:'end_turn'}:{choices:[{message:{content},finish_reason:'stop'}]}});
});
for(const name of ['openai','deepseek','gemini','anthropic']){
 protocol=name;await p.evaluate(async name=>{const {newChannel,defaultAiConfig,saveAiConfig}=await import('/src/services/ai/configuration.ts'),{CredentialVault}=await import('/src/services/ai/credentials.ts'),{defaults,imageVault,credentialId}=await import('/src/services/images/config.ts'),{convertText}=await import('/src/services/images/protocol.ts');const cfg=defaultAiConfig();const ch={...newChannel(name),id:name,baseUrl:'https://'+name+'.mock.invalid/v1',defaultModel:'route-review'};cfg.channels.push(ch);cfg.routes.imagePrompt={mode:'independent',channelId:name,modelId:'route-review'};saveAiConfig(localStorage,cfg);new CredentialVault(sessionStorage,localStorage).set(name,'mock-key-words');
 const img=structuredClone(defaults);img.textBase='https://retired.mock.invalid';img.textModel='retired';img.connections.openai.base='https://images.mock.invalid/v1';imageVault().set(credentialId('openai',img.connections.openai.base),'mock-key-picture');
 window.reviewConvert=async()=>{window.reviewAbort=new AbortController();try{const text=await convertText(img,'测试词组','窗边',window.reviewAbort.signal);return {ok:true,text}}catch(e){return {ok:false,code:e.code||e.name,credentialRejected:/凭证/.test(e.message),echo:e.message.includes('mock-key-')}}};},name);
 const evidence={protocol:name};for(const test of ['normal','image-key','text-key','wait']){kind=test;calls=[];const wait=kind==='wait'?new Promise(r=>seen=r):null;const outcome=p.evaluate(()=>window.reviewConvert());
 if(wait){await wait;await p.evaluate(()=>window.reviewAbort.abort());}
 const answer=await outcome;evidence[test]={answer,calls:calls.slice()};if(wait)await delayed.abort().catch(()=>{});}
 fs.appendFileSync('evidence/converter.jsonl',JSON.stringify(evidence)+'\n');
}}finally{await b.close()}})().catch(e=>{console.error(e);process.exitCode=1});

from pathlib import Path
import csv,json,collections
p=Path(__file__).resolve().parent;e=p/'evidence'
def read(f):return [json.loads(s) for s in f.read_text().splitlines() if s.endswith('}')]
def ids(*globs):
 row={}
 for pattern in globs:
  for f in sorted(e.glob(pattern)):
   for r in read(f):
    k=tuple(x.replace('手机私聊继承现场模型，独立选择保存后可恢复','私聊回复继承现场模型，独立选择保存后可恢复') for x in r['title'])
    row[k]=r
 return row
def stats(data):return dict(collections.Counter(x['status'] for x in data.values()))
H=ids('head.jsonl');B=ids('base-extra*.jsonl','base-batch*.jsonl');HC=ids('headctl*.jsonl');BC=ids('basectl*.jsonl')
planH=json.loads((e/'head.jsonl.plan').read_text());planB=json.loads((e/'baselist.plan').read_text())
rows=list(csv.DictReader((e/'browser-ledger.tsv').open(),delimiter='\t'))
special=ids('mobile-special-batch2-base.jsonl')
for r in rows:
 cl=r['classification'];site=r['head-control-callsite'] or r['head-callsite'];msg=r['head-control-error'] or r['head-error']
 r['review_attribution']=cl;r['specific_evidence']=''
 if cl.startswith('两端均失败') and r['spec']=='ui-compatibility.spec.ts' and r['project']=='desktop' and 'modelWidth' in site:
  r['review_attribution']='新增触发点经双版本探针证实，基线整项亦失败';r['specific_evidence']='model-width.jsonl'
 if cl.startswith('两端均失败') and r['spec']=='mobile-batch2.spec.ts' and r['project']=='mobile' and '正文生成模型' in msg:
  if any(o['title'][-1]==r['test'] and o['status']=='passed' for o in special.values()):
   r['review_attribution']='新增触发点经双版本探针证实，基线整项亦失败';r['specific_evidence']='mobile-special-batch2-head.jsonl / mobile-special-batch2-base.jsonl'
 if cl=='无基线同名用例' and r['spec']=='settings-repartition.spec.ts':
  r['review_attribution']='新增用例失败，实测为入场动画采样';r['specific_evidence']='mobile-animation.json'
with (e/'browser-reviewed.tsv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys(),delimiter='\t');w.writeheader();w.writerows(rows)
groups=dict(collections.Counter(x['review_attribution'] for x in rows));new=[k for k in H if k not in B]
D={'head_planned':len(planH),'baseline_planned':len(planB),'head_first':stats(H),'baseline_first':stats(B),'baseline_latest_control_included':stats({**B,**BC}),'both_collected':len(set(H)&set(B)),'head_only':len(new),'baseline_only':len(set(B)-set(H)),'head_unreported':len(planH)-len(H),'baseline_unreported':len(planB)-len(B),'head_only_first':stats({k:H[k] for k in new}),'head_control_269':stats(ids('headctl001.jsonl')),'classes':groups}
(e/'audit-outcomes.json').write_text(json.dumps(D,ensure_ascii=False,indent=2))
print(json.dumps(D,ensure_ascii=False))

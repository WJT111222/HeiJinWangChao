const { chromium, devices } = require('./head/node_modules/playwright');
const fs = require('fs');
const button = (scope,name) => scope.getByRole('button',{name,exact:true});
const record = r=>fs.appendFileSync('evidence/commit-boundary.jsonl', JSON.stringify(r)+'\n');
(async()=>{
  const browser = await chromium.launch({executablePath:'/usr/bin/chromium'});
  try {
   for (const platform of ['desktop','mobile']) {
    const ctx = await browser.newContext(platform === 'mobile' ? devices['Pixel 7'] : {viewport:{width:1440,height:1000}});
    let posts=0;
    await ctx.route('https://**/*', r=>{if(r.request().method()==='POST') posts++;return r.fulfill({json:{data:[]}})});
    await ctx.addInitScript(()=>{const n=new Date();localStorage.setItem('heijin.notices.hidden-on.v1',[n.getFullYear(),String(n.getMonth()+1).padStart(2,'0'),String(n.getDate()).padStart(2,'0')].join('-'))});
    const page=await ctx.newPage();page.setDefaultTimeout(20000);
    await page.goto('http://127.0.0.1:5174');
    await page.evaluate(async()=>{
      const {defaultAiConfig,newChannel,saveAiConfig}=await import('/src/services/ai/configuration.ts');
      const c=defaultAiConfig();c.channels=[{...newChannel(),id:'test',name:'基准',baseUrl:'https://fixture.mock.invalid/v1',defaultModel:'fixture'}];
      c.routes.story={channelId:'test',modelId:'fixture'};saveAiConfig(localStorage,c);
      localStorage.setItem('heijin.credential.v1:test','fixture-before');
    });
    await page.reload();
    async function open(name) {
      await button(page,'设置').first().click();
      const root=page.getByRole('dialog',{name:'设置',exact:true});
      await button(root,'渠道与密钥').click();
      await button(root,'编辑渠道：'+name).click();return root;
    }
    const root=await open('基准');
    const name=root.getByLabel('渠道名称',{exact:true}), key=root.getByLabel('API 密钥',{exact:true});
    const save=button(root,'保存 AI 配置'), status=root.locator('.ai-save-bar [role=status]');
    await name.fill('首次正常保存');await save.click();await status.filter({hasText:'已保存'}).waitFor();
    const snapshot=()=>page.evaluate(async()=>{
      const db=await new Promise((res,rej)=>{const r=indexedDB.open('heijin.ai-settings-lock',1);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
      const rec=await new Promise((res,rej)=>{const r=db.transaction('lock').objectStore('lock').get('published');r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});db.close();
      return {name:JSON.parse(localStorage.getItem('heijin.ai.v1')).channels[0].name,
       originalKey:localStorage.getItem('heijin.credential.v1:test')==='fixture-before',
       editedKey:localStorage.getItem('heijin.credential.v1:test')==='fixture-edit',
       sessionEmpty:sessionStorage.getItem('heijin.credential.v1:test')===null,
       receiptMatches:!!rec && rec.id===localStorage.getItem('heijin.ai.settings-receipt.v1'),aborted:window.reviewFault===true};
    });
    const before=await snapshot();
    await page.evaluate(()=>{
      let pending;
      const put=IDBObjectStore.prototype.put, set=Storage.prototype.setItem;
      IDBObjectStore.prototype.put=function(...args){
        if(this.transaction.db.name==='heijin.ai-settings-lock'&&args[1]==='published')pending=this.transaction;
        return put.apply(this,args);
      };
      Storage.prototype.setItem=function(k,v){
        const ret=set.call(this,k,v);
        if(k==='heijin.ai.settings-receipt.v1'&&pending){
          IDBObjectStore.prototype.put=put;Storage.prototype.setItem=set;
          pending.abort();window.reviewFault=true;
        }
        return ret;
      };
    });
    await name.fill('异常事务修改');await key.fill('fixture-edit');await save.click();
    await status.filter({hasText:'保存失败'}).waitFor();
    const after=await snapshot(),notice=await status.innerText(), canRetry=await save.isEnabled();
    await page.reload();const storedName=await page.evaluate(()=>JSON.parse(localStorage.getItem('heijin.ai.v1')).channels[0].name);
    const reopened=await open(storedName);
    await reopened.getByLabel('渠道名称',{exact:true}).fill('故障解除后重试');
    await button(reopened,'保存 AI 配置').click();
    const settled=reopened.locator('.ai-save-bar [role=status]').filter({hasText:/已保存|其他标签页|保存失败/});await settled.waitFor();
    record({platform,before,after,notice,canRetry,retryNotice:await settled.innerText(),afterReloadRetry:await snapshot(),posts});
    await ctx.close();
   }
  }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});

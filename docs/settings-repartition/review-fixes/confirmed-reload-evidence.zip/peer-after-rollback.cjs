const {chromium,devices} = require('./head/node_modules/playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const origin='http://127.0.0.1:5174';
const button=(scope,name)=>scope.getByRole('button',{name,exact:true});
async function open(page, channel) {
  await button(page,'设置').first().click();
  const panel=page.getByRole('dialog',{name:'设置',exact:true});
  await button(panel,'渠道与密钥').click();
  await button(panel,'编辑渠道：'+channel).click();
  return panel;
}
const nameInput=root=>root.getByLabel('渠道名称',{exact:true});
const save=root=>button(root,'保存 AI 配置');
const notice=root=>root.locator('.ai-save-bar [role=status]');
const waitNotice=async(root,re)=>{await notice(root).filter({hasText:re}).waitFor();return (await notice(root).innerText()).replace(/\s+/g,' ')};
async function snapshot(page, targetId) {
  return page.evaluate(async id=>{
    const db=await new Promise((ok,no)=>{const r=indexedDB.open('heijin.ai-settings-lock',1);r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)});
    const durable=await new Promise((ok,no)=>{const r=db.transaction('lock').objectStore('lock').get('published');r.onsuccess=()=>ok(r.result?.id);r.onerror=()=>no(r.error)});
    db.close();
    const visible=localStorage.getItem('heijin.ai.settings-receipt.v1');
    const classify=(storage,id)=>{const k=storage.getItem('heijin.credential.v1:'+id);return k===null?'absent':k==='fixture-primary'?'primary fixture':k==='fixture-provisional'?'new fixture':'other'};
    const cfg=JSON.parse(localStorage.getItem('heijin.ai.v1'));
    return {names:cfg.channels.map(x=>x.name),channels:cfg.channels.map(x=>x.id),route:cfg.routes.story,primaryLocal:classify(localStorage,'main'),primarySession:classify(sessionStorage,'main'),targetLocal:classify(localStorage,id),targetSession:classify(sessionStorage,id),visible,durable,aligned:!!durable && visible===durable};
  }, targetId);
}
async function lateAbortAndFailOneConfigRestore(page) {
  await page.evaluate(()=>{
    const originalPut=IDBObjectStore.prototype.put, originalSet=Storage.prototype.setItem;
    let tx;
    const priorRaw=localStorage.getItem('heijin.ai.v1');
    window.independentFault={aborts:0,denied:0};
    IDBObjectStore.prototype.put=function(...args){
      if(this.transaction.db.name==='heijin.ai-settings-lock' && args[1]==='published' && !tx)tx=this.transaction;
      return originalPut.apply(this,args);
    };
    Storage.prototype.setItem=function(k,v){
      if(window.independentFault.aborts===1 && k==='heijin.ai.v1' && v===priorRaw && !window.independentFault.denied){
        window.independentFault.denied++;
        Storage.prototype.setItem=originalSet;
        IDBObjectStore.prototype.put=originalPut;
        throw new DOMException('independent single compensating write failure','QuotaExceededError');
      }
      originalSet.call(this,k,v);
      if(!window.independentFault.aborts && k==='heijin.ai.settings-receipt.v1' && tx) {
        window.independentFault.aborts++;
        tx.abort();
      }
    };
  });
}
async function run(browser,platform,scenario){
  const ctx=await browser.newContext(platform==='mobile'?devices['Pixel 7']:{viewport:{width:1440,height:1000}});
  let posts=0;
  try {
    await ctx.addInitScript(()=>{const d=new Date();localStorage.setItem('heijin.notices.hidden-on.v1',[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-'))});
    await ctx.route('https://**/*',r=>{if(r.request().method()==='POST')posts++; return r.fulfill({json:{data:[]}})});
    const a=await ctx.newPage();a.setDefaultTimeout(18000);await a.goto(origin);
    await a.evaluate(async()=>{
      const {defaultAiConfig,newChannel,saveAiConfig}=await import('/src/services/ai/configuration.ts');
      const cfg=defaultAiConfig();
      cfg.channels=[{...newChannel(),id:'main',name:'初始名称',baseUrl:'https://fixture.mock.invalid/v1',defaultModel:'fixture-model'}];
      cfg.routes.story={channelId:'main',modelId:'fixture-model'};saveAiConfig(localStorage,cfg);
      localStorage.setItem('heijin.credential.v1:main','fixture-primary');
    });
    await a.reload();
    const mine=await open(a,'初始名称');
    await nameInput(mine).fill('基准渠道');await save(mine).click();await waitNotice(mine,'已保存');
    const create=scenario==='peer-deletes';
    const peerName=scenario==='peer-new-value'?'另一标签选择':'基准渠道';
    const provisional='故障残留渠道';
    if(create){
      const back=button(mine,'返回渠道列表');if(await back.isVisible())await back.click();
      await button(mine,'＋ 添加渠道').click();
      await mine.getByRole('group',{name:'服务商',exact:true}).getByRole('button',{name:'Gemini'}).click();
      await nameInput(mine).fill(provisional);
      await mine.getByLabel('API 密钥',{exact:true}).fill('fixture-provisional');
    }else await nameInput(mine).fill(provisional);
    const before=await snapshot(a,'main');
    await lateAbortAndFailOneConfigRestore(a);
    await save(mine).click(); const failedNotice=await waitNotice(mine,'无法恢复原配置');
    const id=await a.evaluate(n=>JSON.parse(localStorage.getItem('heijin.ai.v1')).channels.find(x=>x.name===n).id,provisional);
    const residue=await snapshot(a,id);
    const fault=await a.evaluate(()=>window.independentFault);
    assert.deepEqual(fault,{aborts:1,denied:1});assert(residue.aligned);assert(await save(mine).isDisabled());assert.equal(await nameInput(mine).inputValue(),provisional);
    const peer=await ctx.newPage();peer.setDefaultTimeout(18000);await peer.goto(origin);
    const other=await open(peer,provisional);
    assert.equal(await nameInput(other).inputValue(),provisional);
    if(create){
      await button(other,'删除渠道').click();
      await button(peer,'确认删除渠道').click();
    }else await nameInput(other).fill(peerName);
    assert(await save(other).isEnabled());await save(other).click();
    const peerNotice=await waitNotice(other,'已保存');
    const peerStatus={text:peerNotice,dirty:await save(other).isEnabled()};
    const peerCommitted=await snapshot(peer,id);
    assert(peerCommitted.aligned);assert.notEqual(peerCommitted.visible,residue.visible);assert.equal(peerStatus.dirty,false);
    if(create){assert(!peerCommitted.channels.includes(id));assert.equal(peerCommitted.targetLocal,'absent')}else assert.equal(peerCommitted.names[0],peerName);
    // Ensure the first renderer already sees the peer's *committed* config and receipt before retry.
    await a.waitForFunction(expected=>localStorage.getItem('heijin.ai.settings-receipt.v1')===expected,peerCommitted.visible);
    const seenByA=await snapshot(a,id);assert.deepEqual(seenByA,peerCommitted);
    assert(await save(mine).isDisabled());
    await save(mine).evaluate(b=>b.click());
    assert.deepEqual(await snapshot(a,id),peerCommitted);
    await button(mine,'重新读取最新配置').click();
    await button(a.getByRole('dialog',{name:'重新读取最新配置？'}),'取消').click();
    assert(await save(mine).isDisabled());
    assert.equal(await nameInput(mine).inputValue(),provisional);
    assert.deepEqual(await snapshot(a,id),peerCommitted);
    await button(mine,'重新读取最新配置').click();
    await button(a.getByRole('dialog',{name:'重新读取最新配置？'}),'确认放弃草稿并重新读取').click();
    const readNotice=await waitNotice(mine,'已载入最新配置');
    const after=await snapshot(a,id);
    assert(await save(mine).isDisabled());
    await peer.reload();const afterPeerReload=await snapshot(peer,id);
    assert.deepEqual(peerCommitted,after);assert.deepEqual(afterPeerReload,after);
    assert(after.aligned);assert.equal(posts,0);
    const result={platform,scenario,status:'pass',fault,posts,before,residue,failedNotice,peerStatus,peerCommitted,seenByA,blockedSave:true,cancelPreservedDraft:true,readNotice,after,afterPeerReload};
    fs.appendFileSync('evidence/peer-after-rollback.jsonl',JSON.stringify(result)+'\n');
    console.log(platform,scenario,result.status);
  }finally{await ctx.close()}
}
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium'});try{
  for(const platform of ['desktop','mobile'])for(const scenario of ['peer-deletes','peer-reverts-value','peer-new-value'])await run(browser,platform,scenario);
}finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});

const { chromium }=require('./head/node_modules/playwright');
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/chromium'});try{
 const ctx=await b.newContext();const pages=await Promise.all([ctx.newPage(),ctx.newPage()]);await Promise.all(pages.map(p=>p.goto('http://127.0.0.1:5174/')));
 const counts=await Promise.all(pages.map(p=>p.evaluate(async()=>{const {withAiSaveLock}=await import('/src/ui/settings/aiDraftMerge.ts');let wrote=0;for(let i=0;i<100;i++){await withAiSaveLock(publish=>{const n=Number(localStorage.getItem('fixture-count'))||0;localStorage.setItem('fixture-count',String(n+1));wrote++;publish();});}return wrote;})));
 const final=await pages[0].evaluate(()=>Number(localStorage.getItem('fixture-count')));console.log(JSON.stringify({counts,final}));if(final!==200)process.exitCode=1;
}finally{await b.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
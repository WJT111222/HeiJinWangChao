# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ai-settings.spec.ts >> AI 多渠道、原生模型列表与连接测试、路由和会话凭证恢复
- Location: e2e/ai-settings.spec.ts:86:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('group', { name: '默认模型选择', exact: true })
Expected substring: "当前接口返回 1 个模型。列表由服务端提供，可能不是该平台全部可用模型。"
Received string:    "默认模型mock-model（已保存 / 手动）⌄刷新模型正在获取模型列表…手动填写默认模型 ID默认模型 ID"

Call log:
  - Expect "toContainText" getByRole('group', { name: '默认模型选择', exact: true }) with timeout 5000ms
  - waiting for getByRole('group', { name: '默认模型选择', exact: true })
    3 × locator resolved to <div role="group" data-loading="" aria-label="默认模型选择" class="model-picker" data-list-status="loading">…</div>
      - unexpected value "默认模型mock-model（已保存 / 手动）⌄刷新模型正在获取模型列表…手动填写默认模型 ID默认模型 ID"
  - Test timeout of 30000ms exceeded.

```

```yaml
- group "默认模型选择":
  - text: 默认模型
  - combobox "默认模型": mock-model（已保存 / 手动）
  - button "刷新默认模型" [disabled]: 刷新模型
  - status: 正在获取模型列表…
  - button "手动填写默认模型 ID" [expanded]
  - text: 默认模型 ID
  - textbox "默认模型 ID":
    - /placeholder: 模型接口不可用时填写
    - text: mock-model
```

# Test source

```ts
  37  |       );
  38  |       for (const stage of ['story', 'variables', 'world']) {
  39  |         const prompt = await composePrompt({
  40  |           state,
  41  |           settings: defaultSettings(),
  42  |           mode,
  43  |           stage,
  44  |           draft,
  45  |           userInput: '查看附近环境',
  46  |           domains: ['protagonist', 'economy'],
  47  |         });
  48  |         examples.push({
  49  |           stage,
  50  |           mode,
  51  |           modules: prompt.modules.map((m: { id: string; role: string; order: number }) => ({
  52  |             id: m.id,
  53  |             role: m.role,
  54  |             order: m.order,
  55  |           })),
  56  |           roles: prompt.messages.map((m: { role: string }) => m.role),
  57  |           variablePending: prompt.context.variablePending,
  58  |         });
  59  |       }
  60  |     }
  61  |     return examples;
  62  |   });
  63  |   expect(examples).toHaveLength(6);
  64  |   for (const example of examples) {
  65  |     const ids = example.modules.map((module) => module.id);
  66  |     expect(ids.filter((id) => id.startsWith('stages.'))).toEqual([
  67  |       `stages.${example.mode}.${example.stage}${example.stage === 'variables' ? '.text' : ''}`,
  68  |     ]);
  69  |     expect(example.roles.at(-1)).toBe('user');
  70  |     if (example.stage === 'story') {
  71  |       expect(ids.slice(0, 3)).toEqual([
  72  |         'identity.fusheng',
  73  |         'worldbooks.heijin.worldview',
  74  |         'worldbooks.heijin.modern_underworld',
  75  |       ]);
  76  |       expect(ids.filter((id) => id === 'writing.nsfw')).toHaveLength(1);
  77  |       expect(ids.filter((id) => id === 'writing.intimacy_boundaries')).toHaveLength(1);
  78  |     } else expect(ids.some((id) => id.startsWith('writing.'))).toBe(false);
  79  |     if (example.stage === 'world') expect(example.variablePending).toBe(true);
  80  |   }
  81  |   const artifact = testInfo.outputPath('prompt-order.json');
  82  |   await writeFile(artifact, JSON.stringify(examples, null, 2));
  83  |   await testInfo.attach('prompt-order.json', { path: artifact, contentType: 'application/json' });
  84  | });
  85  | 
  86  | test('AI 多渠道、原生模型列表与连接测试、路由和会话凭证恢复', async ({ page }) => {
  87  |   const errors: string[] = [];
  88  |   page.on('pageerror', (error) => errors.push(error.message));
  89  |   const requests: { url: string; method: string; headers: Record<string, string>; body: string }[] =
  90  |     [];
  91  |   await page.route('https://api.mock.invalid/**', async (route) => {
  92  |     const request = route.request();
  93  |     requests.push({
  94  |       url: request.url(),
  95  |       method: request.method(),
  96  |       headers: request.headers(),
  97  |       body: request.postData() ?? '',
  98  |     });
  99  |     const native = request.url().includes('/gemini/')
  100 |       ? 'gemini'
  101 |       : request.url().includes('/anthropic/')
  102 |         ? 'anthropic'
  103 |         : 'openai';
  104 |     const result =
  105 |       request.method() === 'GET'
  106 |         ? native === 'gemini'
  107 |           ? { models: [{ name: 'models/mock-model' }] }
  108 |           : { data: [{ id: 'mock-model' }] }
  109 |         : native === 'gemini'
  110 |           ? { candidates: [{ content: { parts: [{ text: 'OK' }] }, finishReason: 'STOP' }] }
  111 |           : native === 'anthropic'
  112 |             ? { content: [{ type: 'text', text: 'OK' }], stop_reason: 'end_turn' }
  113 |             : { choices: [{ message: { content: 'OK' }, finish_reason: 'stop' }] };
  114 |     await route.fulfill({ json: result });
  115 |   });
  116 |   await page.goto('/');
  117 |   await page.getByRole('button', { name: '设置', exact: true }).click();
  118 |   await page.getByRole('button', { name: 'AI 连接', exact: true }).click();
  119 |   const ids: string[] = [];
  120 |   for (const protocol of ['openai', 'gemini', 'anthropic', 'deepseek']) {
  121 |     await page.getByRole('button', { name: '新增渠道', exact: true }).click();
  122 |     await page.getByLabel('渠道名称', { exact: true }).fill(`Mock ${protocol}`);
  123 |     await choose(page, '协议', protocol);
  124 |     await page
  125 |       .getByLabel('API Base URL', { exact: true })
  126 |       .fill(`https://api.mock.invalid/${protocol}/v1`);
  127 |     const password = page.getByLabel('API 密钥', { exact: true });
  128 |     await expect(password).toHaveAttribute('type', 'password');
  129 |     await password.fill('browser-mock-credential');
  130 |     await page.getByRole('button', { name: '手动填写默认模型 ID', exact: true }).click();
  131 |     await page.getByLabel('默认模型 ID', { exact: true }).fill('mock-model');
  132 |     expect(requests).toHaveLength(ids.length * 2);
  133 |     await page.getByRole('button', { name: '保存 AI 配置', exact: true }).click();
  134 |     await expect(
  135 |       page.getByText('AI 配置已保存；模型列表会自动获取，尚未发起生成请求。', { exact: true }),
  136 |     ).toBeVisible();
> 137 |     await expect(page.getByRole('group', { name: '默认模型选择', exact: true })).toContainText('当前接口返回 1 个模型。列表由服务端提供，可能不是该平台全部可用模型。');
      |                                                                            ^ Error: expect(locator).toContainText(expected) failed
  138 |     await optionCount(page, '默认模型', 2);
  139 |     await page.getByRole('button', { name: /测试连接（/ }).click();
  140 |     await expect(page.getByText(/连接测试成功，已收到模型文本响应/)).toBeVisible();
  141 |     ids.push(await page.getByRole('combobox', { name: '当前渠道', exact: true }).getAttribute('value') ?? '');
  142 |   }
  143 |   expect(requests).toHaveLength(8);
  144 |   expect(requests.map((request) => request.url)).toEqual([
  145 |     'https://api.mock.invalid/openai/v1/models',
  146 |     'https://api.mock.invalid/openai/v1/chat/completions',
  147 |     'https://api.mock.invalid/gemini/v1/models',
  148 |     'https://api.mock.invalid/gemini/v1/models/mock-model:generateContent',
  149 |     'https://api.mock.invalid/anthropic/v1/models?limit=100',
  150 |     'https://api.mock.invalid/anthropic/v1/messages',
  151 |     'https://api.mock.invalid/deepseek/v1/models',
  152 |     'https://api.mock.invalid/deepseek/v1/chat/completions',
  153 |   ]);
  154 |   for (const [index, header] of [
  155 |     [1, 'authorization'],
  156 |     [3, 'x-goog-api-key'],
  157 |     [5, 'x-api-key'],
  158 |     [7, 'authorization'],
  159 |   ] as const) {
  160 |     expect(requests[index].headers[header]).toContain('browser-mock-credential');
  161 |     expect(requests[index].url).not.toContain('browser-mock-credential');
  162 |     expect(requests[index].body).not.toContain('browser-mock-credential');
  163 |   }
  164 |   await page.getByLabel('变量管理跟随正文模型', { exact: true }).uncheck();
  165 |   await choose(page, '变量管理渠道', ids[1]);
  166 |   await page.getByRole('button', { name: '手动填写变量管理模型 ID', exact: true }).click();
  167 |   await page.getByLabel('变量管理模型 ID', { exact: true }).fill('variable-override');
  168 |   await expect(page.getByLabel('动态世界跟随正文模型', { exact: true })).toBeChecked();
  169 |   await page.getByRole('button', { name: '保存 AI 配置', exact: true }).click();
  170 |   await page.keyboard.press('Escape');
  171 |   await page.reload();
  172 |   await page.getByRole('button', { name: '设置', exact: true }).click();
  173 |   await page.getByRole('button', { name: 'AI 连接', exact: true }).click();
  174 |   await expect(page.getByLabel('API 密钥', { exact: true })).toHaveValue('browser-mock-credential');
  175 |   await selected(page, '变量管理渠道', ids[1]);
  176 |   await expect(page.getByLabel('变量管理模型 ID', { exact: true })).toHaveValue(
  177 |     'variable-override',
  178 |   );
  179 |   const stored = await page.evaluate(() => ({
  180 |     local: JSON.stringify(localStorage),
  181 |     session: JSON.stringify(sessionStorage),
  182 |   }));
  183 |   expect(stored.local).not.toContain('browser-mock-credential');
  184 |   expect(stored.session).toContain('browser-mock-credential');
  185 |   await page.getByRole('button', { name: '删除渠道', exact: true }).click();
  186 |   await page.getByRole('button', { name: '取消删除', exact: true }).click();
  187 |   await optionCount(page, '当前渠道', 4);
  188 |   await page.getByRole('button', { name: '删除渠道', exact: true }).click();
  189 |   await page.getByRole('button', { name: '确认删除渠道', exact: true }).click();
  190 |   await optionCount(page, '当前渠道', 3);
  191 |   await selected(page, '正文生成渠道', '');
  192 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  193 |   expect(errors).toEqual([]);
  194 | });
  195 | 
  196 | test('连接授权错误不展示服务详情，网络错误不误报密钥，取消请求有效', async ({ page }) => {
  197 |   let mode = 'authorization';
  198 |   await page.route('https://api.mock.invalid/**', async (route) => {
  199 |     if (mode === 'authorization')
  200 |       await route.fulfill({
  201 |         status: 401,
  202 |         json: { error: 'browser-mock-credential secret service detail' },
  203 |       });
  204 |     else if (mode === 'network') await route.abort('failed');
  205 |     else
  206 |       await new Promise<void>((resolve) => {
  207 |         route
  208 |           .request()
  209 |           .response()
  210 |           .then(() => resolve())
  211 |           .catch(() => resolve());
  212 |       });
  213 |   });
  214 |   await page.goto('/');
  215 |   await page.getByRole('button', { name: '设置', exact: true }).click();
  216 |   await page.getByRole('button', { name: 'AI 连接', exact: true }).click();
  217 |   await page.getByRole('button', { name: '新增渠道', exact: true }).click();
  218 |   await page.getByLabel('API Base URL', { exact: true }).fill('https://api.mock.invalid/v1');
  219 |   await page.getByRole('button', { name: '手动填写默认模型 ID', exact: true }).click();
  220 |   await page.getByLabel('默认模型 ID', { exact: true }).fill('mock-model');
  221 |   await page.getByLabel('API 密钥', { exact: true }).fill('browser-mock-credential');
  222 |   await page.getByRole('button', { name: '保存 AI 配置', exact: true }).click();
  223 |   await page.getByRole('button', { name: /测试连接（/ }).click();
  224 |   await expect(page.getByRole('status').filter({ hasText: '授权错误' }).last()).toBeVisible();
  225 |   await expect(page.getByRole('dialog')).not.toContainText('secret service detail');
  226 |   mode = 'network';
  227 |   await page.getByRole('button', { name: /测试连接（/ }).click();
  228 |   await expect(page.getByRole('status').filter({ hasText: 'CORS' })).toBeVisible();
  229 |   mode = 'hanging';
  230 |   await page.getByRole('button', { name: /测试连接（/ }).click();
  231 |   await page.getByRole('button', { name: '取消请求', exact: true }).click();
  232 |   await expect(page.getByRole('status').filter({ hasText: '取消' })).toBeVisible();
  233 |   await expect(page.getByRole('button', { name: /测试连接（/ })).toBeEnabled();
  234 | });
  235 | 
  236 | test('P6完善：输出档位映射、旧渠道值与渠道隔离，新渠道默认8K', async ({ page }) => {
  237 |   await page.goto('/');
```
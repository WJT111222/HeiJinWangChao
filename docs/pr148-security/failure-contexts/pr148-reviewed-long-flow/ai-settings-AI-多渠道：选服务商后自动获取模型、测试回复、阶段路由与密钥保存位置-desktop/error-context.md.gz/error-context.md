# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ai-settings.spec.ts >> AI 多渠道：选服务商后自动获取模型、测试回复、阶段路由与密钥保存位置
- Location: e2e/ai-settings.spec.ts:86:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('dialog', { name: '设置', exact: true }).getByRole('button', { name: '保存 AI 配置', exact: true })
    - locator resolved to <button type="button" class="primary">保存 AI 配置</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - main [ref=e4]:
    - region "游戏首页" [ref=e5]:
      - generic [ref=e7]:
        - text: GUANGZHOU · 23°07′N
        - generic [ref=e8]: 早茶 · 榕荫 · 珠江
      - generic [aria-hidden] [ref=e9]: 广州
      - generic [ref=e10]:
        - generic [ref=e11]:
          - generic [aria-hidden] [ref=e12]: 黑
          - generic [ref=e13]:
            - text: 黑金王朝
            - generic [ref=e14]: HEIJINWANGCHAO
        - button "存档馆" [ref=e15] [cursor=pointer]
        - button "设置" [ref=e16] [cursor=pointer]
        - generic [ref=e17]: V1.0 Beta
      - generic [ref=e18]:
        - paragraph [ref=e19]: MODERN CITY / OPEN WORLD
        - heading "黑金王朝" [level=1] [ref=e20]
        - paragraph [ref=e21]: 起点有冲突，人生不预设结局。
        - paragraph [ref=e22]: 一款 AI 驱动的现代都市开放世界文字角色扮演游戏。在熟悉的城市里，写下属于你的人生。
        - generic [ref=e23]:
          - button "开始新游戏" [ref=e24] [cursor=pointer]:
            - text: 开始新游戏
            - generic [aria-hidden] [ref=e25]: ↗
          - button "继续游戏 暂无可继续的存档" [disabled] [ref=e26]:
            - generic [ref=e27]: 继续游戏
            - generic [ref=e28]: 暂无可继续的存档
            - generic [aria-hidden] [ref=e29]: →
          - button "存档馆00" [ref=e30] [cursor=pointer]
        - group "游玩信息" [ref=e31]:
          - button "游玩须知与免责声明" [ref=e32] [cursor=pointer]
          - button "王朝公告" [ref=e33] [cursor=pointer]
      - generic [ref=e34]:
        - generic [ref=e35]:
          - generic [ref=e36]: 四座城市 · 自由职业 · 开放人生
          - generic [ref=e37]: 三阶段生成 · 原子结算 · 连续回合
        - navigation "封面城市" [ref=e38]:
          - button "重庆" [pressed] [ref=e39] [cursor=pointer]
          - button "上海" [ref=e40] [cursor=pointer]
          - button "哈尔滨" [ref=e41] [cursor=pointer]
          - button "广州" [ref=e42] [cursor=pointer]
  - dialog [ref=e43]:
    - banner [ref=e44]:
      - generic [aria-hidden] [ref=e45]: 设
      - generic [ref=e46]:
        - generic [aria-hidden] [ref=e47]: SYSTEM · 系统
        - heading "设置" [level=2] [ref=e48]
        - text: 本地偏好与 AI 渠道
      - generic [aria-hidden] [ref=e49]: ESC
      - button "关闭资料界面" [ref=e50] [cursor=pointer]: 关闭 ×
    - generic [ref=e52]:
      - navigation "设置分类" [ref=e53]:
        - button "AI 连接" [pressed] [ref=e54] [cursor=pointer]:
          - generic [aria-hidden] [ref=e55]: 连
        - button "提示词" [ref=e58] [cursor=pointer]:
          - generic [aria-hidden] [ref=e59]: 词
        - button "记忆" [ref=e61] [cursor=pointer]:
          - generic [aria-hidden] [ref=e62]: 忆
        - button "运行" [ref=e64] [cursor=pointer]:
          - generic [aria-hidden] [ref=e65]: 运
        - button "提示词管理" [ref=e67] [cursor=pointer]:
          - generic [aria-hidden] [ref=e68]: 管
        - group "游玩信息" [ref=e70]:
          - button "游玩须知与免责声明" [ref=e71] [cursor=pointer]
          - button "王朝公告" [ref=e72] [cursor=pointer]
      - generic [ref=e73]:
        - heading "AI 连接" [level=3] [ref=e74]
        - generic [ref=e75]:
          - paragraph [ref=e76]:
            - text: 游戏直接从浏览器连接你填写的服务，密钥只存在这台设备上，不进存档。
            - button "安全说明" [ref=e77] [cursor=pointer]
          - region "各阶段使用的模型" [ref=e78]:
            - generic [ref=e79]:
              - heading "各阶段使用的模型" [level=4] [ref=e80]
              - generic [ref=e81]: 先选渠道，再从这个渠道的模型里选；变量、动态世界、记忆默认跟随正文
            - generic [ref=e82]:
              - generic [ref=e83]:
                - strong [ref=e84]: 正文生成
                - generic [ref=e85]: 写剧情，最需要好模型
              - generic [ref=e86]:
                - generic [ref=e88]:
                  - generic [ref=e89]: 正文生成渠道
                  - combobox "正文生成渠道" [ref=e90] [cursor=pointer]:
                    - generic [ref=e91]: Mock openai
                    - generic [aria-hidden] [ref=e92]: ⌄
                - generic [ref=e94]:
                  - generic [ref=e95]: 正文生成模型
                  - combobox "正文生成模型" [ref=e96] [cursor=pointer]:
                    - generic [ref=e97]: mock-model
                    - generic [aria-hidden] [ref=e98]: ⌄
                - button "刷新正文生成模型" [ref=e99] [cursor=pointer]: ↻
                - button "列表里没有？手动填写正文生成模型 ID" [ref=e101] [cursor=pointer]
            - generic [ref=e102]:
              - generic [ref=e103]:
                - strong [ref=e104]: 变量管理
                - generic [ref=e105]: 整理金钱、物品、关系
              - group "变量管理模型来源" [ref=e106]:
                - button "跟随正文" [ref=e107] [cursor=pointer]
                - button "单独指定" [pressed] [ref=e108] [cursor=pointer]
              - generic [ref=e109]:
                - generic [ref=e111]:
                  - generic [ref=e112]: 变量管理渠道
                  - combobox "变量管理渠道" [ref=e113] [cursor=pointer]:
                    - generic [ref=e114]: Mock gemini
                    - generic [aria-hidden] [ref=e115]: ⌄
                - generic [ref=e117]:
                  - generic [ref=e118]: 变量管理模型
                  - combobox "变量管理模型" [ref=e119] [cursor=pointer]:
                    - generic [ref=e120]: variable-override（手动）
                    - generic [aria-hidden] [ref=e121]: ⌄
                - button "刷新变量管理模型" [ref=e122] [cursor=pointer]: ↻
                - generic [ref=e123]:
                  - button "列表里没有？手动填写变量管理模型 ID" [expanded] [ref=e124] [cursor=pointer]
                  - textbox "变量管理模型 ID" [ref=e125]:
                    - /placeholder: 例如 deepseek-chat
                    - text: variable-override
            - generic [ref=e126]:
              - generic [ref=e127]:
                - strong [ref=e128]: 动态世界
                - generic [ref=e129]: 推进你不在场的世界
              - group "动态世界模型来源" [ref=e130]:
                - button "跟随正文" [pressed] [ref=e131] [cursor=pointer]
                - button "单独指定" [ref=e132] [cursor=pointer]
              - paragraph [ref=e133]: 同正文 · Mock openai / mock-model
            - generic [ref=e134]:
              - generic [ref=e135]:
                - strong [ref=e136]: 记忆维护
                - generic [ref=e137]: 定期整理长期记忆
              - group "记忆维护模型来源" [ref=e138]:
                - button "跟随正文" [pressed] [ref=e139] [cursor=pointer]
                - button "单独指定" [ref=e140] [cursor=pointer]
              - paragraph [ref=e141]: 同正文 · Mock openai / mock-model
          - generic [ref=e142]:
            - region "API 渠道列表" [ref=e143]:
              - heading "我的渠道" [level=4] [ref=e144]
              - button "编辑渠道：Mock openai" [ref=e145] [cursor=pointer]:
                - generic [ref=e146]:
                  - generic [ref=e147]: Mock openai
                  - generic [ref=e148]: OpenAI 兼容
                - generic [ref=e149]: 连接正常 · 1 个模型
                - generic [ref=e151]: 用于：正文 · 动态世界 · 记忆
              - button "编辑渠道：Mock gemini" [ref=e152] [cursor=pointer]:
                - generic [ref=e153]:
                  - generic [ref=e154]: Mock gemini
                  - generic [ref=e155]: Gemini 格式
                - generic [ref=e156]: 连接正常 · 1 个模型
                - generic [ref=e158]: 用于：变量
              - button "编辑渠道：Mock anthropic" [pressed] [ref=e159] [cursor=pointer]:
                - generic [ref=e160]:
                  - generic [ref=e161]: Mock anthropic
                  - generic [ref=e162]: Claude 格式
                - generic [ref=e163]: 连接正常 · 1 个模型
                - generic [ref=e165]: 暂未被任何阶段使用
              - button "编辑渠道：Mock deepseek" [ref=e166] [cursor=pointer]:
                - generic [ref=e167]:
                  - generic [ref=e168]: Mock deepseek
                  - generic [ref=e169]: DeepSeek 格式
                - generic [ref=e170]: 连接正常 · 1 个模型
                - generic [ref=e172]: 暂未被任何阶段使用
              - button "＋ 添加渠道" [ref=e173] [cursor=pointer]
            - region "编辑渠道：Mock anthropic" [ref=e174]:
              - generic [ref=e175]:
                - textbox "渠道名称" [ref=e176]: Mock anthropic
                - button "删除渠道" [ref=e177] [cursor=pointer]
              - generic [ref=e178]:
                - text: 服务商
                - emphasis [ref=e179]: 选好后地址和接口格式自动填写
              - group "服务商" [ref=e180]:
                - button "OpenAI" [ref=e181] [cursor=pointer]: 官方
                - button "Claude" [ref=e183] [cursor=pointer]: 官方
                - button "Gemini" [ref=e185] [cursor=pointer]: 官方
                - button "DeepSeek" [ref=e187] [cursor=pointer]: 官方
                - button "OpenAI 兼容" [pressed] [ref=e189] [cursor=pointer]: 中转／其他
                - button "本地模型" [ref=e191] [cursor=pointer]: Ollama 等
              - generic [ref=e193]:
                - generic [ref=e194]:
                  - generic [ref=e195]: 服务地址
                  - textbox "服务地址" [ref=e197]:
                    - /placeholder: https://…/v1
                    - text: https://api.mock.invalid/anthropic/v1
                  - generic [ref=e198]:
                    - generic [ref=e199]:
                      - generic [ref=e200]: 接口格式
                      - combobox "接口格式" [ref=e201] [cursor=pointer]:
                        - generic [ref=e202]: Claude 格式
                        - generic [aria-hidden] [ref=e203]: ⌄
                    - generic [ref=e204]: 服务商说明里没提就保持「OpenAI 兼容」
                - generic [ref=e205]:
                  - generic [ref=e206]: API 密钥
                  - generic [ref=e207]:
                    - textbox "API 密钥" [ref=e208]:
                      - /placeholder: 粘贴密钥后自动获取模型
                      - text: browser-mock-credential
                    - button "显示" [ref=e209] [cursor=pointer]
                  - generic [ref=e210] [cursor=pointer]:
                    - switch "记住密钥" [active] [ref=e211]
                    - text: 记住密钥
                  - paragraph [ref=e213]: 只在本次打开期间保留，关闭浏览器后需要重新填写。
              - status [ref=e214]:
                - generic [ref=e216]:
                  - generic [ref=e217]: 连接正常
                  - generic [ref=e218]: 用 mock-model 收到了回复，游戏回合未运行。
                - generic [ref=e219]:
                  - button "重新获取模型" [ref=e220] [cursor=pointer]
                  - button "测试回复（可能产生少量费用）" [ref=e221] [cursor=pointer]
              - generic [ref=e222]:
                - text: 最大输出
                - emphasis [ref=e223]: 每次回复最多多少 Token；推理模型的思考也算在内，正文被截断时调大
              - group "最大输出 Token 档位" [ref=e225]:
                - button "4K" [ref=e226] [cursor=pointer]
                - button "8K（推荐）" [pressed] [ref=e227] [cursor=pointer]
                - button "16K" [ref=e228] [cursor=pointer]
                - button "自定义" [ref=e229] [cursor=pointer]
              - group [ref=e230]:
                - generic "高级设置（一般不用改）" [ref=e231] [cursor=pointer]
          - generic [ref=e232]:
            - status [ref=e233]:
              - generic [aria-hidden] [ref=e234]: 注
              - generic [ref=e235]: 有 6 处修改尚未保存
            - button "放弃修改" [ref=e237] [cursor=pointer]
            - button "保存 AI 配置" [ref=e238] [cursor=pointer]
```

# Test source

```ts
  1  | import { expect } from '@playwright/test';
  2  | import type { Locator, Page } from '@playwright/test';
  3  | 
  4  | // AI 连接设置（重设计）的测试操作。电脑端渠道列表与编辑器并排；手机端点开渠道进入编辑，返回后看到各阶段模型。
  5  | type Scope = Page | Locator;
  6  | const pageOf = (scope: Scope): Page => ('page' in scope && typeof scope.page === 'function' ? scope.page() : scope) as Page;
  7  | 
  8  | export async function openAiSettings(page: Page) {
  9  |   await page.getByRole('button', { name: '设置', exact: true }).first().click();
  10 |   const settings = page.getByRole('dialog', { name: '设置', exact: true });
  11 |   await settings.getByRole('button', { name: 'AI 连接', exact: true }).click();
  12 |   return settings;
  13 | }
  14 | /** 设置已打开时确保停在「AI 连接」分类（手机端可能停在分类菜单）。 */
  15 | export async function aiTab(page: Page) {
  16 |   const settings = page.getByRole('dialog', { name: '设置', exact: true });
  17 |   await expect(settings).toBeVisible();
  18 |   const entry = settings.getByRole('button', { name: 'AI 连接', exact: true });
  19 |   if (await entry.isVisible().catch(() => false)) await entry.click();
  20 |   return settings;
  21 | }
  22 | /** 手机端如果正在编辑渠道，先返回渠道列表（各阶段模型在列表页）。 */
  23 | export async function backToList(scope: Scope) {
  24 |   const back = scope.getByRole('button', { name: '‹ 返回渠道列表', exact: true });
  25 |   if (await back.isVisible().catch(() => false)) await back.click();
  26 | }
  27 | export async function openChannel(scope: Scope, name: string) {
  28 |   await backToList(scope);
  29 |   await scope.getByRole('button', { name: `编辑渠道：${name}`, exact: true }).click();
  30 | }
  31 | export interface ChannelInput { preset?: string; name?: string; url?: string; format?: string; key?: string }
  32 | /** 添加渠道：选服务商 → 地址 → 密钥。preset 为服务商按钮的主名称，如「OpenAI 兼容」「Gemini」。 */
  33 | export async function addChannel(scope: Scope, input: ChannelInput = {}) {
  34 |   await backToList(scope);
  35 |   await scope.getByRole('button', { name: '＋ 添加渠道', exact: true }).click();
  36 |   await choosePreset(scope, input.preset ?? 'OpenAI 兼容');
  37 |   if (input.name !== undefined) await scope.getByLabel('渠道名称', { exact: true }).fill(input.name);
  38 |   if (input.url !== undefined) await setUrl(scope, input.url);
  39 |   if (input.format) await chooseText(scope, '接口格式', input.format);
  40 |   if (input.key !== undefined) await scope.getByLabel('API 密钥', { exact: true }).fill(input.key);
  41 | }
  42 | export async function choosePreset(scope: Scope, preset: string) {
  43 |   await scope.getByRole('group', { name: '服务商', exact: true }).getByRole('button', { name: preset, exact: true }).click();
  44 | }
  45 | export async function setUrl(scope: Scope, url: string) {
  46 |   const field = scope.getByLabel('服务地址', { exact: true });
  47 |   if (await field.getAttribute('readonly') !== null) await scope.getByRole('button', { name: '需要改地址？', exact: true }).click();
  48 |   await field.fill(url);
  49 | }
  50 | /** 选择下拉项（按显示文字）。 */
  51 | export async function chooseText(scope: Scope, label: string, text: string | RegExp) {
  52 |   const page = pageOf(scope);
  53 |   await scope.getByRole('combobox', { name: label, exact: true }).click();
  54 |   await page.getByRole('listbox', { name: label, exact: true }).getByRole('option', { name: text }).first().click();
  55 | }
  56 | export async function follow(scope: Scope, stage: string, value: boolean) {
  57 |   await backToList(scope);
  58 |   await scope.getByRole('group', { name: `${stage}模型来源`, exact: true }).getByRole('button', { name: value ? '跟随正文' : '单独指定', exact: true }).click();
  59 | }
  60 | /** 设置某个阶段：选渠道，再手动填写或从列表选模型。 */
  61 | export async function stageModel(scope: Scope, stage: string, channel: string, model: string, from: 'list' | 'manual' = 'manual') {
  62 |   await backToList(scope);
  63 |   if (stage !== '正文生成') {
  64 |     const independent = scope.getByRole('group', { name: `${stage}模型来源`, exact: true }).getByRole('button', { name: '单独指定', exact: true });
  65 |     if (await independent.getAttribute('aria-pressed') !== 'true') await independent.click();
  66 |   }
  67 |   const channelSelect = scope.getByRole('combobox', { name: `${stage}渠道`, exact: true });
  68 |   if ((await channelSelect.textContent())?.trim() !== channel) {
  69 |     await chooseText(scope, `${stage}渠道`, channel);
  70 |   }
  71 |   if (from === 'list') await chooseText(scope, `${stage}模型`, model);
  72 |   else {
  73 |     const input = scope.getByLabel(`${stage}模型 ID`, { exact: true });
  74 |     if (!(await input.isVisible().catch(() => false))) await scope.getByRole('button', { name: `列表里没有？手动填写${stage}模型 ID`, exact: true }).click();
  75 |     await input.fill(model);
  76 |   }
  77 | }
  78 | export async function saveAi(scope: Scope) {
> 79 |   await scope.getByRole('button', { name: '保存 AI 配置', exact: true }).click();
     |                                                                      ^ Error: locator.click: Test timeout of 30000ms exceeded.
  80 |   await expect(scope.locator('.ai-save-bar').getByRole('status')).toContainText('已保存');
  81 | }
  82 | export async function testReply(scope: Scope) {
  83 |   await scope.getByRole('button', { name: '测试回复（可能产生少量费用）', exact: true }).click();
  84 | }
  85 | 
```
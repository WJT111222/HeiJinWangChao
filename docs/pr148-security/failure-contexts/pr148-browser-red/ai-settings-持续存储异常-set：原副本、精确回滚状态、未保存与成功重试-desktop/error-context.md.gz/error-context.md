# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ai-settings.spec.ts >> 持续存储异常 set：原副本、精确回滚状态、未保存与成功重试
- Location: e2e/ai-settings.spec.ts:448:3

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 0

@@ -1,9 +1,8 @@
  Object {
    "local": Object {
      "heijin.ai.v1": "{\"version\":1,\"channels\":[{\"id\":\"a\",\"name\":\"甲渠道\",\"protocol\":\"openai\",\"baseUrl\":\"https://a.mock.invalid/v1\",\"defaultModel\":\"a-model\",\"parameters\":{\"maxOutputTokens\":8192},\"compatibility\":{\"temperature\":true,\"maxOutputTokens\":true,\"jsonMode\":false,\"cotMode\":\"confirmation\",\"cotModels\":[]}},{\"id\":\"b\",\"name\":\"乙渠道\",\"protocol\":\"openai\",\"baseUrl\":\"https://b.mock.invalid/v1\",\"defaultModel\":\"b-model\",\"parameters\":{\"maxOutputTokens\":8192},\"compatibility\":{\"temperature\":true,\"maxOutputTokens\":true,\"jsonMode\":false,\"cotMode\":\"confirmation\",\"cotModels\":[]}},{\"id\":\"c\",\"name\":\"丙渠道\",\"protocol\":\"openai\",\"baseUrl\":\"https://c.mock.invalid/v1\",\"defaultModel\":\"c-model\",\"parameters\":{\"maxOutputTokens\":8192},\"compatibility\":{\"temperature\":true,\"maxOutputTokens\":true,\"jsonMode\":false,\"cotMode\":\"confirmation\",\"cotModels\":[]}}],\"routes\":{\"story\":{\"channelId\":\"a\",\"modelId\":\"a-model\"},\"variables\":{\"mode\":\"follow-story\"},\"world\":{\"mode\":\"follow-story\",\"independent\":{\"channelId\":\"b\",\"modelId\":\"b-old\"}},\"memory\":{\"mode\":\"follow-story\"}}}",
-     "heijin.credential.v1:a": "secret-a",
      "heijin.credential.v1:c": "secret-c",
    },
    "session": Object {
      "heijin.credential.v1:b": "secret-b",
    },
```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - main [ref=f1e4]:
    - region "游戏首页" [ref=f1e5]:
      - generic [ref=f1e7]:
        - text: CHONGQING · 29°33′N
        - generic [ref=f1e8]: 山城 · 江雾 · 轻轨
      - generic [aria-hidden] [ref=f1e9]: 重庆
      - generic [ref=f1e10]:
        - generic [ref=f1e11]:
          - generic [aria-hidden] [ref=f1e12]: 黑
          - generic [ref=f1e13]:
            - text: 黑金王朝
            - generic [ref=f1e14]: HEIJINWANGCHAO
        - button "存档馆" [ref=f1e15] [cursor=pointer]
        - button "设置" [ref=f1e16] [cursor=pointer]
        - generic [ref=f1e17]: V1.0 Beta
      - generic [ref=f1e18]:
        - paragraph [ref=f1e19]: MODERN CITY / OPEN WORLD
        - heading "黑金王朝" [level=1] [ref=f1e20]
        - paragraph [ref=f1e21]: 起点有冲突，人生不预设结局。
        - paragraph [ref=f1e22]: 一款 AI 驱动的现代都市开放世界文字角色扮演游戏。在熟悉的城市里，写下属于你的人生。
        - generic [ref=f1e23]:
          - button "开始新游戏" [ref=f1e24] [cursor=pointer]:
            - text: 开始新游戏
            - generic [aria-hidden] [ref=f1e25]: ↗
          - button "继续游戏 暂无可继续的存档" [disabled] [ref=f1e26]:
            - generic [ref=f1e27]: 继续游戏
            - generic [ref=f1e28]: 暂无可继续的存档
            - generic [aria-hidden] [ref=f1e29]: →
          - button "存档馆00" [ref=f1e30] [cursor=pointer]
        - group "游玩信息" [ref=f1e31]:
          - button "游玩须知与免责声明" [ref=f1e32] [cursor=pointer]
          - button "王朝公告" [ref=f1e33] [cursor=pointer]
      - generic [ref=f1e34]:
        - generic [ref=f1e35]:
          - generic [ref=f1e36]: 四座城市 · 自由职业 · 开放人生
          - generic [ref=f1e37]: 三阶段生成 · 原子结算 · 连续回合
        - navigation "封面城市" [ref=f1e38]:
          - button "重庆" [pressed] [ref=f1e39] [cursor=pointer]
          - button "上海" [ref=f1e40] [cursor=pointer]
          - button "哈尔滨" [ref=f1e41] [cursor=pointer]
          - button "广州" [ref=f1e42] [cursor=pointer]
  - dialog [ref=f1e43]:
    - banner [ref=f1e44]:
      - generic [aria-hidden] [ref=f1e45]: 设
      - generic [ref=f1e46]:
        - generic [aria-hidden] [ref=f1e47]: SYSTEM · 系统
        - heading "设置" [level=2] [ref=f1e48]
        - text: 本地偏好与 AI 渠道
      - generic [aria-hidden] [ref=f1e49]: ESC
      - button "关闭资料界面" [ref=f1e50] [cursor=pointer]: 关闭 ×
    - generic [ref=f1e52]:
      - navigation "设置分类" [ref=f1e53]:
        - button "AI 连接" [pressed] [ref=f1e54] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e55]: 连
        - button "提示词" [ref=f1e58] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e59]: 词
        - button "记忆" [ref=f1e61] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e62]: 忆
        - button "运行" [ref=f1e64] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e65]: 运
        - button "提示词管理" [ref=f1e67] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e68]: 管
        - group "游玩信息" [ref=f1e70]:
          - button "游玩须知与免责声明" [ref=f1e71] [cursor=pointer]
          - button "王朝公告" [ref=f1e72] [cursor=pointer]
      - generic [ref=f1e73]:
        - heading "AI 连接" [level=3] [ref=f1e74]
        - generic [ref=f1e75]:
          - paragraph [ref=f1e76]:
            - text: 游戏直接从浏览器连接你填写的服务，密钥只存在这台设备上，不进存档。
            - button "安全说明" [ref=f1e77] [cursor=pointer]
          - region "各阶段使用的模型" [ref=f1e78]:
            - generic [ref=f1e79]:
              - heading "各阶段使用的模型" [level=4] [ref=f1e80]
              - generic [ref=f1e81]: 先选渠道，再从这个渠道的模型里选；变量、动态世界、记忆默认跟随正文
            - generic [ref=f1e82]:
              - generic [ref=f1e83]:
                - strong [ref=f1e84]: 正文生成
                - generic [ref=f1e85]: 写剧情，最需要好模型
              - generic [ref=f1e86]:
                - generic [ref=f1e88]:
                  - generic [ref=f1e89]: 正文生成渠道
                  - combobox "正文生成渠道" [ref=f1e90] [cursor=pointer]:
                    - generic [ref=f1e91]: 甲渠道
                    - generic [aria-hidden] [ref=f1e92]: ⌄
                - generic [ref=f1e94]:
                  - generic [ref=f1e95]: 正文生成模型
                  - combobox "正文生成模型" [ref=f1e96] [cursor=pointer]:
                    - generic [ref=f1e97]: a-model
                    - generic [aria-hidden] [ref=f1e98]: ⌄
                - button "刷新正文生成模型" [ref=f1e99] [cursor=pointer]: ↻
                - button "列表里没有？手动填写正文生成模型 ID" [ref=f1e101] [cursor=pointer]
            - generic [ref=f1e102]:
              - generic [ref=f1e103]:
                - strong [ref=f1e104]: 变量管理
                - generic [ref=f1e105]: 整理金钱、物品、关系
              - group "变量管理模型来源" [ref=f1e106]:
                - button "跟随正文" [pressed] [ref=f1e107] [cursor=pointer]
                - button "单独指定" [ref=f1e108] [cursor=pointer]
              - paragraph [ref=f1e109]: 同正文 · 甲渠道 / a-model
            - generic [ref=f1e110]:
              - generic [ref=f1e111]:
                - strong [ref=f1e112]: 动态世界
                - generic [ref=f1e113]: 推进你不在场的世界
              - group "动态世界模型来源" [ref=f1e114]:
                - button "跟随正文" [pressed] [ref=f1e115] [cursor=pointer]
                - button "单独指定" [ref=f1e116] [cursor=pointer]
              - paragraph [ref=f1e117]: 同正文 · 甲渠道 / a-model
            - generic [ref=f1e118]:
              - generic [ref=f1e119]:
                - strong [ref=f1e120]: 记忆维护
                - generic [ref=f1e121]: 定期整理长期记忆
              - group "记忆维护模型来源" [ref=f1e122]:
                - button "跟随正文" [pressed] [ref=f1e123] [cursor=pointer]
                - button "单独指定" [ref=f1e124] [cursor=pointer]
              - paragraph [ref=f1e125]: 同正文 · 甲渠道 / a-model
          - generic [ref=f1e126]:
            - region "API 渠道列表" [ref=f1e127]:
              - heading "我的渠道" [level=4] [ref=f1e128]
              - button "编辑渠道：甲渠道" [pressed] [ref=f1e129] [cursor=pointer]:
                - generic [ref=f1e130]:
                  - generic [ref=f1e131]: 甲渠道
                  - generic [ref=f1e132]: OpenAI 兼容
                - generic [ref=f1e133]: 尚未连接
                - generic [ref=f1e135]: 用于：正文 · 变量 · 动态世界 · 记忆
              - button "编辑渠道：乙渠道" [ref=f1e136] [cursor=pointer]:
                - generic [ref=f1e137]:
                  - generic [ref=f1e138]: 乙渠道
                  - generic [ref=f1e139]: OpenAI 兼容
                - generic [ref=f1e140]: 尚未连接
                - generic [ref=f1e142]: 暂未被任何阶段使用
              - button "编辑渠道：丙渠道" [ref=f1e143] [cursor=pointer]:
                - generic [ref=f1e144]:
                  - generic [ref=f1e145]: 丙渠道
                  - generic [ref=f1e146]: OpenAI 兼容
                - generic [ref=f1e147]: 尚未连接
                - generic [ref=f1e149]: 暂未被任何阶段使用
              - button "＋ 添加渠道" [ref=f1e150] [cursor=pointer]
            - region "编辑渠道：甲渠道" [ref=f1e151]:
              - generic [ref=f1e152]:
                - textbox "渠道名称" [ref=f1e153]: 甲渠道
                - button "删除渠道" [ref=f1e154] [cursor=pointer]
              - generic [ref=f1e155]:
                - text: 服务商
                - emphasis [ref=f1e156]: 选好后地址和接口格式自动填写
              - group "服务商" [ref=f1e157]:
                - button "OpenAI" [ref=f1e158] [cursor=pointer]: 官方
                - button "Claude" [ref=f1e160] [cursor=pointer]: 官方
                - button "Gemini" [ref=f1e162] [cursor=pointer]: 官方
                - button "DeepSeek" [ref=f1e164] [cursor=pointer]: 官方
                - button "OpenAI 兼容" [pressed] [ref=f1e166] [cursor=pointer]: 中转／其他
                - button "本地模型" [ref=f1e168] [cursor=pointer]: Ollama 等
              - generic [ref=f1e170]:
                - generic [ref=f1e171]:
                  - generic [ref=f1e172]: 服务地址
                  - textbox "服务地址" [ref=f1e174]:
                    - /placeholder: https://…/v1
                    - text: https://a.mock.invalid/v1
                  - generic [ref=f1e175]:
                    - generic [ref=f1e176]:
                      - generic [ref=f1e177]: 接口格式
                      - combobox "接口格式" [ref=f1e178] [cursor=pointer]:
                        - generic [ref=f1e179]: OpenAI 兼容
                        - generic [aria-hidden] [ref=f1e180]: ⌄
                    - generic [ref=f1e181]: 服务商说明里没提就保持「OpenAI 兼容」
                - generic [ref=f1e182]:
                  - generic [ref=f1e183]: API 密钥
                  - generic [ref=f1e184]:
                    - textbox "API 密钥" [ref=f1e185]:
                      - /placeholder: 粘贴密钥后自动获取模型
                      - text: secret-a-new
                    - button "显示" [ref=f1e186] [cursor=pointer]
                  - generic [ref=f1e187] [cursor=pointer]:
                    - switch "记住密钥" [checked] [ref=f1e188]
                    - text: 记住密钥
                  - paragraph [ref=f1e190]: 关闭浏览器后仍保留。公共电脑请关闭。
              - status [ref=f1e191]:
                - generic [ref=f1e193]:
                  - generic [ref=f1e194]: 尚未检查连接
                  - generic [ref=f1e195]: 点「获取模型」检查连接并读取模型列表（不产生费用）。
                - generic [ref=f1e196]:
                  - button "获取模型" [ref=f1e197] [cursor=pointer]
                  - button "测试回复（可能产生少量费用）" [ref=f1e198] [cursor=pointer]
              - generic [ref=f1e199]:
                - text: 最大输出
                - emphasis [ref=f1e200]: 每次回复最多多少 Token；推理模型的思考也算在内，正文被截断时调大
              - group "最大输出 Token 档位" [ref=f1e202]:
                - button "4K" [ref=f1e203] [cursor=pointer]
                - button "8K（推荐）" [pressed] [ref=f1e204] [cursor=pointer]
                - button "16K" [ref=f1e205] [cursor=pointer]
                - button "自定义" [ref=f1e206] [cursor=pointer]
              - group [ref=f1e207]:
                - generic "高级设置（一般不用改）" [ref=f1e208] [cursor=pointer]
          - generic [ref=f1e209]:
            - status [ref=f1e210]:
              - generic [aria-hidden] [ref=f1e211]: 误
              - generic [ref=f1e212]:
                - generic [ref=f1e213]: 保存失败，请检查浏览器存储权限或空间后重试。
                - generic [ref=f1e214]: 密钥和配置都保持原样。
            - button "放弃修改" [ref=f1e215] [cursor=pointer]
            - button "保存 AI 配置" [active] [ref=f1e216] [cursor=pointer]
```

# Test source

```ts
  405 |   await seedVault(page);
  406 |   await page.evaluate(async () => {
  407 |     const cp = '/src/services/ai/configuration.ts', { readAiConfig, saveAiConfig } = await import(cp);
  408 |     const config = readAiConfig(localStorage);
  409 |     config.channels[2] = { ...config.channels[2], protocol: 'deepseek', baseUrl: 'https://c.mock.invalid/deepseek' };
  410 |     config.routes.variables = { mode: 'follow-story', independent: { channelId: 'b', modelId: 'b-variables' } };
  411 |     config.routes.memory = { mode: 'independent', channelId: 'c', modelId: 'c-memory' };
  412 |     saveAiConfig(localStorage, config);
  413 |   });
  414 |   await page.reload();
  415 |   const settings = await openAiSettings(page);
  416 |   // 旧配置里 DeepSeek 格式 + 第三方地址：按「OpenAI 兼容」显示，接口格式保留 DeepSeek。
  417 |   await openChannel(settings, '丙渠道');
  418 |   await expect(settings.getByRole('group', { name: '服务商', exact: true }).getByRole('button', { name: 'OpenAI 兼容', exact: true })).toHaveAttribute('aria-pressed', 'true');
  419 |   await expect(settings.getByRole('combobox', { name: '接口格式', exact: true })).toHaveAttribute('value', 'deepseek');
  420 |   await expect(settings).not.toContainText('官方地址已自动填写');
  421 |   // 乙渠道换成 Claude 官方：变量、动态世界隐藏着的乙渠道旧模型被清掉，渠道保留。
  422 |   await openChannel(settings, '乙渠道');
  423 |   await settings.getByRole('group', { name: '服务商', exact: true }).getByRole('button', { name: 'Claude', exact: true }).click();
  424 |   await page.getByRole('button', { name: '替换地址', exact: true }).click();
  425 |   await follow(settings, '变量管理', false);
  426 |   await expect(settings.getByRole('combobox', { name: '变量管理渠道', exact: true })).toHaveAttribute('value', 'b');
  427 |   await expect(settings.getByRole('combobox', { name: '变量管理模型', exact: true })).toHaveAttribute('value', '');
  428 |   await follow(settings, '动态世界', false);
  429 |   await expect(settings.getByRole('combobox', { name: '动态世界渠道', exact: true })).toHaveAttribute('value', 'b');
  430 |   await expect(settings.getByRole('combobox', { name: '动态世界模型', exact: true })).toHaveAttribute('value', '');
  431 |   // 正文（甲）和记忆（丙）不受影响。
  432 |   await expect(settings.getByRole('combobox', { name: '正文生成模型', exact: true })).toHaveAttribute('value', 'a-model');
  433 |   await expect(settings.getByRole('combobox', { name: '记忆维护模型', exact: true })).toHaveAttribute('value', 'c-memory');
  434 |   await expect(settings.locator('.ai-save-bar').getByRole('status')).toContainText('选了「单独指定」但还没选模型');
  435 | });
  436 | 
  437 | test('本地模型提示可以填占位密钥', async ({ page }) => {
  438 |   await page.goto('/');
  439 |   const settings = await openAiSettings(page);
  440 |   await addChannel(settings, { preset: '本地模型' });
  441 |   await expect(settings.getByLabel('服务地址', { exact: true })).toHaveValue('http://localhost:11434/v1');
  442 |   await expect(settings).toContainText('本地服务一般不需要真实密钥');
  443 |   await expect(settings.getByLabel('API 密钥', { exact: true })).toHaveAttribute('placeholder', '本地服务一般不校验，可填 ollama');
  444 | });
  445 | 
  446 | // 持续故障不会在第一次异常后自动解除；所有凭证均为隔离测试用值。
  447 | for (const mode of ['set', 'partial', 'remove', 'read'] as const) {
  448 |   test(`持续存储异常 ${mode}：原副本、精确回滚状态、未保存与成功重试`, async ({ page }, info) => {
  449 |     const posts: string[] = [], errors: string[] = [];
  450 |     page.on('pageerror', error => errors.push(error.message));
  451 |     await page.route('https://*.mock.invalid/**', route => {
  452 |       if (route.request().method() === 'POST') posts.push(route.request().url());
  453 |       return route.fulfill({ json: { data: [] } });
  454 |     });
  455 |     await seedVault(page);
  456 |     const before = await vaultDump(page), settings = await openAiSettings(page);
  457 |     await openChannel(settings, '甲渠道');
  458 |     await settings.getByLabel('API 密钥', { exact: true }).fill('secret-a-new');
  459 |     if (mode === 'remove') await settings.getByRole('switch', { name: '记住密钥' }).uncheck();
  460 |     if (mode === 'partial') {
  461 |       await openChannel(settings, '乙渠道'); await settings.getByRole('switch', { name: '记住密钥' }).check();
  462 |       await openChannel(settings, '丙渠道'); await settings.getByRole('button', { name: '删除渠道', exact: true }).click();
  463 |       await page.getByRole('button', { name: '确认删除渠道', exact: true }).click();
  464 |     }
  465 |     await page.evaluate(mode => {
  466 |       const control = { mode: mode as string, activated: false, hits: 0, mutations: [] as string[] };
  467 |       Reflect.set(window, '__vaultFault', control);
  468 |       const get = Storage.prototype.getItem, set = Storage.prototype.setItem, remove = Storage.prototype.removeItem;
  469 |       Storage.prototype.getItem = function(key) {
  470 |         if (control.mode === 'read' && key === 'heijin.credential.v1:a') {
  471 |           control.hits++; throw new DOMException('mock read denied', 'SecurityError');
  472 |         }
  473 |         return get.call(this, key);
  474 |       };
  475 |       Storage.prototype.setItem = function(key, value) {
  476 |         if (key.startsWith('heijin.credential.v1:') || key === 'heijin.ai.v1') control.mutations.push(`set:${key}`);
  477 |         if (this === localStorage && ((control.mode === 'set' && key === 'heijin.credential.v1:a')
  478 |           || (control.mode === 'partial' && (key === 'heijin.credential.v1:b' || (control.activated && key === 'heijin.credential.v1:a'))))) {
  479 |           control.activated = true; control.hits++; throw new DOMException('mock write denied', 'QuotaExceededError');
  480 |         }
  481 |         return set.call(this, key, value);
  482 |       };
  483 |       Storage.prototype.removeItem = function(key) {
  484 |         if (key.startsWith('heijin.credential.v1:')) control.mutations.push(`remove:${key}`);
  485 |         if (control.mode === 'remove' && key === 'heijin.credential.v1:a') {
  486 |           control.hits++; throw new DOMException('mock remove denied', 'SecurityError');
  487 |         }
  488 |         return remove.call(this, key);
  489 |       };
  490 |     }, mode);
  491 |     const status = settings.locator('.ai-save-bar').getByRole('status'), save = settings.getByRole('button', { name: '保存 AI 配置', exact: true });
  492 |     await save.click(); await expect(status).toContainText('保存失败');
  493 |     if (mode === 'read') {
  494 |       await expect(status).toContainText('无法读取密钥存储');
  495 |       expect(await page.evaluate(() => Reflect.get(window, '__vaultFault').mutations)).toEqual([]);
  496 |     } else if (mode === 'partial' || mode === 'remove') {
  497 |       await expect(status).toContainText('未能完全恢复'); await expect(status).toContainText('甲渠道');
  498 |       await expect(status).toContainText('检查密钥存储状态'); await expect(status).not.toContainText('保持原样');
  499 |     }
  500 |     // Disarm only after the UI has handled a still-active, persistent fault.
  501 |     const fault = await page.evaluate(() => { const c = Reflect.get(window, '__vaultFault'); const copy = { hits: c.hits, mutations: [...c.mutations] }; c.mode = ''; return copy; });
  502 |     expect(fault.hits).toBeGreaterThan(0);
  503 |     const after = await vaultDump(page);
  504 |     expect(after.local['heijin.ai.v1']).toBe(before.local['heijin.ai.v1']);
> 505 |     if (mode === 'set' || mode === 'read') expect(after).toEqual(before);
      |                                                          ^ Error: expect(received).toEqual(expected) // deep equality
  506 |     if (mode === 'partial') {
  507 |       expect(after.local['heijin.credential.v1:a']).toBe('secret-a-new');
  508 |       expect(after.session['heijin.credential.v1:b']).toBe('secret-b');
  509 |       expect(after.local['heijin.credential.v1:b']).toBeUndefined();
  510 |       expect(after.local['heijin.credential.v1:c']).toBe('secret-c');
  511 |     }
  512 |     if (mode === 'remove') {
  513 |       expect(after.local['heijin.credential.v1:a']).toBe('secret-a');
  514 |       expect(after.session['heijin.credential.v1:a']).toBe('secret-a-new');
  515 |     }
  516 |     await expect(save).toBeEnabled(); await expect(settings).not.toContainText('secret-');
  517 |     await page.screenshot({ path: `docs/pr148-security/screenshots/${info.project.name}-${mode}-failure.png` });
  518 |     await saveAi(settings);
  519 |     const success = await vaultDump(page);
  520 |     expect(success.local['heijin.ai.v1']).not.toContain('secret-');
  521 |     expect(mode === 'remove' ? success.session['heijin.credential.v1:a'] : success.local['heijin.credential.v1:a']).toBe('secret-a-new');
  522 |     expect(mode === 'remove' ? success.local['heijin.credential.v1:a'] : success.session['heijin.credential.v1:a']).toBeUndefined();
  523 |     await page.screenshot({ path: `docs/pr148-security/screenshots/${info.project.name}-${mode}-saved.png` });
  524 |     await page.reload(); expect(await vaultDump(page)).toEqual(success);
  525 |     const reopened = await openAiSettings(page); await openChannel(reopened, '甲渠道');
  526 |     await expect(reopened.getByLabel('API 密钥', { exact: true })).toHaveValue('secret-a-new');
  527 |     await expect(reopened.getByRole('switch', { name: '记住密钥' })).toBeChecked({ checked: mode !== 'remove' });
  528 |     expect(posts).toEqual([]); expect(errors).toEqual([]);
  529 |   });
  530 | }
  531 | 
```
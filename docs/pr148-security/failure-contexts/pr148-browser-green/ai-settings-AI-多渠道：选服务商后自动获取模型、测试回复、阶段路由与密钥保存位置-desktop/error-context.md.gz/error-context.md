# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ai-settings.spec.ts >> AI 多渠道：选服务商后自动获取模型、测试回复、阶段路由与密钥保存位置
- Location: e2e/ai-settings.spec.ts:86:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('dialog', { name: '设置', exact: true }).getByRole('button', { name: '放弃修改', exact: true })
    - locator resolved to <button type="button" class="ai-btn ghost">放弃修改</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed

```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - main [ref=f1e4]:
    - region "游戏首页" [ref=f1e5]:
      - generic [ref=f1e7]:
        - text: CHONGQING · 29°33′N
        - generic [ref=f1e8]: 山城 · 江雾 · 轻轨
      - generic [aria-hidden] [ref=f1e9]: 重庆
      - generic [ref=f1e10]:
        - generic [ref=f1e11]:
          - generic [aria-hidden] [ref=f1e12]: 黑
          - generic [ref=f1e13]:
            - text: 黑金王朝
            - generic [ref=f1e14]: HEIJINWANGCHAO
        - button "存档馆" [ref=f1e15] [cursor=pointer]
        - button "设置" [ref=f1e16] [cursor=pointer]
        - generic [ref=f1e17]: V1.0 Beta
      - generic [ref=f1e18]:
        - paragraph [ref=f1e19]: MODERN CITY / OPEN WORLD
        - heading "黑金王朝" [level=1] [ref=f1e20]
        - paragraph [ref=f1e21]: 起点有冲突，人生不预设结局。
        - paragraph [ref=f1e22]: 一款 AI 驱动的现代都市开放世界文字角色扮演游戏。在熟悉的城市里，写下属于你的人生。
        - generic [ref=f1e23]:
          - button "开始新游戏" [ref=f1e24] [cursor=pointer]:
            - text: 开始新游戏
            - generic [aria-hidden] [ref=f1e25]: ↗
          - button "继续游戏 暂无可继续的存档" [disabled] [ref=f1e26]:
            - generic [ref=f1e27]: 继续游戏
            - generic [ref=f1e28]: 暂无可继续的存档
            - generic [aria-hidden] [ref=f1e29]: →
          - button "存档馆00" [ref=f1e30] [cursor=pointer]
        - group "游玩信息" [ref=f1e31]:
          - button "游玩须知与免责声明" [ref=f1e32] [cursor=pointer]
          - button "王朝公告" [ref=f1e33] [cursor=pointer]
      - generic [ref=f1e34]:
        - generic [ref=f1e35]:
          - generic [ref=f1e36]: 四座城市 · 自由职业 · 开放人生
          - generic [ref=f1e37]: 三阶段生成 · 原子结算 · 连续回合
        - navigation "封面城市" [ref=f1e38]:
          - button "重庆" [pressed] [ref=f1e39] [cursor=pointer]
          - button "上海" [ref=f1e40] [cursor=pointer]
          - button "哈尔滨" [ref=f1e41] [cursor=pointer]
          - button "广州" [ref=f1e42] [cursor=pointer]
  - dialog [ref=f1e43]:
    - banner [ref=f1e44]:
      - generic [aria-hidden] [ref=f1e45]: 设
      - generic [ref=f1e46]:
        - generic [aria-hidden] [ref=f1e47]: SYSTEM · 系统
        - heading "设置" [level=2] [ref=f1e48]
        - text: 本地偏好与 AI 渠道
      - generic [aria-hidden] [ref=f1e49]: ESC
      - button "关闭资料界面" [ref=f1e50] [cursor=pointer]: 关闭 ×
    - generic [ref=f1e52]:
      - navigation "设置分类" [ref=f1e53]:
        - button "AI 连接" [pressed] [ref=f1e54] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e55]: 连
        - button "提示词" [ref=f1e58] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e59]: 词
        - button "记忆" [ref=f1e61] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e62]: 忆
        - button "运行" [ref=f1e64] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e65]: 运
        - button "提示词管理" [ref=f1e67] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e68]: 管
        - group "游玩信息" [ref=f1e70]:
          - button "游玩须知与免责声明" [ref=f1e71] [cursor=pointer]
          - button "王朝公告" [ref=f1e72] [cursor=pointer]
      - generic [ref=f1e73]:
        - heading "AI 连接" [level=3] [ref=f1e74]
        - generic [ref=f1e75]:
          - paragraph [ref=f1e76]:
            - text: 游戏直接从浏览器连接你填写的服务，密钥只存在这台设备上，不进存档。
            - button "安全说明" [ref=f1e77] [cursor=pointer]
          - region "各阶段使用的模型" [ref=f1e78]:
            - generic [ref=f1e79]:
              - heading "各阶段使用的模型" [level=4] [ref=f1e80]
              - generic [ref=f1e81]: 先选渠道，再从这个渠道的模型里选；变量、动态世界、记忆默认跟随正文
            - generic [ref=f1e82]:
              - generic [ref=f1e83]:
                - strong [ref=f1e84]: 正文生成
                - generic [ref=f1e85]: 写剧情，最需要好模型
              - generic [ref=f1e86]:
                - generic [ref=f1e88]:
                  - generic [ref=f1e89]: 正文生成渠道
                  - combobox "正文生成渠道" [ref=f1e90] [cursor=pointer]:
                    - generic [ref=f1e91]: ① 选择渠道
                    - generic [aria-hidden] [ref=f1e92]: ⌄
                - generic [ref=f1e94]:
                  - generic [ref=f1e95]: 正文生成模型
                  - combobox "正文生成模型" [disabled] [ref=f1e96]:
                    - generic [ref=f1e97]: 先选渠道
                    - generic [aria-hidden] [ref=f1e98]: ⌄
                - button "刷新正文生成模型" [disabled] [ref=f1e99]: ↻
                - button "列表里没有？手动填写正文生成模型 ID" [disabled] [ref=f1e101]
            - generic [ref=f1e102]:
              - generic [ref=f1e103]:
                - strong [ref=f1e104]: 变量管理
                - generic [ref=f1e105]: 整理金钱、物品、关系
              - group "变量管理模型来源" [ref=f1e106]:
                - button "跟随正文" [ref=f1e107] [cursor=pointer]
                - button "单独指定" [pressed] [ref=f1e108] [cursor=pointer]
              - generic [ref=f1e109]:
                - generic [ref=f1e111]:
                  - generic [ref=f1e112]: 变量管理渠道
                  - combobox "变量管理渠道" [ref=f1e113] [cursor=pointer]:
                    - generic [ref=f1e114]: Mock gemini
                    - generic [aria-hidden] [ref=f1e115]: ⌄
                - generic [ref=f1e117]:
                  - generic [ref=f1e118]: 变量管理模型
                  - combobox "变量管理模型" [ref=f1e119] [cursor=pointer]:
                    - generic [ref=f1e120]: variable-override
                    - generic [aria-hidden] [ref=f1e121]: ⌄
                - button "刷新变量管理模型" [ref=f1e122] [cursor=pointer]: ↻
                - button "列表里没有？手动填写变量管理模型 ID" [ref=f1e124] [cursor=pointer]
            - generic [ref=f1e125]:
              - generic [ref=f1e126]:
                - strong [ref=f1e127]: 动态世界
                - generic [ref=f1e128]: 推进你不在场的世界
              - group "动态世界模型来源" [ref=f1e129]:
                - button "跟随正文" [pressed] [ref=f1e130] [cursor=pointer]
                - button "单独指定" [ref=f1e131] [cursor=pointer]
              - paragraph [ref=f1e132]: 同正文 · 未设置 / 未选模型
            - generic [ref=f1e133]:
              - generic [ref=f1e134]:
                - strong [ref=f1e135]: 记忆维护
                - generic [ref=f1e136]: 定期整理长期记忆
              - group "记忆维护模型来源" [ref=f1e137]:
                - button "跟随正文" [pressed] [ref=f1e138] [cursor=pointer]
                - button "单独指定" [ref=f1e139] [cursor=pointer]
              - paragraph [ref=f1e140]: 同正文 · 未设置 / 未选模型
          - generic [ref=f1e141]:
            - region "API 渠道列表" [ref=f1e142]:
              - heading "我的渠道" [level=4] [ref=f1e143]
              - button "编辑渠道：Mock gemini" [pressed] [ref=f1e144] [cursor=pointer]:
                - generic [ref=f1e145]:
                  - generic [ref=f1e146]: Mock gemini
                  - generic [ref=f1e147]: Gemini 格式
                - generic [ref=f1e148]: 尚未连接
                - generic [ref=f1e150]: 用于：变量
              - button "编辑渠道：Mock anthropic" [ref=f1e151] [cursor=pointer]:
                - generic [ref=f1e152]:
                  - generic [ref=f1e153]: Mock anthropic
                  - generic [ref=f1e154]: Claude 格式
                - generic [ref=f1e155]: 尚未连接
                - generic [ref=f1e157]: 暂未被任何阶段使用
              - button "＋ 添加渠道" [ref=f1e158] [cursor=pointer]
            - region "编辑渠道：Mock gemini" [ref=f1e159]:
              - generic [ref=f1e160]:
                - textbox "渠道名称" [ref=f1e161]: Mock gemini
                - button "删除渠道" [active] [ref=f1e162] [cursor=pointer]
              - generic [ref=f1e163]:
                - text: 服务商
                - emphasis [ref=f1e164]: 选好后地址和接口格式自动填写
              - group "服务商" [ref=f1e165]:
                - button "OpenAI" [ref=f1e166] [cursor=pointer]: 官方
                - button "Claude" [ref=f1e168] [cursor=pointer]: 官方
                - button "Gemini" [ref=f1e170] [cursor=pointer]: 官方
                - button "DeepSeek" [ref=f1e172] [cursor=pointer]: 官方
                - button "OpenAI 兼容" [pressed] [ref=f1e174] [cursor=pointer]: 中转／其他
                - button "本地模型" [ref=f1e176] [cursor=pointer]: Ollama 等
              - generic [ref=f1e178]:
                - generic [ref=f1e179]:
                  - generic [ref=f1e180]: 服务地址
                  - textbox "服务地址" [ref=f1e182]:
                    - /placeholder: https://…/v1
                    - text: https://api.mock.invalid/gemini/v1
                  - generic [ref=f1e183]:
                    - generic [ref=f1e184]:
                      - generic [ref=f1e185]: 接口格式
                      - combobox "接口格式" [ref=f1e186] [cursor=pointer]:
                        - generic [ref=f1e187]: Gemini 格式
                        - generic [aria-hidden] [ref=f1e188]: ⌄
                    - generic [ref=f1e189]: 服务商说明里没提就保持「OpenAI 兼容」
                - generic [ref=f1e190]:
                  - generic [ref=f1e191]: API 密钥
                  - generic [ref=f1e192]:
                    - textbox "API 密钥" [ref=f1e193]:
                      - /placeholder: 粘贴密钥后自动获取模型
                      - text: browser-mock-credential
                    - button "显示" [ref=f1e194] [cursor=pointer]
                  - generic [ref=f1e195] [cursor=pointer]:
                    - switch "记住密钥" [checked] [ref=f1e196]
                    - text: 记住密钥
                  - paragraph [ref=f1e198]: 关闭浏览器后仍保留。公共电脑请关闭。
              - status [ref=f1e199]:
                - generic [ref=f1e201]:
                  - generic [ref=f1e202]: 尚未检查连接
                  - generic [ref=f1e203]: 点「获取模型」检查连接并读取模型列表（不产生费用）。
                - generic [ref=f1e204]:
                  - button "获取模型" [ref=f1e205] [cursor=pointer]
                  - button "测试回复（可能产生少量费用）" [ref=f1e206] [cursor=pointer]
              - generic [ref=f1e207]:
                - text: 最大输出
                - emphasis [ref=f1e208]: 每次回复最多多少 Token；推理模型的思考也算在内，正文被截断时调大
              - group "最大输出 Token 档位" [ref=f1e210]:
                - button "4K" [ref=f1e211] [cursor=pointer]
                - button "8K（推荐）" [pressed] [ref=f1e212] [cursor=pointer]
                - button "16K" [ref=f1e213] [cursor=pointer]
                - button "自定义" [ref=f1e214] [cursor=pointer]
              - group [ref=f1e215]:
                - generic "高级设置（一般不用改）" [ref=f1e216] [cursor=pointer]
          - generic [ref=f1e217]:
            - status [ref=f1e218]:
              - generic [aria-hidden] [ref=f1e219]: 注
              - generic [ref=f1e220]:
                - generic [ref=f1e221]: 有 3 处修改尚未保存；
                - generic [ref=f1e222]: 正文生成还没选模型
            - button "放弃修改" [ref=f1e223] [cursor=pointer]
            - button "保存 AI 配置" [disabled] [ref=f1e224]
```

# Test source

```ts
  75  |       ]);
  76  |       expect(ids.filter((id) => id === 'writing.nsfw')).toHaveLength(1);
  77  |       expect(ids.filter((id) => id === 'writing.intimacy_boundaries')).toHaveLength(1);
  78  |     } else expect(ids.some((id) => id.startsWith('writing.'))).toBe(false);
  79  |     if (example.stage === 'world') expect(example.variablePending).toBe(true);
  80  |   }
  81  |   const artifact = testInfo.outputPath('prompt-order.json');
  82  |   await writeFile(artifact, JSON.stringify(examples, null, 2));
  83  |   await testInfo.attach('prompt-order.json', { path: artifact, contentType: 'application/json' });
  84  | });
  85  | 
  86  | test('AI 多渠道：选服务商后自动获取模型、测试回复、阶段路由与密钥保存位置', async ({ page }) => {
  87  |   const errors: string[] = [];
  88  |   page.on('pageerror', (error) => errors.push(error.message));
  89  |   const requests: { url: string; method: string; headers: Record<string, string>; body: string }[] = [];
  90  |   await page.route('https://api.mock.invalid/**', async (route) => {
  91  |     const request = route.request();
  92  |     requests.push({ url: request.url(), method: request.method(), headers: request.headers(), body: request.postData() ?? '' });
  93  |     const native = request.url().includes('/gemini/') ? 'gemini' : request.url().includes('/anthropic/') ? 'anthropic' : 'openai';
  94  |     const result = request.method() === 'GET'
  95  |       ? native === 'gemini' ? { models: [{ name: 'models/mock-model' }] } : { data: [{ id: 'mock-model' }] }
  96  |       : native === 'gemini' ? { candidates: [{ content: { parts: [{ text: 'OK' }] }, finishReason: 'STOP' }] }
  97  |         : native === 'anthropic' ? { content: [{ type: 'text', text: 'OK' }], stop_reason: 'end_turn' }
  98  |           : { choices: [{ message: { content: 'OK' }, finish_reason: 'stop' }] };
  99  |     await route.fulfill({ json: result });
  100 |   });
  101 |   await page.goto('/');
  102 |   const settings = await openAiSettings(page);
  103 |   const channels = [
  104 |     { name: 'Mock openai', preset: 'OpenAI 兼容', url: 'https://api.mock.invalid/openai/v1' },
  105 |     { name: 'Mock gemini', preset: 'OpenAI 兼容', url: 'https://api.mock.invalid/gemini/v1', format: 'Gemini 格式' },
  106 |     { name: 'Mock anthropic', preset: 'OpenAI 兼容', url: 'https://api.mock.invalid/anthropic/v1', format: 'Claude 格式' },
  107 |     { name: 'Mock deepseek', preset: 'DeepSeek', url: 'https://api.mock.invalid/deepseek/v1' },
  108 |   ];
  109 |   for (const [index, channel] of channels.entries()) {
  110 |     await addChannel(settings, { ...channel, key: undefined });
  111 |     const password = settings.getByLabel('API 密钥', { exact: true });
  112 |     await expect(password).toHaveAttribute('type', 'password');
  113 |     // 未保存时也能填好密钥后直接获取模型、测试回复。
  114 |     await password.fill('browser-mock-credential');
  115 |     await expect(settings.getByRole('status').filter({ hasText: '连接正常' }).first()).toBeVisible();
  116 |     await expect.poll(() => requests.length).toBe(index * 2 + 1);
  117 |     await testReply(settings);
  118 |     await expect(settings.getByRole('status').filter({ hasText: '收到了回复' }).first()).toBeVisible();
  119 |     await expect.poll(() => requests.length).toBe(index * 2 + 2);
  120 |   }
  121 |   expect(requests.map((request) => `${request.method} ${request.url}`)).toEqual([
  122 |     'GET https://api.mock.invalid/openai/v1/models',
  123 |     'POST https://api.mock.invalid/openai/v1/chat/completions',
  124 |     'GET https://api.mock.invalid/gemini/v1/models',
  125 |     'POST https://api.mock.invalid/gemini/v1/models/mock-model:generateContent',
  126 |     'GET https://api.mock.invalid/anthropic/v1/models?limit=100',
  127 |     'POST https://api.mock.invalid/anthropic/v1/messages',
  128 |     'GET https://api.mock.invalid/deepseek/v1/models',
  129 |     'POST https://api.mock.invalid/deepseek/v1/chat/completions',
  130 |   ]);
  131 |   for (const [index, header] of [[1, 'authorization'], [3, 'x-goog-api-key'], [5, 'x-api-key'], [7, 'authorization']] as const) {
  132 |     expect(requests[index].headers[header]).toContain('browser-mock-credential');
  133 |     expect(requests[index].url).not.toContain('browser-mock-credential');
  134 |     expect(requests[index].body).not.toContain('browser-mock-credential');
  135 |   }
  136 |   // 正文用第一个渠道（从列表选），变量单独用 Gemini 渠道（手动填写），其余跟随正文。
  137 |   await stageModel(settings, '正文生成', 'Mock openai', 'mock-model', 'list');
  138 |   await stageModel(settings, '变量管理', 'Mock gemini', 'variable-override');
  139 |   await expect(settings.getByRole('group', { name: '动态世界模型来源', exact: true }).getByRole('button', { name: '跟随正文', exact: true })).toHaveAttribute('aria-pressed', 'true');
  140 |   // 第三个渠道关闭「记住密钥」，只在本次会话保留。
  141 |   await openChannel(settings, 'Mock anthropic');
  142 |   await settings.getByRole('switch', { name: '记住密钥' }).uncheck();
  143 |   await saveAi(settings);
  144 |   await page.keyboard.press('Escape');
  145 |   await page.reload();
  146 |   const again = await openAiSettings(page);
  147 |   await openChannel(again, 'Mock openai');
  148 |   await expect(again.getByLabel('API 密钥', { exact: true })).toHaveValue('browser-mock-credential');
  149 |   await backToList(again);
  150 |   await expect(again.getByRole('combobox', { name: '变量管理渠道', exact: true })).toContainText('Mock gemini');
  151 |   await expect(again.getByRole('combobox', { name: '变量管理模型', exact: true })).toHaveAttribute('value', 'variable-override');
  152 |   await expect(again.getByRole('combobox', { name: '正文生成模型', exact: true })).toHaveAttribute('value', 'mock-model');
  153 |   const stored = await page.evaluate(() => ({ local: Object.entries(localStorage), session: Object.entries(sessionStorage) }));
  154 |   const config = stored.local.find(([key]) => key === 'heijin.ai.v1')?.[1] ?? '';
  155 |   expect(config).not.toContain('browser-mock-credential');
  156 |   expect(stored.local.filter(([key, value]) => key.startsWith('heijin.credential.v1:') && value === 'browser-mock-credential')).toHaveLength(3);
  157 |   expect(stored.session.filter(([key, value]) => key.startsWith('heijin.credential.v1:') && value === 'browser-mock-credential')).toHaveLength(1);
  158 |   // 删除：取消不改动；确认后保存才生效；删除正文用的渠道会阻止保存，直到重新选好模型或放弃修改。
  159 |   await openChannel(again, 'Mock deepseek');
  160 |   await again.getByRole('button', { name: '删除渠道', exact: true }).click();
  161 |   await page.getByRole('button', { name: '取消', exact: true }).click();
  162 |   await backToList(again);
  163 |   await expect(again.getByRole('button', { name: /^编辑渠道：/ })).toHaveCount(4);
  164 |   await openChannel(again, 'Mock deepseek');
  165 |   await again.getByRole('button', { name: '删除渠道', exact: true }).click();
  166 |   await page.getByRole('button', { name: '确认删除渠道', exact: true }).click();
  167 |   await backToList(again);
  168 |   await expect(again.getByRole('button', { name: /^编辑渠道：/ })).toHaveCount(3);
  169 |   await openChannel(again, 'Mock openai');
  170 |   await again.getByRole('button', { name: '删除渠道', exact: true }).click();
  171 |   await expect(page.getByRole('dialog', { name: '删除「Mock openai」？' })).toContainText('它正被「正文');
  172 |   await page.getByRole('button', { name: '确认删除渠道', exact: true }).click();
  173 |   await expect(again.getByRole('button', { name: '保存 AI 配置', exact: true })).toBeDisabled();
  174 |   await expect(again.getByRole('status').filter({ hasText: '正文生成还没选模型' })).toBeVisible();
> 175 |   await again.getByRole('button', { name: '放弃修改', exact: true }).click();
      |                                                                  ^ Error: locator.click: Test timeout of 30000ms exceeded.
  176 |   await backToList(again);
  177 |   await expect(again.getByRole('button', { name: /^编辑渠道：/ })).toHaveCount(4);
  178 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  179 |   expect(errors).toEqual([]);
  180 | });
  181 | 
  182 | test('连接授权错误不展示服务详情，网络错误不误报密钥，取消测试有效', async ({ page }) => {
  183 |   let mode = 'authorization';
  184 |   await page.route('https://api.mock.invalid/**', async (route) => {
  185 |     if (mode === 'authorization') await route.fulfill({ status: 401, json: { error: 'browser-mock-credential secret service detail' } });
  186 |     else if (mode === 'network') await route.abort('failed');
  187 |     else await new Promise<void>((resolve) => { route.request().response().then(() => resolve()).catch(() => resolve()); });
  188 |   });
  189 |   await page.goto('/');
  190 |   const settings = await openAiSettings(page);
  191 |   await addChannel(settings, { name: 'Mock', url: 'https://api.mock.invalid/v1', key: 'browser-mock-credential' });
  192 |   await expect(settings.getByRole('status').filter({ hasText: '连接失败' }).first()).toContainText('授权错误');
  193 |   await expect(page.getByRole('dialog').first()).not.toContainText('secret service detail');
  194 |   await stageModel(settings, '正文生成', 'Mock', 'mock-model');
  195 |   await openChannel(settings, 'Mock');
  196 |   await testReply(settings);
  197 |   await expect(settings.getByRole('status').filter({ hasText: '测试失败' }).first()).toContainText('授权错误');
  198 |   mode = 'network';
  199 |   await testReply(settings);
  200 |   await expect(settings.getByRole('status').filter({ hasText: 'CORS' }).first()).toBeVisible();
  201 |   mode = 'hanging';
  202 |   await testReply(settings);
  203 |   await settings.getByRole('button', { name: '取消', exact: true }).click();
  204 |   await expect(settings.getByRole('status').filter({ hasText: '已取消测试' }).first()).toBeVisible();
  205 |   await expect(settings.getByRole('button', { name: '测试回复（可能产生少量费用）', exact: true })).toBeEnabled();
  206 |   await expect(page.getByRole('dialog').first()).not.toContainText('secret service detail');
  207 | });
  208 | 
  209 | test('最大输出：档位直接显示，旧渠道值与渠道隔离，新渠道默认 8K', async ({ page }) => {
  210 |   await page.goto('/');
  211 |   await page.evaluate(async () => {
  212 |     const path = '/src/services/ai/configuration.ts', vaultPath = '/src/services/ai/credentials.ts';
  213 |     const { defaultAiConfig, newChannel, saveAiConfig } = await import(path), { CredentialVault } = await import(vaultPath);
  214 |     const config = defaultAiConfig(), first = newChannel(), second = newChannel();
  215 |     first.name = '旧4K渠道'; first.parameters.maxOutputTokens = 4096;
  216 |     second.name = '旧自定义渠道'; second.parameters.maxOutputTokens = 32768; config.channels = [first, second];
  217 |     config.routes.story = { channelId: first.id, modelId: 'mock-model' };
  218 |     saveAiConfig(localStorage, config); const vault = new CredentialVault(sessionStorage, localStorage);
  219 |     config.channels.forEach((channel: { id: string }) => vault.set(channel.id, 'mock-budget-key'));
  220 |   });
  221 |   await page.reload();
  222 |   const settings = await openAiSettings(page);
  223 |   await openChannel(settings, '旧4K渠道');
  224 |   const tiers = settings.getByRole('group', { name: '最大输出 Token 档位', exact: true });
  225 |   await expect(tiers.getByRole('button', { name: '4K', exact: true })).toHaveAttribute('aria-pressed', 'true');
  226 |   await tiers.getByRole('button', { name: '16K', exact: true }).click();
  227 |   await saveAi(settings);
  228 |   await openChannel(settings, '旧自定义渠道');
  229 |   await expect(tiers.getByRole('button', { name: '自定义', exact: true })).toHaveAttribute('aria-pressed', 'true');
  230 |   await expect(settings.getByLabel('自定义最大输出 Token')).toHaveValue('32768');
  231 |   const values = await page.evaluate(async () => { const path = '/src/services/ai/configuration.ts', { readAiConfig } = await import(path);
  232 |     return readAiConfig(localStorage).channels.map((channel: { parameters: { maxOutputTokens: number } }) => channel.parameters.maxOutputTokens); });
  233 |   expect(values).toEqual([16384, 32768]);
  234 |   await addChannel(settings, { preset: 'OpenAI', key: 'new-mock-key' });
  235 |   await expect(tiers.getByRole('button', { name: '8K（推荐）', exact: true })).toHaveAttribute('aria-pressed', 'true');
  236 |   await saveAi(settings);
  237 |   await page.keyboard.press('Escape'); await page.reload();
  238 |   const again = await openAiSettings(page);
  239 |   await openChannel(again, '旧4K渠道');
  240 |   await expect(tiers.getByRole('button', { name: '16K', exact: true })).toHaveAttribute('aria-pressed', 'true');
  241 |   await openChannel(again, '旧自定义渠道');
  242 |   await expect(tiers.getByRole('button', { name: '自定义', exact: true })).toHaveAttribute('aria-pressed', 'true');
  243 |   await expect(again.getByLabel('自定义最大输出 Token')).toHaveValue('32768');
  244 | });
  245 | 
  246 | test('最大输出：自定义合法范围与 4K/8K/16K 往返，只保存玩家明确设置', async ({ page }) => {
  247 |   await page.goto('/');
  248 |   const settings = await openAiSettings(page);
  249 |   await addChannel(settings, { preset: 'OpenAI', key: 'custom-mock-key' });
  250 |   await stageModel(settings, '正文生成', 'OpenAI 官方', 'mock-model');
  251 |   await openChannel(settings, 'OpenAI 官方');
  252 |   const tiers = settings.getByRole('group', { name: '最大输出 Token 档位', exact: true });
  253 |   await expect(tiers.getByRole('button', { name: '8K（推荐）', exact: true })).toHaveAttribute('aria-pressed', 'true');
  254 |   for (const name of ['4K', '8K（推荐）', '16K']) { await tiers.getByRole('button', { name, exact: true }).click(); await expect(tiers.getByRole('button', { name, exact: true })).toHaveAttribute('aria-pressed', 'true'); }
  255 |   await tiers.getByRole('button', { name: '自定义', exact: true }).click();
  256 |   const custom = settings.getByLabel('自定义最大输出 Token', { exact: true }); await expect(custom).toHaveValue('16384');
  257 |   await custom.fill('12345');
  258 |   await saveAi(settings);
  259 |   for (const value of ['0', '1000001']) {
  260 |     await custom.fill(value); await settings.getByRole('button', { name: '保存 AI 配置', exact: true }).click();
  261 |     await expect(settings.getByText(/配置无效：请核对/)).toBeVisible();
  262 |     expect(await page.evaluate(() => JSON.parse(localStorage.getItem('heijin.ai.v1')!).channels[0].parameters.maxOutputTokens)).toBe(12345);
  263 |   }
  264 |   await custom.fill('1000000'); await saveAi(settings);
  265 |   await page.keyboard.press('Escape'); await page.reload();
  266 |   const again = await openAiSettings(page);
  267 |   await openChannel(again, 'OpenAI 官方');
  268 |   await expect(tiers.getByRole('button', { name: '自定义', exact: true })).toHaveAttribute('aria-pressed', 'true');
  269 |   await expect(again.getByLabel('自定义最大输出 Token', { exact: true })).toHaveValue('1000000');
  270 | });
  271 | 
  272 | test('原生 DeepSeek 官方地址、四阶段独立选模与刷新恢复，纯设置不生成内容', async ({ page }, testInfo) => {
  273 |   const posts: string[] = [], models = ['mock-story', 'mock-variables', 'mock-world', 'mock-memory'];
  274 |   await page.route('https://api.deepseek.com/**', async route => {
  275 |     const request = route.request();
```
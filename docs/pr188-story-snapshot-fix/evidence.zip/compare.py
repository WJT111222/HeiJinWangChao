import json, difflib, pathlib
root=pathlib.Path('/workspace/pr188-snapshot-evidence')
read=lambda p:json.loads(p.read_text())
fixture=read(pathlib.Path('src/tests/fixtures/talent-story-length-baseline.json'))
(root/'baseline-before.json').write_text(json.dumps(fixture,ensure_ascii=False,indent=2)+'\n')
main=read(root/'main-legacy.json'); pr=read(root/'pr-legacy.json')
summary={'legacy':[], 'matrix':{'story':0,'nonStory':0}}
def compare(b,p,allowed,label):
 assert b.keys()==p.keys(),label
 for key in b.keys()-{'messages','modules'}: assert b[key]==p[key],(label,key)
 assert len(b['modules'])==len(p['modules'])
 assert len(b['messages'])==len(p['messages'])
 changed=[]
 for i,(x,y) in enumerate(zip(b['modules'],p['modules'])):
  assert x['id']==y['id'],label
  if x!=y:
   assert x['id'] in allowed,(label,x['id'])
   assert {k for k in x if x[k]!=y[k]} <= {'contentSha256','characters','estimatedTokens'},(label,x,y)
   changed.append(i)
 assert {p['modules'][i]['id'] for i in changed}==allowed,label
 msgchanges=[]
 for i,(x,y) in enumerate(zip(b['messages'],p['messages'])):
  assert x['role']==y['role'],label
  if x!=y: msgchanges.append(i)
 assert msgchanges==changed,(label,msgchanges,changed)
 assert b['messages'][-2:]==p['messages'][-2:],label
 return [{'index':i,'id':p['modules'][i]['id'],'old':b['modules'][i],'new':p['modules'][i]} for i in changed]
for old,b,p in zip(fixture['results'],main,pr):
 assert old['mode']==b['mode']==p['mode']
 for k in ['messages','context','modules']: assert old[k]==b['hashes'][k],(old['mode'],k,'main fixture mismatch')
 assert old['context']==p['hashes']['context']
 changes=compare(b['prompt'],p['prompt'],{'writing.natural_prose','planning.'+p['mode']},p['mode'])
 summary['legacy'].append({'mode':p['mode'],'old':b['hashes'],'new':p['hashes'],'changes':changes})
 diff='\n'.join(difflib.unified_diff(json.dumps(b['prompt'],ensure_ascii=False,indent=2).splitlines(),json.dumps(p['prompt'],ensure_ascii=False,indent=2).splitlines(),fromfile='main',tofile='PR188'))
 (root/(p['mode']+'-request.diff')).write_text(diff+'\n')
a=read(root/'main-requests.json');b=read(root/'pr-requests.json');assert len(a)==len(b)==126
for x,y in zip(a,b):
 assert {k:v for k,v in x.items() if k!='prompt'}=={k:v for k,v in y.items() if k!='prompt'}
 if x['stage']!='story':
  assert x==y,(x['stage'],x.get('task'))
  summary['matrix']['nonStory']+=1
 else:
  compare(x['prompt'],y['prompt'],{'planning.'+x['mode']}|({'writing.natural_prose'} if x['naturalProse'] else set()),str({k:v for k,v in x.items() if k!='prompt'}))
  summary['matrix']['story']+=1
(root/'comparison.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))

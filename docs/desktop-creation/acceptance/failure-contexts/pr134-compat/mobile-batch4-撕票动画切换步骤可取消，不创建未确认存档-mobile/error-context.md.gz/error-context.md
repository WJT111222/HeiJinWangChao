# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mobile-batch4.spec.ts >> 撕票动画切换步骤可取消，不创建未确认存档
- Location: e2e/mobile-batch4.spec.ts:58:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.mobile-creation')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.mobile-creation') with timeout 5000ms
  - waiting for locator('.mobile-creation')

```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import type {Page} from '@playwright/test';
  3  | import {disclaimer} from '../src/ui/notices/disclaimer';
  4  | import {announcement} from '../src/ui/notices/announcement';
  5  | const shots='docs/mobile-batch4/screenshots';
  6  | const doc=(p:Page)=>p.getByRole('dialog',{name:disclaimer.title,exact:true});
  7  | const draft=(p:Page)=>p.evaluate(()=>JSON.parse(localStorage.getItem('heijin.creation.v1')!));
  8  | const packs=(p:Page)=>p.evaluate(()=>Object.fromEntries(Object.entries(localStorage).filter(([key])=>key.startsWith('heijin.opening-pack.v1:'))));
  9  | async function shot(page:Page,name:string){await page.mouse.move(0,0);await page.evaluate(()=>document.fonts.ready);await page.screenshot({path:`${shots}/${name}.png`,animations:'disabled'});}
  10 | async function mute(page:Page){await page.addInitScript(()=>{const d=new Date();localStorage.setItem('heijin.notices.hidden-on.v1',[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-'));});}
  11 | async function create(page:Page,step=1,manual=false){
  12 |  await mute(page);await page.goto('/');await page.evaluate(async({step,manual})=>{
  13 |   const path='/src/ui/creation/model.ts',{newCreation,selectProfession}=await import(path);let f=newCreation();
  14 |   f.person={name:'沈砚',age:'27',gender:'男性',appearance:'原始外貌'.repeat(15),personality:'沉稳谨慎'};f.customProfession='旧书修复师';f.professionDescription='自定义职业介绍';f.professionLongTermImpact='自定义长期影响';f.skills='修补\n记录';f.skillsSource='manual';f.background='旧街巷的成长经历';f.openingPreference='2015年秋天';f.step=step;
  15 |   if(manual){f=selectProfession(f,'程序员');f.skills='玩家自存技能\n第二技能';f.skillsSource='manual';}
  16 |   localStorage.setItem('heijin.creation.v1',JSON.stringify(f));
> 17 |  },{step,manual});await page.goto('/#create');await page.reload();await expect(page.locator('.mobile-creation')).toBeVisible();
     |                                                                                                                  ^ Error: expect(locator).toBeVisible() failed
  18 | }
  19 | async function stores(page:Page){return page.evaluate(async()=>{const path='/src/services/storage/saveRepository.ts',{SaveRepository}=await import(path),repo=await SaveRepository.open();try{return await repo.list();}finally{repo.close();}});}
  20 | async function drag(page:Page,dy:number,cancel=false){const stub=page.locator('.creation-card .creation-ticket-stub');await stub.scrollIntoViewIfNeeded();const b=(await stub.boundingBox())!;await page.mouse.move(b.x+40,b.y+15);await page.mouse.down();await page.mouse.move(b.x+40,b.y+15+dy,{steps:6});if(cancel)await stub.dispatchEvent('pointercancel');await page.mouse.up();}
  21 | let postCalls=0;
  22 | test.beforeEach(async({page})=>{postCalls=0;await page.route('**/*',route=>{if(route.request().method()==='POST'){postCalls++;return route.abort();}return route.continue();});});
  23 | test.afterEach(()=>expect(postCalls).toBe(0));
  24 | 
  25 | test('自动须知→公告、原文、焦点陷阱、章节与进度、手动打开仅一张',async({page})=>{
  26 |  await page.route('**/api/announcement',r=>r.abort());await page.goto('/');await expect(doc(page)).toBeFocused();await expect(doc(page)).toHaveAttribute('aria-modal','true');await shot(page,'notice-auto-390');
  27 |  for(const section of disclaimer.sections){await expect(doc(page)).toContainText(section.title);for(const p of section.paragraphs)await expect(doc(page)).toContainText(p.text);}
  28 |  const chapter=page.getByRole('navigation',{name:'须知章节'});await expect(chapter.getByRole('button')).toHaveCount(6);
  29 |  await chapter.getByRole('button',{name:/第三方 AI 服务与费用/}).click();await expect(chapter.getByRole('button',{name:/第三方 AI 服务与费用/})).toHaveAttribute('aria-current','true');
  30 |  await doc(page).getByLabel('免责声明内容').evaluate(el=>{el.scrollTop=el.scrollHeight;});await expect(chapter.getByRole('button').last()).toHaveAttribute('aria-current','true');await expect(page.locator('.notice-percent')).toHaveText('已阅读 100%');await shot(page,'notice-read-end-390');
  31 |  await doc(page).getByRole('button',{name:'关闭免责声明'}).focus();await page.keyboard.press('Shift+Tab');expect(await page.evaluate(()=>Boolean(document.activeElement?.closest('dialog')))).toBe(true);
  32 |  await doc(page).getByRole('button',{name:'已阅读，查看公告 →'}).click();const a=page.getByRole('dialog',{name:announcement.title,exact:true});await expect(a).toBeVisible();await expect(a).toContainText(announcement.theme);await shot(page,'announcement-auto-390');await a.getByRole('button',{name:'开始游玩'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  33 |  const trigger=page.getByRole('button',{name:'王朝公告',exact:true});await trigger.click();await expect(a.getByRole('button',{name:'关闭',exact:true})).toBeVisible();await expect(a.locator('.notice-steps')).toHaveCount(0);await shot(page,'announcement-manual-390');await page.keyboard.press('Escape');await expect(page.getByRole('dialog')).toHaveCount(0);await expect(trigger).toBeFocused();
  34 | });
  35 | test('今日免打扰、隔日恢复；云端实际版本和长内容、滚动不重复请求',async({page})=>{
  36 |  await page.clock.setFixedTime(new Date('2026-11-13T05:00:00Z'));let calls=0;const remote={version:'MOCK-2026.11',title:'隔离云端王朝公告',theme:'正式接入的测试公告主题',updates:['<script>window.remoteInjected=true</script>','完整更新'.repeat(200)],message:'远程寄语，完整显示。'};
  37 |  await page.route('**/api/announcement',r=>{calls++;return r.fulfill({json:remote});});await page.goto('/');await doc(page).getByRole('checkbox').check();await doc(page).getByRole('button',{name:'关闭免责声明'}).click();const a=page.getByRole('dialog',{name:remote.title,exact:true});await expect(a).toContainText(remote.version);await expect(a).toContainText(remote.updates[0]);await a.getByLabel('公告内容').evaluate(el=>el.scrollTop=el.scrollHeight);await shot(page,'announcement-cloud-mock-390');expect(calls).toBe(1);expect(await page.evaluate(()=>Reflect.get(window,'remoteInjected'))).toBeUndefined();
  38 |  await a.getByRole('button',{name:'开始游玩'}).click();await page.reload();await expect(page.getByRole('dialog')).toHaveCount(0);await page.clock.setFixedTime(new Date('2026-11-14T05:00:00Z'));await page.reload();await expect(doc(page)).toBeVisible();await expect(doc(page).getByRole('checkbox')).not.toBeChecked();
  39 | });
  40 | test('自动翻页动画防重复关闭，reduced-motion 与 Esc 顺序',async({page})=>{
  41 |  await page.emulateMedia({reducedMotion:'no-preference'});await page.goto('/');await doc(page).getByRole('button',{name:'已阅读，查看公告 →'}).click({clickCount:2});const a=page.getByRole('dialog',{name:announcement.title,exact:true});await expect(a).toBeVisible();await expect(a.getByRole('button',{name:'关闭王朝公告'})).toBeEnabled();await page.keyboard.press('Escape');await expect(page.getByRole('dialog')).toHaveCount(0);
  42 | });
  43 | test('五站真实字段、模板与手动技能、城市背景无损、同伴及回顾全文',async({page})=>{
  44 |  await create(page);await page.getByLabel('姓名',{exact:true}).fill('沈砚与很长的名字');await page.getByRole('radiogroup',{name:'外貌模板'}).getByRole('radio',{name:'清爽干练'}).click();await expect(page.getByLabel('外貌',{exact:true})).toHaveValue(/身形匀称/);await shot(page,'creation-step1-390');
  45 |  await page.getByRole('button',{name:/下一步/}).click();await shot(page,'creation-step2-custom-390');await page.getByRole('button',{name:'技术与生产',exact:true}).click();await page.getByRole('radio',{name:/程序员/}).check();await expect(page.getByRole('region',{name:'职业档案'})).toContainText('编程实现');await page.locator('.creation-manual-skills summary').click();await page.getByLabel('个人技能与专长').fill('手动技能不丢失');await shot(page,'creation-step2-preset-390');await page.getByRole('button',{name:/下一步/}).click();
  46 |  for(const city of ['重庆','上海','哈尔滨','广州']){await page.getByRole('radio',{name:new RegExp(city)}).check();await expect(page.locator('.creation-mini-ticket')).toContainText(city);await expect(page.getByLabel('人物背景（可选）')).toHaveValue('旧街巷的成长经历');await shot(page,`creation-city-${city}-390`);}
  47 |  await page.getByRole('button',{name:/下一步/}).click();await shot(page,'creation-step4-off-390');await page.getByRole('checkbox',{name:'创建一名初始同伴'}).check();for(const [label,value] of Object.entries({'同伴姓名':'林晚','同伴年龄（可选）':'26','同伴身份':'书店店员','与主角的关系':'多年朋友','同伴外貌':'齐肩短发','同伴性格':'直率','同伴能力（一行一项）':'记录\n沟通','同伴个人经历':'在旧街巷成长'}))await page.getByLabel(label,{exact:true}).fill(value);await shot(page,'creation-step4-on-390');await page.getByRole('button',{name:/下一步/}).click();await shot(page,'creation-step5-ticket-390');
  48 |  const folds=page.locator('.creation-review-fold');await expect(folds).toHaveCount(4);for(const fold of await folds.all())if(await fold.getAttribute('open')===null)await fold.locator(':scope > summary').click();await expect(page.locator('.creation-review')).toContainText('在旧街巷成长');await expect(page.locator('.creation-review')).toContainText('手动技能不丢失');await expect(page.locator('.creation-review')).toContainText('开局时间待确认');const before=await draft(page);await page.reload();expect(await draft(page)).toEqual(before);expect(await stores(page)).toEqual([]);
  49 | });
  50 | test('顶部预览只读，短拖和取消不建档，正式撕票沿原授权建档且不重复',async({page})=>{
  51 |  await create(page,5,true);await page.getByRole('button',{name:'展开完整车票预览'}).click();const preview=page.getByRole('dialog',{name:'车票预览'});await expect(preview).toContainText('填完第 5 站即可撕票');await expect(preview.getByRole('button',{name:'确认并创建存档'})).toHaveCount(0);await page.keyboard.press('Escape');await drag(page,40);expect(await stores(page)).toEqual([]);await drag(page,90,true);expect(await stores(page)).toEqual([]);
  52 |  await drag(page,75);await expect(page.locator('.game-layout')).toBeVisible();expect(await stores(page)).toHaveLength(1);const saved=await page.evaluate(async()=>{const p='/src/services/storage/saveRepository.ts',{SaveRepository}=await import(p),r=await SaveRepository.open();try{return await r.loadGame(location.hash.slice(6));}finally{r.close();}});expect(saved.state.protagonist.skills).toEqual(['玩家自存技能','第二技能']);expect(saved.state.openingTimePending).toBe(true);expect(saved.state.turnNumber).toBe(0);expect(saved.draft!.turnKind??saved.draft!.mode).toBeDefined();
  53 | });
  54 | test('确认按钮同一校验路径、草稿保留、无效撕票返回错误步骤',async({page})=>{
  55 |  await create(page,5);await page.evaluate(()=>{const f=JSON.parse(localStorage.getItem('heijin.creation.v1')!);f.person.name='';localStorage.setItem('heijin.creation.v1',JSON.stringify(f));});await page.reload();await drag(page,75);await expect(page.getByRole('heading',{name:'基本信息',exact:true})).toBeVisible();await expect(page.getByRole('alert')).toContainText('姓名');expect(await stores(page)).toEqual([]);await shot(page,'creation-validation-390');
  56 |  await page.getByLabel('姓名',{exact:true}).fill('沈砚');await page.getByRole('navigation',{name:'角色创建步骤'}).getByRole('button',{name:'确认与开局',exact:true}).click();await page.getByRole('button',{name:'确认并创建存档',exact:true}).click({clickCount:2});await expect(page.locator('.game-layout')).toBeVisible();expect(await stores(page)).toHaveLength(1);
  57 | });
  58 | test('撕票动画切换步骤可取消，不创建未确认存档',async({page})=>{
  59 |  await create(page,5);await page.emulateMedia({reducedMotion:'no-preference'});await drag(page,75);await expect(page.locator('.creation-ticket-stub.torn')).toHaveCount(1);await shot(page,'creation-tear-390');await page.getByRole('button',{name:'展开完整车票预览'}).click();await page.waitForTimeout(800);expect(await stores(page)).toEqual([]);await page.keyboard.press('Escape');
  60 |  await drag(page,75);await page.getByRole('button',{name:'保存为开局包'}).click();await page.waitForTimeout(800);expect(await stores(page)).toEqual([]);await page.keyboard.press('Escape');
  61 |  await drag(page,75);await page.getByRole('navigation',{name:'角色创建步骤'}).getByRole('button',{name:'基本信息',exact:true}).click();await page.waitForTimeout(800);expect(await stores(page)).toEqual([]);
  62 | });
  63 | test('正式保存失败保留同一创角身份，解除 busy 后可重试一次建档',async({page})=>{
  64 |  await create(page,5);const original=await draft(page);await page.evaluate(async()=>{const p='/src/services/storage/saveRepository.ts',{SaveRepository}=await import(p),real=SaveRepository.prototype.create;let fail=true;SaveRepository.prototype.create=async function(...args:Parameters<typeof real>){if(fail){fail=false;throw new Error('隔离测试：首次写入拒绝');}return real.apply(this,args);};});
  65 |  await page.getByRole('button',{name:'确认并创建存档',exact:true}).click();await expect(page.getByRole('alert')).toContainText('首次写入拒绝');await expect(page.getByRole('alert')).toBeInViewport();await shot(page,'creation-save-failure-390');expect((await draft(page)).saveId).toBe(original.saveId);expect(await stores(page)).toEqual([]);await expect(page.getByRole('button',{name:'确认并创建存档',exact:true})).toBeEnabled();await page.getByRole('button',{name:'确认并创建存档',exact:true}).click();await expect(page.locator('.game-layout')).toBeVisible();const saved=await stores(page);expect(saved).toHaveLength(1);expect(saved[0].saveId).toBe(original.saveId);
  66 | });
  67 | test('开局包六视图、手动技能完整恢复、取消不写、覆盖与删除隔离',async({page})=>{
  68 |  await create(page,5,true);const original=await draft(page);await page.getByRole('button',{name:'保存为开局包'}).click();let dialog=page.getByRole('dialog');await shot(page,'pack-save-390');await dialog.getByLabel('开局包名称').fill('山城人生');await dialog.getByRole('button',{name:'保存开局包',exact:true}).click();const first=await packs(page);expect(Object.keys(first)).toHaveLength(1);
  69 |  await page.getByRole('navigation',{name:'角色创建步骤'}).getByRole('button',{name:'基本信息',exact:true}).click();await page.getByRole('button',{name:'我的开局包'}).click();dialog=page.getByRole('dialog');await expect(dialog.getByRole('button',{name:'套用开局包',exact:true})).toBeDisabled();await dialog.getByRole('radio').first().check();await shot(page,'pack-browse-390');await dialog.getByRole('button',{name:'重命名',exact:true}).click();await shot(page,'pack-rename-390');await dialog.getByLabel('开局包名称').fill('重命名人生');await dialog.getByRole('button',{name:'确认重命名'}).click();const renamed=await packs(page);await dialog.getByRole('button',{name:'删除',exact:true}).click();await shot(page,'pack-delete-390');await dialog.getByRole('button',{name:'取消',exact:true}).click();expect(await packs(page)).toEqual(renamed);
  70 |  await dialog.getByRole('button',{name:'套用开局包',exact:true}).click();await shot(page,'pack-apply-390');const before=await draft(page);await dialog.getByRole('button',{name:'取消',exact:true}).click();expect(await draft(page)).toEqual(before);await dialog.getByRole('button',{name:'套用开局包',exact:true}).click();await dialog.getByRole('button',{name:'确认替换并套用'}).click();const applied=await draft(page);expect(applied.saveId).not.toBe(original.saveId);expect(applied.skills).toBe(original.skills);expect(applied.skillsSource).toBe('manual');expect(applied.worldClock).toBe(original.worldClock);expect(await stores(page)).toEqual([]);
  71 |  await page.getByLabel('开局偏好（可选）').fill('2008年冬季');await page.getByRole('button',{name:'保存为开局包'}).click();dialog=page.getByRole('dialog');await dialog.getByRole('radio',{name:/覆盖：/}).click();await dialog.getByRole('button',{name:'保存开局包',exact:true}).click();await shot(page,'pack-overwrite-390');expect(await packs(page)).toEqual(renamed);await dialog.getByRole('button',{name:'确认覆盖'}).click();const updated=Object.values(await packs(page)) as string[];expect(JSON.parse(updated[0]).settings.openingPreference).toBe('2008年冬季');expect(JSON.parse(updated[0]).settings.saveId).toBeUndefined();await page.getByRole('navigation',{name:'角色创建步骤'}).getByRole('button',{name:'基本信息',exact:true}).click();await page.getByRole('button',{name:'我的开局包'}).click();await page.getByRole('dialog').getByRole('radio').check();await page.getByRole('button',{name:'删除',exact:true}).click();await page.getByRole('button',{name:'确认删除',exact:true}).click();expect(await packs(page)).toEqual({});
  72 | });
  73 | test('#125 车票首页与第四批创角、公告手动入口及真实草稿恢复衔接',async({page})=>{
  74 |  await mute(page);await page.goto('/');await expect(page.locator('.mobile-home')).toBeVisible();await page.locator('.mh-primary').click();await expect(page.getByLabel('姓名',{exact:true})).toBeVisible();await page.getByLabel('姓名',{exact:true}).fill('车票草稿旅人');await page.getByRole('button',{name:'‹ 首页',exact:true}).click();await expect(page.locator('.mh-draft')).toContainText('尚未完成');await page.getByRole('button',{name:'王朝公告',exact:true}).click();const dialog=page.getByRole('dialog',{name:announcement.title,exact:true});await expect(dialog.locator('.notice-steps')).toHaveCount(0);await page.keyboard.press('Escape');await page.locator('.mh-primary').click();await expect(page.getByLabel('姓名',{exact:true})).toHaveValue('车票草稿旅人');
  75 | });
  76 | test('开局包损坏隔离、存储失败不清空原数据和创角草稿',async({page})=>{
  77 |  await create(page,1);await page.evaluate(()=>localStorage.setItem('heijin.opening-pack.v1:broken','{'));const before=await draft(page);await page.getByRole('button',{name:'我的开局包'}).click();await expect(page.getByRole('dialog')).toContainText('1 份开局包无法读取');await page.keyboard.press('Escape');expect(await draft(page)).toEqual(before);await page.getByRole('navigation',{name:'角色创建步骤'}).getByRole('button',{name:'确认与开局',exact:true}).click();await page.getByRole('button',{name:'保存为开局包'}).click();await page.getByLabel('开局包名称').fill('失败测试');await page.evaluate(()=>{const original=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key.startsWith('heijin.opening-pack.v1:'))throw new DOMException('full','QuotaExceededError');return original.call(this,key,value);};});await page.getByRole('button',{name:'保存开局包',exact:true}).click();await expect(page.getByRole('dialog').getByRole('alert')).toContainText('原有开局包未被清空');expect(await packs(page)).toEqual({'heijin.opening-pack.v1:broken':'{'});
  78 | });
  79 | for(const [width,height] of [[375,667],[390,844],[430,932],[392,640],[392,420]])test(`短视口 ${width}×${height} 仅正文滚动，底栏与输入可达`,async({page})=>{
  80 |  await page.setViewportSize({width,height});await create(page,1);await expect(page.locator('.creation-mini-ticket')).toBeInViewport({ratio:1});await expect(page.locator('.wizard-footer')).toBeInViewport({ratio:1});await page.getByLabel('性格',{exact:true}).fill('长性格'.repeat(100));await expect(page.getByLabel('性格',{exact:true})).toBeInViewport();await expect(page.locator('.wizard-footer')).toBeInViewport({ratio:1});await shot(page,`creation-${width}x${height}`);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  81 |  await page.goto('/');await page.getByRole('button',{name:'游玩须知与免责声明',exact:true}).click();await expect(doc(page)).toBeVisible();await doc(page).getByLabel('免责声明内容').evaluate(el=>el.scrollTop=el.scrollHeight);await expect(doc(page).getByRole('checkbox')).toBeInViewport();await expect(doc(page).getByRole('button',{name:'关闭免责声明'})).toBeInViewport();await shot(page,`notice-${width}x${height}`);
  82 | });
  83 | 
```
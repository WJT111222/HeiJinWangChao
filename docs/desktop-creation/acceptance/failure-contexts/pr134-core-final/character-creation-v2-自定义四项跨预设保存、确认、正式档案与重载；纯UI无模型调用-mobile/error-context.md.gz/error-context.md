# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: character-creation-v2.spec.ts >> 自定义四项跨预设保存、确认、正式档案与重载；纯UI无模型调用
- Location: e2e/character-creation-v2.spec.ts:83:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '人物档案', exact: true })

```

# Page snapshot

```yaml
- generic [ref=f2e1]:
  - banner:
    - button "打开游戏菜单" [ref=f2e2] [cursor=pointer]: ☰
  - main [ref=f2e3]:
    - generic "城市与当前场景" [ref=f2e4]:
      - button "此时此地与主角状态" [ref=f2e5] [cursor=pointer]:
        - generic [aria-hidden] [ref=f2e6]: 渝
        - generic [ref=f2e7]:
          - generic [ref=f2e8]: 重庆
          - generic [ref=f2e9]: 重庆
        - time [ref=f2e10]: "--:--"
        - generic "天气：天气待确认" [ref=f2e11]: —
      - generic [ref=f2e12]: 重庆，开局时间待确认 --:--，天气：天气待确认
    - region "剧情与行动" [ref=f2e13]:
      - generic "正文阅读区域" [ref=f2e14]:
        - generic [ref=f2e15]:
          - generic [ref=f2e16]: THE STORY
          - generic [ref=f2e17]: 等待开局
        - generic [ref=f2e18]:
          - generic [aria-hidden] [ref=f2e19]: 序
          - paragraph [ref=f2e20]: A CITY. A TURNING POINT.
          - heading "故事，尚未落笔。" [level=1] [ref=f2e21]
          - paragraph [ref=f2e22]: 你的资料已保存。配置 AI 渠道后，即可生成这座城市中的第一幕。
        - paragraph [ref=f2e23]: 行动建议将在正文生成后显示。
      - generic [ref=f2e24]:
        - region "三阶段工作流" [ref=f2e26]:
          - button "三阶段工作流详情" [active] [ref=f2e29] [cursor=pointer]:
            - status [ref=f2e34]:
              - generic [ref=f2e35]: 三阶段 ·
              - text: 等待开始
            - generic [ref=f2e36]: 详情 ›
        - generic [ref=f2e37]:
          - button "回合操作" [ref=f2e39] [cursor=pointer]: ⋯
          - generic [ref=f2e40]: 你的行动
          - textbox "你的行动" [ref=f2e41]:
            - /placeholder: 填写你的行动
          - button "发送" [disabled] [ref=f2e43]
    - navigation "底部导航" [ref=f2e44]:
      - button "故事" [ref=f2e45] [cursor=pointer]:
        - generic [aria-hidden] [ref=f2e46]: 文
        - text: 故事
      - button "人物" [ref=f2e47] [cursor=pointer]:
        - generic [aria-hidden] [ref=f2e48]: 我
        - text: 人物
      - button "世界资料" [ref=f2e49] [cursor=pointer]:
        - generic [aria-hidden] [ref=f2e50]: 世
        - text: 世界资料
      - button "设置" [ref=f2e51] [cursor=pointer]:
        - generic [aria-hidden] [ref=f2e52]: 设
        - text: 设置
```

# Test source

```ts
  1  | import { expect } from '@playwright/test';
  2  | import { openLibrary } from './home';
  3  | import type { Page } from '@playwright/test';
  4  | 
  5  | // 原有高级工作流/资料测试显式打开折叠区，继续验证原操作；默认折叠由独立布局测试覆盖。
  6  | export async function openGameTools(page: Page, entering = false) {
  7  |   if (entering) await expect.poll(() => new URL(page.url()).hash.startsWith('#game/')).toBe(true);
  8  |   if (!new URL(page.url()).hash.startsWith('#game/')) return;
  9  |   await expect(page.locator('.game-layout')).toBeVisible();
  10 |   await closeWorldArchive(page);
  11 |   await openWorkflow(page);
  12 | }
  13 | 
  14 | // 操作高级控件前显式展开；不调用生成/恢复，也不修改业务状态。
  15 | export async function openWorkflow(page: Page) {
  16 |   const disclosure = page.locator('.workflow-disclosure');
  17 |   await expect(disclosure).toBeAttached();
  18 |   if (!(await disclosure.evaluate(element => element.hasAttribute('open'))))
  19 |     await workflowTrigger(page).click();
  20 | }
  21 | 
  22 | // 两端复用阶段页签；手机在 #122 原生模态 Dialog 中提供两层导航。
  23 | const desktopWorkflow = (page: Page) => (page.viewportSize()?.width ?? 0) > 900;
  24 | const stageIndex = { story: 0, variables: 1, world: 2 } as const;
  25 | export type WorkflowStage = keyof typeof stageIndex;
  26 | export async function openStageSwitches(page: Page) {
  27 |   await openWorkflow(page);
  28 |   const back=page.getByRole('button',{name:'返回三阶段列表',exact:true});
  29 |   if(await back.isVisible())await back.click();
  30 | }
  31 | async function openRailView(page:Page,name:'运行诊断'|'已绑定输入') {
  32 |   await openStageSwitches(page);await page.locator('.wf-aux .wf-ri').filter({hasText:name}).click();
  33 | }
  34 | export async function openWorkflowDiagnostics(page:Page){await openRailView(page,'运行诊断');}
  35 | export async function openBoundInput(page:Page){await openRailView(page,'已绑定输入');}
  36 | export async function openWorkflowStage(page:Page,stage:WorkflowStage){
  37 |   await openStageSwitches(page);await page.locator('.wf-rail .workflow-stages>li').nth(stageIndex[stage]).locator('.wf-ri').click();
  38 | }
  39 | export async function openStageTab(page:Page,stage:WorkflowStage,tab:'概览'|'候选'|'模型原文'|'叙事规划'|'校验结果'){
  40 |   await openWorkflowStage(page,stage);await page.locator('.wf-stage').getByRole('tab',{name:new RegExp(`^${tab}`)}).click();
  41 | }
  42 | export async function openStageRaw(page:Page,stage:WorkflowStage){await openStageTab(page,stage,'模型原文');return page.locator('.stage-responses');}
  43 | export async function openStageCandidates(page:Page,stage:'variables'|'world'){await openStageTab(page,stage,'候选');return page.locator('.wf-stage');}
  44 | export async function openCandidateRaw(page:Page,stage:'variables'|'world'){await openStageTab(page,stage,'模型原文');return page.getByRole('region',{name:'模型原文',exact:true});}
  45 | export async function openStoryInspection(page:Page){await openStageTab(page,'story','叙事规划');return page.locator('.story-inspection');}
  46 | // Candidate is a tab inside the workflow now; return to its first level on phones.
  47 | export async function closeStageCandidates(page:Page){if(!desktopWorkflow(page))await openStageSwitches(page);}
  48 | export async function closeWorkflowSheet(page:Page){if(!desktopWorkflow(page)&&await page.getByRole('dialog',{name:'三阶段工作流',exact:true}).isVisible())await page.keyboard.press('Escape');}
  49 | 
  50 | // Responsive navigation opens the existing directory/profile dialogs, without touching save state.
  51 | export async function openWorldArchive(page: Page) {
  52 |   await closeWorkflowSheet(page);
  53 |   const opener = page.getByRole('navigation', { name: '底部导航' }).getByRole('button', { name: '世界资料', exact: true });
  54 |   if (await opener.isVisible() && !await page.getByRole('dialog', { name: '世界资料', exact: true }).isVisible()) await opener.click();
  55 | }
  56 | export async function openProfile(page: Page) {
  57 |   await closeWorkflowSheet(page);
  58 |   const compact = page.getByRole('button', { name: '展开人物状态', exact: true });
  59 |   if (await compact.isVisible()) await compact.click();
> 60 |   else await page.getByRole('button', { name: '人物档案', exact: true }).click();
     |                                                                      ^ Error: locator.click: Test timeout of 30000ms exceeded.
  61 | }
  62 | export async function goHome(page: Page) {
  63 |   await closeWorkflowSheet(page);
  64 |   const directory = page.getByRole('dialog', { name: '世界资料', exact: true });
  65 |   if (await directory.isVisible()) await page.keyboard.press('Escape');
  66 |   const desktopHome = page.getByRole('navigation', { name: '系统操作' }).getByRole('button', { name: '返回首页', exact: true });
  67 |   if (await desktopHome.isVisible()) { await desktopHome.click(); await openLibrary(page); return; }
  68 |   const menu = page.getByRole('button', { name: '打开游戏菜单', exact: true });
  69 |   if (await menu.isVisible()) await menu.click();
  70 |   await page.getByRole('button', { name: '游戏首页', exact: true }).click(); await openLibrary(page);
  71 | }
  72 | 
  73 | async function closeWorldArchive(page: Page) {
  74 |   const directory = page.getByRole('dialog', { name: '世界资料', exact: true });
  75 |   if (await directory.isVisible()) await directory.getByRole('button', { name: '关闭资料界面', exact: true }).click();
  76 | }
  77 | export async function openSettings(page: Page) {
  78 |   await closeWorkflowSheet(page);
  79 |   await closeWorldArchive(page);
  80 |   await page.getByRole('button', { name: '设置', exact: true }).click();
  81 | }
  82 | 
  83 | export const workflowTrigger = (page: Page) => page.locator('details.workflow-disclosure > summary, .workflow-summary > .workflow-toggle');
  84 | export const workflowSummary = (page: Page) => page.locator('details.workflow-disclosure > summary, .workflow-summary');
  85 | 
```
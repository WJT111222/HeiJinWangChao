# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: character-creation-v2.spec.ts >> 五类各六职业，点击呈现完整介绍、独立技能与长期影响
- Location: e2e/character-creation-v2.spec.ts:57:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('region', { name: '职业档案', exact: true })
Expected substring: "经营经历使人物较熟悉市场变化、利益交换和经营风险，也可能在相关行业积累经验与联系。商业合作、企业竞争和经营纠纷更容易进入生活，作息往往受到客户与项目影响。但财富、公司规模、股权及实际人脉必须依正式状态确定，职业名称不能直接创造企业资产或支配他人的权限。"
Error: element(s) not found

Call log:
  - Expect "toContainText" getByRole('region', { name: '职业档案', exact: true }) with timeout 5000ms
  - waiting for getByRole('region', { name: '职业档案', exact: true })
  - Test timeout of 30000ms exceeded.

```

```yaml
- main:
  - button "‹ 首页"
  - text: NEW LIFE 空白车票
  - button "展开完整车票预览": FROM 林舟 TO 重庆 30 岁 · 女性 · 企业经营者 STATION 05
  - navigation "角色创建步骤":
    - button "基本信息": ✓ 基本
    - button "职业与能力": ✓ 职业
    - button "城市与背景": ✓ 城市
    - button "初始同伴": ✓ 同伴
    - button "确认与开局": 确认
  - button "保存为开局包"
  - paragraph: STEP 05 / 05
  - heading "确认与开局" [level=2]
  - text: 填写内容自动保留
  - article "人生车票":
    - text: 重庆 29°33′N NEW LIFE FROM 林舟 TO 重庆
    - term: 年龄
    - definition: "30"
    - term: 性别
    - definition: 女性
    - term: 职业
    - definition: 企业经营者
    - text: 确认并创建存档 ↓ 按住票根往下撕 · 可能产生第三方 API 费用
  - group:
    - text: 01 人物资料 ›
    - button "修改基本信息"
    - term: 姓名
    - definition: 林舟
    - term: 年龄
    - definition: "30"
    - term: 性别
    - definition: 女性
    - term: 外貌
    - definition: 未填写
    - term: 性格
    - definition: 未填写
    - term: 外貌模板
    - definition: 自由选择
    - term: 性格模板
    - definition: 自由选择
  - group: 02 职业与起点 ›
  - group: 03 初始同伴 ›
  - group: 04 开局准备 ›
  - text: 开局偏好（可选）
  - textbox "开局偏好（可选）":
    - /placeholder: 对故事起点的期待，将随开局草稿保存。
  - paragraph: 确认后创建存档并自动开始开局，可能产生第三方 API 费用。按已启用的阶段顺序生成候选，不会自动结算；未配置 AI 时会安全停止，设置后由你主动继续。
  - button "上一步"
  - text: 可能产生第三方 API 费用
  - button "确认并创建存档"
```

# Test source

```ts
  1   | import { expect, test } from './helpers/test';
  2   | import type { Page } from '@playwright/test';
  3   | import { appearanceTemplates, personalityTemplates } from '../src/ui/creation/personTemplates';
  4   | import professions from '../src/ui/creation/professions.json' with { type: 'json' };
  5   | const professionCategories = [...new Set(professions.map(job => job.category))];
  6   | import { chooseCustomProfession, chooseProfession, mobileCreation, showPersonalSkills } from './helpers/creation';
  7   | import { openGameTools, openProfile } from './helpers/gameLayout';
  8   | 
  9   | async function begin(page: Page) {
  10  |   await page.goto('/'); await page.getByRole('button', { name: /开始新游戏/ }).click();
  11  |   await page.getByLabel('姓名', { exact: true }).fill('林舟');
  12  |   await page.getByLabel('年龄', { exact: true }).fill('30');
  13  |   await page.getByRole('radio', { name: '女性', exact: true }).check();
  14  | }
  15  | async function choose(page: Page, label: string, value: string) {
  16  |   await page.getByRole('radiogroup', { name: label, exact: true }).getByRole('radio', { name: value, exact: true }).click();
  17  | }
  18  | const template = (page: Page, label: string, value: string) =>
  19  |   page.getByRole('radiogroup', { name: label, exact: true }).getByRole('radio', { name: value, exact: true });
  20  | async function confirm(page: Page) {
  21  |   await page.getByRole('button', { name: /下一步/ }).click();
  22  |   await page.getByRole('button', { name: '跳过背景，继续' }).click();
  23  |   await page.getByRole('button', { name: '跳过同伴，继续' }).click();
  24  | }
  25  | async function noOverflow(page: Page) {
  26  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  27  | }
  28  | 
  29  | test('基本信息模板独立、可编辑、往返与刷新保留；键盘选择', async ({ page }, info) => {
  30  |   await begin(page);
  31  |   await expect(page.getByRole('group', { name: '性别', exact: true }).getByRole('radio')).toHaveCount(2);
  32  |   await expect(template(page, '外貌模板', '自由选择')).toHaveAttribute('aria-checked', 'true');
  33  |   await expect(template(page, '性格模板', '自由选择')).toHaveAttribute('aria-checked', 'true');
  34  |   for (const item of appearanceTemplates) {
  35  |     await choose(page, '外貌模板', item.name); await expect(page.getByLabel('外貌', { exact: true })).toHaveValue(item.description);
  36  |     await expect(page.getByLabel('性格', { exact: true })).toHaveValue('');
  37  |   }
  38  |   for (const item of personalityTemplates) {
  39  |     await choose(page, '性格模板', item.name); await expect(page.getByLabel('性格', { exact: true })).toHaveValue(item.description);
  40  |     await expect(page.getByLabel('外貌', { exact: true })).toHaveValue(appearanceTemplates.at(-1)!.description);
  41  |   }
  42  |   await template(page, '外貌模板', appearanceTemplates.at(-1)!.name).focus();
  43  |   await page.keyboard.press('Home');
  44  |   await expect(template(page, '外貌模板', '自由选择')).toHaveAttribute('aria-checked', 'true');
  45  |   await expect(template(page, '外貌模板', '自由选择')).toBeFocused();
  46  |   const appearance = appearanceTemplates[0].description + '\n手背有淡淡旧痕。';
  47  |   await page.getByLabel('外貌', { exact: true }).fill(appearance);
  48  |   await page.getByLabel('性格', { exact: true }).fill('平日谨慎，今天愿意主动冒险。');
  49  |   await page.getByRole('button', { name: /下一步/ }).click(); await page.getByRole('button', { name: '上一步', exact: true }).click();
  50  |   await page.reload(); await expect(page.getByLabel('外貌', { exact: true })).toHaveValue(appearance);
  51  |   await expect(page.getByLabel('性格', { exact: true })).toHaveValue('平日谨慎，今天愿意主动冒险。');
  52  |   await expect(page.getByRole('radio', { name: '女性', exact: true })).toBeChecked();
  53  |   await noOverflow(page);
  54  |   await page.screenshot({ path: `docs/screenshots/character-creation-v2/${info.project.name}-basics.png`, fullPage: true });
  55  | });
  56  | 
  57  | test('五类各六职业，点击呈现完整介绍、独立技能与长期影响', async ({ page }, info) => {
  58  |   await begin(page); await page.getByRole('button', { name: /下一步/ }).click();
  59  |   if (mobileCreation(page)) await expect(page.getByRole('button', { name: '✎ 自由选择', exact: true })).toHaveAttribute('aria-pressed', 'true');
  60  |   else await expect(page.getByRole('radio', { name: '自由选择', exact: true })).toBeChecked();
  61  |   for (const category of professionCategories) {
  62  |     await page.getByRole('button', { name: category, exact: true }).click();
  63  |     await expect(page.getByRole('radio')).toHaveCount(mobileCreation(page) ? 6 : 7);
  64  |     for (const job of professions.filter(job => job.category === category)) {
  65  |       await chooseProfession(page, job.name);
  66  |       const profile = page.getByRole('region', { name: '职业档案', exact: true });
  67  |       await expect(profile).toContainText(job.description); await expect(profile).toContainText(job.longTermImpact);
  68  |       await expect(profile.locator('li')).toHaveText(job.skills);
  69  |       await showPersonalSkills(page);
  70  |       await expect(page.getByLabel('个人技能与专长')).toHaveValue(job.skills.join('\n'));
  71  |     }
  72  |   }
  73  |   await page.getByRole('button', { name: '企业与商业', exact: true }).click();
  74  |   await chooseProfession(page, '企业经营者');
  75  |   await noOverflow(page);
  76  |   await page.screenshot({ path: `docs/screenshots/character-creation-v2/${info.project.name}-professions.png`, fullPage: true });
  77  |   await confirm(page);
  78  |   const job = professions.find(job => job.name === '企业经营者')!;
> 79  |   await expect(page.getByRole('region', { name: '职业档案', exact: true })).toContainText(job.longTermImpact);
      |                                                                         ^ Error: expect(locator).toContainText(expected) failed
  80  | });
  81  | 
  82  | test('自定义四项跨预设保存、确认、正式档案与重载；纯UI无模型调用', async ({ page }, info) => {
  83  |   const requests: string[] = [];
  84  |   await page.route('https://**/*', async route => { requests.push(route.request().url()); await route.abort(); });
  85  |   await begin(page); await page.getByRole('button', { name: /下一步/ }).click();
  86  |   const custom = { name: '古籍修复师', description: '在社区工作室修复旧书。\n日常记录纸张、装帧与修补过程。', skills: '纸张辨识\n修补\n配色\n装帧\n记录\n沟通', impact: '与图书馆和收藏者合作，保留耐心观察的习惯。\n仍愿意尝试全新的生活。' };
  87  |   await page.getByLabel('职业名称', { exact: true }).fill(custom.name);
  88  |   await page.getByLabel('职业介绍', { exact: true }).fill(custom.description);
  89  |   await page.getByLabel('内置职业技能', { exact: true }).fill(custom.skills);
  90  |   await page.getByLabel('长期影响', { exact: true }).fill(custom.impact);
  91  |   await page.getByRole('button', { name: '技术与生产', exact: true }).click();
  92  |   await chooseProfession(page, '程序员'); await page.reload();
  93  |   await chooseCustomProfession(page);
  94  |   await expect(page.getByLabel('职业名称', { exact: true })).toHaveValue(custom.name);
  95  |   await expect(page.getByLabel('职业介绍', { exact: true })).toHaveValue(custom.description);
  96  |   await expect(page.getByLabel('内置职业技能', { exact: true })).toHaveValue(custom.skills);
  97  |   await expect(page.getByLabel('长期影响', { exact: true })).toHaveValue(custom.impact);
  98  |   await noOverflow(page);
  99  |   await page.screenshot({ path: `docs/screenshots/character-creation-v2/${info.project.name}-custom.png`, fullPage: true });
  100 |   await confirm(page);
  101 |   const profile = page.getByRole('region', { name: '职业档案', exact: true });
  102 |   await expect(profile).toContainText(custom.description); await expect(profile).toContainText(custom.impact);
  103 |   await expect(profile.locator('li')).toHaveText(custom.skills.split('\n'));
  104 |   await page.getByRole('button', { name: '确认并创建存档', exact: true }).click();
  105 |   await expect(page.locator('.game-layout')).toBeVisible();
  106 |   await page.reload(); await openGameTools(page);
  107 |   await openProfile(page);
  108 |   const dialog = page.getByRole('dialog', { name: '人物档案', exact: true });
  109 |   await expect(dialog).toContainText(custom.name); await expect(dialog).toContainText(custom.description);
  110 |   await expect(dialog).toContainText(custom.impact); await expect(dialog.locator('.skill-tags li')).toHaveText(custom.skills.split('\n'));
  111 |   await noOverflow(page); await page.getByRole('button', { name: '关闭资料界面' }).click();
  112 |   const saved = await page.evaluate(async () => {
  113 |     const path = '/src/services/storage/saveRepository.ts', { SaveRepository } = await import(path), repo = await SaveRepository.open();
  114 |     try { return await repo.load(location.hash.slice(6)); } finally { repo.close(); }
  115 |   });
  116 |   expect(saved.protagonist).toMatchObject({ profession: custom.name, professionDescription: custom.description, professionLongTermImpact: custom.impact, skills: custom.skills.split('\n'), gender: '女性' });
  117 |   expect(saved.economy.cash).toBeNull(); expect(saved.items).toEqual({}); expect(saved.organizations).toEqual({});
  118 |   expect(requests).toEqual([]);
  119 | });
  120 | 
```
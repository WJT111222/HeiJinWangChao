# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: opening-packs.spec.ts >> 完整五步保存、再次套用直达第五步、编辑刷新与正式建档隔离
- Location: e2e/opening-packs.spec.ts:32:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '返回首页', exact: true })

```

# Page snapshot

```yaml
- main [ref=e4]:
  - generic [ref=e5]:
    - button "‹ 首页" [ref=e6] [cursor=pointer]
    - generic [ref=e7]:
      - generic [ref=e8]: NEW LIFE
      - text: 空白车票
  - button "展开完整车票预览" [ref=e9] [cursor=pointer]:
    - generic [ref=e11]:
      - generic [ref=e12]:
        - generic [ref=e13]:
          - generic [ref=e14]: FROM
          - generic "林岚" [ref=e15]
        - generic [ref=e17]:
          - generic [ref=e18]: TO
          - generic [ref=e19]: 上海
      - generic "29 · 女性 · 程序员" [ref=e20]: 29 岁 · 女性 · 程序员 · 同伴 许宁
    - generic [ref=e21]:
      - generic [ref=e22]: STATION
      - generic [ref=e23]: "05"
    - generic [aria-hidden] [ref=e26]: 展开 ›
  - navigation "角色创建步骤" [ref=e27]:
    - button "基本信息" [ref=e28] [cursor=pointer]:
      - generic [ref=e29]: ✓
      - text: 基本
    - button "职业与能力" [ref=e30] [cursor=pointer]:
      - generic [ref=e31]: ✓
      - text: 职业
    - button "城市与背景" [ref=e32] [cursor=pointer]:
      - generic [ref=e33]: ✓
      - text: 城市
    - button "初始同伴" [ref=e34] [cursor=pointer]:
      - generic [ref=e35]: ✓
      - text: 同伴
    - button "确认与开局" [ref=e36] [cursor=pointer]: 确认
  - generic [ref=e38]:
    - button "保存为开局包" [active] [ref=e39] [cursor=pointer]
    - status [ref=e40]: 开局包已保存
  - generic [ref=e41]:
    - generic [ref=e42]:
      - generic [ref=e43]:
        - generic [ref=e44]:
          - paragraph [ref=e45]: STEP 05 / 05
          - heading "确认与开局" [level=2] [ref=e46]
        - generic [ref=e47]: 填写内容自动保留
      - article "人生车票" [ref=e48]:
        - generic [ref=e49]:
          - generic [ref=e50]:
            - generic [ref=e51]: 上海
            - generic [ref=e52]: 31°14′N
            - generic [ref=e53]: NEW LIFE
          - generic [ref=e54]:
            - generic [ref=e55]:
              - generic [ref=e56]: FROM
              - text: 林岚
            - generic [aria-hidden] [ref=e57]: 单程
            - generic [ref=e58]:
              - generic [ref=e59]: TO
              - text: 上海
          - generic [ref=e60]:
            - generic [ref=e61]:
              - term [ref=e62]: 年龄
              - definition [ref=e63]: "29"
            - generic [ref=e64]:
              - term [ref=e65]: 性别
              - definition [ref=e66]: 女性
            - generic [ref=e67]:
              - term [ref=e68]: 职业
              - definition [ref=e69]: 程序员
          - generic [aria-hidden] [ref=e70]:
            - generic [ref=e87]: 31°14′N · 121°29′E
            - generic [ref=e88]: 外滩 · 霓虹 · 江风
            - generic [ref=e89]:
              - text: 待开局
              - generic [ref=e90]: BOARDING
        - generic [ref=e93]:
          - text: 确认并创建存档
          - generic [ref=e94]: ↓ 按住票根往下撕 · 可能产生第三方 API 费用
      - generic [ref=e96]:
        - group [ref=e97]:
          - generic "01 人物资料 ›" [ref=e98] [cursor=pointer]:
            - generic [ref=e99]: "01"
            - generic [ref=e100]: 人物资料
            - text: ›
          - button "修改基本信息" [ref=e102] [cursor=pointer]
          - generic [ref=e103]:
            - generic [ref=e104]:
              - term [ref=e105]: 姓名
              - definition [ref=e106]: 林岚
            - generic [ref=e107]:
              - term [ref=e108]: 年龄
              - definition [ref=e109]: "29"
            - generic [ref=e110]:
              - term [ref=e111]: 性别
              - definition [ref=e112]: 女性
            - generic [ref=e113]:
              - term [ref=e114]: 外貌
              - definition [ref=e115]: 衣着素净 手上有淡淡的墨痕。
            - generic [ref=e116]:
              - term [ref=e117]: 性格
              - definition [ref=e118]: 认真 偶尔冲动
            - generic [ref=e119]:
              - term [ref=e120]: 外貌模板
              - definition [ref=e121]: 自由选择
            - generic [ref=e122]:
              - term [ref=e123]: 性格模板
              - definition [ref=e124]: 自由选择
        - group [ref=e125]:
          - generic "02 职业与起点 ›" [ref=e126] [cursor=pointer]:
            - generic [ref=e127]: "02"
            - generic [ref=e128]: 职业与起点
            - text: ›
        - group [ref=e129]:
          - generic "03 初始同伴 ›" [ref=e130] [cursor=pointer]:
            - generic [ref=e131]: "03"
            - generic [ref=e132]: 初始同伴
            - text: ›
        - group [ref=e133]:
          - generic "04 开局准备 ›" [ref=e134] [cursor=pointer]:
            - generic [ref=e135]: "04"
            - generic [ref=e136]: 开局准备
            - text: ›
      - generic [ref=e137]:
        - text: 开局偏好（可选）
        - textbox "开局偏好（可选）" [ref=e138]:
          - /placeholder: 对故事起点的期待，将随开局草稿保存。
          - text: 2008年秋天 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 从普通的一天开始，不改写已有家庭设定。 偏好末行
      - paragraph [ref=e139]: 确认后创建存档并自动开始开局，可能产生第三方 API 费用。按已启用的阶段顺序生成候选，不会自动结算；未配置 AI 时会安全停止，设置后由你主动继续。
    - generic [ref=e140]:
      - button "上一步" [ref=e141] [cursor=pointer]
      - generic [ref=e142]: 可能产生第三方 API 费用
      - button "确认并创建存档" [ref=e143] [cursor=pointer]
```

# Test source

```ts
  1   | import { test, expect } from './helpers/test';
  2   | import type { Page } from '@playwright/test';
  3   | import type { Creation } from '../src/ui/creation/model';
  4   | import type { OpeningPack } from '../src/ui/creation/openingPacks';
  5   | import { chooseCustomProfession, chooseProfession, mobileCreation, showPersonalSkills, showCreationReview } from './helpers/creation';
  6   | import { goHome } from './helpers/gameLayout';
  7   | 
  8   | const draft = (page: Page) => page.evaluate(() => JSON.parse(localStorage.getItem('heijin.creation.v1')!) as Creation);
  9   | const packs = (page: Page) => page.evaluate(() => Object.keys(localStorage)
  10  |   .filter(key => key.startsWith('heijin.opening-pack.v1:')).map(key => JSON.parse(localStorage.getItem(key)!) as OpeningPack));
  11  | async function saves(page: Page) {
  12  |   return page.evaluate(async () => {
  13  |     const path = '/src/services/storage/saveRepository.ts';
  14  |     const { SaveRepository } = await import(path), repo = await SaveRepository.open();
  15  |     try { return await repo.list(); } finally { repo.close(); }
  16  |   });
  17  | }
  18  | async function seeded(page: Page) {
  19  |   await page.goto('/');
  20  |   await page.evaluate(async () => {
  21  |     const modelPath = '/src/ui/creation/model.ts', packPath = '/src/ui/creation/openingPacks.ts';
  22  |     const { newCreation } = await import(modelPath), { OpeningPackStore } = await import(packPath);
  23  |     const form = newCreation();
  24  |     Object.assign(form, { person: { name: '林岚', age: '29', gender: '女性', appearance: '衣着素净', personality: '谨慎' },
  25  |       customProfession: '修复师', skills: '修补\n记录', skillsSource: 'manual', background: '原始背景', openingPreference: '2008年秋天' });
  26  |     const store = new OpeningPackStore(localStorage); store.save('城市生活', form); store.save('城市生活', form);
  27  |     localStorage.setItem('heijin.creation.v1', JSON.stringify(form));
  28  |   });
  29  |   await page.reload(); await page.getByRole('button', { name: /开始新游戏/ }).click();
  30  | }
  31  | 
  32  | test('完整五步保存、再次套用直达第五步、编辑刷新与正式建档隔离', async ({ page }, info) => {
  33  |   const requests: string[] = [];
  34  |   await page.route('https://**/*', route => { requests.push(route.request().url()); return route.abort(); });
  35  |   await page.goto('/'); await page.getByRole('button', { name: /开始新游戏/ }).click();
  36  |   await page.getByLabel('姓名', { exact: true }).fill('林岚');
  37  |   await page.getByLabel('年龄', { exact: true }).fill('29');
  38  |   await page.getByRole('radio', { name: '女性', exact: true }).check();
  39  |   await page.getByLabel('外貌', { exact: true }).fill('  衣着素净\n手上有淡淡的墨痕。  ');
  40  |   await page.getByLabel('性格', { exact: true }).fill('认真\n偶尔冲动');
  41  |   await page.getByRole('button', { name: /下一步/ }).click();
  42  |   await page.getByLabel('职业名称', { exact: true }).fill('旧书修复师');
  43  |   await page.getByLabel('职业介绍', { exact: true }).fill('修复纸本\n保存社区档案');
  44  |   await page.getByLabel('内置职业技能', { exact: true }).fill('修复\n\n  手写记录  ');
  45  |   await page.getByLabel('长期影响', { exact: true }).fill('长期与社区合作\n保持独立');
  46  |   await page.getByRole('button', { name: '技术与生产', exact: true }).click();
  47  |   await chooseProfession(page, '程序员');
  48  |   await showPersonalSkills(page);
  49  |   await page.getByLabel('个人技能与专长').fill('手工编程\n记录工作');
  50  |   await page.getByRole('button', { name: /下一步/ }).click();
  51  |   await page.getByRole('radio', { name: /上海/ }).check();
  52  |   const background = '  成长经历\n' + '家庭、求学与工作经历。\n'.repeat(100) + '背景末行  ';
  53  |   await page.getByLabel('人物背景（可选）').fill(background);
  54  |   await page.getByRole('button', { name: /下一步/ }).click();
  55  |   await page.getByRole('checkbox', { name: '创建一名初始同伴' }).check();
  56  |   for (const [label, value] of Object.entries({ 同伴姓名: '许宁', '同伴年龄（可选）': '28', 同伴身份: '同事',
  57  |     与主角的关系: '相识多年的朋友', 同伴外貌: '短发', 同伴性格: '直率', '同伴能力（一行一项）': '排版\n沟通', 同伴个人经历: '少年在外地读书\n后来回城' })) {
  58  |     await page.getByLabel(label, { exact: true }).fill(value);
  59  |   }
  60  |   await page.getByRole('button', { name: /下一步/ }).click();
  61  |   const preference = '  2008年秋天\n' + '从普通的一天开始，不改写已有家庭设定。\n'.repeat(100) + '偏好末行  ';
  62  |   await page.getByLabel('开局偏好（可选）').fill(preference);
  63  |   const original = await draft(page);
  64  |   await page.getByRole('button', { name: '保存为开局包', exact: true }).click();
  65  |   await page.getByLabel('开局包名称').fill('上海普通人生');
  66  |   await page.getByRole('button', { name: '保存开局包', exact: true }).click();
  67  |   await expect(page.getByRole('status')).toHaveText('开局包已保存');
  68  |   expect(await saves(page)).toEqual([]); expect((await draft(page)).step).toBe(5);
  69  |   const originalPacks = await packs(page);
> 70  |   await page.getByRole('button', { name: '返回首页', exact: true }).click();
      |                                                                 ^ Error: locator.click: Test timeout of 30000ms exceeded.
  71  |   await page.getByRole('button', { name: /开始新游戏/ }).click();
  72  |   await page.getByRole('navigation', { name: '角色创建步骤' }).getByRole('button', { name: /基本信息/ }).click();
  73  |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  74  |   await page.getByRole('radio', { name: /上海普通人生/ }).check();
  75  |   await page.screenshot({ path: `docs/opening-packs/screenshots/${info.project.name}-select.png`, fullPage: true });
  76  |   await page.getByRole('button', { name: '套用开局包', exact: true }).click();
  77  |   await expect(page.getByRole('dialog')).toContainText('将替换当前创角草稿');
  78  |   await page.getByRole('button', { name: '取消', exact: true }).click();
  79  |   expect(await draft(page)).toMatchObject({ saveId: original.saveId, step: 1 });
  80  |   await page.getByRole('button', { name: '套用开局包', exact: true }).click();
  81  |   await page.getByRole('button', { name: '确认替换并套用' }).click();
  82  |   const applied = await draft(page);
  83  |   expect(applied).toEqual({ ...original, saveId: applied.saveId });
  84  |   expect(applied.saveId).not.toBe(original.saveId);
  85  |   await expect(page.getByRole('heading', { name: '确认与开局', exact: true })).toBeVisible();
  86  |   await expect(page.getByLabel('开局偏好（可选）')).toHaveValue(preference);
  87  |   await showCreationReview(page);
  88  |   await page.getByText('完整职业表单', { exact: true }).click();
  89  |   await expect(page.getByRole('region', { name: '保留的自定义职业' })).toContainText('旧书修复师');
  90  |   await expect(page.locator('.creation-review')).toContainText('背景末行');
  91  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  92  |   await page.screenshot({ path: `docs/opening-packs/screenshots/${info.project.name}-review.png`, fullPage: true });
  93  |   await page.evaluate(() => scrollTo(0, 0));
  94  |   await page.screenshot({ path: `docs/opening-packs/screenshots/${info.project.name}-review-viewport.png` });
  95  |   await page.getByRole('button', { name: '修改职业', exact: true }).click();
  96  |   await chooseCustomProfession(page);
  97  |   await expect(page.getByLabel('内置职业技能')).toHaveValue(original.customProfile!.skills);
  98  |   await page.getByLabel('内置职业技能').fill('新编辑技能\n修补');
  99  |   await page.getByRole('button', { name: '确认与开局', exact: false }).click();
  100 |   await page.reload();
  101 |   expect(await draft(page)).toMatchObject({ saveId: applied.saveId, step: 5, skills: '新编辑技能\n修补', background, openingPreference: preference });
  102 |   expect(await packs(page)).toEqual(originalPacks); expect(await saves(page)).toEqual([]);
  103 |   await page.getByRole('button', { name: '确认并创建存档', exact: true }).click();
  104 |   await expect(page.locator('.game-layout')).toBeVisible();
  105 |   expect(await saves(page)).toHaveLength(1);
  106 |   const saved = await page.evaluate(async id => {
  107 |     const path = '/src/services/storage/saveRepository.ts';
  108 |     const { SaveRepository } = await import(path), repo = await SaveRepository.open();
  109 |     try { return { state: await repo.load(id), draft: await repo.loadDraft(id) }; } finally { repo.close(); }
  110 |   }, applied.saveId);
  111 |   expect(saved.state.protagonist).toMatchObject({ name: original.person.name, background, skills: ['新编辑技能', '修补'] });
  112 |   expect(saved.state.npc.companion).toMatchObject({ name: '许宁', background: original.companion.background });
  113 |   expect(saved.draft.userInput).toBe(preference); expect(await packs(page)).toEqual(originalPacks);
  114 |   // After the original creation flow finishes, the next new character starts at step 1.
  115 |   await goHome(page);
  116 |   if (mobileCreation(page)) await page.getByRole('button', { name: /开始新游戏/ }).click();
  117 |   else await page.locator('.library .dossier.new button').click();
  118 |   expect((await draft(page)).step).toBe(1);
  119 |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  120 |   await page.getByRole('radio', { name: /上海普通人生/ }).check();
  121 |   await page.getByRole('button', { name: '套用开局包', exact: true }).click();
  122 |   await page.getByRole('button', { name: '确认替换并套用' }).click();
  123 |   const fresh = await draft(page);
  124 |   expect(fresh).toEqual({ ...original, saveId: fresh.saveId });
  125 |   expect(fresh.saveId).not.toBe(applied.saveId); expect(await saves(page)).toHaveLength(1);
  126 |   expect(await packs(page)).toEqual(originalPacks);
  127 |   expect(requests).toEqual([]);
  128 | });
  129 | 
  130 | test('同名包独立管理：重命名、取消删除、明确覆盖及确认删除', async ({ page }) => {
  131 |   await seeded(page); const original = await packs(page);
  132 |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  133 |   await expect(page.getByRole('dialog').getByRole('radio')).toHaveCount(2);
  134 |   const choices = page.getByRole('dialog').getByRole('radio');
  135 |   await choices.first().check(); await page.getByRole('button', { name: '重命名', exact: true }).click();
  136 |   await page.getByLabel('开局包名称').fill('重命名包'); await page.getByRole('button', { name: '确认重命名' }).click();
  137 |   await expect(page.getByRole('dialog')).toContainText('重命名包');
  138 |   await page.getByRole('button', { name: '删除', exact: true }).click();
  139 |   await page.getByRole('button', { name: '取消', exact: true }).click(); expect(await packs(page)).toHaveLength(2);
  140 |   await page.getByRole('button', { name: '关闭开局包' }).click();
  141 |   await page.getByRole('button', { name: '确认与开局', exact: false }).click();
  142 |   await page.getByLabel('开局偏好（可选）').fill('新的偏好');
  143 |   await page.getByRole('button', { name: '保存为开局包', exact: true }).click();
  144 |   if (mobileCreation(page)) await page.getByRole('radiogroup', { name: '保存方式' }).getByRole('radio', { name: '覆盖：重命名包', exact: true }).click();
  145 |   else await page.getByLabel('保存方式').selectOption(original[0].id);
  146 |   await page.getByRole('button', { name: '保存开局包', exact: true }).click();
  147 |   expect((await packs(page))[0].settings.openingPreference).toBe(original[0].settings.openingPreference);
  148 |   await page.getByRole('button', { name: '取消', exact: true }).click();
  149 |   await page.getByRole('button', { name: '保存开局包', exact: true }).click();
  150 |   await page.getByRole('button', { name: '确认覆盖' }).click();
  151 |   const updated = await packs(page);
  152 |   expect(updated[0]).toMatchObject({ id: original[0].id, name: '重命名包', settings: { openingPreference: '新的偏好' } });
  153 |   expect(updated[1]).toEqual(original[1]);
  154 |   await page.getByRole('navigation', { name: '角色创建步骤' }).getByRole('button', { name: /基本信息/ }).click();
  155 |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  156 |   await page.getByRole('radio', { name: /重命名包/ }).check();
  157 |   await page.getByRole('button', { name: '删除', exact: true }).click();
  158 |   await expect(page.getByRole('dialog')).toContainText('不可撤销');
  159 |   await page.getByRole('button', { name: '确认删除', exact: true }).click();
  160 |   await page.getByRole('button', { name: '关闭开局包' }).click(); await page.reload();
  161 |   expect(await packs(page)).toEqual([original[1]]); expect(await saves(page)).toEqual([]);
  162 | });
  163 | 
  164 | test('损坏包隔离，存储拒绝不误报成功、不丢失有效包或当前草稿', async ({ page }) => {
  165 |   await seeded(page); const before = await packs(page), original = await draft(page);
  166 |   await page.evaluate(() => localStorage.setItem('heijin.opening-pack.v1:broken', '{'));
  167 |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  168 |   await expect(page.getByRole('dialog')).toContainText('1 份开局包无法读取');
  169 |   await expect(page.getByRole('dialog').getByRole('radio')).toHaveCount(2);
  170 |   await page.getByRole('button', { name: '关闭开局包' }).click();
```
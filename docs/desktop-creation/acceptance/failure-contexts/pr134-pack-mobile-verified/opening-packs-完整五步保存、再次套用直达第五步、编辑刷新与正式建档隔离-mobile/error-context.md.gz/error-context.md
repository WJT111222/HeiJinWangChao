# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: opening-packs.spec.ts >> 完整五步保存、再次套用直达第五步、编辑刷新与正式建档隔离
- Location: e2e/opening-packs.spec.ts:32:1

# Error details

```
TypeError: Cannot read properties of null (reading 'step')
```

# Page snapshot

```yaml
- main [ref=f1e4]:
  - generic [ref=f1e5]:
    - button "‹ 首页" [ref=f1e6] [cursor=pointer]
    - generic [ref=f1e7]:
      - generic [ref=f1e8]: NEW LIFE
      - text: 空白车票
  - button "展开完整车票预览" [ref=f1e9] [cursor=pointer]:
    - generic [ref=f1e11]:
      - generic [ref=f1e12]:
        - generic [ref=f1e13]:
          - generic [ref=f1e14]: FROM
          - generic [ref=f1e15]: ？
        - generic [ref=f1e17]:
          - generic [ref=f1e18]: TO
          - generic [ref=f1e19]: ？
      - generic "· ·" [ref=f1e20]: 年龄 · 性别 · 职业
    - generic [ref=f1e21]:
      - generic [ref=f1e22]: STATION
      - generic [ref=f1e23]: "01"
    - generic [aria-hidden] [ref=f1e25]: 展开 ›
  - navigation "角色创建步骤" [ref=f1e26]:
    - button "基本信息" [ref=f1e27] [cursor=pointer]: 基本
    - button "职业与能力" [ref=f1e29] [cursor=pointer]: 职业
    - button "城市与背景" [ref=f1e31] [cursor=pointer]: 城市
    - button "初始同伴" [ref=f1e33] [cursor=pointer]: 同伴
    - button "确认与开局" [ref=f1e35] [cursor=pointer]: 确认
  - button "我的开局包" [ref=f1e38] [cursor=pointer]
  - generic [ref=f1e39]:
    - generic [ref=f1e40]:
      - generic [ref=f1e41]:
        - generic [ref=f1e42]:
          - paragraph [ref=f1e43]: STEP 01 / 05
          - heading "基本信息" [level=2] [ref=f1e44]
        - generic [ref=f1e45]: 填写内容自动保留
      - generic [ref=f1e46]:
        - generic [ref=f1e47]:
          - text: 姓名
          - textbox "姓名" [ref=f1e48]
        - generic [ref=f1e49]:
          - text: 年龄
          - spinbutton "年龄" [ref=f1e50]
        - group "性别" [ref=f1e51]:
          - generic [ref=f1e53]:
            - generic [ref=f1e54] [cursor=pointer]:
              - radio "男性" [ref=f1e55]
              - text: 男性
            - generic [ref=f1e56] [cursor=pointer]:
              - radio "女性" [ref=f1e57]
              - text: 女性
        - generic [ref=f1e58]:
          - generic [ref=f1e59]:
            - heading "外貌" [level=3] [ref=f1e60]
            - radiogroup "外貌模板" [ref=f1e61]:
              - radio "自由选择" [checked] [ref=f1e62] [cursor=pointer]
              - radio "自然耐看" [ref=f1e63] [cursor=pointer]
              - radio "清爽干练" [ref=f1e64] [cursor=pointer]
              - radio "温润斯文" [ref=f1e65] [cursor=pointer]
              - radio "冷峻凌厉" [ref=f1e66] [cursor=pointer]
              - radio "成熟硬朗" [ref=f1e67] [cursor=pointer]
              - radio "惊艳出众" [ref=f1e68] [cursor=pointer]
            - generic [ref=f1e69]:
              - text: 外貌
              - textbox "外貌" [ref=f1e70]
          - generic [ref=f1e71]:
            - heading "性格" [level=3] [ref=f1e72]
            - radiogroup "性格模板" [ref=f1e73]:
              - radio "自由选择" [checked] [ref=f1e74] [cursor=pointer]
              - radio "沉稳谨慎" [ref=f1e75] [cursor=pointer]
              - radio "开朗健谈" [ref=f1e76] [cursor=pointer]
              - radio "冷静理性" [ref=f1e77] [cursor=pointer]
              - radio "直率果敢" [ref=f1e78] [cursor=pointer]
              - radio "圆滑世故" [ref=f1e79] [cursor=pointer]
              - radio "野心勃勃" [ref=f1e80] [cursor=pointer]
            - generic [ref=f1e81]:
              - text: 性格
              - textbox "性格" [ref=f1e82]
    - generic [ref=f1e83]:
      - button "上一步" [disabled] [ref=f1e84]
      - generic [ref=f1e85]: 01 / 05
      - button "下一步 →" [ref=f1e86] [cursor=pointer]
```

# Test source

```ts
  30  | }
  31  | 
  32  | test('完整五步保存、再次套用直达第五步、编辑刷新与正式建档隔离', async ({ page }, info) => {
  33  |   const requests: string[] = [];
  34  |   await page.route('https://**/*', route => { requests.push(route.request().url()); return route.abort(); });
  35  |   await page.goto('/'); await page.getByRole('button', { name: /开始新游戏/ }).click();
  36  |   await page.getByLabel('姓名', { exact: true }).fill('林岚');
  37  |   await page.getByLabel('年龄', { exact: true }).fill('29');
  38  |   await page.getByRole('radio', { name: '女性', exact: true }).check();
  39  |   await page.getByLabel('外貌', { exact: true }).fill('  衣着素净\n手上有淡淡的墨痕。  ');
  40  |   await page.getByLabel('性格', { exact: true }).fill('认真\n偶尔冲动');
  41  |   await page.getByRole('button', { name: /下一步/ }).click();
  42  |   await page.getByLabel('职业名称', { exact: true }).fill('旧书修复师');
  43  |   await page.getByLabel('职业介绍', { exact: true }).fill('修复纸本\n保存社区档案');
  44  |   await page.getByLabel('内置职业技能', { exact: true }).fill('修复\n\n  手写记录  ');
  45  |   await page.getByLabel('长期影响', { exact: true }).fill('长期与社区合作\n保持独立');
  46  |   await page.getByRole('button', { name: '技术与生产', exact: true }).click();
  47  |   await chooseProfession(page, '程序员');
  48  |   await showPersonalSkills(page);
  49  |   await page.getByLabel('个人技能与专长').fill('手工编程\n记录工作');
  50  |   await page.getByRole('button', { name: /下一步/ }).click();
  51  |   await page.getByRole('radio', { name: /上海/ }).check();
  52  |   const background = '  成长经历\n' + '家庭、求学与工作经历。\n'.repeat(100) + '背景末行  ';
  53  |   await page.getByLabel('人物背景（可选）').fill(background);
  54  |   await page.getByRole('button', { name: /下一步/ }).click();
  55  |   await page.getByRole('checkbox', { name: '创建一名初始同伴' }).check();
  56  |   for (const [label, value] of Object.entries({ 同伴姓名: '许宁', '同伴年龄（可选）': '28', 同伴身份: '同事',
  57  |     与主角的关系: '相识多年的朋友', 同伴外貌: '短发', 同伴性格: '直率', '同伴能力（一行一项）': '排版\n沟通', 同伴个人经历: '少年在外地读书\n后来回城' })) {
  58  |     await page.getByLabel(label, { exact: true }).fill(value);
  59  |   }
  60  |   await page.getByRole('button', { name: /下一步/ }).click();
  61  |   const preference = '  2008年秋天\n' + '从普通的一天开始，不改写已有家庭设定。\n'.repeat(100) + '偏好末行  ';
  62  |   await page.getByLabel('开局偏好（可选）').fill(preference);
  63  |   const original = await draft(page);
  64  |   await page.getByRole('button', { name: '保存为开局包', exact: true }).click();
  65  |   await page.getByLabel('开局包名称').fill('上海普通人生');
  66  |   await page.getByRole('button', { name: '保存开局包', exact: true }).click();
  67  |   await expect(page.getByRole('status')).toHaveText('开局包已保存');
  68  |   expect(await saves(page)).toEqual([]); expect((await draft(page)).step).toBe(5);
  69  |   const originalPacks = await packs(page);
  70  |   await page.getByRole('button', { name: mobileCreation(page) ? '‹ 首页' : '返回首页', exact: true }).click();
  71  |   await page.getByRole('button', { name: /开始新游戏/ }).click();
  72  |   await page.getByRole('navigation', { name: '角色创建步骤' }).getByRole('button', { name: /基本信息/ }).click();
  73  |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  74  |   await page.getByRole('radio', { name: /上海普通人生/ }).check();
  75  |   await page.screenshot({ path: `docs/opening-packs/screenshots/${info.project.name}-select.png`, fullPage: true });
  76  |   await page.getByRole('button', { name: '套用开局包', exact: true }).click();
  77  |   await expect(page.getByRole('dialog')).toContainText('将替换当前创角草稿');
  78  |   await page.getByRole('button', { name: '取消', exact: true }).click();
  79  |   expect(await draft(page)).toMatchObject({ saveId: original.saveId, step: 1 });
  80  |   await page.getByRole('button', { name: '套用开局包', exact: true }).click();
  81  |   await page.getByRole('button', { name: '确认替换并套用' }).click();
  82  |   const applied = await draft(page);
  83  |   expect(applied).toEqual({ ...original, saveId: applied.saveId });
  84  |   expect(applied.saveId).not.toBe(original.saveId);
  85  |   await expect(page.getByRole('heading', { name: '确认与开局', exact: true })).toBeVisible();
  86  |   await expect(page.getByLabel('开局偏好（可选）')).toHaveValue(preference);
  87  |   await showCreationReview(page);
  88  |   await page.getByText('完整职业表单', { exact: true }).click();
  89  |   await expect(page.getByRole('region', { name: '保留的自定义职业' })).toContainText('旧书修复师');
  90  |   await expect(page.locator('.creation-review')).toContainText('背景末行');
  91  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  92  |   await page.screenshot({ path: `docs/opening-packs/screenshots/${info.project.name}-review.png`, fullPage: true });
  93  |   await page.evaluate(() => scrollTo(0, 0));
  94  |   await page.screenshot({ path: `docs/opening-packs/screenshots/${info.project.name}-review-viewport.png` });
  95  |   await page.getByRole('button', { name: '修改职业', exact: true }).click();
  96  |   await chooseCustomProfession(page);
  97  |   await expect(page.getByLabel('内置职业技能')).toHaveValue(original.customProfile!.skills);
  98  |   await page.getByLabel('内置职业技能').fill('新编辑技能\n修补');
  99  |   await page.getByRole('button', { name: '确认与开局', exact: false }).click();
  100 |   await page.reload();
  101 |   expect(await draft(page)).toMatchObject({ saveId: applied.saveId, step: 5, skills: '新编辑技能\n修补', background, openingPreference: preference });
  102 |   expect(await packs(page)).toEqual(originalPacks); expect(await saves(page)).toEqual([]);
  103 |   await page.getByRole('button', { name: '确认并创建存档', exact: true }).click();
  104 |   await expect(page.locator('.game-layout')).toBeVisible();
  105 |   expect(await saves(page)).toHaveLength(1);
  106 |   const saved = await page.evaluate(async id => {
  107 |     const path = '/src/services/storage/saveRepository.ts';
  108 |     const { SaveRepository } = await import(path), repo = await SaveRepository.open();
  109 |     try { return { state: await repo.load(id), draft: await repo.loadDraft(id) }; } finally { repo.close(); }
  110 |   }, applied.saveId);
  111 |   expect(saved.state.protagonist).toMatchObject({ name: original.person.name, background, skills: ['新编辑技能', '修补'] });
  112 |   expect(saved.state.npc.companion).toMatchObject({ name: '许宁', background: original.companion.background });
  113 |   expect(saved.draft.userInput).toBe(preference); expect(await packs(page)).toEqual(originalPacks);
  114 |   // Without AI configuration, the existing mobile diagnostics sheet reports a safe stop.
  115 |   // Close that real modal before using the external game menu; never bypass it with force.
  116 |   if (mobileCreation(page)) {
  117 |     const diagnostics = page.locator('.mobile-diagnostics-sheet');
  118 |     await expect(diagnostics).toBeVisible();
  119 |     await expect(diagnostics).toContainText('错误码：configuration');
  120 |     await page.keyboard.press('Escape');
  121 |     await expect(diagnostics).not.toBeVisible();
  122 |   }
  123 |   // After the original creation flow finishes, the next new character starts at step 1.
  124 |   await goHome(page);
  125 |   if (mobileCreation(page)) {
  126 |     await page.getByRole('navigation', { name: '车票页码' }).getByRole('button', { name: /空白车票/ }).click();
  127 |     await page.getByRole('button', { name: /开始新游戏/ }).click();
  128 |   }
  129 |   else await page.locator('.library .dossier.new button').click();
> 130 |   expect((await draft(page)).step).toBe(1);
      |                              ^ TypeError: Cannot read properties of null (reading 'step')
  131 |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  132 |   await page.getByRole('radio', { name: /上海普通人生/ }).check();
  133 |   await page.getByRole('button', { name: '套用开局包', exact: true }).click();
  134 |   await page.getByRole('button', { name: '确认替换并套用' }).click();
  135 |   const fresh = await draft(page);
  136 |   expect(fresh).toEqual({ ...original, saveId: fresh.saveId });
  137 |   expect(fresh.saveId).not.toBe(applied.saveId); expect(await saves(page)).toHaveLength(1);
  138 |   expect(await packs(page)).toEqual(originalPacks);
  139 |   expect(requests).toEqual([]);
  140 | });
  141 | 
  142 | test('同名包独立管理：重命名、取消删除、明确覆盖及确认删除', async ({ page }) => {
  143 |   await seeded(page); const original = await packs(page);
  144 |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  145 |   await expect(page.getByRole('dialog').getByRole('radio')).toHaveCount(2);
  146 |   const choices = page.getByRole('dialog').getByRole('radio');
  147 |   await choices.first().check(); await page.getByRole('button', { name: '重命名', exact: true }).click();
  148 |   await page.getByLabel('开局包名称').fill('重命名包'); await page.getByRole('button', { name: '确认重命名' }).click();
  149 |   await expect(page.getByRole('dialog')).toContainText('重命名包');
  150 |   await page.getByRole('button', { name: '删除', exact: true }).click();
  151 |   await page.getByRole('button', { name: '取消', exact: true }).click(); expect(await packs(page)).toHaveLength(2);
  152 |   await page.getByRole('button', { name: '关闭开局包' }).click();
  153 |   await page.getByRole('button', { name: '确认与开局', exact: false }).click();
  154 |   await page.getByLabel('开局偏好（可选）').fill('新的偏好');
  155 |   await page.getByRole('button', { name: '保存为开局包', exact: true }).click();
  156 |   if (mobileCreation(page)) await page.getByRole('radiogroup', { name: '保存方式' }).getByRole('radio', { name: '覆盖：重命名包', exact: true }).click();
  157 |   else await page.getByLabel('保存方式').selectOption(original[0].id);
  158 |   await page.getByRole('button', { name: '保存开局包', exact: true }).click();
  159 |   expect((await packs(page))[0].settings.openingPreference).toBe(original[0].settings.openingPreference);
  160 |   await page.getByRole('button', { name: '取消', exact: true }).click();
  161 |   await page.getByRole('button', { name: '保存开局包', exact: true }).click();
  162 |   await page.getByRole('button', { name: '确认覆盖' }).click();
  163 |   const updated = await packs(page);
  164 |   expect(updated[0]).toMatchObject({ id: original[0].id, name: '重命名包', settings: { openingPreference: '新的偏好' } });
  165 |   expect(updated[1]).toEqual(original[1]);
  166 |   await page.getByRole('navigation', { name: '角色创建步骤' }).getByRole('button', { name: /基本信息/ }).click();
  167 |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  168 |   await page.getByRole('radio', { name: /重命名包/ }).check();
  169 |   await page.getByRole('button', { name: '删除', exact: true }).click();
  170 |   await expect(page.getByRole('dialog')).toContainText('不可撤销');
  171 |   await page.getByRole('button', { name: '确认删除', exact: true }).click();
  172 |   await page.getByRole('button', { name: '关闭开局包' }).click(); await page.reload();
  173 |   expect(await packs(page)).toEqual([original[1]]); expect(await saves(page)).toEqual([]);
  174 | });
  175 | 
  176 | test('损坏包隔离，存储拒绝不误报成功、不丢失有效包或当前草稿', async ({ page }) => {
  177 |   await seeded(page); const before = await packs(page), original = await draft(page);
  178 |   await page.evaluate(() => localStorage.setItem('heijin.opening-pack.v1:broken', '{'));
  179 |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  180 |   await expect(page.getByRole('dialog')).toContainText('1 份开局包无法读取');
  181 |   await expect(page.getByRole('dialog').getByRole('radio')).toHaveCount(2);
  182 |   await page.getByRole('button', { name: '关闭开局包' }).click();
  183 |   await page.getByRole('button', { name: '确认与开局', exact: false }).click();
  184 |   await page.getByRole('button', { name: '保存为开局包', exact: true }).click();
  185 |   await page.getByLabel('开局包名称').fill('不能保存');
  186 |   await page.evaluate(() => {
  187 |     const original = Storage.prototype.setItem;
  188 |     Storage.prototype.setItem = function(key, value) {
  189 |       if (key.startsWith('heijin.opening-pack.v1:')) throw new DOMException('quota', 'QuotaExceededError');
  190 |       original.call(this, key, value);
  191 |     };
  192 |   });
  193 |   await page.getByRole('button', { name: '保存开局包', exact: true }).click();
  194 |   await expect(page.getByRole('dialog').getByRole('alert')).toContainText('操作未完成');
  195 |   await expect(page.getByText('开局包已保存', { exact: true })).toHaveCount(0);
  196 |   expect(await draft(page)).toEqual({ ...original, step: 5 });
  197 |   expect(await page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('heijin.opening-pack.v1:')).length)).toBe(3);
  198 |   await page.getByRole('button', { name: '关闭开局包' }).click(); await page.reload();
  199 |   expect(await page.evaluate(() => localStorage.getItem('heijin.opening-pack.v1:broken'))).toBe('{');
  200 |   const valid = await page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('heijin.opening-pack.v1:') && !key.endsWith(':broken')).map(key => JSON.parse(localStorage.getItem(key)!)));
  201 |   expect(valid).toEqual(before); expect(await saves(page)).toEqual([]);
  202 | });
  203 | 
  204 | test('读取被拒绝时明确反馈，恢复权限后仍可查看有效包', async ({ page }) => {
  205 |   await seeded(page);
  206 |   await page.evaluate(() => {
  207 |     const original = Storage.prototype.getItem;
  208 |     Storage.prototype.getItem = function(key) {
  209 |       if (key.startsWith('heijin.opening-pack.v1:')) throw new DOMException('denied', 'SecurityError');
  210 |       return original.call(this, key);
  211 |     };
  212 |   });
  213 |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  214 |   await expect(page.locator('.opening-packs').getByRole('alert')).toContainText('操作未完成');
  215 |   await expect(page.getByRole('dialog')).toHaveCount(0);
  216 |   await page.reload(); await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  217 |   await expect(page.getByRole('dialog').getByRole('radio')).toHaveCount(2);
  218 | });
  219 | 
```
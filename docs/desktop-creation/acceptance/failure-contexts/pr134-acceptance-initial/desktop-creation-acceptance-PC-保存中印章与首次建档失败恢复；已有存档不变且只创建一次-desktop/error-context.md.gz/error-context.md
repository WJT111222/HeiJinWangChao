# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: desktop-creation-acceptance.spec.ts >> PC 保存中印章与首次建档失败恢复；已有存档不变且只创建一次
- Location: e2e/desktop-creation-acceptance.spec.ts:130:1

# Error details

```
Error: page.goto: net::ERR_CONNECTION_REFUSED at http://127.0.0.1:5182/
Call log:
  - navigating to "http://127.0.0.1:5182/", waiting until "load"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e6]:
    - heading "This site can’t be reached" [level=1] [ref=e7]
    - paragraph [ref=e8]:
      - strong [ref=e9]: 127.0.0.1
      - text: refused to connect.
    - generic [ref=e10]:
      - paragraph [ref=e11]: "Try:"
      - list [ref=e12]:
        - listitem [ref=e13]: Checking the connection
        - listitem [ref=e14]:
          - link "Checking the proxy and the firewall" [ref=e15] [cursor=pointer]:
            - /url: "#buttons"
    - generic [ref=e16]: ERR_CONNECTION_REFUSED
  - generic [ref=e17]:
    - button "Reload" [ref=e19] [cursor=pointer]
    - button "Details" [ref=e20] [cursor=pointer]
```

# Test source

```ts
  1   | import { test, expect } from './helpers/test';
  2   | import type { Page, TestInfo } from '@playwright/test';
  3   | import { appearanceTemplates } from '../src/ui/creation/personTemplates';
  4   | import { chooseCustomProfession, chooseProfession } from './helpers/creation';
  5   | 
  6   | const evidence = 'docs/desktop-creation/acceptance/screenshots';
  7   | async function shot(page: Page, info: TestInfo, name: string) {
  8   |   await page.evaluate(() => document.fonts.ready);
  9   |   await page.mouse.move(0, 0);
  10  |   await page.screenshot({ path: `${evidence}/${info.project.name}-${name}.png`, animations: 'disabled' });
  11  | }
  12  | async function enter(page: Page) {
> 13  |   await page.goto('/');
      |              ^ Error: page.goto: net::ERR_CONNECTION_REFUSED at http://127.0.0.1:5182/
  14  |   await page.getByRole('button', { name: /开始新游戏/ }).click();
  15  | }
  16  | const next = (page: Page) => page.getByRole('button', { name: /下一步/ }).click();
  17  | const heading = (page: Page, name: string) => page.getByRole('heading', { name, exact: true });
  18  | const step = (page: Page, name: string) => page.getByRole('navigation', { name: '角色创建步骤' }).getByRole('button', { name: new RegExp(name) }).click();
  19  | async function noOverflow(page: Page) {
  20  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  21  | }
  22  | async function stored(page: Page) {
  23  |   return page.evaluate(async () => {
  24  |     const path = '/src/services/storage/saveRepository.ts', { SaveRepository } = await import(path), repo = await SaveRepository.open();
  25  |     try { return await repo.list(); } finally { repo.close(); }
  26  |   });
  27  | }
  28  | 
  29  | for (const [width, height] of [[901, 768], [1100, 800], [1440, 900], [1100, 580]]) {
  30  |   test(`PC 正式五步、实时档案、键盘、滚动与错误 ${width}x${height}`, async ({ page }, info) => {
  31  |     await page.setViewportSize({ width, height });
  32  |     let posts = 0;
  33  |     page.on('request', request => { if (request.method() === 'POST') posts++; });
  34  |     await enter(page);
  35  |     await expect(page.locator('.desktop-creation')).toBeVisible();
  36  |     await page.getByLabel('姓名', { exact: true }).fill('林序');
  37  |     await page.getByLabel('年龄', { exact: true }).fill('29');
  38  |     await page.getByRole('radio', { name: '女性', exact: true }).check();
  39  |     const group = page.getByRole('radiogroup', { name: '外貌模板' });
  40  |     const custom = group.getByRole('radio', { name: '自由选择', exact: true });
  41  |     await custom.focus(); await page.keyboard.press('ArrowRight');
  42  |     await expect(group.getByRole('radio', { name: appearanceTemplates[0].name, exact: true })).toBeFocused();
  43  |     await expect(page.getByLabel('外貌', { exact: true })).toHaveValue(appearanceTemplates[0].description);
  44  |     await page.keyboard.press('End'); await expect(group.getByRole('radio').last()).toBeFocused();
  45  |     await page.keyboard.press('ArrowLeft'); await expect(group.getByRole('radio').nth(appearanceTemplates.length - 1)).toBeFocused();
  46  |     await page.keyboard.press('Home'); await expect(custom).toBeFocused();
  47  |     await page.getByLabel('外貌', { exact: true }).fill('深色外套，袖口有修补痕迹。');
  48  |     await page.getByLabel('性格', { exact: true }).fill('谨慎而不失好奇，遇事先观察。');
  49  |     const dossier = page.locator('.creation-dossier');
  50  |     await expect(dossier).toContainText('林序'); await expect(dossier).toContainText('29 岁');
  51  |     await expect(dossier).toContainText('深色外套');
  52  |     await noOverflow(page); await shot(page, info, `${width}x${height}-01`);
  53  |     await next(page); await expect(heading(page, '职业与能力')).toBeVisible();
  54  |     await page.getByRole('button', { name: '技术与生产', exact: true }).click();
  55  |     await chooseProfession(page, '程序员');
  56  |     await expect(dossier).toContainText('程序员'); await noOverflow(page);
  57  |     await shot(page, info, `${width}x${height}-02-preset`);
  58  |     await chooseCustomProfession(page);
  59  |     await page.getByLabel('职业名称', { exact: true }).fill('旧籍修复师');
  60  |     await page.getByLabel('职业介绍', { exact: true }).fill('修复旧籍，保存社区资料。');
  61  |     await page.getByLabel('内置职业技能').fill('纸张修复\n记录');
  62  |     await page.getByLabel('长期影响', { exact: true }).fill('与社区合作，长期保存地方记忆。');
  63  |     await expect(dossier).toContainText('旧籍修复师');
  64  |     await shot(page, info, `${width}x${height}-02-custom`);
  65  |     await next(page);
  66  |     for (const name of ['重庆', '上海', '哈尔滨', '广州']) {
  67  |       await page.getByRole('radio', { name: new RegExp(name) }).check();
  68  |       await expect(dossier.locator('.dz-city-seal')).toHaveClass(/on/);
  69  |       await expect(dossier).toContainText(name);
  70  |     }
  71  |     await page.getByLabel('人物背景（可选）').fill('在旧街区长大，后来参与社区档案整理。\n背景全文末行。');
  72  |     await noOverflow(page); await shot(page, info, `${width}x${height}-03`);
  73  |     await next(page);
  74  |     await page.getByRole('checkbox', { name: '创建一名初始同伴' }).check();
  75  |     await page.getByLabel('同伴姓名', { exact: true }).fill(' ');
  76  |     await page.getByLabel('与主角的关系', { exact: true }).fill(' ');
  77  |     await next(page);
  78  |     await expect(page.getByRole('alert')).toContainText('同伴');
  79  |     await page.getByRole('alert').scrollIntoViewIfNeeded();
  80  |     await shot(page, info, `${width}x${height}-04-error`);
  81  |     for (const [label, value] of Object.entries({ 同伴姓名: '许宁', '同伴年龄（可选）': '28', 同伴身份: '同事',
  82  |       与主角的关系: '相识多年的朋友', 同伴外貌: '短发', 同伴性格: '直率', '同伴能力（一行一项）': '排版\n沟通', 同伴个人经历: '曾在外地求学，后来回城。' }))
  83  |       await page.getByLabel(label, { exact: true }).fill(value);
  84  |     await noOverflow(page); await shot(page, info, `${width}x${height}-04`);
  85  |     await next(page);
  86  |     await page.getByLabel('开局偏好（可选）').fill('2008年秋天，从平常的一天开始。\n开局偏好末行。');
  87  |     await expect(page.locator('.creation-review')).toContainText('背景全文末行');
  88  |     await expect(page.locator('.creation-review')).toContainText('曾在外地求学');
  89  |     await expect(page.locator('.creation-review')).toContainText('修复旧籍');
  90  |     await page.getByLabel('开局偏好（可选）').scrollIntoViewIfNeeded();
  91  |     await expect(page.getByRole('button', { name: '确认并创建存档', exact: true })).toBeInViewport();
  92  |     await noOverflow(page); await shot(page, info, `${width}x${height}-05`);
  93  |     await page.getByRole('button', { name: '修改基本信息', exact: true }).click();
  94  |     await expect(page.getByLabel('姓名', { exact: true })).toHaveValue('林序');
  95  |     await step(page, '城市与背景'); await expect(heading(page, '城市与背景')).toBeVisible();
  96  |     await page.getByRole('button', { name: '上一步', exact: true }).click();
  97  |     await expect(page.getByLabel('职业名称', { exact: true })).toHaveValue('旧籍修复师');
  98  |     await step(page, '确认与开局');
  99  |     await page.getByRole('button', { name: '保存为开局包', exact: true }).click();
  100 |     await page.getByLabel('开局包名称').fill('正式验收开局包');
  101 |     await shot(page, info, `${width}x${height}-pack`);
  102 |     await page.keyboard.press('Escape');
  103 |     await expect(page.getByRole('dialog')).toHaveCount(0);
  104 |     expect(await stored(page)).toEqual([]); expect(posts).toBe(0);
  105 |     await page.reload(); await expect(heading(page, '确认与开局')).toBeVisible();
  106 |     await expect(page.getByLabel('开局偏好（可选）')).toHaveValue(/开局偏好末行/);
  107 |   });
  108 | }
  109 | 
  110 | for (const width of [375, 390]) test(`手机人生车票保持、断点切换及跳过 ${width}`, async ({ page }, info) => {
  111 |   await page.setViewportSize({ width, height: 844 }); await enter(page);
  112 |   await expect(page.locator('.mobile-creation')).toBeVisible();
  113 |   await expect(page.locator('.creation-dossier')).toHaveCount(0);
```
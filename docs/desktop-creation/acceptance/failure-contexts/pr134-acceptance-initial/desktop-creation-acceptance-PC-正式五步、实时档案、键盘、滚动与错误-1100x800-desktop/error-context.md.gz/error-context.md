# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: desktop-creation-acceptance.spec.ts >> PC 正式五步、实时档案、键盘、滚动与错误 1100x800
- Location: e2e/desktop-creation-acceptance.spec.ts:30:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.check: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('checkbox', { name: '创建一名初始同伴' })
    - locator resolved to <input type="checkbox"/>
  - attempting click action
    - waiting for element to be visible, enabled and stable

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "黑金王朝首页" [ref=e5] [cursor=pointer]:
      - /url: "#"
      - generic [ref=e6]: 黑
      - generic [ref=e7]:
        - text: 黑金王朝
        - generic [ref=e8]: HEIJINWANGCHAO
    - navigation "主导航" [ref=e9]:
      - button "游戏首页" [ref=e10] [cursor=pointer]
      - button "设置" [ref=e11] [cursor=pointer]
      - generic [ref=e12]: V1.0 Beta
  - main [ref=e13]:
    - generic [ref=e14]:
      - generic [ref=e15]:
        - generic [ref=e16]:
          - paragraph [ref=e17]: A LIFE, UNWRITTEN
          - heading "写下你是谁。" [level=1] [ref=e18]
          - paragraph [ref=e19]: 从一座真实的城市开始。此后的人生，由你选择。
        - button "返回首页" [ref=e20] [cursor=pointer]
      - complementary [aria-hidden] [ref=e21]:
        - generic [ref=e22]:
          - generic [ref=e23]: 人物档案
          - generic [ref=e24]: No. 3E3F-GZ
        - generic [ref=e25]:
          - generic [ref=e26]:
            - generic [ref=e27]:
              - text: 林
              - generic [ref=e28]: 穗
              - text: 像
            - generic [ref=e29]:
              - generic [ref=e30]:
                - term [ref=e31]: 姓名
                - definition [ref=e32]: 林序
              - generic [ref=e33]:
                - term [ref=e34]: 年龄
                - definition [ref=e35]: 29 岁
              - generic [ref=e36]:
                - term [ref=e37]: 性别
                - definition [ref=e38]: 女性
              - generic [ref=e39]:
                - term [ref=e40]: 职业
                - definition [ref=e41]: 旧籍修复师
              - generic [ref=e42]:
                - term [ref=e43]: 起点城市
                - definition [ref=e44]: 广州
          - heading [level=3] [ref=e45]: 外貌
          - paragraph [ref=e46]: 深色外套，袖口有修补痕迹。
          - heading [level=3] [ref=e47]: 性格
          - paragraph [ref=e48]: 谨慎而不失好奇，遇事先观察。
          - heading [level=3] [ref=e49]: 职业技能
          - generic [ref=e50]:
            - generic [ref=e51]: 纸张修复
            - generic [ref=e52]: 记录
          - heading [level=3] [ref=e53]: 人物背景
          - paragraph [ref=e54]: 在旧街区长大，后来参与社区档案整理。 背景全文末行。
          - heading [level=3] [ref=e55]: 初始同伴
          - paragraph [ref=e56]: 未创建同伴
          - generic [ref=e57]:
            - generic [ref=e58]: 基
            - generic [ref=e59]: 职
            - generic [ref=e60]: 城
            - generic [ref=e61]: 伴
            - generic [ref=e62]: 启
        - generic:
          - text: 立档
          - generic: HEIJIN
    - generic [ref=e63]:
      - navigation "角色创建步骤" [ref=e65]:
        - button "基本信息" [ref=e66] [cursor=pointer]:
          - generic [aria-hidden] [ref=e67]: ✓
          - text: 基本信息
        - button "职业与能力" [ref=e68] [cursor=pointer]:
          - generic [aria-hidden] [ref=e69]: ✓
          - text: 职业与能力
        - button "城市与背景" [ref=e70] [cursor=pointer]:
          - generic [aria-hidden] [ref=e71]: ✓
          - text: 城市与背景
        - button "初始同伴" [ref=e72] [cursor=pointer]:
          - generic [aria-hidden] [ref=e73]: "04"
          - text: 初始同伴
        - button "确认与开局" [ref=e74] [cursor=pointer]:
          - generic [aria-hidden] [ref=e75]: "05"
          - text: 确认与开局
      - generic [ref=e76]:
        - generic [ref=e77]:
          - generic [ref=e78]:
            - generic [ref=e79]:
              - paragraph [ref=e80]: STEP 04 / 05
              - heading "初始同伴" [level=2] [ref=e81]
            - paragraph [ref=e82]: 可选。同伴会作为特殊 NPC 进入故事。
            - generic [ref=e83]: 填写内容自动保留
          - generic [ref=e84]:
            - generic [ref=e85] [cursor=pointer]:
              - checkbox "创建一名初始同伴" [ref=e86]
              - generic [ref=e87]: 创建一名初始同伴
            - paragraph [ref=e88]: 可完全跳过。同伴将作为特殊 NPC 保存；开局保护规则将在 AI 接入后执行。
          - button "跳过同伴，继续" [ref=e89] [cursor=pointer]
        - generic [ref=e90]:
          - button "上一步" [ref=e91] [cursor=pointer]: ← 上一步
          - generic [ref=e92]:
            - generic [ref=e93]: 04 / 05
            - text: 下一步：确认与开局
          - button "下一步 →" [active] [ref=e94] [cursor=pointer]
```

# Test source

```ts
  1   | import { test, expect } from './helpers/test';
  2   | import type { Page, TestInfo } from '@playwright/test';
  3   | import { appearanceTemplates } from '../src/ui/creation/personTemplates';
  4   | import { chooseCustomProfession, chooseProfession } from './helpers/creation';
  5   | 
  6   | const evidence = 'docs/desktop-creation/acceptance/screenshots';
  7   | async function shot(page: Page, info: TestInfo, name: string) {
  8   |   await page.evaluate(() => document.fonts.ready);
  9   |   await page.mouse.move(0, 0);
  10  |   await page.screenshot({ path: `${evidence}/${info.project.name}-${name}.png`, animations: 'disabled' });
  11  | }
  12  | async function enter(page: Page) {
  13  |   await page.goto('/');
  14  |   await page.getByRole('button', { name: /开始新游戏/ }).click();
  15  | }
  16  | const next = (page: Page) => page.getByRole('button', { name: /下一步/ }).click();
  17  | const heading = (page: Page, name: string) => page.getByRole('heading', { name, exact: true });
  18  | const step = (page: Page, name: string) => page.getByRole('navigation', { name: '角色创建步骤' }).getByRole('button', { name: new RegExp(name) }).click();
  19  | async function noOverflow(page: Page) {
  20  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  21  | }
  22  | async function stored(page: Page) {
  23  |   return page.evaluate(async () => {
  24  |     const path = '/src/services/storage/saveRepository.ts', { SaveRepository } = await import(path), repo = await SaveRepository.open();
  25  |     try { return await repo.list(); } finally { repo.close(); }
  26  |   });
  27  | }
  28  | 
  29  | for (const [width, height] of [[901, 768], [1100, 800], [1440, 900], [1100, 580]]) {
  30  |   test(`PC 正式五步、实时档案、键盘、滚动与错误 ${width}x${height}`, async ({ page }, info) => {
  31  |     await page.setViewportSize({ width, height });
  32  |     let posts = 0;
  33  |     page.on('request', request => { if (request.method() === 'POST') posts++; });
  34  |     await enter(page);
  35  |     await expect(page.locator('.desktop-creation')).toBeVisible();
  36  |     await page.getByLabel('姓名', { exact: true }).fill('林序');
  37  |     await page.getByLabel('年龄', { exact: true }).fill('29');
  38  |     await page.getByRole('radio', { name: '女性', exact: true }).check();
  39  |     const group = page.getByRole('radiogroup', { name: '外貌模板' });
  40  |     const custom = group.getByRole('radio', { name: '自由选择', exact: true });
  41  |     await custom.focus(); await page.keyboard.press('ArrowRight');
  42  |     await expect(group.getByRole('radio', { name: appearanceTemplates[0].name, exact: true })).toBeFocused();
  43  |     await expect(page.getByLabel('外貌', { exact: true })).toHaveValue(appearanceTemplates[0].description);
  44  |     await page.keyboard.press('End'); await expect(group.getByRole('radio').last()).toBeFocused();
  45  |     await page.keyboard.press('ArrowLeft'); await expect(group.getByRole('radio').nth(appearanceTemplates.length - 1)).toBeFocused();
  46  |     await page.keyboard.press('Home'); await expect(custom).toBeFocused();
  47  |     await page.getByLabel('外貌', { exact: true }).fill('深色外套，袖口有修补痕迹。');
  48  |     await page.getByLabel('性格', { exact: true }).fill('谨慎而不失好奇，遇事先观察。');
  49  |     const dossier = page.locator('.creation-dossier');
  50  |     await expect(dossier).toContainText('林序'); await expect(dossier).toContainText('29 岁');
  51  |     await expect(dossier).toContainText('深色外套');
  52  |     await noOverflow(page); await shot(page, info, `${width}x${height}-01`);
  53  |     await next(page); await expect(heading(page, '职业与能力')).toBeVisible();
  54  |     await page.getByRole('button', { name: '技术与生产', exact: true }).click();
  55  |     await chooseProfession(page, '程序员');
  56  |     await expect(dossier).toContainText('程序员'); await noOverflow(page);
  57  |     await shot(page, info, `${width}x${height}-02-preset`);
  58  |     await chooseCustomProfession(page);
  59  |     await page.getByLabel('职业名称', { exact: true }).fill('旧籍修复师');
  60  |     await page.getByLabel('职业介绍', { exact: true }).fill('修复旧籍，保存社区资料。');
  61  |     await page.getByLabel('内置职业技能').fill('纸张修复\n记录');
  62  |     await page.getByLabel('长期影响', { exact: true }).fill('与社区合作，长期保存地方记忆。');
  63  |     await expect(dossier).toContainText('旧籍修复师');
  64  |     await shot(page, info, `${width}x${height}-02-custom`);
  65  |     await next(page);
  66  |     for (const name of ['重庆', '上海', '哈尔滨', '广州']) {
  67  |       await page.getByRole('radio', { name: new RegExp(name) }).check();
  68  |       await expect(dossier.locator('.dz-city-seal')).toHaveClass(/on/);
  69  |       await expect(dossier).toContainText(name);
  70  |     }
  71  |     await page.getByLabel('人物背景（可选）').fill('在旧街区长大，后来参与社区档案整理。\n背景全文末行。');
  72  |     await noOverflow(page); await shot(page, info, `${width}x${height}-03`);
  73  |     await next(page);
> 74  |     await page.getByRole('checkbox', { name: '创建一名初始同伴' }).check();
      |                                                            ^ Error: locator.check: Test timeout of 30000ms exceeded.
  75  |     await page.getByLabel('同伴姓名', { exact: true }).fill(' ');
  76  |     await page.getByLabel('与主角的关系', { exact: true }).fill(' ');
  77  |     await next(page);
  78  |     await expect(page.getByRole('alert')).toContainText('同伴');
  79  |     await page.getByRole('alert').scrollIntoViewIfNeeded();
  80  |     await shot(page, info, `${width}x${height}-04-error`);
  81  |     for (const [label, value] of Object.entries({ 同伴姓名: '许宁', '同伴年龄（可选）': '28', 同伴身份: '同事',
  82  |       与主角的关系: '相识多年的朋友', 同伴外貌: '短发', 同伴性格: '直率', '同伴能力（一行一项）': '排版\n沟通', 同伴个人经历: '曾在外地求学，后来回城。' }))
  83  |       await page.getByLabel(label, { exact: true }).fill(value);
  84  |     await noOverflow(page); await shot(page, info, `${width}x${height}-04`);
  85  |     await next(page);
  86  |     await page.getByLabel('开局偏好（可选）').fill('2008年秋天，从平常的一天开始。\n开局偏好末行。');
  87  |     await expect(page.locator('.creation-review')).toContainText('背景全文末行');
  88  |     await expect(page.locator('.creation-review')).toContainText('曾在外地求学');
  89  |     await expect(page.locator('.creation-review')).toContainText('修复旧籍');
  90  |     await page.getByLabel('开局偏好（可选）').scrollIntoViewIfNeeded();
  91  |     await expect(page.getByRole('button', { name: '确认并创建存档', exact: true })).toBeInViewport();
  92  |     await noOverflow(page); await shot(page, info, `${width}x${height}-05`);
  93  |     await page.getByRole('button', { name: '修改基本信息', exact: true }).click();
  94  |     await expect(page.getByLabel('姓名', { exact: true })).toHaveValue('林序');
  95  |     await step(page, '城市与背景'); await expect(heading(page, '城市与背景')).toBeVisible();
  96  |     await page.getByRole('button', { name: '上一步', exact: true }).click();
  97  |     await expect(page.getByLabel('职业名称', { exact: true })).toHaveValue('旧籍修复师');
  98  |     await step(page, '确认与开局');
  99  |     await page.getByRole('button', { name: '保存为开局包', exact: true }).click();
  100 |     await page.getByLabel('开局包名称').fill('正式验收开局包');
  101 |     await shot(page, info, `${width}x${height}-pack`);
  102 |     await page.keyboard.press('Escape');
  103 |     await expect(page.getByRole('dialog')).toHaveCount(0);
  104 |     expect(await stored(page)).toEqual([]); expect(posts).toBe(0);
  105 |     await page.reload(); await expect(heading(page, '确认与开局')).toBeVisible();
  106 |     await expect(page.getByLabel('开局偏好（可选）')).toHaveValue(/开局偏好末行/);
  107 |   });
  108 | }
  109 | 
  110 | for (const width of [375, 390]) test(`手机人生车票保持、断点切换及跳过 ${width}`, async ({ page }, info) => {
  111 |   await page.setViewportSize({ width, height: 844 }); await enter(page);
  112 |   await expect(page.locator('.mobile-creation')).toBeVisible();
  113 |   await expect(page.locator('.creation-dossier')).toHaveCount(0);
  114 |   await page.getByLabel('姓名', { exact: true }).fill('车票旅人');
  115 |   await page.getByLabel('年龄', { exact: true }).fill('30');
  116 |   await page.getByRole('radio', { name: '男性', exact: true }).check();
  117 |   await shot(page, info, `${width}-ticket-01`);
  118 |   await page.setViewportSize({ width: 901, height: 844 });
  119 |   await expect(page.locator('.creation-dossier')).toContainText('车票旅人');
  120 |   await page.setViewportSize({ width, height: 844 });
  121 |   await expect(page.getByLabel('姓名', { exact: true })).toHaveValue('车票旅人');
  122 |   await next(page);
  123 |   await page.getByLabel('职业名称', { exact: true }).fill('修复师');
  124 |   await next(page); await page.getByRole('button', { name: '跳过背景，继续' }).click();
  125 |   await page.getByRole('button', { name: '跳过同伴，继续' }).click();
  126 |   await expect(page.locator('.creation-ticket-stub').first()).toBeVisible();
  127 |   await page.getByLabel('开局偏好（可选）').fill('2015年秋天');
  128 |   await noOverflow(page); await shot(page, info, `${width}-ticket-05`);
  129 |   expect(await stored(page)).toEqual([]);
  130 | });
  131 | 
  132 | test('PC 保存中印章与首次建档失败恢复；已有存档不变且只创建一次', async ({ page }, info) => {
  133 |   await enter(page);
  134 |   await page.evaluate(async () => {
  135 |     const m = '/src/ui/creation/model.ts', r = '/src/services/storage/saveRepository.ts';
  136 |     const { newCreation } = await import(m), { SaveRepository } = await import(r);
  137 |     const existing = newCreation(); existing.customProfession = '记录员'; existing.person = { name: '已有旅人', age: '32', gender: '男性', appearance: '', personality: '' };
  138 |     // Existing independent save is installed via the same formal creation helper.
  139 |     const { createProfileSave } = await import(m);
  140 |     const settingsPath = '/src/ui/settings/model.ts', { defaultSettings } = await import(settingsPath);
  141 |     const repo = await SaveRepository.open();
  142 |     try { await createProfileSave(repo, existing, defaultSettings()); } finally { repo.close(); }
  143 |   });
  144 |   const before = await stored(page);
  145 |   await page.getByLabel('姓名', { exact: true }).fill('新旅人');
  146 |   await page.getByLabel('年龄', { exact: true }).fill('28');
  147 |   await page.getByRole('radio', { name: '女性', exact: true }).check();
  148 |   await next(page);
  149 |   await page.getByLabel('职业名称', { exact: true }).fill('修复师');
  150 |   await step(page, '确认与开局');
  151 |   await page.evaluate(async () => {
  152 |     const p = '/src/services/storage/saveRepository.ts', { SaveRepository } = await import(p), real = SaveRepository.prototype.create;
  153 |     const control = { calls: 0, release: () => {} };
  154 |     Reflect.set(window, '__creationControl', control);
  155 |     SaveRepository.prototype.create = async function(...args: Parameters<typeof real>) {
  156 |       control.calls++;
  157 |       if (control.calls === 1) throw new Error('正式验收：首次存储拒绝');
  158 |       await new Promise<void>(resolve => { control.release = resolve; });
  159 |       return real.apply(this, args);
  160 |     };
  161 |   });
  162 |   await page.getByRole('button', { name: '确认并创建存档', exact: true }).click();
  163 |   await expect(page.getByRole('alert')).toContainText('首次存储拒绝');
  164 |   expect(await stored(page)).toEqual(before);
  165 |   await shot(page, info, '1440-save-failure');
  166 |   await page.getByRole('button', { name: '确认并创建存档', exact: true }).click({ clickCount: 2 });
  167 |   await expect(page.getByRole('button', { name: '正在保存…', exact: true })).toBeDisabled();
  168 |   await expect(page.locator('.dz-big-seal')).toHaveClass(/on/);
  169 |   await shot(page, info, '1440-saving');
  170 |   expect(await page.evaluate(() => Reflect.get(window, '__creationControl').calls)).toBe(2);
  171 |   await page.evaluate(() => Reflect.get(window, '__creationControl').release());
  172 |   await expect(page.locator('.game-layout')).toBeVisible();
  173 |   const after = await stored(page); expect(after).toHaveLength(2);
  174 |   expect(after.find(save => save.saveId === before[0].saveId)).toEqual(before[0]);
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: character-creation-v2.spec.ts >> 自定义四项跨预设保存、确认、正式档案与重载；纯UI无模型调用
- Location: e2e/character-creation-v2.spec.ts:79:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.check: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('radio', { name: '程序员', exact: true })

```

# Page snapshot

```yaml
- main [ref=e4]:
  - generic [ref=e5]:
    - button "‹ 首页" [ref=e6] [cursor=pointer]
    - generic [ref=e7]:
      - generic [ref=e8]: NEW LIFE
      - text: 空白车票
  - button "展开完整车票预览" [ref=e9] [cursor=pointer]:
    - generic [ref=e11]:
      - generic [ref=e12]:
        - generic [ref=e13]:
          - generic [ref=e14]: FROM
          - generic "林舟" [ref=e15]
        - generic [ref=e17]:
          - generic [ref=e18]: TO
          - generic [ref=e19]: ？
      - generic "30 · 女性 · 古籍修复师" [ref=e20]: 30 岁 · 女性 · 古籍修复师
    - generic [ref=e21]:
      - generic [ref=e22]: STATION
      - generic [ref=e23]: "02"
    - generic [aria-hidden] [ref=e26]: 展开 ›
  - navigation "角色创建步骤" [ref=e27]:
    - button "基本信息" [ref=e28] [cursor=pointer]:
      - generic [ref=e29]: ✓
      - text: 基本
    - button "职业与能力" [ref=e30] [cursor=pointer]: 职业
    - button "城市与背景" [ref=e32] [cursor=pointer]: 城市
    - button "初始同伴" [ref=e34] [cursor=pointer]: 同伴
    - button "确认与开局" [ref=e36] [cursor=pointer]: 确认
  - generic [ref=e38]:
    - generic [ref=e39]:
      - generic [ref=e40]:
        - generic [ref=e41]:
          - paragraph [ref=e42]: STEP 02 / 05
          - heading "职业与能力" [level=2] [ref=e43]
        - generic [ref=e44]: 填写内容自动保留
      - group "选择职业" [ref=e45]:
        - navigation "职业方向" [ref=e47]:
          - button "学生与人生阶段" [ref=e48] [cursor=pointer]
          - button "企业与商业" [ref=e49] [cursor=pointer]
          - button "专业与公共服务" [ref=e50] [cursor=pointer]
          - button "技术与生产" [active] [pressed] [ref=e51] [cursor=pointer]
          - button "城市服务与自由职业" [ref=e52] [cursor=pointer]
          - button "✎ 自由选择" [ref=e53] [cursor=pointer]
        - generic [ref=e54]:
          - generic [ref=e56] [cursor=pointer]:
            - radio "程序员 编程实现 · 代码阅读 · 问题排查" [ref=e57]
            - generic [ref=e58]:
              - generic [ref=e59]: 程序员
              - generic [ref=e60]: 编程实现 · 代码阅读 · 问题排查
          - generic [ref=e62] [cursor=pointer]:
            - radio "工程师 技术制图 · 方案分析 · 质量检查" [ref=e63]
            - generic [ref=e64]:
              - generic [ref=e65]: 工程师
              - generic [ref=e66]: 技术制图 · 方案分析 · 质量检查
          - generic [ref=e68] [cursor=pointer]:
            - radio "汽修技师 车辆检修 · 故障排查 · 工具使用" [ref=e69]
            - generic [ref=e70]:
              - generic [ref=e71]: 汽修技师
              - generic [ref=e72]: 车辆检修 · 故障排查 · 工具使用
          - generic [ref=e74] [cursor=pointer]:
            - radio "工厂技工 设备操作 · 工艺识读 · 质量自检" [ref=e75]
            - generic [ref=e76]:
              - generic [ref=e77]: 工厂技工
              - generic [ref=e78]: 设备操作 · 工艺识读 · 质量自检
          - generic [ref=e80] [cursor=pointer]:
            - radio "建筑工人 施工识图 · 安全操作 · 工具使用" [ref=e81]
            - generic [ref=e82]:
              - generic [ref=e83]: 建筑工人
              - generic [ref=e84]: 施工识图 · 安全操作 · 工具使用
          - generic [ref=e86] [cursor=pointer]:
            - radio "仓储物流人员 货品核对 · 库存盘点 · 配送协调" [ref=e87]
            - generic [ref=e88]:
              - generic [ref=e89]: 仓储物流人员
              - generic [ref=e90]: 货品核对 · 库存盘点 · 配送协调
    - generic [ref=e91]:
      - button "上一步" [ref=e92] [cursor=pointer]
      - generic [ref=e93]: 02 / 05
      - button "下一步 →" [ref=e94] [cursor=pointer]
```

# Test source

```ts
  1   | import { expect, test } from './helpers/test';
  2   | import type { Page } from '@playwright/test';
  3   | import { appearanceTemplates, personalityTemplates } from '../src/ui/creation/personTemplates';
  4   | import professions from '../src/ui/creation/professions.json' with { type: 'json' };
  5   | const professionCategories = [...new Set(professions.map(job => job.category))];
  6   | import { openGameTools, openProfile } from './helpers/gameLayout';
  7   | 
  8   | async function begin(page: Page) {
  9   |   await page.goto('/'); await page.getByRole('button', { name: /开始新游戏/ }).click();
  10  |   await page.getByLabel('姓名', { exact: true }).fill('林舟');
  11  |   await page.getByLabel('年龄', { exact: true }).fill('30');
  12  |   await page.getByRole('radio', { name: '女性', exact: true }).check();
  13  | }
  14  | async function choose(page: Page, label: string, value: string) {
  15  |   await page.getByRole('radiogroup', { name: label, exact: true }).getByRole('radio', { name: value, exact: true }).click();
  16  | }
  17  | const template = (page: Page, label: string, value: string) =>
  18  |   page.getByRole('radiogroup', { name: label, exact: true }).getByRole('radio', { name: value, exact: true });
  19  | async function confirm(page: Page) {
  20  |   await page.getByRole('button', { name: /下一步/ }).click();
  21  |   await page.getByRole('button', { name: '跳过背景，继续' }).click();
  22  |   await page.getByRole('button', { name: '跳过同伴，继续' }).click();
  23  | }
  24  | async function noOverflow(page: Page) {
  25  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  26  | }
  27  | 
  28  | test('基本信息模板独立、可编辑、往返与刷新保留；键盘选择', async ({ page }, info) => {
  29  |   await begin(page);
  30  |   await expect(page.getByRole('group', { name: '性别', exact: true }).getByRole('radio')).toHaveCount(2);
  31  |   await expect(template(page, '外貌模板', '自由选择')).toHaveAttribute('aria-checked', 'true');
  32  |   await expect(template(page, '性格模板', '自由选择')).toHaveAttribute('aria-checked', 'true');
  33  |   for (const item of appearanceTemplates) {
  34  |     await choose(page, '外貌模板', item.name); await expect(page.getByLabel('外貌', { exact: true })).toHaveValue(item.description);
  35  |     await expect(page.getByLabel('性格', { exact: true })).toHaveValue('');
  36  |   }
  37  |   for (const item of personalityTemplates) {
  38  |     await choose(page, '性格模板', item.name); await expect(page.getByLabel('性格', { exact: true })).toHaveValue(item.description);
  39  |     await expect(page.getByLabel('外貌', { exact: true })).toHaveValue(appearanceTemplates.at(-1)!.description);
  40  |   }
  41  |   await template(page, '外貌模板', appearanceTemplates.at(-1)!.name).focus();
  42  |   await page.keyboard.press('Home');
  43  |   await expect(template(page, '外貌模板', '自由选择')).toHaveAttribute('aria-checked', 'true');
  44  |   await expect(template(page, '外貌模板', '自由选择')).toBeFocused();
  45  |   const appearance = appearanceTemplates[0].description + '\n手背有淡淡旧痕。';
  46  |   await page.getByLabel('外貌', { exact: true }).fill(appearance);
  47  |   await page.getByLabel('性格', { exact: true }).fill('平日谨慎，今天愿意主动冒险。');
  48  |   await page.getByRole('button', { name: /下一步/ }).click(); await page.getByRole('button', { name: '上一步', exact: true }).click();
  49  |   await page.reload(); await expect(page.getByLabel('外貌', { exact: true })).toHaveValue(appearance);
  50  |   await expect(page.getByLabel('性格', { exact: true })).toHaveValue('平日谨慎，今天愿意主动冒险。');
  51  |   await expect(page.getByRole('radio', { name: '女性', exact: true })).toBeChecked();
  52  |   await noOverflow(page);
  53  |   await page.screenshot({ path: `docs/screenshots/character-creation-v2/${info.project.name}-basics.png`, fullPage: true });
  54  | });
  55  | 
  56  | test('五类各六职业，点击呈现完整介绍、独立技能与长期影响', async ({ page }, info) => {
  57  |   await begin(page); await page.getByRole('button', { name: /下一步/ }).click();
  58  |   await expect(page.getByRole('radio', { name: '自由选择', exact: true })).toBeChecked();
  59  |   for (const category of professionCategories) {
  60  |     await page.getByRole('button', { name: category, exact: true }).click();
  61  |     await expect(page.getByRole('radio')).toHaveCount(7);
  62  |     for (const job of professions.filter(job => job.category === category)) {
  63  |       await page.getByRole('radio', { name: job.name, exact: true }).check();
  64  |       const profile = page.getByRole('region', { name: '职业档案', exact: true });
  65  |       await expect(profile).toContainText(job.description); await expect(profile).toContainText(job.longTermImpact);
  66  |       await expect(profile.locator('li')).toHaveText(job.skills);
  67  |       await expect(page.getByLabel('个人技能与专长')).toHaveValue(job.skills.join('\n'));
  68  |     }
  69  |   }
  70  |   await page.getByRole('button', { name: '企业与商业', exact: true }).click();
  71  |   await page.getByRole('radio', { name: '企业经营者', exact: true }).check();
  72  |   await noOverflow(page);
  73  |   await page.screenshot({ path: `docs/screenshots/character-creation-v2/${info.project.name}-professions.png`, fullPage: true });
  74  |   await confirm(page);
  75  |   const job = professions.find(job => job.name === '企业经营者')!;
  76  |   await expect(page.getByRole('region', { name: '职业档案', exact: true })).toContainText(job.longTermImpact);
  77  | });
  78  | 
  79  | test('自定义四项跨预设保存、确认、正式档案与重载；纯UI无模型调用', async ({ page }, info) => {
  80  |   const requests: string[] = [];
  81  |   await page.route('https://**/*', async route => { requests.push(route.request().url()); await route.abort(); });
  82  |   await begin(page); await page.getByRole('button', { name: /下一步/ }).click();
  83  |   const custom = { name: '古籍修复师', description: '在社区工作室修复旧书。\n日常记录纸张、装帧与修补过程。', skills: '纸张辨识\n修补\n配色\n装帧\n记录\n沟通', impact: '与图书馆和收藏者合作，保留耐心观察的习惯。\n仍愿意尝试全新的生活。' };
  84  |   await page.getByLabel('职业名称', { exact: true }).fill(custom.name);
  85  |   await page.getByLabel('职业介绍', { exact: true }).fill(custom.description);
  86  |   await page.getByLabel('内置职业技能', { exact: true }).fill(custom.skills);
  87  |   await page.getByLabel('长期影响', { exact: true }).fill(custom.impact);
  88  |   await page.getByRole('button', { name: '技术与生产', exact: true }).click();
> 89  |   await page.getByRole('radio', { name: '程序员', exact: true }).check(); await page.reload();
      |                                                               ^ Error: locator.check: Test timeout of 30000ms exceeded.
  90  |   await page.getByRole('radio', { name: '自由选择', exact: true }).check();
  91  |   await expect(page.getByLabel('职业名称', { exact: true })).toHaveValue(custom.name);
  92  |   await expect(page.getByLabel('职业介绍', { exact: true })).toHaveValue(custom.description);
  93  |   await expect(page.getByLabel('内置职业技能', { exact: true })).toHaveValue(custom.skills);
  94  |   await expect(page.getByLabel('长期影响', { exact: true })).toHaveValue(custom.impact);
  95  |   await noOverflow(page);
  96  |   await page.screenshot({ path: `docs/screenshots/character-creation-v2/${info.project.name}-custom.png`, fullPage: true });
  97  |   await confirm(page);
  98  |   const profile = page.getByRole('region', { name: '职业档案', exact: true });
  99  |   await expect(profile).toContainText(custom.description); await expect(profile).toContainText(custom.impact);
  100 |   await expect(profile.locator('li')).toHaveText(custom.skills.split('\n'));
  101 |   await page.getByRole('button', { name: '确认并创建存档', exact: true }).click();
  102 |   await expect(page.locator('.game-layout')).toBeVisible();
  103 |   await page.reload(); await openGameTools(page);
  104 |   await openProfile(page);
  105 |   const dialog = page.getByRole('dialog', { name: '人物档案', exact: true });
  106 |   await expect(dialog).toContainText(custom.name); await expect(dialog).toContainText(custom.description);
  107 |   await expect(dialog).toContainText(custom.impact); await expect(dialog.locator('.skill-tags li')).toHaveText(custom.skills.split('\n'));
  108 |   await noOverflow(page); await page.getByRole('button', { name: '关闭资料界面' }).click();
  109 |   const saved = await page.evaluate(async () => {
  110 |     const path = '/src/services/storage/saveRepository.ts', { SaveRepository } = await import(path), repo = await SaveRepository.open();
  111 |     try { return await repo.load(location.hash.slice(6)); } finally { repo.close(); }
  112 |   });
  113 |   expect(saved.protagonist).toMatchObject({ profession: custom.name, professionDescription: custom.description, professionLongTermImpact: custom.impact, skills: custom.skills.split('\n'), gender: '女性' });
  114 |   expect(saved.economy.cash).toBeNull(); expect(saved.items).toEqual({}); expect(saved.organizations).toEqual({});
  115 |   expect(requests).toEqual([]);
  116 | });
  117 | 
```
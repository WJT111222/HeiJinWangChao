# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: opening-packs.spec.ts >> 完整五步保存、再次套用直达第五步、编辑刷新与正式建档隔离
- Location: e2e/opening-packs.spec.ts:31:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.check: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('radio', { name: '程序员', exact: true })

```

# Page snapshot

```yaml
- main [ref=e4]:
  - generic [ref=e5]:
    - button "‹ 首页" [ref=e6] [cursor=pointer]
    - generic [ref=e7]:
      - generic [ref=e8]: NEW LIFE
      - text: 空白车票
  - button "展开完整车票预览" [ref=e9] [cursor=pointer]:
    - generic [ref=e11]:
      - generic [ref=e12]:
        - generic [ref=e13]:
          - generic [ref=e14]: FROM
          - generic "林岚" [ref=e15]
        - generic [ref=e17]:
          - generic [ref=e18]: TO
          - generic [ref=e19]: ？
      - generic "29 · 女性 · 旧书修复师" [ref=e20]: 29 岁 · 女性 · 旧书修复师
    - generic [ref=e21]:
      - generic [ref=e22]: STATION
      - generic [ref=e23]: "02"
    - generic [aria-hidden] [ref=e26]: 展开 ›
  - navigation "角色创建步骤" [ref=e27]:
    - button "基本信息" [ref=e28] [cursor=pointer]:
      - generic [ref=e29]: ✓
      - text: 基本
    - button "职业与能力" [ref=e30] [cursor=pointer]: 职业
    - button "城市与背景" [ref=e32] [cursor=pointer]: 城市
    - button "初始同伴" [ref=e34] [cursor=pointer]: 同伴
    - button "确认与开局" [ref=e36] [cursor=pointer]: 确认
  - generic [ref=e38]:
    - generic [ref=e39]:
      - generic [ref=e40]:
        - generic [ref=e41]:
          - paragraph [ref=e42]: STEP 02 / 05
          - heading "职业与能力" [level=2] [ref=e43]
        - generic [ref=e44]: 填写内容自动保留
      - group "选择职业" [ref=e45]:
        - navigation "职业方向" [ref=e47]:
          - button "学生与人生阶段" [ref=e48] [cursor=pointer]
          - button "企业与商业" [ref=e49] [cursor=pointer]
          - button "专业与公共服务" [ref=e50] [cursor=pointer]
          - button "技术与生产" [active] [pressed] [ref=e51] [cursor=pointer]
          - button "城市服务与自由职业" [ref=e52] [cursor=pointer]
          - button "✎ 自由选择" [ref=e53] [cursor=pointer]
        - generic [ref=e54]:
          - generic [ref=e56] [cursor=pointer]:
            - radio "程序员 编程实现 · 代码阅读 · 问题排查" [ref=e57]
            - generic [ref=e58]:
              - generic [ref=e59]: 程序员
              - generic [ref=e60]: 编程实现 · 代码阅读 · 问题排查
          - generic [ref=e62] [cursor=pointer]:
            - radio "工程师 技术制图 · 方案分析 · 质量检查" [ref=e63]
            - generic [ref=e64]:
              - generic [ref=e65]: 工程师
              - generic [ref=e66]: 技术制图 · 方案分析 · 质量检查
          - generic [ref=e68] [cursor=pointer]:
            - radio "汽修技师 车辆检修 · 故障排查 · 工具使用" [ref=e69]
            - generic [ref=e70]:
              - generic [ref=e71]: 汽修技师
              - generic [ref=e72]: 车辆检修 · 故障排查 · 工具使用
          - generic [ref=e74] [cursor=pointer]:
            - radio "工厂技工 设备操作 · 工艺识读 · 质量自检" [ref=e75]
            - generic [ref=e76]:
              - generic [ref=e77]: 工厂技工
              - generic [ref=e78]: 设备操作 · 工艺识读 · 质量自检
          - generic [ref=e80] [cursor=pointer]:
            - radio "建筑工人 施工识图 · 安全操作 · 工具使用" [ref=e81]
            - generic [ref=e82]:
              - generic [ref=e83]: 建筑工人
              - generic [ref=e84]: 施工识图 · 安全操作 · 工具使用
          - generic [ref=e86] [cursor=pointer]:
            - radio "仓储物流人员 货品核对 · 库存盘点 · 配送协调" [ref=e87]
            - generic [ref=e88]:
              - generic [ref=e89]: 仓储物流人员
              - generic [ref=e90]: 货品核对 · 库存盘点 · 配送协调
    - generic [ref=e91]:
      - button "上一步" [ref=e92] [cursor=pointer]
      - generic [ref=e93]: 02 / 05
      - button "下一步 →" [ref=e94] [cursor=pointer]
```

# Test source

```ts
  1   | import { test, expect } from './helpers/test';
  2   | import type { Page } from '@playwright/test';
  3   | import type { Creation } from '../src/ui/creation/model';
  4   | import type { OpeningPack } from '../src/ui/creation/openingPacks';
  5   | import { goHome } from './helpers/gameLayout';
  6   | 
  7   | const draft = (page: Page) => page.evaluate(() => JSON.parse(localStorage.getItem('heijin.creation.v1')!) as Creation);
  8   | const packs = (page: Page) => page.evaluate(() => Object.keys(localStorage)
  9   |   .filter(key => key.startsWith('heijin.opening-pack.v1:')).map(key => JSON.parse(localStorage.getItem(key)!) as OpeningPack));
  10  | async function saves(page: Page) {
  11  |   return page.evaluate(async () => {
  12  |     const path = '/src/services/storage/saveRepository.ts';
  13  |     const { SaveRepository } = await import(path), repo = await SaveRepository.open();
  14  |     try { return await repo.list(); } finally { repo.close(); }
  15  |   });
  16  | }
  17  | async function seeded(page: Page) {
  18  |   await page.goto('/');
  19  |   await page.evaluate(async () => {
  20  |     const modelPath = '/src/ui/creation/model.ts', packPath = '/src/ui/creation/openingPacks.ts';
  21  |     const { newCreation } = await import(modelPath), { OpeningPackStore } = await import(packPath);
  22  |     const form = newCreation();
  23  |     Object.assign(form, { person: { name: '林岚', age: '29', gender: '女性', appearance: '衣着素净', personality: '谨慎' },
  24  |       customProfession: '修复师', skills: '修补\n记录', skillsSource: 'manual', background: '原始背景', openingPreference: '2008年秋天' });
  25  |     const store = new OpeningPackStore(localStorage); store.save('城市生活', form); store.save('城市生活', form);
  26  |     localStorage.setItem('heijin.creation.v1', JSON.stringify(form));
  27  |   });
  28  |   await page.reload(); await page.getByRole('button', { name: /开始新游戏/ }).click();
  29  | }
  30  | 
  31  | test('完整五步保存、再次套用直达第五步、编辑刷新与正式建档隔离', async ({ page }, info) => {
  32  |   const requests: string[] = [];
  33  |   await page.route('https://**/*', route => { requests.push(route.request().url()); return route.abort(); });
  34  |   await page.goto('/'); await page.getByRole('button', { name: /开始新游戏/ }).click();
  35  |   await page.getByLabel('姓名', { exact: true }).fill('林岚');
  36  |   await page.getByLabel('年龄', { exact: true }).fill('29');
  37  |   await page.getByRole('radio', { name: '女性', exact: true }).check();
  38  |   await page.getByLabel('外貌', { exact: true }).fill('  衣着素净\n手上有淡淡的墨痕。  ');
  39  |   await page.getByLabel('性格', { exact: true }).fill('认真\n偶尔冲动');
  40  |   await page.getByRole('button', { name: /下一步/ }).click();
  41  |   await page.getByLabel('职业名称', { exact: true }).fill('旧书修复师');
  42  |   await page.getByLabel('职业介绍', { exact: true }).fill('修复纸本\n保存社区档案');
  43  |   await page.getByLabel('内置职业技能', { exact: true }).fill('修复\n\n  手写记录  ');
  44  |   await page.getByLabel('长期影响', { exact: true }).fill('长期与社区合作\n保持独立');
  45  |   await page.getByRole('button', { name: '技术与生产', exact: true }).click();
> 46  |   await page.getByRole('radio', { name: '程序员', exact: true }).check();
      |                                                               ^ Error: locator.check: Test timeout of 30000ms exceeded.
  47  |   await page.getByLabel('个人技能与专长').fill('手工编程\n记录工作');
  48  |   await page.getByRole('button', { name: /下一步/ }).click();
  49  |   await page.getByRole('radio', { name: /上海/ }).check();
  50  |   const background = '  成长经历\n' + '家庭、求学与工作经历。\n'.repeat(100) + '背景末行  ';
  51  |   await page.getByLabel('人物背景（可选）').fill(background);
  52  |   await page.getByRole('button', { name: /下一步/ }).click();
  53  |   await page.getByRole('checkbox', { name: '创建一名初始同伴' }).check();
  54  |   for (const [label, value] of Object.entries({ 同伴姓名: '许宁', '同伴年龄（可选）': '28', 同伴身份: '同事',
  55  |     与主角的关系: '相识多年的朋友', 同伴外貌: '短发', 同伴性格: '直率', '同伴能力（一行一项）': '排版\n沟通', 同伴个人经历: '少年在外地读书\n后来回城' })) {
  56  |     await page.getByLabel(label, { exact: true }).fill(value);
  57  |   }
  58  |   await page.getByRole('button', { name: /下一步/ }).click();
  59  |   const preference = '  2008年秋天\n' + '从普通的一天开始，不改写已有家庭设定。\n'.repeat(100) + '偏好末行  ';
  60  |   await page.getByLabel('开局偏好（可选）').fill(preference);
  61  |   const original = await draft(page);
  62  |   await page.getByRole('button', { name: '保存为开局包', exact: true }).click();
  63  |   await page.getByLabel('开局包名称').fill('上海普通人生');
  64  |   await page.getByRole('button', { name: '保存开局包', exact: true }).click();
  65  |   await expect(page.getByRole('status')).toHaveText('开局包已保存');
  66  |   expect(await saves(page)).toEqual([]); expect((await draft(page)).step).toBe(5);
  67  |   const originalPacks = await packs(page);
  68  |   await page.getByRole('button', { name: '返回首页', exact: true }).click();
  69  |   await page.getByRole('button', { name: /开始新游戏/ }).click();
  70  |   await page.getByRole('navigation', { name: '角色创建步骤' }).getByRole('button', { name: /基本信息/ }).click();
  71  |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  72  |   await page.getByRole('radio', { name: /上海普通人生/ }).check();
  73  |   await page.screenshot({ path: `docs/opening-packs/screenshots/${info.project.name}-select.png`, fullPage: true });
  74  |   await page.getByRole('button', { name: '套用开局包', exact: true }).click();
  75  |   await expect(page.getByRole('dialog')).toContainText('将替换当前创角草稿');
  76  |   await page.getByRole('button', { name: '取消', exact: true }).click();
  77  |   expect(await draft(page)).toMatchObject({ saveId: original.saveId, step: 1 });
  78  |   await page.getByRole('button', { name: '套用开局包', exact: true }).click();
  79  |   await page.getByRole('button', { name: '确认替换并套用' }).click();
  80  |   const applied = await draft(page);
  81  |   expect(applied).toEqual({ ...original, saveId: applied.saveId });
  82  |   expect(applied.saveId).not.toBe(original.saveId);
  83  |   await expect(page.getByRole('heading', { name: '确认与开局', exact: true })).toBeVisible();
  84  |   await expect(page.getByLabel('开局偏好（可选）')).toHaveValue(preference);
  85  |   await page.getByText('完整职业表单', { exact: true }).click();
  86  |   await expect(page.getByRole('region', { name: '保留的自定义职业' })).toContainText('旧书修复师');
  87  |   await expect(page.locator('.creation-review')).toContainText('背景末行');
  88  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  89  |   await page.screenshot({ path: `docs/opening-packs/screenshots/${info.project.name}-review.png`, fullPage: true });
  90  |   await page.evaluate(() => scrollTo(0, 0));
  91  |   await page.screenshot({ path: `docs/opening-packs/screenshots/${info.project.name}-review-viewport.png` });
  92  |   await page.getByRole('button', { name: '修改职业', exact: true }).click();
  93  |   await page.getByRole('radio', { name: '自由选择', exact: true }).check();
  94  |   await expect(page.getByLabel('内置职业技能')).toHaveValue(original.customProfile!.skills);
  95  |   await page.getByLabel('内置职业技能').fill('新编辑技能\n修补');
  96  |   await page.getByRole('button', { name: '确认与开局', exact: false }).click();
  97  |   await page.reload();
  98  |   expect(await draft(page)).toMatchObject({ saveId: applied.saveId, step: 5, skills: '新编辑技能\n修补', background, openingPreference: preference });
  99  |   expect(await packs(page)).toEqual(originalPacks); expect(await saves(page)).toEqual([]);
  100 |   await page.getByRole('button', { name: '确认并创建存档', exact: true }).click();
  101 |   await expect(page.locator('.game-layout')).toBeVisible();
  102 |   expect(await saves(page)).toHaveLength(1);
  103 |   const saved = await page.evaluate(async id => {
  104 |     const path = '/src/services/storage/saveRepository.ts';
  105 |     const { SaveRepository } = await import(path), repo = await SaveRepository.open();
  106 |     try { return { state: await repo.load(id), draft: await repo.loadDraft(id) }; } finally { repo.close(); }
  107 |   }, applied.saveId);
  108 |   expect(saved.state.protagonist).toMatchObject({ name: original.person.name, background, skills: ['新编辑技能', '修补'] });
  109 |   expect(saved.state.npc.companion).toMatchObject({ name: '许宁', background: original.companion.background });
  110 |   expect(saved.draft.userInput).toBe(preference); expect(await packs(page)).toEqual(originalPacks);
  111 |   // After the original creation flow finishes, the next new character starts at step 1.
  112 |   await goHome(page); await page.getByRole('button', { name: /开始新游戏/ }).click();
  113 |   expect((await draft(page)).step).toBe(1);
  114 |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  115 |   await page.getByRole('radio', { name: /上海普通人生/ }).check();
  116 |   await page.getByRole('button', { name: '套用开局包', exact: true }).click();
  117 |   await page.getByRole('button', { name: '确认替换并套用' }).click();
  118 |   const fresh = await draft(page);
  119 |   expect(fresh).toEqual({ ...original, saveId: fresh.saveId });
  120 |   expect(fresh.saveId).not.toBe(applied.saveId); expect(await saves(page)).toHaveLength(1);
  121 |   expect(await packs(page)).toEqual(originalPacks);
  122 |   expect(requests).toEqual([]);
  123 | });
  124 | 
  125 | test('同名包独立管理：重命名、取消删除、明确覆盖及确认删除', async ({ page }) => {
  126 |   await seeded(page); const original = await packs(page);
  127 |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  128 |   await expect(page.getByRole('dialog').getByRole('radio')).toHaveCount(2);
  129 |   const choices = page.getByRole('dialog').getByRole('radio');
  130 |   await choices.first().check(); await page.getByRole('button', { name: '重命名', exact: true }).click();
  131 |   await page.getByLabel('开局包名称').fill('重命名包'); await page.getByRole('button', { name: '确认重命名' }).click();
  132 |   await expect(page.getByRole('dialog')).toContainText('重命名包');
  133 |   await page.getByRole('button', { name: '删除', exact: true }).click();
  134 |   await page.getByRole('button', { name: '取消', exact: true }).click(); expect(await packs(page)).toHaveLength(2);
  135 |   await page.getByRole('button', { name: '关闭开局包' }).click();
  136 |   await page.getByRole('button', { name: '确认与开局', exact: false }).click();
  137 |   await page.getByLabel('开局偏好（可选）').fill('新的偏好');
  138 |   await page.getByRole('button', { name: '保存为开局包', exact: true }).click();
  139 |   await page.getByLabel('保存方式').selectOption(original[0].id);
  140 |   await page.getByRole('button', { name: '保存开局包', exact: true }).click();
  141 |   expect((await packs(page))[0].settings.openingPreference).toBe(original[0].settings.openingPreference);
  142 |   await page.getByRole('button', { name: '取消', exact: true }).click();
  143 |   await page.getByRole('button', { name: '保存开局包', exact: true }).click();
  144 |   await page.getByRole('button', { name: '确认覆盖' }).click();
  145 |   const updated = await packs(page);
  146 |   expect(updated[0]).toMatchObject({ id: original[0].id, name: '重命名包', settings: { openingPreference: '新的偏好' } });
```
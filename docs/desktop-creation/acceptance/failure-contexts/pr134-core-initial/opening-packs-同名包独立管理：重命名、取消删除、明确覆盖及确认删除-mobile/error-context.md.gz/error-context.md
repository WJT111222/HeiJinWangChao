# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: opening-packs.spec.ts >> 同名包独立管理：重命名、取消删除、明确覆盖及确认删除
- Location: e2e/opening-packs.spec.ts:125:1

# Error details

```
Error: locator.selectOption: Error: Element is not a <select> element
Call log:
  - waiting for getByLabel('保存方式')
    - locator resolved to <div role="radiogroup" aria-label="保存方式">…</div>
  - attempting select option action
    - waiting for element to be visible and enabled

```

# Page snapshot

```yaml
- main [ref=f1e4]:
  - generic [ref=f1e5]:
    - button "‹ 首页" [ref=f1e6] [cursor=pointer]
    - generic [ref=f1e7]:
      - generic [ref=f1e8]: NEW LIFE
      - text: 空白车票
  - button "展开完整车票预览" [ref=f1e9] [cursor=pointer]:
    - generic [ref=f1e11]:
      - generic [ref=f1e12]:
        - generic [ref=f1e13]:
          - generic [ref=f1e14]: FROM
          - generic "林岚" [ref=f1e15]
        - generic [ref=f1e17]:
          - generic [ref=f1e18]: TO
          - generic [ref=f1e19]: 重庆
      - generic "29 · 女性 · 修复师" [ref=f1e20]: 29 岁 · 女性 · 修复师
    - generic [ref=f1e21]:
      - generic [ref=f1e22]: STATION
      - generic [ref=f1e23]: "05"
    - generic [aria-hidden] [ref=f1e26]: 展开 ›
  - navigation "角色创建步骤" [ref=f1e27]:
    - button "基本信息" [ref=f1e28] [cursor=pointer]:
      - generic [ref=f1e29]: ✓
      - text: 基本
    - button "职业与能力" [ref=f1e30] [cursor=pointer]:
      - generic [ref=f1e31]: ✓
      - text: 职业
    - button "城市与背景" [ref=f1e32] [cursor=pointer]:
      - generic [ref=f1e33]: ✓
      - text: 城市
    - button "初始同伴" [ref=f1e34] [cursor=pointer]:
      - generic [ref=f1e35]: ✓
      - text: 同伴
    - button "确认与开局" [ref=f1e36] [cursor=pointer]: 确认
  - generic [ref=f1e38]:
    - button "保存为开局包" [ref=f1e39] [cursor=pointer]
    - dialog [active] [ref=f1e40]:
      - generic [ref=f1e43]:
        - generic [aria-hidden] [ref=f1e44]: 包
        - generic [ref=f1e45]:
          - paragraph [ref=f1e46]: HEIJIN / ARCHIVE
          - heading "保存为开局包" [level=2] [ref=f1e47]
        - button "关闭开局包" [ref=f1e48] [cursor=pointer]:
          - text: 关闭
          - generic [aria-hidden] [ref=f1e49]: ×
      - generic [ref=f1e51]:
        - group "保存方式" [ref=f1e52]:
          - radiogroup "保存方式" [ref=f1e54]:
            - radio "新建开局包" [checked] [ref=f1e55] [cursor=pointer]
            - radio "覆盖：重命名包" [ref=f1e56] [cursor=pointer]
            - radio "覆盖：城市生活" [ref=f1e57] [cursor=pointer]
        - generic [ref=f1e58]:
          - text: 开局包名称
          - textbox "开局包名称" [ref=f1e59]
        - button "取消" [ref=f1e60] [cursor=pointer]
        - button "保存开局包" [ref=f1e61] [cursor=pointer]
  - generic [ref=f1e62]:
    - generic [ref=f1e63]:
      - generic [ref=f1e64]:
        - generic [ref=f1e65]:
          - paragraph [ref=f1e66]: STEP 05 / 05
          - heading "确认与开局" [level=2] [ref=f1e67]
        - generic [ref=f1e68]: 填写内容自动保留
      - article "人生车票" [ref=f1e69]:
        - generic [ref=f1e70]:
          - generic [ref=f1e71]:
            - generic [ref=f1e72]: 重庆
            - generic [ref=f1e73]: 29°33′N
            - generic [ref=f1e74]: NEW LIFE
          - generic [ref=f1e75]:
            - generic [ref=f1e76]:
              - generic [ref=f1e77]: FROM
              - text: 林岚
            - generic [aria-hidden] [ref=f1e78]: 单程
            - generic [ref=f1e79]:
              - generic [ref=f1e80]: TO
              - text: 重庆
          - generic [ref=f1e81]:
            - generic [ref=f1e82]:
              - term [ref=f1e83]: 年龄
              - definition [ref=f1e84]: "29"
            - generic [ref=f1e85]:
              - term [ref=f1e86]: 性别
              - definition [ref=f1e87]: 女性
            - generic [ref=f1e88]:
              - term [ref=f1e89]: 职业
              - definition [ref=f1e90]: 修复师
          - generic [aria-hidden] [ref=f1e91]:
            - generic [ref=f1e108]: 29°33′N · 106°33′E
            - generic [ref=f1e109]: 山城 · 江雾 · 轻轨
            - generic [ref=f1e110]:
              - text: 待开局
              - generic [ref=f1e111]: BOARDING
        - generic [ref=f1e114]:
          - text: 确认并创建存档
          - generic [ref=f1e115]: ↓ 按住票根往下撕 · 可能产生第三方 API 费用
      - generic [ref=f1e117]:
        - group [ref=f1e118]:
          - generic "01 人物资料 ›" [ref=f1e119] [cursor=pointer]:
            - generic [ref=f1e120]: "01"
            - generic [ref=f1e121]: 人物资料
            - text: ›
          - button "修改基本信息" [ref=f1e123] [cursor=pointer]
          - generic [ref=f1e124]:
            - generic [ref=f1e125]:
              - term [ref=f1e126]: 姓名
              - definition [ref=f1e127]: 林岚
            - generic [ref=f1e128]:
              - term [ref=f1e129]: 年龄
              - definition [ref=f1e130]: "29"
            - generic [ref=f1e131]:
              - term [ref=f1e132]: 性别
              - definition [ref=f1e133]: 女性
            - generic [ref=f1e134]:
              - term [ref=f1e135]: 外貌
              - definition [ref=f1e136]: 衣着素净
            - generic [ref=f1e137]:
              - term [ref=f1e138]: 性格
              - definition [ref=f1e139]: 谨慎
            - generic [ref=f1e140]:
              - term [ref=f1e141]: 外貌模板
              - definition [ref=f1e142]: 自由选择
            - generic [ref=f1e143]:
              - term [ref=f1e144]: 性格模板
              - definition [ref=f1e145]: 自由选择
        - group [ref=f1e146]:
          - generic "02 职业与起点 ›" [ref=f1e147] [cursor=pointer]:
            - generic [ref=f1e148]: "02"
            - generic [ref=f1e149]: 职业与起点
            - text: ›
        - group [ref=f1e150]:
          - generic "03 初始同伴 ›" [ref=f1e151] [cursor=pointer]:
            - generic [ref=f1e152]: "03"
            - generic [ref=f1e153]: 初始同伴
            - text: ›
        - group [ref=f1e154]:
          - generic "04 开局准备 ›" [ref=f1e155] [cursor=pointer]:
            - generic [ref=f1e156]: "04"
            - generic [ref=f1e157]: 开局准备
            - text: ›
      - generic [ref=f1e158]:
        - text: 开局偏好（可选）
        - textbox "开局偏好（可选）" [ref=f1e159]:
          - /placeholder: 对故事起点的期待，将随开局草稿保存。
          - text: 新的偏好
      - paragraph [ref=f1e160]: 确认后创建存档并自动开始开局，可能产生第三方 API 费用。按已启用的阶段顺序生成候选，不会自动结算；未配置 AI 时会安全停止，设置后由你主动继续。
    - generic [ref=f1e161]:
      - button "上一步" [ref=f1e162] [cursor=pointer]
      - generic [ref=f1e163]: 可能产生第三方 API 费用
      - button "确认并创建存档" [ref=f1e164] [cursor=pointer]
```

# Test source

```ts
  39  |   await page.getByLabel('性格', { exact: true }).fill('认真\n偶尔冲动');
  40  |   await page.getByRole('button', { name: /下一步/ }).click();
  41  |   await page.getByLabel('职业名称', { exact: true }).fill('旧书修复师');
  42  |   await page.getByLabel('职业介绍', { exact: true }).fill('修复纸本\n保存社区档案');
  43  |   await page.getByLabel('内置职业技能', { exact: true }).fill('修复\n\n  手写记录  ');
  44  |   await page.getByLabel('长期影响', { exact: true }).fill('长期与社区合作\n保持独立');
  45  |   await page.getByRole('button', { name: '技术与生产', exact: true }).click();
  46  |   await page.getByRole('radio', { name: '程序员', exact: true }).check();
  47  |   await page.getByLabel('个人技能与专长').fill('手工编程\n记录工作');
  48  |   await page.getByRole('button', { name: /下一步/ }).click();
  49  |   await page.getByRole('radio', { name: /上海/ }).check();
  50  |   const background = '  成长经历\n' + '家庭、求学与工作经历。\n'.repeat(100) + '背景末行  ';
  51  |   await page.getByLabel('人物背景（可选）').fill(background);
  52  |   await page.getByRole('button', { name: /下一步/ }).click();
  53  |   await page.getByRole('checkbox', { name: '创建一名初始同伴' }).check();
  54  |   for (const [label, value] of Object.entries({ 同伴姓名: '许宁', '同伴年龄（可选）': '28', 同伴身份: '同事',
  55  |     与主角的关系: '相识多年的朋友', 同伴外貌: '短发', 同伴性格: '直率', '同伴能力（一行一项）': '排版\n沟通', 同伴个人经历: '少年在外地读书\n后来回城' })) {
  56  |     await page.getByLabel(label, { exact: true }).fill(value);
  57  |   }
  58  |   await page.getByRole('button', { name: /下一步/ }).click();
  59  |   const preference = '  2008年秋天\n' + '从普通的一天开始，不改写已有家庭设定。\n'.repeat(100) + '偏好末行  ';
  60  |   await page.getByLabel('开局偏好（可选）').fill(preference);
  61  |   const original = await draft(page);
  62  |   await page.getByRole('button', { name: '保存为开局包', exact: true }).click();
  63  |   await page.getByLabel('开局包名称').fill('上海普通人生');
  64  |   await page.getByRole('button', { name: '保存开局包', exact: true }).click();
  65  |   await expect(page.getByRole('status')).toHaveText('开局包已保存');
  66  |   expect(await saves(page)).toEqual([]); expect((await draft(page)).step).toBe(5);
  67  |   const originalPacks = await packs(page);
  68  |   await page.getByRole('button', { name: '返回首页', exact: true }).click();
  69  |   await page.getByRole('button', { name: /开始新游戏/ }).click();
  70  |   await page.getByRole('navigation', { name: '角色创建步骤' }).getByRole('button', { name: /基本信息/ }).click();
  71  |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  72  |   await page.getByRole('radio', { name: /上海普通人生/ }).check();
  73  |   await page.screenshot({ path: `docs/opening-packs/screenshots/${info.project.name}-select.png`, fullPage: true });
  74  |   await page.getByRole('button', { name: '套用开局包', exact: true }).click();
  75  |   await expect(page.getByRole('dialog')).toContainText('将替换当前创角草稿');
  76  |   await page.getByRole('button', { name: '取消', exact: true }).click();
  77  |   expect(await draft(page)).toMatchObject({ saveId: original.saveId, step: 1 });
  78  |   await page.getByRole('button', { name: '套用开局包', exact: true }).click();
  79  |   await page.getByRole('button', { name: '确认替换并套用' }).click();
  80  |   const applied = await draft(page);
  81  |   expect(applied).toEqual({ ...original, saveId: applied.saveId });
  82  |   expect(applied.saveId).not.toBe(original.saveId);
  83  |   await expect(page.getByRole('heading', { name: '确认与开局', exact: true })).toBeVisible();
  84  |   await expect(page.getByLabel('开局偏好（可选）')).toHaveValue(preference);
  85  |   await page.getByText('完整职业表单', { exact: true }).click();
  86  |   await expect(page.getByRole('region', { name: '保留的自定义职业' })).toContainText('旧书修复师');
  87  |   await expect(page.locator('.creation-review')).toContainText('背景末行');
  88  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  89  |   await page.screenshot({ path: `docs/opening-packs/screenshots/${info.project.name}-review.png`, fullPage: true });
  90  |   await page.evaluate(() => scrollTo(0, 0));
  91  |   await page.screenshot({ path: `docs/opening-packs/screenshots/${info.project.name}-review-viewport.png` });
  92  |   await page.getByRole('button', { name: '修改职业', exact: true }).click();
  93  |   await page.getByRole('radio', { name: '自由选择', exact: true }).check();
  94  |   await expect(page.getByLabel('内置职业技能')).toHaveValue(original.customProfile!.skills);
  95  |   await page.getByLabel('内置职业技能').fill('新编辑技能\n修补');
  96  |   await page.getByRole('button', { name: '确认与开局', exact: false }).click();
  97  |   await page.reload();
  98  |   expect(await draft(page)).toMatchObject({ saveId: applied.saveId, step: 5, skills: '新编辑技能\n修补', background, openingPreference: preference });
  99  |   expect(await packs(page)).toEqual(originalPacks); expect(await saves(page)).toEqual([]);
  100 |   await page.getByRole('button', { name: '确认并创建存档', exact: true }).click();
  101 |   await expect(page.locator('.game-layout')).toBeVisible();
  102 |   expect(await saves(page)).toHaveLength(1);
  103 |   const saved = await page.evaluate(async id => {
  104 |     const path = '/src/services/storage/saveRepository.ts';
  105 |     const { SaveRepository } = await import(path), repo = await SaveRepository.open();
  106 |     try { return { state: await repo.load(id), draft: await repo.loadDraft(id) }; } finally { repo.close(); }
  107 |   }, applied.saveId);
  108 |   expect(saved.state.protagonist).toMatchObject({ name: original.person.name, background, skills: ['新编辑技能', '修补'] });
  109 |   expect(saved.state.npc.companion).toMatchObject({ name: '许宁', background: original.companion.background });
  110 |   expect(saved.draft.userInput).toBe(preference); expect(await packs(page)).toEqual(originalPacks);
  111 |   // After the original creation flow finishes, the next new character starts at step 1.
  112 |   await goHome(page); await page.getByRole('button', { name: /开始新游戏/ }).click();
  113 |   expect((await draft(page)).step).toBe(1);
  114 |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  115 |   await page.getByRole('radio', { name: /上海普通人生/ }).check();
  116 |   await page.getByRole('button', { name: '套用开局包', exact: true }).click();
  117 |   await page.getByRole('button', { name: '确认替换并套用' }).click();
  118 |   const fresh = await draft(page);
  119 |   expect(fresh).toEqual({ ...original, saveId: fresh.saveId });
  120 |   expect(fresh.saveId).not.toBe(applied.saveId); expect(await saves(page)).toHaveLength(1);
  121 |   expect(await packs(page)).toEqual(originalPacks);
  122 |   expect(requests).toEqual([]);
  123 | });
  124 | 
  125 | test('同名包独立管理：重命名、取消删除、明确覆盖及确认删除', async ({ page }) => {
  126 |   await seeded(page); const original = await packs(page);
  127 |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  128 |   await expect(page.getByRole('dialog').getByRole('radio')).toHaveCount(2);
  129 |   const choices = page.getByRole('dialog').getByRole('radio');
  130 |   await choices.first().check(); await page.getByRole('button', { name: '重命名', exact: true }).click();
  131 |   await page.getByLabel('开局包名称').fill('重命名包'); await page.getByRole('button', { name: '确认重命名' }).click();
  132 |   await expect(page.getByRole('dialog')).toContainText('重命名包');
  133 |   await page.getByRole('button', { name: '删除', exact: true }).click();
  134 |   await page.getByRole('button', { name: '取消', exact: true }).click(); expect(await packs(page)).toHaveLength(2);
  135 |   await page.getByRole('button', { name: '关闭开局包' }).click();
  136 |   await page.getByRole('button', { name: '确认与开局', exact: false }).click();
  137 |   await page.getByLabel('开局偏好（可选）').fill('新的偏好');
  138 |   await page.getByRole('button', { name: '保存为开局包', exact: true }).click();
> 139 |   await page.getByLabel('保存方式').selectOption(original[0].id);
      |                                 ^ Error: locator.selectOption: Error: Element is not a <select> element
  140 |   await page.getByRole('button', { name: '保存开局包', exact: true }).click();
  141 |   expect((await packs(page))[0].settings.openingPreference).toBe(original[0].settings.openingPreference);
  142 |   await page.getByRole('button', { name: '取消', exact: true }).click();
  143 |   await page.getByRole('button', { name: '保存开局包', exact: true }).click();
  144 |   await page.getByRole('button', { name: '确认覆盖' }).click();
  145 |   const updated = await packs(page);
  146 |   expect(updated[0]).toMatchObject({ id: original[0].id, name: '重命名包', settings: { openingPreference: '新的偏好' } });
  147 |   expect(updated[1]).toEqual(original[1]);
  148 |   await page.getByRole('navigation', { name: '角色创建步骤' }).getByRole('button', { name: /基本信息/ }).click();
  149 |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  150 |   await page.getByRole('radio', { name: /重命名包/ }).check();
  151 |   await page.getByRole('button', { name: '删除', exact: true }).click();
  152 |   await expect(page.getByRole('dialog')).toContainText('不可撤销');
  153 |   await page.getByRole('button', { name: '确认删除', exact: true }).click();
  154 |   await page.getByRole('button', { name: '关闭开局包' }).click(); await page.reload();
  155 |   expect(await packs(page)).toEqual([original[1]]); expect(await saves(page)).toEqual([]);
  156 | });
  157 | 
  158 | test('损坏包隔离，存储拒绝不误报成功、不丢失有效包或当前草稿', async ({ page }) => {
  159 |   await seeded(page); const before = await packs(page), original = await draft(page);
  160 |   await page.evaluate(() => localStorage.setItem('heijin.opening-pack.v1:broken', '{'));
  161 |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  162 |   await expect(page.getByRole('dialog')).toContainText('1 份开局包无法读取');
  163 |   await expect(page.getByRole('dialog').getByRole('radio')).toHaveCount(2);
  164 |   await page.getByRole('button', { name: '关闭开局包' }).click();
  165 |   await page.getByRole('button', { name: '确认与开局', exact: false }).click();
  166 |   await page.getByRole('button', { name: '保存为开局包', exact: true }).click();
  167 |   await page.getByLabel('开局包名称').fill('不能保存');
  168 |   await page.evaluate(() => {
  169 |     const original = Storage.prototype.setItem;
  170 |     Storage.prototype.setItem = function(key, value) {
  171 |       if (key.startsWith('heijin.opening-pack.v1:')) throw new DOMException('quota', 'QuotaExceededError');
  172 |       original.call(this, key, value);
  173 |     };
  174 |   });
  175 |   await page.getByRole('button', { name: '保存开局包', exact: true }).click();
  176 |   await expect(page.getByRole('dialog').getByRole('alert')).toContainText('操作未完成');
  177 |   await expect(page.getByText('开局包已保存', { exact: true })).toHaveCount(0);
  178 |   expect(await draft(page)).toEqual({ ...original, step: 5 });
  179 |   expect(await page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('heijin.opening-pack.v1:')).length)).toBe(3);
  180 |   await page.getByRole('button', { name: '关闭开局包' }).click(); await page.reload();
  181 |   expect(await page.evaluate(() => localStorage.getItem('heijin.opening-pack.v1:broken'))).toBe('{');
  182 |   const valid = await page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('heijin.opening-pack.v1:') && !key.endsWith(':broken')).map(key => JSON.parse(localStorage.getItem(key)!)));
  183 |   expect(valid).toEqual(before); expect(await saves(page)).toEqual([]);
  184 | });
  185 | 
  186 | test('读取被拒绝时明确反馈，恢复权限后仍可查看有效包', async ({ page }) => {
  187 |   await seeded(page);
  188 |   await page.evaluate(() => {
  189 |     const original = Storage.prototype.getItem;
  190 |     Storage.prototype.getItem = function(key) {
  191 |       if (key.startsWith('heijin.opening-pack.v1:')) throw new DOMException('denied', 'SecurityError');
  192 |       return original.call(this, key);
  193 |     };
  194 |   });
  195 |   await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  196 |   await expect(page.locator('.opening-packs').getByRole('alert')).toContainText('操作未完成');
  197 |   await expect(page.getByRole('dialog')).toHaveCount(0);
  198 |   await page.reload(); await page.getByRole('button', { name: '我的开局包', exact: true }).click();
  199 |   await expect(page.getByRole('dialog').getByRole('radio')).toHaveCount(2);
  200 | });
  201 | 
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: opening-packs.spec.ts >> 完整五步保存、再次套用直达第五步、编辑刷新与正式建档隔离
- Location: e2e/opening-packs.spec.ts:31:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.isVisible: Target page, context or browser has been closed
```

# Page snapshot

```yaml
- main [ref=f1e2]:
  - generic "城市与当前场景" [ref=f1e3]:
    - generic [ref=f1e4]:
      - generic [aria-hidden] [ref=f1e5]: 黑
      - generic [ref=f1e6]:
        - heading "上海" [level=1] [ref=f1e7]
        - generic "SHANGHAI · 魔都" [ref=f1e8]
    - generic [ref=f1e9]:
      - generic "上海" [ref=f1e10]: 当前地点
      - generic "开局时间待确认 --:--" [ref=f1e13]:
        - time [ref=f1e14]: "--:--"
        - generic [ref=f1e15]: 开局时间待确认
      - generic [ref=f1e17]:
        - button "查看天气详情" [ref=f1e18] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e19]: 晴
          - generic [ref=f1e20]: 天气
          - generic [ref=f1e21]: 天气待确认
        - button "查看环境详情" [ref=f1e22] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e23]: 境
          - generic [ref=f1e24]: 环境
          - generic [ref=f1e25]: 环境待确认
  - complementary "主角信息" [ref=f1e26]:
    - generic [ref=f1e27]:
      - generic [aria-hidden] [ref=f1e28]: 林
      - generic [ref=f1e29]:
        - heading "林岚" [level=2] [ref=f1e30]
        - paragraph [ref=f1e31]: 29 岁 · 女性 · 旧书修复师
    - paragraph [ref=f1e32]: 资金
    - generic [ref=f1e33]:
      - generic [ref=f1e34]:
        - generic [ref=f1e35]: 现金
        - strong [ref=f1e36]: 未确认
      - generic [ref=f1e37]:
        - generic [ref=f1e38]: 线上资金
        - strong [ref=f1e39]: 未确认
    - paragraph [ref=f1e40]: 状态
    - generic [ref=f1e41]:
      - generic "待开局确认" [ref=f1e42]:
        - generic [ref=f1e43]: 身体
        - text: 待开局确认
      - generic "待开局确认" [ref=f1e44]:
        - generic [ref=f1e45]: 情绪
        - text: 待开局确认
    - region "当前穿戴与装备" [ref=f1e46]:
      - paragraph [ref=f1e47]: 当前穿戴与装备
      - generic [ref=f1e48]:
        - generic [ref=f1e49]:
          - term [ref=f1e50]: 上衣
          - definition [ref=f1e51]: 无
        - generic [ref=f1e52]:
          - term [ref=f1e53]: 下装
          - definition [ref=f1e54]: 无
        - generic [ref=f1e55]:
          - term [ref=f1e56]: 鞋子
          - definition [ref=f1e57]: 无
        - generic [ref=f1e58]:
          - term [ref=f1e59]: 饰品
          - definition [ref=f1e60]: 无
        - generic [ref=f1e61]:
          - term [ref=f1e62]: 主武器
          - definition [ref=f1e63]: 无
        - generic [ref=f1e64]:
          - term [ref=f1e65]: 副武器
          - definition [ref=f1e66]: 无
        - generic [ref=f1e67]:
          - term [ref=f1e68]: 载具
          - definition [ref=f1e69]: 无
    - generic [ref=f1e70]:
      - button "人物档案" [ref=f1e71] [cursor=pointer]
      - button "经济与资产" [ref=f1e72] [cursor=pointer]
  - region "剧情与行动" [ref=f1e73]:
    - generic "正文阅读区域" [ref=f1e74]:
      - generic [ref=f1e75]:
        - generic [ref=f1e76]: THE STORY
        - generic [ref=f1e77]: 等待开局
      - generic [ref=f1e78]:
        - generic [aria-hidden] [ref=f1e79]: 序
        - paragraph [ref=f1e80]: A CITY. A TURNING POINT.
        - heading "故事，尚未落笔。" [level=1] [ref=f1e81]
        - paragraph [ref=f1e82]: 你的资料已保存。配置 AI 渠道后，即可生成这座城市中的第一幕。
      - paragraph [ref=f1e83]: 行动建议将在正文生成后显示。
    - generic [ref=f1e84]:
      - region "三阶段工作流" [ref=f1e86]:
        - generic [ref=f1e88]:
          - status [ref=f1e89]: 三阶段 · 生成失败 · 查看详情
          - generic [ref=f1e90]:
            - button "01 正文 · 待生成" [ref=f1e91] [cursor=pointer]:
              - generic [ref=f1e93]:
                - generic [ref=f1e94]: "01"
                - text: 正文
                - emphasis [ref=f1e95]: · 待生成
            - button "02 变量 · 待生成" [ref=f1e96] [cursor=pointer]:
              - generic [ref=f1e98]:
                - generic [ref=f1e99]: "02"
                - text: 变量
                - emphasis [ref=f1e100]: · 待生成
            - button "03 动态世界 · 待生成" [ref=f1e101] [cursor=pointer]:
              - generic [ref=f1e103]:
                - generic [ref=f1e104]: "03"
                - text: 动态世界
                - emphasis [ref=f1e105]: · 待生成
          - button "详情" [ref=f1e106] [cursor=pointer]
      - generic [ref=f1e107]:
        - generic [ref=f1e109]:
          - button "撤回" [disabled] [ref=f1e110]
          - button "生成开局正文" [ref=f1e111] [cursor=pointer]
        - generic [ref=f1e112]: 你的行动
        - textbox "你的行动" [ref=f1e113]:
          - /placeholder: 填写你的行动；发送后生成三阶段并自动结算
        - generic [ref=f1e114]:
          - button "发送" [disabled] [ref=f1e115]
          - generic [ref=f1e116]: Ctrl + Enter
  - complementary "世界资料" [ref=f1e117]:
    - heading "世界资料" [level=2] [ref=f1e118]
    - navigation "世界资料分类" [ref=f1e119]:
      - button "NPC" [ref=f1e120] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e121]: 人
      - button "势力组织" [ref=f1e123] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e124]: 势
      - button "地图" [ref=f1e126] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e127]: 图
      - button "物品栏" [ref=f1e129] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e130]: 物
      - button "世界事件" [ref=f1e132] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e133]: 事
      - button "历史时间轴" [ref=f1e135] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e136]: 史
      - button "记忆" [ref=f1e138] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e139]: 忆
    - navigation "系统操作" [ref=f1e141]:
      - button "设置" [ref=f1e142] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e143]: 设
      - button "返回首页" [ref=f1e145] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e146]: 归
```

# Test source

```ts
  1  | import { expect } from '@playwright/test';
  2  | import type { Page } from '@playwright/test';
  3  | export async function openLibrary(page: Page) {
> 4  |   if (await page.locator('.mobile-home').isVisible()) {
     |                                          ^ Error: locator.isVisible: Target page, context or browser has been closed
  5  |     await expect(page.locator('.mh-rail')).toBeVisible(); return;
  6  |   }
  7  |   const home = page.locator('.home-experience');
  8  |   await expect(home).toBeVisible();
  9  |   if (await home.count()) {
  10 |     const library = home.locator('.library');
  11 |     if (await library.getAttribute('hidden') !== null) await home.locator('.btn-library').click();
  12 |     await expect(library).toHaveCSS('transform','none');
  13 |   }
  14 | }
  15 | 
  16 | /** Enter through whichever production home is active; never bypass the UI route. */
  17 | export async function openStoredSave(page: Page) {
  18 |   await openLibrary(page);
  19 |   if (await page.locator('.mobile-home').isVisible()) {
  20 |     await page.locator('.mh-primary').click();
  21 |   } else await page.getByRole('button', { name: /读取存档/ }).first().click();
  22 | }
  23 | 
```
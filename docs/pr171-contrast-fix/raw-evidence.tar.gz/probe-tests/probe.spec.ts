import {test,expect} from '../../pr171-review/e2e/helpers/test';
import {openWorkflow,openWorkflowStage,openStageCandidates} from '../../pr171-review/e2e/helpers/gameLayout';
import type {Page} from '@playwright/test';
import {readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
const root='/workspace/pr171-contrast-fix-20261116';
const cssPath='src/ui/game/day-appearance.css';
const baseCSS=execFileSync('git',['show',`fbbb289c5e40103d7c3f89fa1874e8f24a3206b8:${cssPath}`],{cwd:'/workspace/pr171-review',encoding:'utf8'});
const headCSS=()=>readFile('/workspace/pr171-review/'+cssPath,'utf8');
async function seed(page:Page,ready:boolean){
 await page.goto('/');await page.evaluate(async ready=>{
  const paths=['/src/services/storage/saveRepository.ts','/src/tests/fixtures/world.ts','/src/tests/fixtures/turn.ts','/src/ui/settings/model.ts','/src/services/ai/configuration.ts','/src/services/ai/credentials.ts'];
  const [{SaveRepository},{worldState},{completeDraft},{defaultSettings,settingsKey},{newChannel,defaultAiConfig,saveAiConfig},{CredentialVault}]=await Promise.all(paths.map(p=>import(p)));
  const settings=defaultSettings();settings.display.appearance='day';settings.prompts.minNarrativeChars=5;settings.prompts.actionOptions=false;for(const s of Object.values(settings.memory.summaries) as {automatic:boolean}[])s.automatic=false;
  localStorage.setItem(settingsKey,JSON.stringify(settings));const channel=newChannel(),config=defaultAiConfig();channel.baseUrl='https://review171.invalid/v1';config.channels=[channel];config.routes.story={channelId:channel.id,modelId:'story'};saveAiConfig(localStorage,config);new CredentialVault(sessionStorage,localStorage).set(channel.id,'synthetic-review-key');
  const r=await SaveRepository.open();try{await r.create(worldState());const done=await r.commitTurn({draft:await completeDraft(r),nextAction:'',useVariableStage:true,useWorldStage:true});await r.bindTurnAction(done.draft,'观察站台',true,true);if(ready){const state=await r.load('save-a');await completeDraft(r,{variables:{commands:[{type:'SetWorldClock',commandId:'clock-next',worldClock:new Date(Date.parse(state.worldClock)+60000).toISOString(),evidence:'经过一分钟'}],rejectedSuggestions:[],unresolved:[]}});}}finally{r.close();}
 },ready);await page.goto('/#game/save-a');await page.reload();await expect(page.getByTestId('story-reader')).toBeVisible();
}
async function style(page:Page,selector:string){return page.locator(selector).first().evaluate(el=>{
 const rgba=(s:string)=>{const values=s.match(/[\d.]+/g)?.map(Number)??[0,0,0,0];return[values[0],values[1],values[2],values[3]??1]};
 const over=(a:number[],b:number[])=>[a[0]*a[3]+b[0]*(1-a[3]),a[1]*a[3]+b[1]*(1-a[3]),a[2]*a[3]+b[2]*(1-a[3]),1];
 let background=[255,255,255,1],opacity=1;const chain:Element[]=[];for(let p:Element|null=el;p;p=p.parentElement)chain.unshift(p);
 for(const p of chain){const s=getComputedStyle(p);background=over(rgba(s.backgroundColor),background);opacity*=Number(s.opacity);}
 const s=getComputedStyle(el),fg=over(rgba(s.color),background);
 const lum=(rgb:number[])=>rgb.slice(0,3).map(c=>c/255).map(c=>c<=.04045?c/12.92:((c+.055)/1.055)**2.4).reduce((a,c,i)=>a+c*[.2126,.7152,.0722][i],0);
 const contrast=(a:number[],b:number[])=>{const x=lum(a),y=lum(b);return(Math.max(x,y)+.05)/(Math.min(x,y)+.05)};
 return{text:el.textContent?.trim(),color:s.color,background:s.backgroundColor,image:s.backgroundImage,effectiveBackground:background,opacity,fontSize:s.fontSize,fontWeight:s.fontWeight,disabled:(el as HTMLButtonElement).disabled,contrast:s.backgroundImage==='none'?contrast(fg,background):null,variables:Object.fromEntries(['--gold','--feedback-err','--feedback-warn','--feedback-info','--feedback-ok','--warn-text'].map(k=>[k,s.getPropertyValue(k).trim()]))};
});}
async function collect(page:Page,selectors:string[]){const result:Record<string,unknown>={};for(const s of selectors)if(await page.locator(s).first().isVisible())result[s]=await style(page,s);return result;}
async function compare(page:Page,name:string,selectors:string[],project:string){
 const sheet=page.locator('style[data-vite-dev-id$="/src/ui/game/day-appearance.css"]');await expect(sheet).toHaveCount(1);
 const head=await collect(page,selectors);await page.screenshot({path:`${root}/${project}-${name}-head.png`});
 await sheet.evaluate((el,css)=>{el.textContent=css;},baseCSS);const base=await collect(page,selectors);await page.screenshot({path:`${root}/${project}-${name}-base.png`});
 await sheet.evaluate((el,css)=>{el.textContent=css;},await headCSS());await writeFile(`${root}/${project}-${name}.json`,JSON.stringify({head,base},null,2));
}
test('真实待结算候选的操作按钮与状态对比度',async({page},info)=>{
 await seed(page,true);await openWorkflow(page);await compare(page,'ready',['.workflow-primary button.primary','.wf-node','.wf-sw input'],info.project.name);

 // Compare native disabled pseudo-state and night CSS exactly against the reviewed HEAD.
 // This is a style probe; the committed regression separately exercises the real Commit callback.
 const target=page.locator('.workflow-primary button.primary');
 const sheet=page.locator('style[data-vite-dev-id$="/src/ui/game/day-appearance.css"]');
 const states=[];
 for(const [theme,disabled] of [['night',false],['night',true],['day',true]] as const){
  await page.evaluate(theme=>{document.documentElement.dataset.appearance=theme;},theme);
  await target.evaluate((el,disabled)=>{(el as HTMLButtonElement).disabled=disabled;},disabled);
  const select=(value:Awaited<ReturnType<typeof style>>)=>({color:value.color,background:value.background,image:value.image,opacity:value.opacity,disabled:value.disabled});
  const head=select(await style(page,'.workflow-primary button.primary'));
  await sheet.evaluate((el,css)=>{el.textContent=css;},baseCSS);
  const base=select(await style(page,'.workflow-primary button.primary'));
  expect(head).toEqual(base);states.push({theme,disabled,head,base});
  await sheet.evaluate((el,css)=>{el.textContent=css;},await headCSS());
 }
 await writeFile(`${root}/${info.project.name}-unchanged-states.json`,JSON.stringify(states,null,2));
 await page.evaluate(()=>{document.documentElement.dataset.appearance='day';});
 await target.evaluate(el=>{(el as HTMLButtonElement).disabled=false;});
 await openStageCandidates(page,'variables');await compare(page,'candidate',['.wf-stats .l-ok b','.wf-stats .l-warn b','.wf-pill[data-s=ok]','.wf-dt-act button','.workflow-primary button.primary'],info.project.name);
});
test('真实正文失败的安全诊断与恢复按钮对比度',async({page},info)=>{
 await seed(page,false);let calls=0;await page.route('https://review171.invalid/**',async route=>{calls++;await route.fulfill({contentType:'text/event-stream',body:'data: '+JSON.stringify({choices:[{delta:{content:'<thinking>保持现场</thinking><正文>短</正文><短期记忆>观察</短期记忆><变量规划>[]</变量规划>'}}]})+'\n\ndata: [DONE]\n\n'});});
 await page.locator('.composer-workflow-action').click();await expect(page.locator('.workflow-summary')).toContainText('失败');const error=page.locator('dialog.mobile-diagnostics-sheet[open]');if(await error.isVisible())await page.keyboard.press('Escape');
 await openWorkflowStage(page,'story');await compare(page,'failure',['.wf-banner','.wf-banner-msg p','.wf-pill[data-s=fail]','.wf-count','.wf-dt-act button','.workflow-primary button.primary','.workflow-stages li[data-s=fail] small'],info.project.name);expect(calls).toBe(1);
});

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: automatic-settlement.spec.ts >> #190 eventCommands 的非法重复组织命令必须整批拒绝，主动修正后仅重试World
- Location: e2e/automatic-settlement.spec.ts:242:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByTestId('runtime-log')
Expected: visible
Error: strict mode violation: getByTestId('runtime-log') resolved to 2 elements:
    1) <details open="" class="runtime-log" data-testid="runtime-log">…</details> aka getByRole('tabpanel', { name: '运行日志' }).getByTestId('runtime-log')
    2) <details open="" class="runtime-log" data-testid="runtime-log">…</details> aka getByRole('region', { name: '三阶段详情' }).getByTestId('runtime-log')

Call log:
  - Expect "toBeVisible" getByTestId('runtime-log') with timeout 5000ms
  - waiting for getByTestId('runtime-log')

```

# Page snapshot

```yaml
- generic:
  - generic [ref=f1e1]:
    - banner:
      - button "打开游戏菜单" [ref=f1e2] [cursor=pointer]: ☰
    - main [ref=f1e3]:
      - generic "城市与当前场景" [ref=f1e4]:
        - button "此时此地与主角状态" [ref=f1e5] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e6]: 城
          - generic [ref=f1e7]:
            - generic [ref=f1e8]: 当前地点
            - generic [ref=f1e9]: 重庆
          - time [ref=f1e10]: 08:00
          - generic "天气：天气待确认" [ref=f1e11]: —
        - generic [ref=f1e12]: 重庆，2026/10/18 星期日 08:00，天气：天气待确认
      - region "剧情与行动" [ref=f1e13]:
        - generic "正文阅读区域" [ref=f1e14]:
          - generic [ref=f1e15]:
            - generic [ref=f1e16]: THE STORY
            - generic [ref=f1e17]: 已保存草稿
          - article [ref=f1e18]:
            - generic [ref=f1e19]:
              - heading "第 1 回合" [level=2] [ref=f1e20]
              - generic [aria-hidden] [ref=f1e21]: 第一回
              - generic [ref=f1e22]:
                - text: 2026/10/18 · 星期日 · 08:00
                - generic [ref=f1e23]: 重庆
                - text: · 草稿
            - text: 正文草稿 · 世界状态尚未确认
            - paragraph [ref=f1e25]: 第1幕：主角在街边用餐，观察来往行人。
        - generic [ref=f1e26]:
          - region "三阶段工作流" [ref=f1e28]:
            - button "三阶段工作流详情" [expanded] [ref=f1e31] [cursor=pointer]:
              - status [ref=f1e36]:
                - generic [ref=f1e37]: 三阶段 ·
                - text: 动态世界生成失败 · 查看详情
              - generic [ref=f1e38]: 详情 ›
          - generic [ref=f1e39]:
            - generic [ref=f1e41]:
              - button "撤回" [disabled] [ref=f1e42]:
                - generic [aria-hidden] [ref=f1e43]: 撤
              - button "继续生成世界" [ref=f1e44] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e45]: 续
            - generic [ref=f1e46]: 你的行动
            - textbox "你的行动" [ref=f1e47]:
              - /placeholder: 填写你的行动
            - button "发送" [disabled] [ref=f1e49]
          - status [ref=f1e50]: 本回合尚未结算，请点击输入框左侧“续”（继续生成世界）。输入仅本页暂存，不会替换已绑定行动。
      - navigation "底部导航" [ref=f1e51]:
        - button "故事" [ref=f1e52] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e53]: 文
          - text: 故事
        - button "人物" [ref=f1e54] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e55]: 我
          - text: 人物
        - button "世界资料" [ref=f1e56] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e57]: 世
          - text: 世界资料
        - button "设置" [ref=f1e58] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e59]: 设
          - text: 设置
      - dialog [active] [ref=f1e60]:
        - generic [ref=f1e63]:
          - generic [aria-hidden] [ref=f1e64]: 诊
          - generic [ref=f1e65]:
            - paragraph [aria-hidden] [ref=f1e66]: WORKFLOW · 诊断
            - heading "重试与变更详情" [level=2] [ref=f1e67]
          - button "关闭资料界面" [ref=f1e68] [cursor=pointer]:
            - text: 关闭
            - generic [aria-hidden] [ref=f1e69]: ×
        - generic [ref=f1e70]:
          - tablist "诊断分类" [ref=f1e71]:
            - tab "概要" [ref=f1e72] [cursor=pointer]
            - tab "运行日志 1" [selected] [ref=f1e73] [cursor=pointer]:
              - text: 运行日志
              - generic [ref=f1e74]: "1"
            - tab "请求用量 3" [ref=f1e75] [cursor=pointer]:
              - text: 请求用量
              - generic [ref=f1e76]: "3"
            - tab "模型原文" [ref=f1e77] [cursor=pointer]
          - tabpanel "运行日志 1" [ref=f1e78]:
            - region "持久失败摘要" [ref=f1e79]:
              - heading "持久失败摘要" [level=5] [ref=f1e80]
              - paragraph [ref=f1e81]: 动态世界 · 安全失败码：permission · 第 2 次尝试
              - paragraph [ref=f1e82]: 当前可主动继续生成世界；生成可能产生费用，查看诊断不会发起请求。
              - paragraph [ref=f1e83]: 持久失败摘要仅保留安全码和尝试信息，不是本页新发生的事件，也不是模型原始响应；不能凭错误码还原具体失败原因。
            - group [ref=f1e84]:
              - generic "运行日志 · 错误 1 条 最近错误 · permission" [ref=f1e85] [cursor=pointer]:
                - generic [ref=f1e86]: 运行日志 · 错误 1 条
                - strong [ref=f1e87]: 最近错误 · permission
              - generic [ref=f1e88]:
                - paragraph [ref=f1e89]: 仅显示当前存档、当前回合的本页临时日志；已恢复的失败不再计为当前错误。每条可单独复制安全诊断，不含原始模型响应、请求正文或密钥。刷新即清空。
                - button "清空日志" [ref=f1e91] [cursor=pointer]
                - list "错误日志条目" [ref=f1e92]:
                  - listitem [ref=f1e93]:
                    - generic [ref=f1e94]:
                      - generic [ref=f1e95]:
                        - time [ref=f1e96]: 06:14:46
                        - strong [ref=f1e97]: 动态世界
                        - generic [ref=f1e98]: 错误
                      - button "复制此条" [ref=f1e99] [cursor=pointer]
                    - paragraph [ref=f1e100]: 候选超出本阶段允许的命令或对象范围。
                    - generic [ref=f1e101]: 本页存档标识：3d21834b-d492-4291-8af3-d894d074c714 · 本页回合标识：8bb02611-258c-4637-b296-6672e2e97db2（匿名关联标识）
                    - generic [ref=f1e102]: 错误码：permission
                    - generic [ref=f1e103]: 字段：eventCommands.0
                    - generic [ref=f1e104]: 命令序号：第 3 条
                    - generic [ref=f1e105]: 命令类型：UpdateOrganization
                    - generic [ref=f1e106]: 世界校验：command_structure · 命令类型或分组不符合世界协议
          - paragraph [ref=f1e107]: 本页日志与模型原文刷新即清空；持久失败摘要随当前草稿保存。
  - generic [ref=f1e108]:
    - button "收起工作流暗区" [ref=f1e109] [cursor=pointer]
    - dialog "三阶段工作流" [ref=f1e110]:
      - generic [ref=f1e111]:
        - button "收起三阶段工作流" [ref=f1e112] [cursor=pointer]
        - button "行动输入" [ref=f1e114] [cursor=pointer]
      - region "三阶段详情" [ref=f1e115]:
        - generic [ref=f1e116]:
          - generic [ref=f1e117]:
            - text: THREE STAGES · 三阶段
            - heading "动态世界生成失败 · 查看详情" [level=3] [ref=f1e118]
          - button "收起三阶段详情" [ref=f1e119] [cursor=pointer]: ×
        - alert [ref=f1e121]:
          - text: 误
          - generic [ref=f1e122]:
            - paragraph [ref=f1e123]: 动态世界：候选超出本阶段允许的命令或对象范围。 字段：eventCommands.0（UpdateOrganization，第3条）。
            - generic [ref=f1e124]: 动态世界 · 安全失败码：permission · 2 次尝试
          - button "打开 AI 设置" [ref=f1e125] [cursor=pointer]
          - button "关闭错误提示" [ref=f1e126] [cursor=pointer]: ×
        - navigation "三阶段导航" [ref=f1e128]:
          - paragraph [ref=f1e129]: STAGES
          - list [ref=f1e130]:
            - listitem [ref=f1e131]:
              - button "01正文生成 已完成" [ref=f1e132] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e133]: ✓
                - strong [ref=f1e134]:
                  - generic [ref=f1e135]: "01"
                  - text: 正文生成
                - generic [ref=f1e136]: 已完成
            - listitem [ref=f1e137]:
              - button "02变量管理 已完成" [ref=f1e138] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e139]: ✓
                - strong [ref=f1e140]:
                  - generic [ref=f1e141]: "02"
                  - text: 变量管理
                - generic [ref=f1e142]: 已完成
              - generic "变量管理阶段开关" [ref=f1e143]:
                - checkbox "变量管理" [checked] [ref=f1e144]
            - listitem [ref=f1e145]:
              - button "03动态世界 失败 · 可重试" [ref=f1e146] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e147]: "!"
                - strong [ref=f1e148]:
                  - generic [ref=f1e149]: "03"
                  - text: 动态世界
                - generic [ref=f1e150]: 失败 · 可重试
              - generic "动态世界阶段开关" [ref=f1e151]:
                - checkbox "动态世界" [checked] [ref=f1e152]
          - paragraph [ref=f1e153]: 本回合
          - list [ref=f1e154]:
            - listitem [ref=f1e155]:
              - button "运行诊断 错误与用量 错误 1 条" [ref=f1e156] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e157]: 诊
                - strong [ref=f1e158]: 运行诊断
                - generic [ref=f1e159]: 错误与用量
                - generic "错误 1 条" [ref=f1e160]: "1"
            - listitem [ref=f1e161]:
              - button "已绑定输入 只读" [ref=f1e162] [cursor=pointer]:
                - generic [aria-hidden] [ref=f1e163]: 述
                - strong [ref=f1e164]: 已绑定输入
                - generic [ref=f1e165]: 只读
        - generic [ref=f1e166]:
          - button "继续未完成阶段" [ref=f1e168] [cursor=pointer]
          - generic [ref=f1e169]: 生成可能产生费用。
```

# Test source

```ts
  159 |     };
  160 |   });
  161 |   await page.getByRole('button', { name: '自动生成开局', exact: true }).click();
  162 |   const log = page.getByTestId('runtime-log'); await expect(log).toContainText('错误码：storage'); await expect(log).toContainText('保存变量候选');
  163 |   await expect(log).not.toContainText('private-storage-detail');
  164 |   const failed = await stored(page); expect(failed.state).toEqual(before.state); expect(failed.draft.story).toBeDefined(); expect(failed.draft.stageStatus.variables).toBe('failed');
  165 |   expect(server.calls).toEqual(['story','variables']);
  166 |   await page.evaluate(() => Reflect.set(window, '__failSourceSave', false));
  167 |   await page.getByRole('button', { name: '继续未完成阶段', exact: true }).click(); await settled(page);
  168 |   const committed = await stored(page); expect(committed.state.turnNumber).toBe(1); expect(committed.state.economy.cash).toBe(7000);
  169 |   expect(server.calls).toEqual(['story','variables','variables','world']);
  170 | });
  171 | 
  172 | test('时间诊断保留重排前文本编号；失败原文可读，恢复自动结算且刷新不重发', async ({ page }) => {
  173 |   await seed(page); const server = await mock(page), before = await stored(page);
  174 |   server.control.variables = '<命令>\nset protagonist.emotionText = "从容"\nset npc[scene].lastInteractionAt = "2026-10-18T09:00:00+08:00"\nset worldClock = "2026-10-18T08:10:00+08:00"\n</命令>';
  175 |   await page.getByRole('button', { name: '自动生成开局', exact: true }).click();
  176 |   await openWorkflowDiagnostics(page);
  177 |   const log = page.getByTestId('runtime-log');
  178 |   await expect(log).toContainText('错误码：time_data'); await expect(log).toContainText('命令序号：第 2 条');
  179 |   await expect(log).toContainText('命令类型：UpdateNpc'); await expect(log).toContainText('NPC 互动时间晚于执行时的游戏时钟');
  180 |   await expect(log).not.toContainText('相关命令：'); await expect(log).not.toContainText('mock-auto-settlement-key');
  181 |   const failed = await stored(page); expect(failed.state).toEqual(before.state); expect(failed.draft.story).toBeDefined(); expect(failed.draft.variables).toBeUndefined();
  182 |   expect(server.calls).toEqual(['story', 'variables']);
  183 |   await openStageRaw(page, 'variables');
  184 |   await expect(page.locator('.stage-responses')).toContainText('第2条命令：NPC 互动时间');
  185 |   expect(await page.getByLabel('变量模型完整原文').textContent()).toBe(server.responses.variables);
  186 |   server.control.variables = server.control.variables.replace('09:00:00', '08:10:00');
  187 |   await page.getByRole('button', { name: '继续未完成阶段', exact: true }).click(); await settled(page);
  188 |   const committed = await stored(page); expect(committed.state.turnNumber).toBe(1); expect(committed.state.npc.scene.lastInteractionAt).toBe('2026-10-18T08:10:00+08:00');
  189 |   expect(server.calls).toEqual(['story', 'variables', 'variables', 'world']);
  190 |   await page.reload(); await openGameTools(page); await settled(page); expect(await stored(page)).toEqual(committed); expect(server.calls).toHaveLength(4);
  191 | });
  192 | 
  193 | test('认知格式、时间线对象和组织历史逐项拒绝，明确修正后保留Story并一次结算', async ({ page }) => {
  194 |   await seed(page); const server = await mock(page), before = await stored(page);
  195 |   server.control.variables = '<命令>\npush npc[scene].knownInformation = {"text":"收到安排","source":"当面通知","learnedAt":"2026-10-18T08:00:00+08:00"}\n</命令>';
  196 |   const world = { worldCommands: [{ type: 'CreateOrganization', commandId: 'create-community', evidence: '登记社区团队', organization: {
  197 |     id: 'org-community', name: '社区团队', kind: 'civil', description: '日常协调', protagonistRelation: '暂无往来', relationHistory: ['不应预填的历史'], keyNpcIds: [], currentTaskIds: [], activities: [],
  198 |   } }], taskCommands: [], eventCommands: [], visibleHooks: [], timelineCandidates: [{ eventId: 'invented' }], unresolved: [] };
  199 |   server.control.world = JSON.stringify(world);
  200 |   await page.getByRole('button', { name: '自动生成开局', exact: true }).click(); await openWorkflowDiagnostics(page);
  201 |   const log = page.getByTestId('runtime-log'); await expect(log).toContainText('npc[id].knownInformation.knowledgeKind');
  202 |   const story = (await stored(page)).draft.story; expect(story).toBeDefined(); expect((await stored(page)).state).toEqual(before.state);
  203 |   server.control.variables = '<命令>\npush npc[scene].knownInformation = {"text":"收到安排","knowledgeKind":"reported","knowledgeSource":"当面通知","visibility":"npc_private"}\n</命令>';
  204 |   await page.getByRole('button', { name: '继续未完成阶段', exact: true }).click(); await expect(log).toContainText('schema_fields');
  205 |   // 旧 Variables 错误也含 schema_fields；等待本次 World 错误，才更换下一次响应。
  206 |   await expect(log.getByRole('listitem').filter({ hasText: '动态世界' })).toContainText('错误码：schema_fields');
  207 |   expect(server.calls).toEqual(['story', 'variables', 'variables', 'world']);
  208 |   expect((await stored(page)).state).toEqual(before.state); expect((await stored(page)).draft.variables.validation).toBe('validated');
  209 |   Reflect.deleteProperty(world, 'timelineCandidates'); server.control.world = JSON.stringify(world);
  210 |   await page.getByRole('button', { name: '继续未完成阶段', exact: true }).click(); await expect(log).toContainText('organization_initialization');
  211 |   expect((await stored(page)).state).toEqual(before.state);
  212 |   world.worldCommands[0].organization.relationHistory = []; server.control.world = JSON.stringify(world);
  213 |   await page.getByRole('button', { name: '继续未完成阶段', exact: true }).click(); await settled(page);
  214 |   const committed = await stored(page); expect(committed.state.turnNumber).toBe(1); expect(committed.state.journal[0].story).toEqual(story);
  215 |   expect(committed.state.npc.scene.knownInformation).toEqual([{ text: '[转述]收到安排', source: '当面通知', learnedAt: '2026-10-18T08:00:00+08:00' }]);
  216 |   expect(committed.state.npc['npc-a'].memories).toEqual(before.state.npc['npc-a'].memories); expect(committed.state.timeline).toEqual([]);
  217 |   expect(server.calls).toEqual(['story', 'variables', 'variables', 'world', 'world', 'world']);
  218 |   await page.reload(); await openGameTools(page); await settled(page); expect(await stored(page)).toEqual(committed); expect(server.calls).toHaveLength(6);
  219 | });
  220 | 
  221 | test('#186 World重复写入Variables本轮组织字段：以Variables为准剔除，阶段不失败，只在诊断页说明', async ({ page }, info) => {
  222 |   await seed(page, false, true); const server = await mock(page);
  223 |   server.control.variables = '<命令>\nset worldClock = "2026-10-18T08:10:00+08:00"\nset organizations[org-shop].state = {"operatingStatus":"正文确认：今晚照常营业"}\n</命令>';
  224 |   server.control.world = JSON.stringify({ worldCommands: [{ type: 'UpdateOrganization', commandId: 'world-shop', evidence: '后台推演', organizationId: 'org-shop', expectedRevision: 0,
  225 |     changes: { operatingStatus: '模型另写：暂停营业', ownershipText: '股权结构不变' } }], taskCommands: [], eventCommands: [], visibleHooks: [], unresolved: [] });
  226 |   await page.getByRole('button', { name: '自动生成开局', exact: true }).click(); await settled(page);
  227 |   const committed = await stored(page);
  228 |   expect(committed.state.organizations['org-shop']).toMatchObject({ operatingStatus: '正文确认：今晚照常营业', ownershipText: '股权结构不变' });
  229 |   expect(server.calls).toEqual(['story', 'variables', 'world']);
  230 |   await openWorkflowDiagnostics(page); await expect(page.getByTestId('runtime-log')).not.toContainText('scene_write_conflict');
  231 |   // 模型原文保持原样（含被忽略的字段），处理说明只出现在“校验结果”。
  232 |   await openStageRaw(page, 'world'); expect(await page.getByLabel('动态世界模型完整原文').textContent()).toBe(server.responses.world);
  233 |   await openStageTab(page, 'world', '校验结果');
  234 |   const notes = page.locator('.wf-stage .stage-notes');
  235 |   await expect(notes).toContainText('程序处理说明'); await expect(notes).toContainText('operatingStatus 的值与变量阶段不同，以变量阶段为准');
  236 |   await expect(page.getByLabel('动态世界规范化结果')).not.toContainText('模型另写');
  237 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  238 |   await page.screenshot({ path: info.outputPath('world-scene-write-notes.png') });
  239 | });
  240 | 
  241 | for (const group of ['taskCommands', 'eventCommands'] as const) {
  242 |   test(`#190 ${group} 的非法重复组织命令必须整批拒绝，主动修正后仅重试World`, async ({ page }, info) => {
  243 |     await seed(page, false, true); const server = await mock(page), before = await stored(page);
  244 |     server.control.variables = '<命令>\nset worldClock = "2026-10-18T08:10:00+08:00"\nset organizations[org-shop].state = {"operatingStatus":"正文确认照常营业"}\n</命令>';
  245 |     const repeated = { type: 'UpdateOrganization', commandId: 'repeated-shop', evidence: '后台', organizationId: 'org-shop', expectedRevision: 0,
  246 |       changes: { operatingStatus: 'World重复值' } };
  247 |     const independent = { ...repeated, commandId: 'independent-shop', changes: { ownershipText: 'World独立合法字段' } };
  248 |     const wrong = { ...repeated, commandId: 'wrong-group' };
  249 |     server.control.world = JSON.stringify({ worldCommands: [repeated, independent], taskCommands: [], eventCommands: [], visibleHooks: [], unresolved: [], [group]: [wrong] });
  250 |     await page.getByRole('button', { name: '自动生成开局', exact: true }).click();
  251 |     await expect.poll(async () => (await stored(page)).draft.stageStatus.world).toBe('failed');
  252 |     const failed = await stored(page);
  253 |     expect(failed.state).toEqual(before.state); expect(failed.draft.world).toBeUndefined();
  254 |     expect(failed.draft.variables.validation).toBe('validated');
  255 |     expect(server.calls).toEqual(['story', 'variables', 'world']);
  256 |     // Mobile opens failed-request diagnostics automatically; do not click the
  257 |     // workflow behind that modal. Desktop still uses its existing diagnostics rail.
  258 |     if ((page.viewportSize()?.width ?? 0) > 900) await openWorkflowDiagnostics(page);
> 259 |     await expect(page.getByTestId('runtime-log')).toBeVisible();
      |                                                   ^ Error: expect(locator).toBeVisible() failed
  260 |     await expect(page.getByTestId('runtime-log')).toContainText(`${group}.0`);
  261 |     await expect(page.getByTestId('runtime-log')).toContainText('UpdateOrganization');
  262 |     // Failed-stage diagnostics use a native modal on mobile; close it before
  263 |     // switching the underlying nonmodal workflow to the raw-response tab.
  264 |     const diagnosticClose = page.getByRole('dialog').filter({ has: page.getByRole('heading', { name: '重试与变更详情', exact: true }) })
  265 |       .getByRole('button', { name: '关闭资料界面', exact: true });
  266 |     if (await diagnosticClose.isVisible()) await diagnosticClose.click();
  267 |     await openStageRaw(page, 'world');
  268 |     expect(await page.getByLabel('动态世界模型完整原文').textContent()).toBe(server.responses.world);
  269 |     expect(await stored(page)).toEqual(failed);
  270 |     await page.screenshot({ path: info.outputPath(`world-rejected-${group}.png`) });
  271 |     // Explicit recovery only: do not rerun Story/Variables or keep any failed World candidate.
  272 |     server.control.world = JSON.stringify({ worldCommands: [repeated, independent], taskCommands: [], eventCommands: [], visibleHooks: [], unresolved: [] });
  273 |     await page.getByRole('button', { name: '继续未完成阶段', exact: true }).click(); await settled(page);
  274 |     const committed = await stored(page);
  275 |     expect(committed.state.organizations['org-shop']).toMatchObject({ operatingStatus: '正文确认照常营业', ownershipText: 'World独立合法字段' });
  276 |     expect(committed.state.revision).toBe(1); expect(committed.state.journal).toHaveLength(1);
  277 |     expect(server.calls).toEqual(['story', 'variables', 'world', 'world']);
  278 |   });
  279 | }
  280 | 
```
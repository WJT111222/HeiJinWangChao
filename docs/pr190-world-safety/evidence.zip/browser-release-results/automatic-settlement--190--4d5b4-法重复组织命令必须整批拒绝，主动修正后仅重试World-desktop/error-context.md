# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: automatic-settlement.spec.ts >> #190 eventCommands 的非法重复组织命令必须整批拒绝，主动修正后仅重试World
- Location: e2e/automatic-settlement.spec.ts:242:3

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('region', { name: '三阶段工作流' }).getByRole('status')
Expected substring: "本回合已结算"
Error: strict mode violation: getByRole('region', { name: '三阶段工作流' }).getByRole('status') resolved to 2 elements:
    1) <strong role="status" aria-live="polite">…</strong> aka getByText('三阶段 · 动态世界生成中 · 3/')
    2) <p role="status">响应接收中 · 未完成；尚未通过完整校验，不是候选或正式结果。</p> aka getByText('响应接收中 · 未完成；尚未通过完整校验，不是候选或正式结果。')

Call log:
  - Expect "toContainText" getByRole('region', { name: '三阶段工作流' }).getByRole('status') with timeout 5000ms
  - waiting for getByRole('region', { name: '三阶段工作流' }).getByRole('status')
    - locator resolved to <strong role="status" aria-live="polite">…</strong>
    - unexpected value "三阶段 · 动态世界生成中 · 3/3"

```

# Page snapshot

```yaml
- main [ref=f1e2]:
  - generic "城市与当前场景" [ref=f1e3]:
    - generic [ref=f1e4]:
      - generic [aria-hidden] [ref=f1e5]: 黑
      - generic [ref=f1e6]:
        - heading "城市长夜" [level=1] [ref=f1e7]
        - generic "A CITY. A TURNING POINT." [ref=f1e8]
    - generic [ref=f1e9]:
      - generic "重庆" [ref=f1e10]: 当前地点
      - generic "2026/10/18 星期日 08:10" [ref=f1e13]:
        - time [ref=f1e14]: 08:10
        - generic [ref=f1e15]:
          - generic [ref=f1e16]: 2026/10/18 星期日
          - generic [ref=f1e17]: 早晨
      - generic [ref=f1e18]:
        - button "查看天气详情" [ref=f1e19] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e20]: 晴
          - generic [ref=f1e21]: 天气
          - generic [ref=f1e22]: 天气待确认
        - button "查看环境详情" [ref=f1e23] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e24]: 境
          - generic [ref=f1e25]: 环境
          - generic [ref=f1e26]: 环境待确认
  - complementary "主角信息" [ref=f1e27]:
    - generic [ref=f1e28]:
      - generic [aria-hidden] [ref=f1e29]: 林
      - generic [ref=f1e30]:
        - heading "林舟" [level=2] [ref=f1e31]
        - paragraph [ref=f1e32]: 30 岁 · 男 · 教师
    - paragraph [ref=f1e33]: 资金
    - generic [ref=f1e34]:
      - generic [ref=f1e35]:
        - generic [ref=f1e36]: 现金
        - strong [ref=f1e37]: 100.00 元
      - generic [ref=f1e38]:
        - generic [ref=f1e39]: 线上资金
        - strong [ref=f1e40]: 200.00 元
    - paragraph [ref=f1e41]: 状态
    - generic [ref=f1e42]:
      - generic "健康" [ref=f1e43]:
        - generic [ref=f1e44]: 身体
        - text: 健康
      - generic "平静" [ref=f1e45]:
        - generic [ref=f1e46]: 情绪
        - text: 平静
    - region "当前穿戴与装备" [ref=f1e47]:
      - paragraph [ref=f1e48]: 当前穿戴与装备
      - generic [ref=f1e49]:
        - generic [ref=f1e50]:
          - term [ref=f1e51]: 上衣
          - definition [ref=f1e52]: 无
        - generic [ref=f1e53]:
          - term [ref=f1e54]: 下装
          - definition [ref=f1e55]: 无
        - generic [ref=f1e56]:
          - term [ref=f1e57]: 鞋子
          - definition [ref=f1e58]: 无
        - generic [ref=f1e59]:
          - term [ref=f1e60]: 饰品
          - definition [ref=f1e61]: 无
        - generic [ref=f1e62]:
          - term [ref=f1e63]: 主武器
          - definition [ref=f1e64]: 无
        - generic [ref=f1e65]:
          - term [ref=f1e66]: 副武器
          - definition [ref=f1e67]: 无
        - generic [ref=f1e68]:
          - term [ref=f1e69]: 载具
          - definition [ref=f1e70]: 无
    - generic [ref=f1e71]:
      - button "人物档案" [ref=f1e72] [cursor=pointer]
      - button "经济与资产" [ref=f1e73] [cursor=pointer]
  - region "剧情与行动" [ref=f1e74]:
    - generic "正文阅读区域" [ref=f1e75]:
      - generic [ref=f1e76]:
        - generic [ref=f1e77]: THE STORY
        - generic [ref=f1e78]: 已结算历史
      - article [ref=f1e79]:
        - generic [ref=f1e80]:
          - heading "第 1 回合" [level=2] [ref=f1e81]
          - generic [aria-hidden] [ref=f1e82]: 第一回
          - generic [aria-hidden] [ref=f1e83]: 十月十八日 · 星期日 · 八时整 · 重庆
        - paragraph [ref=f1e85]: 第1幕：主角在街边用餐，观察来往行人。
        - generic [ref=f1e86]:
          - button "本回合变化 不可用" [disabled] [ref=f1e87]:
            - generic [ref=f1e88]: 本回合变化
            - generic [ref=f1e89]: 不可用
            - generic [aria-hidden] [ref=f1e90]: ▼
          - status [ref=f1e91]: 本回合没有可对比的结算前记录
    - generic [ref=f1e92]:
      - region "三阶段工作流" [ref=f1e94]:
        - generic [ref=f1e95]:
          - generic [ref=f1e96]:
            - status [ref=f1e97]: 三阶段 · 本回合已结算 · 等待行动
            - generic [ref=f1e98]:
              - button "01 正文 · 已结算" [ref=f1e99] [cursor=pointer]:
                - generic [ref=f1e101]:
                  - generic [ref=f1e102]: "01"
                  - text: 正文
                  - emphasis [ref=f1e103]: · 已结算
              - button "02 变量 · 已结算" [ref=f1e104] [cursor=pointer]:
                - generic [ref=f1e106]:
                  - generic [ref=f1e107]: "02"
                  - text: 变量
                  - emphasis [ref=f1e108]: · 已结算
              - button "03 动态世界 · 已结算" [ref=f1e109] [cursor=pointer]:
                - generic [ref=f1e111]:
                  - generic [ref=f1e112]: "03"
                  - text: 动态世界
                  - emphasis [ref=f1e113]: · 已结算
            - button "详情" [expanded] [ref=f1e114] [cursor=pointer]
          - region "三阶段详情" [ref=f1e115]:
            - generic [ref=f1e116]:
              - generic [ref=f1e118]:
                - generic [ref=f1e119]: THREE STAGES · 三阶段
                - heading "本回合已结算 · 等待行动" [level=3] [ref=f1e120]
              - button "收起三阶段详情" [ref=f1e121] [cursor=pointer]: ×
            - generic [ref=f1e122]:
              - navigation "三阶段导航" [ref=f1e123]:
                - paragraph [ref=f1e124]: STAGES
                - list [ref=f1e125]:
                  - listitem [ref=f1e126]:
                    - button "01正文生成 已结算" [ref=f1e127] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f1e128]: ✓
                      - strong [ref=f1e129]:
                        - generic [ref=f1e130]: "01"
                        - text: 正文生成
                      - generic [ref=f1e131]: 已结算
                  - listitem [ref=f1e132]:
                    - button "02变量管理 已结算" [ref=f1e133] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f1e134]: ✓
                      - strong [ref=f1e135]:
                        - generic [ref=f1e136]: "02"
                        - text: 变量管理
                      - generic [ref=f1e137]: 已结算
                    - generic "变量管理阶段开关" [ref=f1e138]:
                      - checkbox "变量管理" [checked] [ref=f1e139] [cursor=pointer]
                  - listitem [ref=f1e140]:
                    - button "03动态世界 已结算" [ref=f1e141] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f1e142]: ✓
                      - strong [ref=f1e143]:
                        - generic [ref=f1e144]: "03"
                        - text: 动态世界
                      - generic [ref=f1e145]: 已结算
                    - generic "动态世界阶段开关" [ref=f1e146]:
                      - checkbox "动态世界" [checked] [ref=f1e147] [cursor=pointer]
                - paragraph [ref=f1e148]: 本回合
                - list [ref=f1e149]:
                  - listitem [ref=f1e150]:
                    - button "运行诊断 错误与用量" [ref=f1e151] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f1e152]: 诊
                      - strong [ref=f1e153]: 运行诊断
                      - generic [ref=f1e154]: 错误与用量
                  - listitem [ref=f1e155]:
                    - button "已绑定输入 只读" [ref=f1e156] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f1e157]: 述
                      - strong [ref=f1e158]: 已绑定输入
                      - generic [ref=f1e159]: 只读
              - region "动态世界详情" [ref=f1e161]:
                - generic [ref=f1e162]:
                  - generic [ref=f1e163]:
                    - text: STAGE 03 · WORLD
                    - heading "动态世界 已结算" [level=4] [ref=f1e164]:
                      - text: 动态世界
                      - generic [ref=f1e165]: 已结算
                  - button "生成世界候选" [disabled] [ref=f1e167]
                - tablist "动态世界内容" [ref=f1e168]:
                  - tab "概览" [ref=f1e169] [cursor=pointer]
                  - tab "候选" [ref=f1e170] [cursor=pointer]
                  - tab "模型原文" [selected] [ref=f1e171] [cursor=pointer]
                  - tab "校验结果" [ref=f1e172] [cursor=pointer]
                - tabpanel "模型原文" [ref=f1e173]:
                  - region "模型原文" [ref=f1e174]:
                    - heading "动态世界模型原文（临时响应）" [level=5] [ref=f1e175]
                    - generic [ref=f1e176]:
                      - text: 查看响应内容
                      - combobox "动态世界原文内容" [ref=f1e177]:
                        - option "供应商 content" [selected]
                        - option "供应商公开思考"
                        - option "安全响应诊断"
                    - textbox "动态世界模型完整原文" [ref=f1e178]: "{\"worldCommands\":[{\"type\":\"UpdateOrganization\",\"commandId\":\"repeated-shop\",\"evidence\":\"后台\",\"organizationId\":\"org-shop\",\"expectedRevision\":0,\"changes\":{\"operatingStatus\":\"World重复值\"}},{\"type\":\"UpdateOrganization\",\"commandId\":\"independent-shop\",\"evidence\":\"后台\",\"organizationId\":\"org-shop\",\"expectedRevision\":0,\"changes\":{\"ownershipText\":\"World独立合法字段\"}}],\"taskCommands\":[],\"eventCommands\":[],\"visibleHooks\":[],\"unresolved\":[]}"
                    - paragraph [ref=f1e179]: 响应传输已结束；是否可用仍以正式校验为准。
                    - paragraph [ref=f1e180]: content 与公开思考按来源分别查看，不代表两者的生成先后。最近最多保留六次，容量超限会提前淘汰旧响应。安全诊断仅保留白名单结构，不展示任意供应商错误文字。
                    - paragraph [ref=f1e181]: 仅本页面临时保存，刷新或淘汰后无法恢复；模型原文不等于已执行结果。不会写入正式世界或剧情历史，不会发起请求。系统凭证会隐藏。
            - generic [ref=f1e182]:
              - generic [ref=f1e183]: 发送新行动后开始下一回合
              - generic [ref=f1e184]: 生成可能产生费用。
      - generic [ref=f1e185]:
        - generic [ref=f1e187]:
          - button "撤回" [disabled] [ref=f1e188]
          - button "本回合已完成" [disabled] [ref=f1e189]
        - generic [ref=f1e190]: 你的行动
        - textbox "你的行动" [ref=f1e191]:
          - /placeholder: 填写你的行动；发送后生成三阶段并自动结算
        - generic [ref=f1e192]:
          - button "发送" [disabled] [ref=f1e193]
          - generic [ref=f1e194]: Ctrl + Enter
  - complementary "世界资料" [ref=f1e195]:
    - heading "世界资料" [level=2] [ref=f1e196]
    - navigation "世界资料分类" [ref=f1e197]:
      - button "NPC" [ref=f1e198] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e199]: 人
      - button "势力组织" [ref=f1e201] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e202]: 势
      - button "地图" [ref=f1e204] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e205]: 图
      - button "物品栏" [ref=f1e207] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e208]: 物
      - button "世界事件" [ref=f1e210] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e211]: 事
      - button "历史时间轴" [ref=f1e213] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e214]: 史
      - button "记忆" [ref=f1e216] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e217]: 忆
    - navigation "系统操作" [ref=f1e219]:
      - button "设置" [ref=f1e220] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e221]: 设
      - button "返回首页" [ref=f1e223] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e224]: 归
```

# Test source

```ts
  1   | import { variableTextEnvelope } from '../src/tests/fixtures/variableReply';
  2   | import { expect, test } from './helpers/test';
  3   | import type { Page } from '@playwright/test';
  4   | import { openGameTools, openWorkflowDiagnostics, openStageRaw, openStageTab } from './helpers/gameLayout';
  5   | 
  6   | async function seed(page: Page, remoteLocation = false, organization = false) {
  7   |   await page.goto('/');
  8   |   await page.evaluate(async ([remoteLocation, organization]) => {
  9   |     const storage = '/src/services/storage/saveRepository.ts', fixtures = '/src/tests/fixtures/world.ts', drafts = '/src/domain/drafts.ts',
  10  |       configuration = '/src/services/ai/configuration.ts', gameFixtures = '/src/tests/fixtures/game.ts', credentials = '/src/services/ai/credentials.ts', settingsPath = '/src/ui/settings/model.ts';
  11  |     const { SaveRepository } = await import(storage), { worldState } = await import(fixtures), { createTurnDraft } = await import(drafts),
  12  |       { defaultAiConfig, newChannel, saveAiConfig } = await import(configuration), { CredentialVault } = await import(credentials), { defaultSettings, settingsKey } = await import(settingsPath);
  13  |     const settings = defaultSettings(); settings.prompts.minNarrativeChars = 5; settings.prompts.actionOptions = false; localStorage.setItem(settingsKey, JSON.stringify(settings));
  14  |     const channel = newChannel(), config = defaultAiConfig(); channel.baseUrl = 'https://auto-settlement.mock.invalid/v1'; channel.compatibility.jsonMode = true;
  15  |     config.channels = [channel]; config.routes.story = { channelId: channel.id, modelId: 'story' }; config.routes.variables = { mode: 'independent', channelId: channel.id, modelId: 'variables' }; config.routes.world = { mode: 'independent', channelId: channel.id, modelId: 'world' };
  16  |     saveAiConfig(localStorage, config); new CredentialVault(sessionStorage, localStorage).set(channel.id, 'mock-auto-settlement-key');
  17  |     const state = worldState();
  18  |     if (remoteLocation) state.locations.remote = { id: 'remote', name: '诊所' };
  19  |     if (organization) { const { organizations } = await import(gameFixtures); state.organizations['org-shop'] = { ...organizations[3], id: 'org-shop', name: '街口商行' }; }
  20  |     const repo = await SaveRepository.open(); try { await repo.create(state); await repo.saveDraft(createTurnDraft('save-a', 0, 'auto-opening', 'opening', ''), null); } finally { repo.close(); }
  21  |   }, [remoteLocation, organization] as const);
  22  |   await page.goto('/#game/save-a'); await page.reload(); await openGameTools(page);
  23  | }
  24  | async function stored(page: Page) { return page.evaluate(async () => { const path = '/src/services/storage/saveRepository.ts', { SaveRepository } = await import(path), repo = await SaveRepository.open(); try { return await repo.loadGame('save-a'); } finally { repo.close(); } }); }
  25  | async function mock(page: Page) {
  26  |   const calls: string[] = [], responses: { variables: string; world: string } = { variables: '', world: '' };
  27  |   const control: { bad?: boolean; hold?: Promise<void>; variables?: string; world?: string } = {};
  28  |   await page.route('https://auto-settlement.mock.invalid/**', async route => {
  29  |     const stage = String(route.request().postDataJSON().model); calls.push(stage);
  30  |     const turn = calls.filter(stage => stage === 'story').length;
  31  |     const variables = variableTextEnvelope(control.variables ?? `<说明>原始说明：第${turn}轮消费，保留换行。🟡</说明>\n<命令>\nset worldClock = "2026-10-18T08:${turn === 1 ? '10' : '20'}:00+08:00"\nadd economy.cash = -3000\n</命令>`);
  32  |     const world = control.world ?? (control.bad ? '{\n "worldCommands": [], "taskCommands": [], "eventCommands": [ {"type":"SaveEvent","commandId":"missing-end","evidence":"{}","event":{"id":"review","title":"清点","status":"scheduled","startAt":"2026-10-19T08:00:00+08:00","actorRefs":[{"kind":"npc","id":"npc-a"}],"linkedTaskIds":[],"prerequisites":[],"blockers":[],"visibility":"hidden","impact":"minor","sourceTurnIds":["auto-opening"],"backgroundText":"值班清点","goalText":"完成清点"}} ], "visibleHooks": [], "unresolved": []\n}'
  33  |       : '{\n "worldCommands": [], "taskCommands": [], "eventCommands": [], "visibleHooks": [], "unresolved": []\n}');
  34  |     const worldText = world.replace('"evidence":"{}"', `"evidence":${JSON.stringify(JSON.stringify({ version: 1, kind: 'planned', at: '2026-10-18T08:05:00+08:00', sources: ['npc:npc-a'], fact: '计划进行内部清点。', rationale: '根据日常工作安排准备清点。' }))}`);
  35  |     const text = stage === 'story' ? `<thinking>保持当前行动连续。</thinking>\n<正文>第${turn}幕：主角在街边用餐，观察来往行人。</正文>\n<短期记忆>在街边用餐。</短期记忆>\n<变量规划>[]</变量规划>` : stage === 'variables' ? variables : worldText;
  36  |     if (stage === 'variables') responses.variables = text;
  37  |     if (stage === 'world') { responses.world = text; if (control.hold) await control.hold; }
  38  |     await route.fulfill({ contentType: stage === 'story' ? 'text/event-stream' : 'application/json', body: stage === 'story'
  39  |       ? `data: ${JSON.stringify({ choices: [{ delta: { content: text } }] })}\n\ndata: [DONE]\n\n`
  40  |       : JSON.stringify({ choices: [{ message: { content: text }, finish_reason: 'stop' }] }) }).catch(() => undefined);
  41  |   });
  42  |   return { calls, control, responses };
  43  | }
> 44  | const settled = (page: Page) => expect(page.getByRole('region', { name: '三阶段工作流' }).getByRole('status')).toContainText('本回合已结算');
      |                                                                                                          ^ Error: expect(locator).toContainText(expected) failed
  45  | 
  46  | test('完整原文可读，开局与下一条行动各自动结算一次，刷新和空待输入不调用模型', async ({ page }, info) => {
  47  |   await seed(page); const server = await mock(page);
  48  |   await page.getByRole('button', { name: '自动生成开局', exact: true }).click(); await settled(page);
  49  |   let data = await stored(page); expect(data.state.turnNumber).toBe(1); expect(data.state.economy.cash).toBe(7000); expect(data.draft.userInput).toBe(''); expect(server.calls).toEqual(['story','variables','world']);
  50  |   await openStageRaw(page, 'variables');
  51  |   await expect(page.getByLabel('变量模型完整原文')).toHaveText(server.responses.variables, { useInnerText: false });
  52  |   expect(await page.getByLabel('变量模型完整原文').textContent()).toBe(server.responses.variables);
  53  |   await openStageRaw(page, 'world'); expect(await page.getByLabel('动态世界模型完整原文').textContent()).toBe(server.responses.world);
  54  |   await page.getByLabel('你的行动', { exact: true }).fill('继续在街边用餐'); await page.getByRole('button', { name: '发送', exact: true }).evaluate((button: HTMLButtonElement) => { button.click(); button.click(); });
  55  |   await expect.poll(async () => (await stored(page)).state.turnNumber).toBe(2);
  56  |   await settled(page); data = await stored(page); expect(data.state.turnNumber).toBe(2); expect(data.state.economy.cash).toBe(4000); expect(data.state.journal).toHaveLength(2); expect(data.draft.userInput).toBe(''); expect(server.calls).toHaveLength(6);
  57  |   await page.reload(); await openGameTools(page); await settled(page); expect(await stored(page)).toEqual(data); expect(server.calls).toHaveLength(6);
  58  |   await openStageRaw(page, 'variables'); await expect(page.locator('.stage-responses')).toContainText('本页面没有可恢复的模型原文');
  59  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  60  |   await page.screenshot({ path: info.outputPath('auto-settlement-raw-output.png') });
  61  | });
  62  | test('World字段错误可定位并查看完整失败原文，不提交；恢复仅请求World并自动结算', async ({ page }) => {
  63  |   await seed(page); const server = await mock(page); server.control.bad = true;
  64  |   await page.getByRole('button', { name: '自动生成开局', exact: true }).click();
  65  |   await expect(page.getByTestId('runtime-log')).toContainText('estimatedEndAt'); await expect(page.getByTestId('runtime-log')).toContainText('SaveEvent');
  66  |   const before = await stored(page); expect(before.state.revision).toBe(0); expect(before.draft.story).toBeDefined(); expect(before.draft.variables.validation).toBe('validated'); expect(before.draft.stageStatus.world).toBe('failed');
  67  |   await openStageRaw(page, 'world'); expect(await page.getByLabel('动态世界模型完整原文').textContent()).toBe(server.responses.world);
  68  |   server.control.bad = false; await page.getByRole('button', { name: '继续未完成阶段', exact: true }).click(); await settled(page);
  69  |   expect((await stored(page)).state.turnNumber).toBe(1); expect(server.calls).toEqual(['story','variables','world','world']);
  70  | });
  71  | 
  72  | test('发送下一条行动仅绑定草稿，commit日志必须等到三阶段完成才开始', async ({ page }) => {
  73  |   // 仅观察真实日志函数的调用，不替换返回值、工作流或存储行为。
  74  |   await page.route('**/src/ui/game/runtimeLog.ts*', async route => {
  75  |     // 仅本地 Vite 模块读取可重试一次 ECONNRESET；不重试任何模型或业务请求。
  76  |     const response = await route.fetch({ maxRetries: 1 }), source = await response.text();
  77  |     const anchor = 'const label = runtimeStageNames[stage];';
  78  |     expect(source).toContain(anchor);
  79  |     await route.fulfill({ response, body: source.replace(anchor, `${anchor}\n(window.__commitAudit ??= []).push({stage, kind});`) });
  80  |   });
  81  |   const commits = (kind: string) => page.evaluate(kind => {
  82  |     const events: unknown = Reflect.get(window, '__commitAudit');
  83  |     return Array.isArray(events) ? events.filter((entry: unknown) => entry && typeof entry === 'object' && 'stage' in entry && 'kind' in entry && entry.stage === 'commit' && entry.kind === kind).length : 0;
  84  |   }, kind);
  85  |   await seed(page); const server = await mock(page);
  86  |   await page.getByRole('button', { name: '自动生成开局', exact: true }).click(); await settled(page);
  87  |   expect(await commits('started')).toBe(1); expect(await commits('completed')).toBe(1);
  88  |   let release!: () => void; server.control.hold = new Promise<void>(resolve => { release = resolve; });
  89  |   await page.getByLabel('你的行动', { exact: true }).fill('继续在街边用餐');
  90  |   await page.getByRole('button', { name: '发送', exact: true }).click();
  91  |   await expect.poll(() => server.calls.length).toBe(6);
  92  |   try {
  93  |     expect((await stored(page)).state.turnNumber).toBe(1);
  94  |     expect(await commits('started')).toBe(1); expect(await commits('completed')).toBe(1);
  95  |   } finally { release(); }
  96  |   await expect.poll(async () => (await stored(page)).state.turnNumber).toBe(2); await settled(page);
  97  |   expect(await commits('started')).toBe(2); expect(await commits('completed')).toBe(2);
  98  |   await page.reload(); await openGameTools(page); await settled(page); expect(server.calls).toHaveLength(6);
  99  | });
  100 | 
  101 | test('NPC场景ID诊断与World规则同时保留，逐阶段恢复后只结算一次', async ({ page }, info) => {
  102 |   await seed(page, true); const server = await mock(page);
  103 |   server.control.variables = '<命令>\nset worldClock = "2026-10-18T08:10:00+08:00"\nset npc[scene].locationId = null\n</命令>';
  104 |   server.control.bad = true;
  105 |   await page.getByRole('button', { name: '自动生成开局', exact: true }).click();
  106 |   const log = page.getByTestId('runtime-log');
  107 |   await expect(log).toContainText('在场 NPC 缺少明确地点（NPC：scene）');
  108 |   expect(server.calls).toEqual(['story', 'variables']);
  109 |   const initial = await stored(page); expect(initial.state.revision).toBe(0);
  110 |   expect(initial.draft.stageStatus.variables).toBe('failed'); expect(initial.draft.world).toBeUndefined();
  111 | 
  112 |   server.control.variables = '<命令>\nset worldClock = "2026-10-18T08:10:00+08:00"\nset protagonist.locationId = "remote"\nset npc[scene].locationId = "remote"\n</命令>';
  113 |   await page.getByRole('button', { name: '继续未完成阶段', exact: true }).click();
  114 |   await expect(log).toContainText('estimatedEndAt'); await expect(log).toContainText('世界校验：event_plan');
  115 |   await expect(log).toContainText('（NPC：scene）');
  116 |   const worldFailed = await stored(page); expect(worldFailed.state).toEqual(initial.state);
  117 |   expect(worldFailed.draft.variables.validation).toBe('validated'); expect(worldFailed.draft.stageStatus.world).toBe('failed');
  118 |   expect(server.calls).toEqual(['story', 'variables', 'variables', 'world']);
  119 |   await expect(log).not.toContainText('mock-auto-settlement-key');
  120 |   await page.screenshot({ path: info.outputPath('world-and-npc-diagnostics.png') });
  121 | 
  122 |   server.control.bad = false;
  123 |   await page.getByRole('button', { name: '继续未完成阶段', exact: true }).click(); await settled(page);
  124 |   const committed = await stored(page); expect(committed.state.turnNumber).toBe(1); expect(committed.state.journal).toHaveLength(1);
  125 |   expect(committed.state.protagonist.locationId).toBe('remote'); expect(committed.state.npc.scene.locationId).toBe('remote');
  126 |   expect(committed.draft.userInput).toBe(''); expect(server.calls).toEqual(['story', 'variables', 'variables', 'world', 'world']);
  127 |   await expect(log).toContainText('世界校验：event_plan'); await expect(log).toContainText('（NPC：scene）');
  128 |   await page.reload(); await openGameTools(page); await settled(page); expect(server.calls).toHaveLength(5);
  129 |   expect(await stored(page)).toEqual(committed);
  130 | });
  131 | 
  132 | test('源三标签截断保留正文；明确恢复后四操作自动结算并完整显示原文', async ({ page }, info) => {
  133 |   await seed(page); const server = await mock(page), before = await stored(page);
  134 |   server.control.variables = '<thinking>本轮状态分析。</thinking><说明>- 更新本幕变量。</说明><命令>set protagonist.emotionText = "安心"';
  135 |   await page.getByRole('button', { name: '自动生成开局', exact: true }).click();
  136 |   await expect(page.getByTestId('runtime-log')).toContainText('解析三个标签区块');
  137 |   const failed = await stored(page); expect(failed.state).toEqual(before.state); expect(failed.draft.story).toBeDefined(); expect(failed.draft.variables).toBeUndefined();
  138 |   expect(server.calls).toEqual(['story','variables']);
  139 |   server.control.variables = '<thinking>本轮变量变化分析结果。</thinking>\n<说明>\n- 用餐并更新技能记录。\n</说明>\n<命令>\nset worldClock = "2026-10-18T08:10:00+08:00"\nset protagonist = {"emotionText":"安心","skills":["驾驶","急救"]}\nadd economy.cash = -3000\npush protagonist.skills = "烹饪"\ndelete protagonist.skills[0]\n</命令>';
  140 |   await page.getByRole('button', { name: '继续未完成阶段', exact: true }).click(); await settled(page);
  141 |   const data = await stored(page); expect(data.state.turnNumber).toBe(1); expect(data.state.economy.cash).toBe(7000); expect(data.state.protagonist.skills).toEqual(['急救','烹饪']);
  142 |   expect(server.calls).toEqual(['story','variables','variables','world']); expect(data.draft.userInput).toBe('');
  143 |   await openStageRaw(page, 'variables');
  144 |   expect(await page.getByLabel('变量模型完整原文').textContent()).toBe(server.control.variables);
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: game.spec.ts >> 四类设置可键盘操作、保存恢复，七项提示词与两个运行开关独立
- Location: e2e/game.spec.ts:299:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '提示词', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - main "游戏首页与存档馆" [ref=e4]:
    - generic [ref=e5]:
      - generic [aria-hidden] [ref=e6]: 黑
      - generic [ref=e7]:
        - text: 黑金王朝
        - generic [ref=e8]: HEIJINWANGCHAO
      - button "设置" [ref=e9] [cursor=pointer]
      - generic [ref=e10]: V1.0 Beta
    - generic [ref=e11]:
      - paragraph [ref=e12]: MODERN CITY / OPEN WORLD
      - heading "黑金王朝" [level=1] [ref=e13]
      - paragraph [ref=e14]: 起点有冲突，人生不预设结局。
    - status "终点 新人生，时刻 --:--，可购票" [ref=e15]:
      - generic [ref=e16]:
        - text: 终点
        - generic [ref=e17]: DEST
      - generic [ref=e18]:
        - generic [ref=e19]: 新
        - generic [ref=e20]: 人
        - generic [ref=e21]: 生
      - generic [ref=e22]:
        - generic [ref=e23]: "-"
        - generic [ref=e24]: "-"
        - generic [ref=e25]: ":"
        - generic [ref=e26]: "-"
        - generic [ref=e27]: "-"
      - generic [ref=e28]: 可购票
    - generic [ref=e29]:
      - generic [ref=e30]: 车票 00
      - generic [ref=e31]: 本地保存 · 无需账号
      - button "导入备份" [disabled] [ref=e32]: ⤓ 导入备份
      - button "刷新列表" [ref=e33] [cursor=pointer]
    - region "车票栏，左右方向键切换" [ref=e34]:
      - article "空白车票：开启新的人生" [ref=e36]:
        - generic [ref=e37]:
          - generic [ref=e38]:
            - generic [ref=e39]: 空白车票
            - generic [ref=e40]: NEW LIFE
            - generic [ref=e41]: NEW
          - generic [ref=e42]:
            - generic [ref=e43]:
              - generic [ref=e44]:
                - generic [ref=e45]: FROM
                - generic [ref=e46]: ？
              - generic [aria-hidden] [ref=e47]: 单程
              - generic [ref=e49]:
                - generic [ref=e50]: TO
                - generic [ref=e51]: ？
            - generic [ref=e52]:
              - generic [ref=e53]:
                - term [ref=e54]: 城市
                - definition [ref=e55]
              - generic [ref=e57]:
                - term [ref=e58]: 职业
                - definition [ref=e59]
              - generic [ref=e61]:
                - term [ref=e62]: 存档
                - definition [ref=e63]: —
            - paragraph [ref=e64]: 四座城市 · 自由职业 · 开放人生
        - generic [ref=e66]:
          - text: 开启新的人生
          - generic [ref=e67]: ↓ 按住票根往下撕
    - navigation "车票页码" [ref=e69]:
      - button "第 1 张，空白车票" [ref=e70] [cursor=pointer]
    - paragraph [ref=e71]: 还没有开始的人生。创建角色，留下第一份存档。
    - button "开始新游戏" [disabled] [ref=e73]:
      - text: 开始新游戏
      - generic [aria-hidden] [ref=e74]: ↗
    - generic [ref=e75]:
      - group "游玩信息" [ref=e76]:
        - button "游玩须知与免责声明" [ref=e77] [cursor=pointer]
        - button "王朝公告" [ref=e78] [cursor=pointer]
      - paragraph [ref=e79]: 四座城市 · 自由职业 · 开放人生三阶段生成 · 原子结算 · 连续回合
  - dialog [ref=e80]:
    - banner [ref=e83]:
      - generic [aria-hidden] [ref=e84]: 设
      - generic [ref=e85]:
        - paragraph [aria-hidden] [ref=e86]: SYSTEM · 系统
        - heading "设置" [level=2] [ref=e87]
      - button "关闭资料界面" [ref=e88] [cursor=pointer]:
        - text: 关闭
        - generic [aria-hidden] [ref=e89]: ×
    - generic [ref=e92]:
      - button "返回设置" [ref=e93] [cursor=pointer]: ‹ 设置
      - heading "AI 连接" [active] [level=3] [ref=e94]
      - generic [ref=e95]:
        - paragraph [ref=e96]:
          - text: 游戏直接从浏览器连接你填写的服务，密钥只存在这台设备上，不进存档。
          - button "安全说明" [ref=e97] [cursor=pointer]
        - region "各阶段使用的模型" [ref=e98]:
          - generic [ref=e99]:
            - heading "各阶段使用的模型" [level=4] [ref=e100]
            - generic [ref=e101]: 先选渠道，再从这个渠道的模型里选；变量、动态世界、记忆默认跟随正文
          - generic [ref=e102]:
            - generic [ref=e103]:
              - strong [ref=e104]: 正文生成
              - generic [ref=e105]: 写剧情，最需要好模型
            - generic [ref=e106]:
              - generic [ref=e108]:
                - generic [ref=e109]: 正文生成渠道
                - combobox "正文生成渠道" [ref=e110] [cursor=pointer]:
                  - generic [ref=e111]: ① 选择渠道
                  - generic [aria-hidden] [ref=e112]: ⌄
              - generic [ref=e114]:
                - generic [ref=e115]: 正文生成模型
                - combobox "正文生成模型" [disabled] [ref=e116]:
                  - generic [ref=e117]: 先选渠道
                  - generic [aria-hidden] [ref=e118]: ⌄
              - button "刷新正文生成模型" [disabled] [ref=e119]: ↻
              - generic [ref=e120]:
                - generic [ref=e121]: 还没有渠道：先在下方「我的渠道」点「＋ 添加渠道」，填好地址和密钥后再回来选择。
                - button "列表里没有？手动填写正文生成模型 ID" [disabled] [ref=e122]
          - generic [ref=e123]:
            - generic [ref=e124]:
              - strong [ref=e125]: 变量管理
              - generic [ref=e126]: 整理金钱、物品、关系
            - group "变量管理模型来源" [ref=e127]:
              - button "跟随正文" [pressed] [ref=e128] [cursor=pointer]
              - button "单独指定" [ref=e129] [cursor=pointer]
          - generic [ref=e130]:
            - generic [ref=e131]:
              - strong [ref=e132]: 动态世界
              - generic [ref=e133]: 推进你不在场的世界
            - group "动态世界模型来源" [ref=e134]:
              - button "跟随正文" [pressed] [ref=e135] [cursor=pointer]
              - button "单独指定" [ref=e136] [cursor=pointer]
          - generic [ref=e137]:
            - generic [ref=e138]:
              - strong [ref=e139]: 记忆维护
              - generic [ref=e140]: 定期整理长期记忆
            - group "记忆维护模型来源" [ref=e141]:
              - button "跟随正文" [pressed] [ref=e142] [cursor=pointer]
              - button "单独指定" [ref=e143] [cursor=pointer]
        - region "API 渠道列表" [ref=e145]:
          - heading "我的渠道 · 点开编辑" [level=4] [ref=e146]
          - button "＋ 添加渠道" [ref=e147] [cursor=pointer]
        - generic [ref=e148]:
          - status
          - button "放弃修改" [disabled] [ref=e149]
          - button "保存 AI 配置" [disabled] [ref=e150]
```

# Test source

```ts
  211 | });
  212 | test('自定义职业、跳过同伴，多存档选择切换与确认删除', async ({ page }) => {
  213 |   await seed(page);
  214 |   await begin(page, '自定义角色');
  215 |   await page.getByRole('radio', { name: '自由选择', exact: true }).check();
  216 |   await page.getByLabel('职业名称', { exact: true }).fill('独立策展人');
  217 |   await page.getByRole('button', { name: /下一步/ }).click();
  218 |   await page.getByRole('button', { name: '跳过背景，继续' }).click();
  219 |   await page.getByRole('button', { name: '跳过同伴，继续' }).click();
  220 |   await page.getByRole('button', { name: '确认并创建存档' }).click(); await openGameTools(page, true);
  221 |   await expect(page.getByRole('heading', { name: '自定义角色' })).toBeVisible();
  222 |   await goHome(page);
  223 |   await expect(page.locator('.save-card')).toHaveCount(2);
  224 |   const first = page.locator('.save-card').filter({ hasText: '界面测试存档（隔离）' });
  225 |   await first.getByRole('button', { name: '选择', exact: true }).click();
  226 |   await page.getByRole('button', { name: /继续游戏/ }).click();
  227 |   await expect(page.getByText('这是隔离测试用正文。').first()).toBeVisible();
  228 |   await goHome(page);
  229 |   await page
  230 |     .locator('.save-card')
  231 |     .filter({ hasText: '自定义角色' })
  232 |     .getByRole('button', { name: '删除', exact: true })
  233 |     .click();
  234 |   await page.getByRole('button', { name: '取消', exact: true }).click();
  235 |   await expect(page.locator('.save-card')).toHaveCount(2);
  236 |   await page
  237 |     .locator('.save-card')
  238 |     .filter({ hasText: '自定义角色' })
  239 |     .getByRole('button', { name: '删除', exact: true })
  240 |     .click();
  241 |   await page.getByRole('button', { name: '确认删除' }).click();
  242 |   await expect(page.locator('.save-card')).toHaveCount(1);
  243 |   await page.reload(); await openGameTools(page);
  244 |   await expect(page.locator('.save-card')).toHaveCount(1);
  245 | });
  246 | test('七面板一键打开、键盘关闭、全量资料只读且保留阅读位置', async ({ page }) => {
  247 |   await seed(page);
  248 |   await page.getByRole('button', { name: /读取存档/ }).click(); await openGameTools(page);
  249 |   const reader = page.getByTestId('story-reader');
  250 |   await reader.evaluate((el) => {
  251 |     el.scrollTop = 500;
  252 |   });
  253 |   const position = await reader.evaluate((el) => el.scrollTop);
  254 |   await openWorldArchive(page);
  255 |   for (const title of ['NPC', '势力组织', '地图', '物品栏', '世界事件', '历史时间轴', '记忆']) {
  256 |     const opener = page
  257 |       .getByRole('complementary', { name: '世界资料' })
  258 |       .getByRole('button', { name: new RegExp(title) });
  259 |     await opener.click();
  260 |     const modal = page.getByRole('dialog', { name: title, exact: true });
  261 |     await expect(modal).toBeVisible();
  262 |     if (title === 'NPC') {
  263 |       await page.getByLabel('搜索人物').fill('同事');
  264 |       await page.getByRole('button', { name: '查看人物：同事', exact: true }).click();
  265 |       await expect(modal).toContainText('内部关系判断不可见');
  266 |       await expect(modal).toContainText('在场人物内部身份不可见');
  267 |       await expect(modal.locator('.detail').filter({ hasText: '关系倾向' })).toContainText('30');
  268 |     }
  269 |     if (title === '世界事件') {
  270 |       await modal.getByText('旧版独立事件资料', { exact: false }).first().click();
  271 |       await modal.getByRole('button', { name: /公开会面/ }).first().click();
  272 |       await expect(modal).toContainText('2099');
  273 |       const back = modal.getByRole('button', { name: '返回事件列表', exact: true });
  274 |       if (await back.isVisible()) await back.click();
  275 |       await expect(modal).toContainText('秘密计划不可见');
  276 |     }
  277 |     if (title === '历史时间轴')
  278 |       expect(await modal.getByRole('region', { name: '史料记录', exact: true }).getByRole('heading', { level: 3 }).allTextContents()).toEqual([
  279 |         '更早的公开事件',
  280 |         '公开会面',
  281 |       ]);
  282 |     if (title === '记忆') {
  283 |       await modal.getByRole('button', { name: '短期记忆', exact: true }).click();
  284 |       await expect(modal).toContainText('已知记忆：一次公开会面');
  285 |       for (const name of ['即时记忆', '短期记忆', '中期记忆', '长期记忆']) {
  286 |         await modal.getByRole('button', { name, exact: true }).click();
  287 |         await expect(modal.getByRole('button', { name, exact: true })).toHaveAttribute('aria-pressed', 'true');
  288 |       }
  289 |     }
  290 |     await page.keyboard.press('Tab');
  291 |     expect(await modal.evaluate((el) => el.contains(document.activeElement))).toBe(true);
  292 |     await page.keyboard.press('Escape');
  293 |     await expect(modal).toHaveCount(0);
  294 |     await expect(opener).toBeFocused();
  295 |     expect(await reader.evaluate((el) => el.scrollTop)).toBe(position);
  296 |   }
  297 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  298 | });
  299 | test('四类设置可键盘操作、保存恢复，七项提示词与两个运行开关独立', async ({ page, baseURL }) => {
  300 |   const external: string[] = [];
  301 |   page.on('request', (request) => {
  302 |     if (new URL(request.url()).origin !== new URL(baseURL!).origin) external.push(request.url());
  303 |   });
  304 |   await page.goto('/');
  305 |   await page.getByRole('button', { name: '设置', exact: true }).click();
  306 |   await aiTab(page);
  307 |   // 还没有渠道：只显示添加入口，没有可填写的密钥或可点的测试按钮。
  308 |   await expect(page.getByRole('button', { name: '＋ 添加渠道', exact: true })).toBeVisible();
  309 |   await expect(page.getByLabel('API 密钥')).toHaveCount(0);
  310 |   await expect(page.getByRole('button', { name: /测试回复/ })).toHaveCount(0);
> 311 |   await page.getByRole('button', { name: '提示词', exact: true }).click();
      |                                                                ^ Error: locator.click: Test timeout of 30000ms exceeded.
  312 |   await expect(page.locator('.settings-fields > label')).toHaveCount(7);
  313 |   await page.getByLabel('叙事人称').selectOption('first');
  314 |   await page.getByLabel('正文最低字数').fill('2000');
  315 |   await page.getByLabel('NoControl（防抢话）').uncheck();
  316 |   await page.getByRole('button', { name: '保存本地设置' }).click();
  317 |   await page.getByRole('button', { name: '记忆', exact: true }).click();
  318 |   await expect(page.getByRole('button', { name: '记忆总结', exact: true })).toHaveCount(0);
  319 |   await page.getByLabel('即时记忆完整回合数').fill('0');
  320 |   await page.getByRole('button', { name: '保存记忆设置', exact: true }).click();
  321 |   await expect(page.getByText(/即时记忆完整回合数须为1～10000的正整数/)).toBeVisible();
  322 |   await page.getByLabel('即时记忆完整回合数').fill('12');
  323 |   await page.getByRole('button', { name: '保存记忆设置', exact: true }).click();
  324 |   await expect(page.getByText(/记忆设置已保存/)).toBeVisible();
  325 |   await page.getByRole('button', { name: '运行', exact: true }).click();
  326 |   await page.getByLabel('变量管理', { exact: true }).uncheck();
  327 |   await expect(page.getByLabel('动态世界', { exact: true })).toBeChecked();
  328 |   await page.getByRole('button', { name: '保存本地设置' }).click();
  329 |   await page.keyboard.press('Escape');
  330 |   await page.reload(); await openGameTools(page);
  331 |   await page.getByRole('button', { name: '设置', exact: true }).click();
  332 |   await page.getByRole('button', { name: '提示词', exact: true }).click();
  333 |   await expect(page.getByLabel('叙事人称')).toHaveValue('first');
  334 |   await expect(page.getByLabel('正文最低字数')).toHaveValue('2000');
  335 |   await expect(page.getByLabel('NoControl（防抢话）')).not.toBeChecked();
  336 |   await page.getByRole('button', { name: '记忆', exact: true }).click();
  337 |   await expect(page.getByLabel('即时记忆完整回合数')).toHaveValue('12');
  338 |   await page.getByRole('button', { name: '运行', exact: true }).click();
  339 |   await expect(page.getByLabel('变量管理', { exact: true })).not.toBeChecked();
  340 |   await expect(page.getByLabel('动态世界', { exact: true })).toBeChecked();
  341 |   expect(external).toEqual([]);
  342 | });
  343 | 
```
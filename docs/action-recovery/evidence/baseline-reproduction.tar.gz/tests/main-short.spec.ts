import {test,expect} from '../../action-recovery-fix/e2e/helpers/test';
import {setup,plan,data,send,closeError} from '../../action-recovery-fix/e2e/helpers/actionRecovery';
import {openWorkflowDiagnostics} from '../../action-recovery-fix/e2e/helpers/gameLayout';
test('main short viewport diagnostic comparison',async({page})=>{
 await setup(page);await plan(page,'401','world');await send(page);await expect.poll(async()=>(await data(page)).draft?.stageStatus.world).toBe('failed');await closeError(page);await page.setViewportSize({width:392,height:420});await page.locator('#player-input').click();await page.locator('#player-input').fill('未发送行动');await page.screenshot({path:'/workspace/action-recovery-20261116/before-screenshots/main-392x420.png'});await openWorkflowDiagnostics(page);
});

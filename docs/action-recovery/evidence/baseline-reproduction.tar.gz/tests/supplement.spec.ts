import {test,expect} from '../../action-recovery-fix/e2e/helpers/test';
import {setup,transport,plan,calls,data,closeError,button,stopped,record,oldOptions} from './support';
test('C explicit suggestion, twice failed, unsent edit, save switch, reload and resend',async({page},info)=>{
 await setup(page);const original=await data(page);
 await page.getByRole('button',{name:/沿江走一走/}).click();await expect(page.locator('#player-input')).toHaveValue(oldOptions[0]);expect(await data(page)).toEqual(original);expect(await calls(page)).toHaveLength(0);
 await plan(page,'invalid');await page.getByRole('button',{name:'发送',exact:true}).click();await expect.poll(async()=>(await data(page)).draft?.failures.length).toBe(1);await stopped(page);await closeError(page);
 await button(page).click();await expect.poll(async()=>(await data(page)).draft?.failures.length).toBe(2);await stopped(page);await closeError(page);const failed=await data(page);expect(failed.state).toEqual(original.state);expect(await calls(page)).toHaveLength(2);
 await page.locator('#player-input').fill('暂未发送的修改');await record(page,'twice-failed-unsent',info.project.name);expect(await data(page)).toEqual(failed);
 await page.goto('/#game/save-b');await expect(page.getByTestId('story-reader')).toBeVisible();await expect(page.getByText('正文生成失败：invalid_output',{exact:false})).toHaveCount(0);
 await page.goto('/#game/save-a');await expect(page.getByTestId('story-reader')).toBeVisible();await page.reload();await expect(page.getByTestId('story-reader')).toBeVisible();await expect(page.locator('#player-input')).toHaveValue(oldOptions[0]);expect(await data(page)).toEqual(failed);
 await transport(page);await plan(page,'ok');await page.locator('#player-input').fill('改去街边观察');await page.getByRole('button',{name:'发送',exact:true}).click();await expect.poll(async()=>(await data(page)).state.turnNumber).toBe(2);expect((await calls(page)).map(c=>c.stage)).toEqual(['story','variables','world']);
});
test('RED stopped story retains explicitly identified prior journal suggestions',async({page})=>{
 await setup(page);await plan(page,'invalid');await page.locator('#player-input').fill('沿江走一走');await page.getByRole('button',{name:'发送',exact:true}).click();await expect.poll(async()=>(await data(page)).draft?.stageStatus.story).toBe('failed');await stopped(page);await closeError(page);
 await expect(page.getByText('上一已结算回合建议 · 第1回合',{exact:true})).toBeVisible();
 await expect(page.getByRole('button',{name:/去书店看看/})).toBeVisible();
});
test('RED pending variables explains disabled send and legal continuation',async({page})=>{
 await setup(page);await plan(page,'401','variables');await page.locator('#player-input').fill('沿江走一走');await page.getByRole('button',{name:'发送',exact:true}).click();await expect.poll(async()=>(await data(page)).draft?.stageStatus.variables).toBe('failed');await stopped(page);await closeError(page);
 await expect(page.locator('#action-recovery-guidance')).toContainText('继续生成变量');await expect(page.getByRole('button',{name:'发送',exact:true})).toBeDisabled();
});

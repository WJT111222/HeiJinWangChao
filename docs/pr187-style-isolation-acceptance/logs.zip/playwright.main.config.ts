import base from '/workspace/pr187-main-control/playwright.config';
export default {...base,testDir:'/workspace/pr187-main-control/e2e',workers:1,outputDir:'/workspace/pr187-evidence/browser-main-results',
  use:{...base.use,baseURL:'http://127.0.0.1:47581'},
  webServer:{...base.webServer,command:'npm run dev -- --host 127.0.0.1 --port 47581 --strictPort',cwd:'/workspace/pr187-main-control',url:'http://127.0.0.1:47581',reuseExistingServer:false}};

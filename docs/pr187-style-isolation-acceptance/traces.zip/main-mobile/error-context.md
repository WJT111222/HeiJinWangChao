# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: pr187-memory-style-wake.spec.ts >> 调查：仅保存剧情风格是否唤醒已有自动记忆任务
- Location: e2e/pr187-memory-style-wake.spec.ts:3:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: 2
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - banner:
    - button "打开游戏菜单" [ref=f1e2] [cursor=pointer]: ☰
  - main [ref=f1e3]:
    - generic "城市与当前场景" [ref=f1e4]:
      - button "此时此地与主角状态" [ref=f1e5] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e6]: 城
        - generic [ref=f1e7]:
          - generic: 当前地点
          - generic [ref=f1e8]: 重庆
        - time [ref=f1e9]: 08:00
        - generic "天气：天气待确认" [ref=f1e10]: —
      - generic [ref=f1e11]: 重庆，2026/10/18 星期日 08:00，天气：天气待确认
    - region "剧情与行动" [ref=f1e12]:
      - generic "正文阅读区域" [ref=f1e13]:
        - generic [ref=f1e14]:
          - generic [ref=f1e15]: THE STORY
          - generic [ref=f1e16]: 已结算历史
        - article [ref=f1e17]:
          - generic [ref=f1e18]:
            - heading "第 1 回合" [level=2] [ref=f1e19]
            - generic [aria-hidden] [ref=f1e20]: 第一回
            - generic [ref=f1e21]: 时间地点未记录
          - paragraph [ref=f1e23]: 第 1 回合，主角在河边散步，观察水面。
        - article [ref=f1e24]:
          - generic [ref=f1e25]:
            - heading "第 2 回合" [level=2] [ref=f1e26]
            - generic [aria-hidden] [ref=f1e27]: 第二回
            - generic [ref=f1e28]: 时间地点未记录
          - paragraph [ref=f1e30]: 第 2 回合，主角在河边散步，观察水面。
        - article [ref=f1e31]:
          - generic [ref=f1e32]:
            - heading "第 3 回合" [level=2] [ref=f1e33]
            - generic [aria-hidden] [ref=f1e34]: 第三回
            - generic [ref=f1e35]: 时间地点未记录
          - paragraph [ref=f1e37]: 主角和同事陈宁在社区诊所约定下周三再次见面，并保管一枚蓝色钥匙。
        - article [ref=f1e38]:
          - generic [ref=f1e39]:
            - heading "第 4 回合" [level=2] [ref=f1e40]
            - generic [aria-hidden] [ref=f1e41]: 第四回
            - generic [ref=f1e42]: 时间地点未记录
          - paragraph [ref=f1e44]: 第 4 回合，主角在河边散步，观察水面。
        - article [ref=f1e45]:
          - generic [ref=f1e46]:
            - heading "第 5 回合" [level=2] [ref=f1e47]
            - generic [aria-hidden] [ref=f1e48]: 第五回
            - generic [ref=f1e49]: 时间地点未记录
          - paragraph [ref=f1e51]: 第 5 回合，主角在河边散步，观察水面。
        - article [ref=f1e52]:
          - generic [ref=f1e53]:
            - heading "第 6 回合" [level=2] [ref=f1e54]
            - generic [aria-hidden] [ref=f1e55]: 第六回
            - generic [ref=f1e56]: 时间地点未记录
          - paragraph [ref=f1e58]: 第 6 回合，主角在河边散步，观察水面。
        - article [ref=f1e59]:
          - generic [ref=f1e60]:
            - heading "第 7 回合" [level=2] [ref=f1e61]
            - generic [aria-hidden] [ref=f1e62]: 第七回
            - generic [ref=f1e63]: 时间地点未记录
          - paragraph [ref=f1e65]: 第 7 回合，主角在河边散步，观察水面。
        - article [ref=f1e66]:
          - generic [ref=f1e67]:
            - heading "第 8 回合" [level=2] [ref=f1e68]
            - generic [aria-hidden] [ref=f1e69]: 第八回
            - generic [ref=f1e70]: 时间地点未记录
          - paragraph [ref=f1e72]: 第 8 回合，主角在河边散步，观察水面。
        - article [ref=f1e73]:
          - generic [ref=f1e74]:
            - heading "第 9 回合" [level=2] [ref=f1e75]
            - generic [aria-hidden] [ref=f1e76]: 第九回
            - generic [ref=f1e77]: 时间地点未记录
          - paragraph [ref=f1e79]: 第 9 回合，主角在河边散步，观察水面。
        - article [ref=f1e80]:
          - generic [ref=f1e81]:
            - heading "第 10 回合" [level=2] [ref=f1e82]
            - generic [aria-hidden] [ref=f1e83]: 第十回
            - generic [ref=f1e84]: 时间地点未记录
          - paragraph [ref=f1e86]: 第 10 回合，主角在河边散步，观察水面。
        - article [ref=f1e87]:
          - generic [ref=f1e88]:
            - heading "第 11 回合" [level=2] [ref=f1e89]
            - generic [aria-hidden] [ref=f1e90]: 第十一回
            - generic [ref=f1e91]: 时间地点未记录
          - paragraph [ref=f1e93]: 第 11 回合，主角在河边散步，观察水面。
        - article [ref=f1e94]:
          - generic [ref=f1e95]:
            - heading "第 12 回合" [level=2] [ref=f1e96]
            - generic [aria-hidden] [ref=f1e97]: 第十二回
            - generic [ref=f1e98]: 时间地点未记录
          - paragraph [ref=f1e100]: 第 12 回合，主角在河边散步，观察水面。
        - article [ref=f1e101]:
          - generic [ref=f1e102]:
            - heading "第 13 回合" [level=2] [ref=f1e103]
            - generic [aria-hidden] [ref=f1e104]: 第十三回
            - generic [ref=f1e105]: 时间地点未记录
          - paragraph [ref=f1e107]: 第 13 回合，主角在河边散步，观察水面。
        - article [ref=f1e108]:
          - generic [ref=f1e109]:
            - heading "第 14 回合" [level=2] [ref=f1e110]
            - generic [aria-hidden] [ref=f1e111]: 第十四回
            - generic [ref=f1e112]: 时间地点未记录
          - paragraph [ref=f1e114]: 第 14 回合，主角在河边散步，观察水面。
        - article [ref=f1e115]:
          - generic [ref=f1e116]:
            - heading "第 15 回合" [level=2] [ref=f1e117]
            - generic [aria-hidden] [ref=f1e118]: 第十五回
            - generic [ref=f1e119]: 时间地点未记录
          - paragraph [ref=f1e121]: 第 15 回合，主角在河边散步，观察水面。
        - article [ref=f1e122]:
          - generic [ref=f1e123]:
            - heading "第 16 回合" [level=2] [ref=f1e124]
            - generic [aria-hidden] [ref=f1e125]: 第十六回
            - generic [ref=f1e126]: 时间地点未记录
          - paragraph [ref=f1e128]: 第 16 回合，主角在河边散步，观察水面。
        - article [ref=f1e129]:
          - generic [ref=f1e130]:
            - heading "第 17 回合" [level=2] [ref=f1e131]
            - generic [aria-hidden] [ref=f1e132]: 第十七回
            - generic [ref=f1e133]: 时间地点未记录
          - paragraph [ref=f1e135]: 第 17 回合，主角在河边散步，观察水面。
        - article [ref=f1e136]:
          - generic [ref=f1e137]:
            - heading "第 18 回合" [level=2] [ref=f1e138]
            - generic [aria-hidden] [ref=f1e139]: 第十八回
            - generic [ref=f1e140]: 时间地点未记录
          - paragraph [ref=f1e142]: 第 18 回合，主角在河边散步，观察水面。
        - article [ref=f1e143]:
          - generic [ref=f1e144]:
            - heading "第 19 回合" [level=2] [ref=f1e145]
            - generic [aria-hidden] [ref=f1e146]: 第十九回
            - generic [ref=f1e147]: 时间地点未记录
          - paragraph [ref=f1e149]: 第 19 回合，主角在河边散步，观察水面。
        - article [ref=f1e150]:
          - generic [ref=f1e151]:
            - heading "第 20 回合" [level=2] [ref=f1e152]
            - generic [aria-hidden] [ref=f1e153]: 第二十回
            - generic [ref=f1e154]: 时间地点未记录
          - paragraph [ref=f1e156]: 第 20 回合，主角在河边散步，观察水面。
        - article [ref=f1e157]:
          - generic [ref=f1e158]:
            - heading "第 21 回合" [level=2] [ref=f1e159]
            - generic [aria-hidden] [ref=f1e160]: 第二十一回
            - generic [ref=f1e161]: 时间地点未记录
          - paragraph [ref=f1e163]: 第 21 回合，主角在河边散步，观察水面。
        - article [ref=f1e164]:
          - generic [ref=f1e165]:
            - heading "第 22 回合" [level=2] [ref=f1e166]
            - generic [aria-hidden] [ref=f1e167]: 第二十二回
            - generic [ref=f1e168]: 时间地点未记录
          - paragraph [ref=f1e170]: 第 22 回合，主角在河边散步，观察水面。
        - article [ref=f1e171]:
          - generic [ref=f1e172]:
            - heading "第 23 回合" [level=2] [ref=f1e173]
            - generic [aria-hidden] [ref=f1e174]: 第二十三回
            - generic [ref=f1e175]: 时间地点未记录
          - paragraph [ref=f1e177]: 第 23 回合，主角在河边散步，观察水面。
        - article [ref=f1e178]:
          - generic [ref=f1e179]:
            - heading "第 24 回合" [level=2] [ref=f1e180]
            - generic [aria-hidden] [ref=f1e181]: 第二十四回
            - generic [ref=f1e182]: 时间地点未记录
          - paragraph [ref=f1e184]: 第 24 回合，主角在河边散步，观察水面。
        - article [ref=f1e185]:
          - generic [ref=f1e186]:
            - heading "第 25 回合" [level=2] [ref=f1e187]
            - generic [aria-hidden] [ref=f1e188]: 第二十五回
            - generic [ref=f1e189]: 时间地点未记录
          - paragraph [ref=f1e191]: 第 25 回合，主角在河边散步，观察水面。
        - article [ref=f1e192]:
          - generic [ref=f1e193]:
            - heading "第 26 回合" [level=2] [ref=f1e194]
            - generic [aria-hidden] [ref=f1e195]: 第二十六回
            - generic [ref=f1e196]: 时间地点未记录
          - paragraph [ref=f1e198]: 第 26 回合，主角在河边散步，观察水面。
        - article [ref=f1e199]:
          - generic [ref=f1e200]:
            - heading "第 27 回合" [level=2] [ref=f1e201]
            - generic [aria-hidden] [ref=f1e202]: 第二十七回
            - generic [ref=f1e203]: 时间地点未记录
          - paragraph [ref=f1e205]: 第 27 回合，主角在河边散步，观察水面。
        - article [ref=f1e206]:
          - generic [ref=f1e207]:
            - heading "第 28 回合" [level=2] [ref=f1e208]
            - generic [aria-hidden] [ref=f1e209]: 第二十八回
            - generic [ref=f1e210]: 时间地点未记录
          - paragraph [ref=f1e212]: 第 28 回合，主角在河边散步，观察水面。
        - article [ref=f1e213]:
          - generic [ref=f1e214]:
            - heading "第 29 回合" [level=2] [ref=f1e215]
            - generic [aria-hidden] [ref=f1e216]: 第二十九回
            - generic [ref=f1e217]: 时间地点未记录
          - paragraph [ref=f1e219]: 第 29 回合，主角在河边散步，观察水面。
        - article [ref=f1e220]:
          - generic [ref=f1e221]:
            - heading "第 30 回合" [level=2] [ref=f1e222]
            - generic [aria-hidden] [ref=f1e223]: 第三十回
            - generic [ref=f1e224]: 时间地点未记录
          - paragraph [ref=f1e226]: 第 30 回合，主角在河边散步，观察水面。
        - article [ref=f1e227]:
          - generic [ref=f1e228]:
            - heading "第 31 回合" [level=2] [ref=f1e229]
            - generic [aria-hidden] [ref=f1e230]: 第三十一回
            - generic [ref=f1e231]: 时间地点未记录
          - paragraph [ref=f1e233]: 第 31 回合，主角在河边散步，观察水面。
        - article [ref=f1e234]:
          - generic [ref=f1e235]:
            - heading "第 32 回合" [level=2] [ref=f1e236]
            - generic [aria-hidden] [ref=f1e237]: 第三十二回
            - generic [ref=f1e238]: 时间地点未记录
          - paragraph [ref=f1e240]: 第 32 回合，主角在河边散步，观察水面。
        - article [ref=f1e241]:
          - generic [ref=f1e242]:
            - heading "第 33 回合" [level=2] [ref=f1e243]
            - generic [aria-hidden] [ref=f1e244]: 第三十三回
            - generic [ref=f1e245]: 时间地点未记录
          - paragraph [ref=f1e247]: 第 33 回合，主角在河边散步，观察水面。
        - article [ref=f1e248]:
          - generic [ref=f1e249]:
            - heading "第 34 回合" [level=2] [ref=f1e250]
            - generic [aria-hidden] [ref=f1e251]: 第三十四回
            - generic [ref=f1e252]: 时间地点未记录
          - paragraph [ref=f1e254]: 第 34 回合，主角在河边散步，观察水面。
        - article [ref=f1e255]:
          - generic [ref=f1e256]:
            - heading "第 35 回合" [level=2] [ref=f1e257]
            - generic [aria-hidden] [ref=f1e258]: 第三十五回
            - generic [ref=f1e259]: 时间地点未记录
          - paragraph [ref=f1e261]: 第 35 回合，主角在河边散步，观察水面。
        - article [ref=f1e262]:
          - generic [ref=f1e263]:
            - heading "第 36 回合" [level=2] [ref=f1e264]
            - generic [aria-hidden] [ref=f1e265]: 第三十六回
            - generic [ref=f1e266]: 时间地点未记录
          - paragraph [ref=f1e268]: 第 36 回合，主角在河边散步，观察水面。
        - article [ref=f1e269]:
          - generic [ref=f1e270]:
            - heading "第 37 回合" [level=2] [ref=f1e271]
            - generic [aria-hidden] [ref=f1e272]: 第三十七回
            - generic [ref=f1e273]: 时间地点未记录
          - paragraph [ref=f1e275]: 第 37 回合，主角在河边散步，观察水面。
        - article [ref=f1e276]:
          - generic [ref=f1e277]:
            - heading "第 38 回合" [level=2] [ref=f1e278]
            - generic [aria-hidden] [ref=f1e279]: 第三十八回
            - generic [ref=f1e280]: 时间地点未记录
          - paragraph [ref=f1e282]: 第 38 回合，主角在河边散步，观察水面。
        - article [ref=f1e283]:
          - generic [ref=f1e284]:
            - heading "第 39 回合" [level=2] [ref=f1e285]
            - generic [aria-hidden] [ref=f1e286]: 第三十九回
            - generic [ref=f1e287]: 时间地点未记录
          - paragraph [ref=f1e289]: 第 39 回合，主角在河边散步，观察水面。
        - article [ref=f1e290]:
          - generic [ref=f1e291]:
            - heading "第 40 回合" [level=2] [ref=f1e292]
            - generic [aria-hidden] [ref=f1e293]: 第四十回
            - generic [ref=f1e294]: 时间地点未记录
          - paragraph [ref=f1e296]: 第 40 回合，主角在河边散步，观察水面。
        - article [ref=f1e297]:
          - generic [ref=f1e298]:
            - heading "第 41 回合" [level=2] [ref=f1e299]
            - generic [aria-hidden] [ref=f1e300]: 第四十一回
            - generic [ref=f1e301]: 时间地点未记录
          - paragraph [ref=f1e303]: 第 41 回合，主角在河边散步，观察水面。
        - article [ref=f1e304]:
          - generic [ref=f1e305]:
            - heading "第 42 回合" [level=2] [ref=f1e306]
            - generic [aria-hidden] [ref=f1e307]: 第四十二回
            - generic [ref=f1e308]: 时间地点未记录
          - paragraph [ref=f1e310]: 第 42 回合，主角在河边散步，观察水面。
        - article [ref=f1e311]:
          - generic [ref=f1e312]:
            - heading "第 43 回合" [level=2] [ref=f1e313]
            - generic [aria-hidden] [ref=f1e314]: 第四十三回
            - generic [ref=f1e315]: 时间地点未记录
          - paragraph [ref=f1e317]: 第 43 回合，主角在河边散步，观察水面。
        - article [ref=f1e318]:
          - generic [ref=f1e319]:
            - heading "第 44 回合" [level=2] [ref=f1e320]
            - generic [aria-hidden] [ref=f1e321]: 第四十四回
            - generic [ref=f1e322]: 时间地点未记录
          - paragraph [ref=f1e324]: 第 44 回合，主角在河边散步，观察水面。
        - article [ref=f1e325]:
          - generic [ref=f1e326]:
            - heading "第 45 回合" [level=2] [ref=f1e327]
            - generic [aria-hidden] [ref=f1e328]: 第四十五回
            - generic [ref=f1e329]: 时间地点未记录
          - paragraph [ref=f1e331]: 第 45 回合，主角在河边散步，观察水面。
        - article [ref=f1e332]:
          - generic [ref=f1e333]:
            - heading "第 46 回合" [level=2] [ref=f1e334]
            - generic [aria-hidden] [ref=f1e335]: 第四十六回
            - generic [ref=f1e336]: 时间地点未记录
          - paragraph [ref=f1e338]: 第 46 回合，主角在河边散步，观察水面。
        - article [ref=f1e339]:
          - generic [ref=f1e340]:
            - heading "第 47 回合" [level=2] [ref=f1e341]
            - generic [aria-hidden] [ref=f1e342]: 第四十七回
            - generic [ref=f1e343]: 时间地点未记录
          - paragraph [ref=f1e345]: 第 47 回合，主角在河边散步，观察水面。
        - article [ref=f1e346]:
          - generic [ref=f1e347]:
            - heading "第 48 回合" [level=2] [ref=f1e348]
            - generic [aria-hidden] [ref=f1e349]: 第四十八回
            - generic [ref=f1e350]: 时间地点未记录
          - paragraph [ref=f1e352]: 第 48 回合，主角在河边散步，观察水面。
        - article [ref=f1e353]:
          - generic [ref=f1e354]:
            - heading "第 49 回合" [level=2] [ref=f1e355]
            - generic [aria-hidden] [ref=f1e356]: 第四十九回
            - generic [ref=f1e357]: 时间地点未记录
          - paragraph [ref=f1e359]: 第 49 回合，主角在河边散步，观察水面。
        - article [ref=f1e360]:
          - generic [ref=f1e361]:
            - heading "第 50 回合" [level=2] [ref=f1e362]
            - generic [aria-hidden] [ref=f1e363]: 第五十回
            - generic [ref=f1e364]: 时间地点未记录
          - paragraph [ref=f1e366]: 第 50 回合，主角在河边散步，观察水面。
        - article [ref=f1e367]:
          - generic [ref=f1e368]:
            - heading "第 51 回合" [level=2] [ref=f1e369]
            - generic [aria-hidden] [ref=f1e370]: 第五十一回
            - generic [ref=f1e371]: 时间地点未记录
          - paragraph [ref=f1e373]: 第 51 回合，主角在河边散步，观察水面。
        - article [ref=f1e374]:
          - generic [ref=f1e375]:
            - heading "第 52 回合" [level=2] [ref=f1e376]
            - generic [aria-hidden] [ref=f1e377]: 第五十二回
            - generic [ref=f1e378]: 时间地点未记录
          - paragraph [ref=f1e380]: 第 52 回合，主角在河边散步，观察水面。
        - article [ref=f1e381]:
          - generic [ref=f1e382]:
            - heading "第 53 回合" [level=2] [ref=f1e383]
            - generic [aria-hidden] [ref=f1e384]: 第五十三回
            - generic [ref=f1e385]: 时间地点未记录
          - paragraph [ref=f1e387]: 第 53 回合，主角在河边散步，观察水面。
        - article [ref=f1e388]:
          - generic [ref=f1e389]:
            - heading "第 54 回合" [level=2] [ref=f1e390]
            - generic [aria-hidden] [ref=f1e391]: 第五十四回
            - generic [ref=f1e392]: 时间地点未记录
          - paragraph [ref=f1e394]: 第 54 回合，主角在河边散步，观察水面。
        - article [ref=f1e395]:
          - generic [ref=f1e396]:
            - heading "第 55 回合" [level=2] [ref=f1e397]
            - generic [aria-hidden] [ref=f1e398]: 第五十五回
            - generic [ref=f1e399]: 时间地点未记录
          - paragraph [ref=f1e401]: 第 55 回合，主角在河边散步，观察水面。
        - article [ref=f1e402]:
          - generic [ref=f1e403]:
            - heading "第 56 回合" [level=2] [ref=f1e404]
            - generic [aria-hidden] [ref=f1e405]: 第五十六回
            - generic [ref=f1e406]: 时间地点未记录
          - paragraph [ref=f1e408]: 第 56 回合，主角在河边散步，观察水面。
        - article [ref=f1e409]:
          - generic [ref=f1e410]:
            - heading "第 57 回合" [level=2] [ref=f1e411]
            - generic [aria-hidden] [ref=f1e412]: 第五十七回
            - generic [ref=f1e413]: 时间地点未记录
          - paragraph [ref=f1e415]: 第 57 回合，主角在河边散步，观察水面。
        - article [ref=f1e416]:
          - generic [ref=f1e417]:
            - heading "第 58 回合" [level=2] [ref=f1e418]
            - generic [aria-hidden] [ref=f1e419]: 第五十八回
            - generic [ref=f1e420]: 时间地点未记录
          - paragraph [ref=f1e422]: 第 58 回合，主角在河边散步，观察水面。
        - article [ref=f1e423]:
          - generic [ref=f1e424]:
            - heading "第 59 回合" [level=2] [ref=f1e425]
            - generic [aria-hidden] [ref=f1e426]: 第五十九回
            - generic [ref=f1e427]: 时间地点未记录
          - paragraph [ref=f1e429]: 第 59 回合，主角在河边散步，观察水面。
        - article [ref=f1e430]:
          - generic [ref=f1e431]:
            - heading "第 60 回合" [level=2] [ref=f1e432]
            - generic [aria-hidden] [ref=f1e433]: 第六十回
            - generic [ref=f1e434]: 时间地点未记录
          - paragraph [ref=f1e436]: 第 60 回合，主角在河边散步，观察水面。
        - article [ref=f1e437]:
          - generic [ref=f1e438]:
            - heading "第 61 回合" [level=2] [ref=f1e439]
            - generic [aria-hidden] [ref=f1e440]: 第六十一回
            - generic [ref=f1e441]: 时间地点未记录
          - paragraph [ref=f1e443]: 第 61 回合，主角在河边散步，观察水面。
        - article [ref=f1e444]:
          - generic [ref=f1e445]:
            - heading "第 62 回合" [level=2] [ref=f1e446]
            - generic [aria-hidden] [ref=f1e447]: 第六十二回
            - generic [ref=f1e448]: 时间地点未记录
          - paragraph [ref=f1e450]: 第 62 回合，主角在河边散步，观察水面。
        - article [ref=f1e451]:
          - generic [ref=f1e452]:
            - heading "第 63 回合" [level=2] [ref=f1e453]
            - generic [aria-hidden] [ref=f1e454]: 第六十三回
            - generic [ref=f1e455]: 时间地点未记录
          - paragraph [ref=f1e457]: 第 63 回合，主角在河边散步，观察水面。
        - article [ref=f1e458]:
          - generic [ref=f1e459]:
            - heading "第 64 回合" [level=2] [ref=f1e460]
            - generic [aria-hidden] [ref=f1e461]: 第六十四回
            - generic [ref=f1e462]: 时间地点未记录
          - paragraph [ref=f1e464]: 第 64 回合，主角在河边散步，观察水面。
        - article [ref=f1e465]:
          - generic [ref=f1e466]:
            - heading "第 65 回合" [level=2] [ref=f1e467]
            - generic [aria-hidden] [ref=f1e468]: 第六十五回
            - generic [ref=f1e469]: 时间地点未记录
          - paragraph [ref=f1e471]: 第 65 回合，主角在河边散步，观察水面。
        - article [ref=f1e472]:
          - generic [ref=f1e473]:
            - heading "第 66 回合" [level=2] [ref=f1e474]
            - generic [aria-hidden] [ref=f1e475]: 第六十六回
            - generic [ref=f1e476]: 时间地点未记录
          - paragraph [ref=f1e478]: 第 66 回合，主角在河边散步，观察水面。
        - article [ref=f1e479]:
          - generic [ref=f1e480]:
            - heading "第 67 回合" [level=2] [ref=f1e481]
            - generic [aria-hidden] [ref=f1e482]: 第六十七回
            - generic [ref=f1e483]: 时间地点未记录
          - paragraph [ref=f1e485]: 第 67 回合，主角在河边散步，观察水面。
        - article [ref=f1e486]:
          - generic [ref=f1e487]:
            - heading "第 68 回合" [level=2] [ref=f1e488]
            - generic [aria-hidden] [ref=f1e489]: 第六十八回
            - generic [ref=f1e490]: 时间地点未记录
          - paragraph [ref=f1e492]: 第 68 回合，主角在河边散步，观察水面。
        - article [ref=f1e493]:
          - generic [ref=f1e494]:
            - heading "第 69 回合" [level=2] [ref=f1e495]
            - generic [aria-hidden] [ref=f1e496]: 第六十九回
            - generic [ref=f1e497]: 时间地点未记录
          - paragraph [ref=f1e499]: 第 69 回合，主角在河边散步，观察水面。
        - article [ref=f1e500]:
          - generic [ref=f1e501]:
            - heading "第 70 回合" [level=2] [ref=f1e502]
            - generic [aria-hidden] [ref=f1e503]: 第七十回
            - generic [ref=f1e504]: 时间地点未记录
          - paragraph [ref=f1e506]: 第 70 回合，主角在河边散步，观察水面。
        - article [ref=f1e507]:
          - generic [ref=f1e508]:
            - heading "第 71 回合" [level=2] [ref=f1e509]
            - generic [aria-hidden] [ref=f1e510]: 第七十一回
            - generic [ref=f1e511]: 时间地点未记录
          - paragraph [ref=f1e513]: 第 71 回合，主角在河边散步，观察水面。
        - article [ref=f1e514]:
          - generic [ref=f1e515]:
            - heading "第 72 回合" [level=2] [ref=f1e516]
            - generic [aria-hidden] [ref=f1e517]: 第七十二回
            - generic [ref=f1e518]: 时间地点未记录
          - paragraph [ref=f1e520]: 第 72 回合，主角在河边散步，观察水面。
        - article [ref=f1e521]:
          - generic [ref=f1e522]:
            - heading "第 73 回合" [level=2] [ref=f1e523]
            - generic [aria-hidden] [ref=f1e524]: 第七十三回
            - generic [ref=f1e525]: 时间地点未记录
          - paragraph [ref=f1e527]: 第 73 回合，主角在河边散步，观察水面。
        - article [ref=f1e528]:
          - generic [ref=f1e529]:
            - heading "第 74 回合" [level=2] [ref=f1e530]
            - generic [aria-hidden] [ref=f1e531]: 第七十四回
            - generic [ref=f1e532]: 时间地点未记录
          - paragraph [ref=f1e534]: 第 74 回合，主角在河边散步，观察水面。
        - article [ref=f1e535]:
          - generic [ref=f1e536]:
            - heading "第 75 回合" [level=2] [ref=f1e537]
            - generic [aria-hidden] [ref=f1e538]: 第七十五回
            - generic [ref=f1e539]: 时间地点未记录
          - paragraph [ref=f1e541]: 第 75 回合，主角在河边散步，观察水面。
        - article [ref=f1e542]:
          - generic [ref=f1e543]:
            - heading "第 76 回合" [level=2] [ref=f1e544]
            - generic [aria-hidden] [ref=f1e545]: 第七十六回
            - generic [ref=f1e546]: 时间地点未记录
          - paragraph [ref=f1e548]: 第 76 回合，主角在河边散步，观察水面。
        - article [ref=f1e549]:
          - generic [ref=f1e550]:
            - heading "第 77 回合" [level=2] [ref=f1e551]
            - generic [aria-hidden] [ref=f1e552]: 第七十七回
            - generic [ref=f1e553]: 时间地点未记录
          - paragraph [ref=f1e555]: 第 77 回合，主角在河边散步，观察水面。
        - article [ref=f1e556]:
          - generic [ref=f1e557]:
            - heading "第 78 回合" [level=2] [ref=f1e558]
            - generic [aria-hidden] [ref=f1e559]: 第七十八回
            - generic [ref=f1e560]: 时间地点未记录
          - paragraph [ref=f1e562]: 第 78 回合，主角在河边散步，观察水面。
        - article [ref=f1e563]:
          - generic [ref=f1e564]:
            - heading "第 79 回合" [level=2] [ref=f1e565]
            - generic [aria-hidden] [ref=f1e566]: 第七十九回
            - generic [ref=f1e567]: 时间地点未记录
          - paragraph [ref=f1e569]: 第 79 回合，主角在河边散步，观察水面。
        - article [ref=f1e570]:
          - generic [ref=f1e571]:
            - heading "第 80 回合" [level=2] [ref=f1e572]
            - generic [aria-hidden] [ref=f1e573]: 第八十回
            - generic [ref=f1e574]: 时间地点未记录
          - paragraph [ref=f1e576]: 第 80 回合，主角在河边散步，观察水面。
        - article [ref=f1e577]:
          - generic [ref=f1e578]:
            - heading "第 81 回合" [level=2] [ref=f1e579]
            - generic [aria-hidden] [ref=f1e580]: 第八十一回
            - generic [ref=f1e581]: 时间地点未记录
          - paragraph [ref=f1e583]: 第 81 回合，主角在河边散步，观察水面。
        - article [ref=f1e584]:
          - generic [ref=f1e585]:
            - heading "第 82 回合" [level=2] [ref=f1e586]
            - generic [aria-hidden] [ref=f1e587]: 第八十二回
            - generic [ref=f1e588]: 时间地点未记录
          - paragraph [ref=f1e590]: 第 82 回合，主角在河边散步，观察水面。
        - article [ref=f1e591]:
          - generic [ref=f1e592]:
            - heading "第 83 回合" [level=2] [ref=f1e593]
            - generic [aria-hidden] [ref=f1e594]: 第八十三回
            - generic [ref=f1e595]: 时间地点未记录
          - paragraph [ref=f1e597]: 第 83 回合，主角在河边散步，观察水面。
        - article [ref=f1e598]:
          - generic [ref=f1e599]:
            - heading "第 84 回合" [level=2] [ref=f1e600]
            - generic [aria-hidden] [ref=f1e601]: 第八十四回
            - generic [ref=f1e602]: 时间地点未记录
          - paragraph [ref=f1e604]: 第 84 回合，主角在河边散步，观察水面。
        - article [ref=f1e605]:
          - generic [ref=f1e606]:
            - heading "第 85 回合" [level=2] [ref=f1e607]
            - generic [aria-hidden] [ref=f1e608]: 第八十五回
            - generic [ref=f1e609]: 时间地点未记录
          - paragraph [ref=f1e611]: 第 85 回合，主角在河边散步，观察水面。
        - article [ref=f1e612]:
          - generic [ref=f1e613]:
            - heading "第 86 回合" [level=2] [ref=f1e614]
            - generic [aria-hidden] [ref=f1e615]: 第八十六回
            - generic [ref=f1e616]: 时间地点未记录
          - paragraph [ref=f1e618]: 第 86 回合，主角在河边散步，观察水面。
        - article [ref=f1e619]:
          - generic [ref=f1e620]:
            - heading "第 87 回合" [level=2] [ref=f1e621]
            - generic [aria-hidden] [ref=f1e622]: 第八十七回
            - generic [ref=f1e623]: 时间地点未记录
          - paragraph [ref=f1e625]: 第 87 回合，主角在河边散步，观察水面。
        - article [ref=f1e626]:
          - generic [ref=f1e627]:
            - heading "第 88 回合" [level=2] [ref=f1e628]
            - generic [aria-hidden] [ref=f1e629]: 第八十八回
            - generic [ref=f1e630]: 时间地点未记录
          - paragraph [ref=f1e632]: 第 88 回合，主角在河边散步，观察水面。
        - article [ref=f1e633]:
          - generic [ref=f1e634]:
            - heading "第 89 回合" [level=2] [ref=f1e635]
            - generic [aria-hidden] [ref=f1e636]: 第八十九回
            - generic [ref=f1e637]: 时间地点未记录
          - paragraph [ref=f1e639]: 第 89 回合，主角在河边散步，观察水面。
        - article [ref=f1e640]:
          - generic [ref=f1e641]:
            - heading "第 90 回合" [level=2] [ref=f1e642]
            - generic [aria-hidden] [ref=f1e643]: 第九十回
            - generic [ref=f1e644]: 时间地点未记录
          - paragraph [ref=f1e646]: 第 90 回合，主角在河边散步，观察水面。
        - article [ref=f1e647]:
          - generic [ref=f1e648]:
            - heading "第 91 回合" [level=2] [ref=f1e649]
            - generic [aria-hidden] [ref=f1e650]: 第九十一回
            - generic [ref=f1e651]: 时间地点未记录
          - paragraph [ref=f1e653]: 第 91 回合，主角在河边散步，观察水面。
        - article [ref=f1e654]:
          - generic [ref=f1e655]:
            - heading "第 92 回合" [level=2] [ref=f1e656]
            - generic [aria-hidden] [ref=f1e657]: 第九十二回
            - generic [ref=f1e658]: 时间地点未记录
          - paragraph [ref=f1e660]: 第 92 回合，主角在河边散步，观察水面。
        - article [ref=f1e661]:
          - generic [ref=f1e662]:
            - heading "第 93 回合" [level=2] [ref=f1e663]
            - generic [aria-hidden] [ref=f1e664]: 第九十三回
            - generic [ref=f1e665]: 时间地点未记录
          - paragraph [ref=f1e667]: 第 93 回合，主角在河边散步，观察水面。
        - article [ref=f1e668]:
          - generic [ref=f1e669]:
            - heading "第 94 回合" [level=2] [ref=f1e670]
            - generic [aria-hidden] [ref=f1e671]: 第九十四回
            - generic [ref=f1e672]: 时间地点未记录
          - paragraph [ref=f1e674]: 第 94 回合，主角在河边散步，观察水面。
        - article [ref=f1e675]:
          - generic [ref=f1e676]:
            - heading "第 95 回合" [level=2] [ref=f1e677]
            - generic [aria-hidden] [ref=f1e678]: 第九十五回
            - generic [ref=f1e679]: 时间地点未记录
          - paragraph [ref=f1e681]: 第 95 回合，主角在河边散步，观察水面。
        - article [ref=f1e682]:
          - generic [ref=f1e683]:
            - heading "第 96 回合" [level=2] [ref=f1e684]
            - generic [aria-hidden] [ref=f1e685]: 第九十六回
            - generic [ref=f1e686]: 时间地点未记录
          - paragraph [ref=f1e688]: 第 96 回合，主角在河边散步，观察水面。
        - article [ref=f1e689]:
          - generic [ref=f1e690]:
            - heading "第 97 回合" [level=2] [ref=f1e691]
            - generic [aria-hidden] [ref=f1e692]: 第九十七回
            - generic [ref=f1e693]: 时间地点未记录
          - paragraph [ref=f1e695]: 第 97 回合，主角在河边散步，观察水面。
        - article [ref=f1e696]:
          - generic [ref=f1e697]:
            - heading "第 98 回合" [level=2] [ref=f1e698]
            - generic [aria-hidden] [ref=f1e699]: 第九十八回
            - generic [ref=f1e700]: 时间地点未记录
          - paragraph [ref=f1e702]: 第 98 回合，主角在河边散步，观察水面。
        - article [ref=f1e703]:
          - generic [ref=f1e704]:
            - heading "第 99 回合" [level=2] [ref=f1e705]
            - generic [aria-hidden] [ref=f1e706]: 第九十九回
            - generic [ref=f1e707]: 时间地点未记录
          - paragraph [ref=f1e709]: 第 99 回合，主角在河边散步，观察水面。
        - article [ref=f1e710]:
          - generic [ref=f1e711]:
            - heading "第 100 回合" [level=2] [ref=f1e712]
            - generic [aria-hidden] [ref=f1e713]: 第一百回
            - generic [ref=f1e714]: 时间地点未记录
          - paragraph [ref=f1e716]: 第 100 回合，主角在河边散步，观察水面。
          - generic [ref=f1e717]:
            - button "本回合变化 不可用" [disabled] [ref=f1e718]:
              - generic [ref=f1e719]: 本回合变化
              - generic [ref=f1e720]: 不可用
              - generic [aria-hidden] [ref=f1e721]: ▼
            - status [ref=f1e722]: 本回合没有可对比的结算前记录
        - paragraph [ref=f1e723]: 行动建议将在正文生成后显示。
      - generic [ref=f1e724]:
        - region "三阶段工作流" [ref=f1e726]:
          - button "三阶段工作流详情" [ref=f1e729] [cursor=pointer]:
            - status [ref=f1e734]:
              - generic [ref=f1e735]: 三阶段 ·
              - text: 草稿不可用 · 查看详情
            - generic [ref=f1e736]: 详情 ›
        - generic [ref=f1e737]:
          - generic [ref=f1e739]:
            - button "撤回" [disabled] [ref=f1e740]:
              - generic [aria-hidden] [ref=f1e741]: 撤
            - button "生成开局正文" [disabled] [ref=f1e742]:
              - generic [aria-hidden] [ref=f1e743]: 续
          - generic [ref=f1e744]: 你的行动
          - textbox "你的行动" [ref=f1e745]:
            - /placeholder: 填写你的行动
          - button "发送" [disabled] [ref=f1e747]
        - status [ref=f1e748]: 没有可执行的回合草稿。请重新读取存档；暂时无法生成或结算。
    - navigation "底部导航" [ref=f1e749]:
      - button "故事" [ref=f1e750] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e751]: 文
        - text: 故事
      - button "人物" [ref=f1e752] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e753]: 我
        - text: 人物
      - button "世界资料" [ref=f1e754] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e755]: 世
        - text: 世界资料
      - button "设置" [ref=f1e756] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e757]: 设
        - text: 设置
    - dialog [ref=f1e758]:
      - generic [ref=f1e761]:
        - generic [aria-hidden] [ref=f1e762]: 设
        - generic [ref=f1e763]:
          - paragraph [aria-hidden] [ref=f1e764]: SYSTEM · 系统
          - heading "设置" [level=2] [ref=f1e765]
        - button "关闭资料界面" [ref=f1e766] [cursor=pointer]:
          - text: 关闭
          - generic [aria-hidden] [ref=f1e767]: ×
      - generic [ref=f1e770]:
        - button "返回设置" [ref=f1e771] [cursor=pointer]: ‹ 设置
        - heading "提示词" [level=3] [ref=f1e772]
        - paragraph [ref=f1e773]: 七项叙事偏好用于下一次正文请求的提示词与输出校验。
        - generic [ref=f1e774]:
          - generic [ref=f1e775]:
            - text: 叙事人称
            - combobox "叙事人称" [ref=f1e776]:
              - option "第一人称"
              - option "第二人称"
              - option "第三人称" [selected]
          - generic [ref=f1e777]:
            - text: 剧情风格
            - combobox "剧情风格" [ref=f1e778]:
              - option "一般" [selected]
          - group "正文篇幅" [ref=f1e779]:
            - generic [ref=f1e781]:
              - radiogroup "正文篇幅档位" [ref=f1e782]:
                - generic [ref=f1e783] [cursor=pointer]:
                  - radio "低 1,000～2,000 字" [checked] [ref=f1e784]
                  - strong [ref=f1e785]: 低
                  - generic [ref=f1e786]: 1,000～2,000 字
                - generic [ref=f1e787] [cursor=pointer]:
                  - radio "中 4,000～5,000 字" [ref=f1e788]
                  - strong [ref=f1e789]: 中
                  - generic [ref=f1e790]: 4,000～5,000 字
                - generic [ref=f1e791] [cursor=pointer]:
                  - radio "高 8,000～10,000 字" [ref=f1e792]
                  - strong [ref=f1e793]: 高
                  - generic [ref=f1e794]: 8,000～10,000 字
                - generic [ref=f1e795] [cursor=pointer]:
                  - radio "自定义 自己填写" [ref=f1e796]
                  - strong [ref=f1e797]: 自定义
                  - generic [ref=f1e798]: 自己填写
              - generic [ref=f1e799]:
                - generic [ref=f1e800]:
                  - text: 正文最低字数
                  - spinbutton "正文最低字数" [ref=f1e801]: "1000"
                - generic [ref=f1e802]:
                  - text: 正文建议上限
                  - spinbutton "正文建议上限" [ref=f1e803]: "2000"
              - paragraph [ref=f1e804]: 最低字数由程序硬性检查，不够会判失败并重写；建议上限只告诉模型写到这里收尾，写多了也照常通过。
          - generic [ref=f1e805] [cursor=pointer]:
            - checkbox "NoControl（防抢话）" [checked] [ref=f1e806]
            - text: NoControl（防抢话）
          - generic [ref=f1e807] [cursor=pointer]:
            - checkbox "自然文风修复" [checked] [ref=f1e808]
            - text: 自然文风修复
          - generic [ref=f1e809] [cursor=pointer]:
            - checkbox "行动选项" [checked] [ref=f1e810]
            - text: 行动选项
          - generic [ref=f1e811] [cursor=pointer]:
            - checkbox "真实世界模式" [checked] [ref=f1e812]
            - text: 真实世界模式
        - generic [ref=f1e813]:
          - status [ref=f1e814]:
            - generic [aria-hidden] [ref=f1e815]: 成
            - generic [ref=f1e816]: 本地偏好已保存，将用于下一次生成尝试；不会改写进行中的请求或已保存草稿。
          - button "保存本地设置" [active] [ref=f1e817] [cursor=pointer]
```

# Test source

```ts
  1  | import { expect,test } from './helpers/test';
  2  | 
  3  | test('调查：仅保存剧情风格是否唤醒已有自动记忆任务',async({page},info)=>{
  4  |   let calls=0;
  5  |   const summary=JSON.stringify({summary:'已记录的散步与约定。',importantEvents:['与陈宁约定见面并保管蓝色钥匙。']});
  6  |   await page.route('https://pr187-memory-toggle.mock.invalid/**',async route=>{
  7  |     const headers={'access-control-allow-origin':'*','access-control-allow-headers':'authorization, content-type','access-control-allow-methods':'POST, OPTIONS'};
  8  |     if(route.request().method()==='OPTIONS'){await route.fulfill({status:204,headers});return;}
  9  |     expect(route.request().postDataJSON().model).toBe('memory');
  10 |     calls++;
  11 |     await route.fulfill({headers,contentType:'application/json',body:JSON.stringify({choices:[{message:{content:summary},finish_reason:'stop'}]})});
  12 |   });
  13 |   await page.goto('/');
  14 |   await page.evaluate(async()=>{
  15 |     const f='/src/tests/fixtures/compression.ts',r='/src/services/storage/saveRepository.ts',s='/src/ui/settings/model.ts',
  16 |       c='/src/services/ai/configuration.ts',v='/src/services/ai/credentials.ts';
  17 |     const {compressionState}=await import(f),{SaveRepository}=await import(r),{defaultSettings,settingsKey}=await import(s),
  18 |       {defaultAiConfig,newChannel,saveAiConfig}=await import(c),{CredentialVault}=await import(v);
  19 |     const state=compressionState('short',100),repo=await SaveRepository.open();repo.close();
  20 |     await new Promise<void>((resolve,reject)=>{
  21 |       const request=indexedDB.open('heijinwangchao');request.onerror=()=>reject(request.error);
  22 |       request.onsuccess=()=>{const db=request.result,tx=db.transaction('saves','readwrite');tx.objectStore('saves').put(state);
  23 |         tx.oncomplete=()=>{db.close();resolve();};tx.onabort=()=>{db.close();reject(tx.error);};};
  24 |     });
  25 |     const settings=defaultSettings();settings.memory.summaries.short.automatic=true;
  26 |     settings.memory.summaries.medium.automatic=false;settings.memory.summaries.npc.automatic=false;
  27 |     localStorage.setItem(settingsKey,JSON.stringify(settings));
  28 |     const config=defaultAiConfig(),channel=newChannel();channel.baseUrl='https://pr187-memory-toggle.mock.invalid/v1';
  29 |     config.channels=[channel];config.routes.story={channelId:channel.id,modelId:'unused-story'};
  30 |     config.routes.memory={mode:'independent',channelId:channel.id,modelId:'memory'};
  31 |     saveAiConfig(localStorage,config);new CredentialVault(sessionStorage,localStorage).set(channel.id,'pr187-mock-memory-secret');
  32 |   });
  33 |   // 种子设置先在首页刷新加载，避免同文档 hash 路由仍使用旧的 React 设置对象。
  34 |   await page.reload();
  35 |   await page.goto('/#game/save-a');
  36 |   await expect(page.locator('.game-layout')).toBeVisible();
  37 |   const mediumCount=()=>page.evaluate(async()=>{const p='/src/services/storage/saveRepository.ts',{SaveRepository}=await import(p),r=await SaveRepository.open();try{return(await r.load('save-a')).memories.medium.length;}finally{r.close();}});
  38 |   await expect.poll(mediumCount).toBe(1);expect(calls).toBe(1);
  39 |   const beforeSettings=await page.evaluate(()=>JSON.parse(localStorage.getItem('heijin.settings.v1')!));
  40 |   const started=Date.now();
  41 |   const menu=page.getByRole('button',{name:'打开游戏菜单',exact:true});
  42 |   if(await menu.isVisible())await menu.click();
  43 |   await page.getByRole('button',{name:'设置',exact:true}).first().click();
  44 |   const root=page.getByRole('dialog',{name:'设置',exact:true});
  45 |   const back=root.getByRole('button',{name:'返回设置',exact:true});if(await back.isVisible())await back.click();
  46 |   await root.getByRole('button',{name:'提示词',exact:true}).click();
  47 |   const group=root.getByRole('radiogroup',{name:'剧情风格'});
  48 |   const hasStyles=await group.isVisible();
  49 |   if(hasStyles)await group.getByRole('radio',{name:'冷硬黑色',exact:true}).check();
  50 |   expect(calls).toBe(1);
  51 |   await root.getByRole('button',{name:'保存本地设置',exact:true}).click();
  52 |   await expect(root.getByRole('status')).toContainText('本地偏好已保存');
  53 |   const afterSettings=await page.evaluate(()=>JSON.parse(localStorage.getItem('heijin.settings.v1')!));
  54 |   expect(afterSettings).toEqual(hasStyles?{...beforeSettings,prompts:{...beforeSettings.prompts,style:'noir'}}:beforeSettings);
  55 |   // 观察第二次实际 Mock 请求与合法总结保存，不修改正式代码去触发它。
  56 |   await expect.poll(()=>calls).toBe(2);
  57 |   await expect.poll(mediumCount).toBe(2);
  58 |   expect(Date.now()-started).toBeLessThan(20_000);
  59 |   await page.screenshot({path:info.outputPath('style-save-wakes-memory.png'),animations:'disabled'});
  60 |   await info.attach('observation',{body:JSON.stringify({before:1,after:calls,hasStyles,mediumAfter:await mediumCount(),elapsed:Date.now()-started}),contentType:'application/json'});
  61 |   // 产品要求：只保存风格不应增加模型请求。观测到 2 时，此安全验收必须报红。
> 62 |   expect(calls).toBe(1);
     |                 ^ Error: expect(received).toBe(expected) // Object.is equality
  63 | });
  64 | 
```